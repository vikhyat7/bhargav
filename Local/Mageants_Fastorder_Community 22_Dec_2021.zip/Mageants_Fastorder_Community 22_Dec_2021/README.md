# Wholesale fast order

	Current version number: 2.0.8
	Date :- 31/05/2021
	************************************************************
    Bug fixed
	************************************************************
	-  When customer added some products from the fast order page & page refreshed without adding those products to the cart, all added products were gone from the fast order list. Mageants team fixed this issue. Now products are selected even after the page refresh. This works fine in all Magento versions.

	************************************************************
    File list
	************************************************************
	Mageants/FastOrder/etc/module.xml
	Mageants/FastOrder/etc/composer.json
	Mageants/FastOrder/view/frontend/templates/fastorder.phtml
	Mageants/FastOrder/view/frontend/web/js/fastorder.js
	Mageants/FastOrder/view/frontend/web/js/fastorder-swatch.js
	Mageants/FastOrder/view/frontend/web/js/grouped.js
	Mageants/FastOrder/view/frontend/web/js/select-option.js

	************************************************************
    New file added
	************************************************************
	Mageants/FastOrder/Controller/Index/PageLoad.php

************************************************************************************************************************************************************************************

	Current version number: 2.0.7
	Date :- 09/07/2020
	************************************************************
    Bug fixed
	************************************************************
	- When admin run setup:di:compile command when install Magento 2 wholesale fast order extension in particular Magento2.3.5-P1 version then it's showing error, MageAnts team resolved issue in and working fine in all magento version.

	************************************************************
    File list
	************************************************************
	- Mageants/FastOrder/Block/Product/View/Options/Type/Select.php
	- Mageants/FastOrder/composer.json
	- Mageants/FastOrder/etc/module.xml

************************************************************************************************************************************************************************************

	Current version number: 2.0.6
	Date :- 14/10/2019
	************************************************************
    Bug fixed
	************************************************************
	- When admin disable extension for particular not login customer but when general user logout then also fast order display in frontend. issue solve in all magento version.

	************************************************************
    File list
	************************************************************
	- Mageants/FastOrder/Controller/Index/Index.php
	- Mageants/FastOrder/composer.json
	- Mageants/FastOrder/etc/module.xml

************************************************************************************************************************************************************************************


	Current version number: 2.0.5
	Date :- 04/04/2019
	************************************************************
    Bug fixed
	************************************************************
	- When admin disable module for retail customer then it is also display retail customer.
	- When user have not more add line then it is not display any message, now add message when user have not more lines.
	- When admin add tier price in configurable then it display regular price in wholesale fast order extension, now tier price working in wholesale fast order extension.
	- When user add more product using Csv file then available lines then not display any message, now issue fixed and working fine in all magento version. 

*********************************************************************************************************************************

	Current version number: 2.0.4
	Date :- 11/03/2019
	************************************************************
    Bug fixed
	************************************************************
	- MageAnts update Wholesale fast order extension in latest magento2.3 version, Now extension working with all magento version.

*********************************************************************************************************************************

	Current version number: 2.0.4
	Date :- 16/01/2019
	************************************************************
    Bug fixed
	************************************************************
	Update module version name in composer.json file same as module.xml file.


*********************************************************************************************************************************

	Current version number: 2.0.4
	Date :- 06/12/2018
	************************************************************
    Bug fixed
	************************************************************
	- When user add configurable product using wholesale fast order after user want to edit this product then configurable product display in popup with cancel and submit button, but user want to cancel it then product clear from wholesale page, now issue fixed in all magento version and user cancel this product then configurable product added with original option(First time added option).

	************************************************************
	File list
	************************************************************
	Mageants/FastOrder/view/frontend/templates/option.phtml
	Mageants/FastOrder/view/frontend/templates/grouped.phtml
	Mageants/FastOrder/view/frontend/templates/product/view/options/type/select.phtml
	Mageants/FastOrder/view/frontend/web/js/fastorder.js
	Mageants/FastOrder/view/frontend/web/js/select-option.js
	Mageants/FastOrder/view/frontend/web/js/fastorder-swatch.js
	Mageants/FastOrder/view/frontend/web/js/grouped.js

*********************************************************************************************************************************
	
	Current version number: 2.0.3
	Date :- 04/10/2018
	************************************************************
    Bug fixed
	************************************************************
	- If user set configuration like "Default Number of lines = 3" and "Max results to show = 10" then 'Add lines' button not working.
	- In Subtotal column not show proper price symbol in multi store view. it's always show dollar sign.
	- Image not set in product then it's not show Default Placeholder Image now all issue fixed and working fine.


	************************************************************
	File list
	************************************************************
	Mageants/FastOrder/view/frontend/web/js/fastorder.js
	Mageants/FastOrder/view/frontend/templates/fastorder.phtml
	Mageants/FastOrder/Controller/Index/Search.php

*********************************************************************************************************************************

	Current version number: 2.0.2
	Date :- 30/08/2018
	************************************************************
    Bug fixed
	************************************************************
	- Wholesale fast order working for Simple Product,Configurable product,Group product ,Downloadable Product,Virtual Product and Simple Product with custom option.
	- in a configuration one option Default Number of lines if user set 1 line then it's not working, always it display 2 line so this issue fixed.
	- in frontend side add new lines display for add more product then it's not working same as configuration. now it's working fine.
	- When user add group product then not any validation, now we add validation over there.
	-  When user add any product and change qty to null(0) then click on add to cart not any validation, so now add validation like "Please specify the quantity of product(s)"
	- when user add product using csv file but if any product with quantity zero(0) then this product not added. this issue fixed now.

*********************************************************************************************************************************

	Current version number: 2.0.1
	Date :- 11/07/2018
	************************************************************
    Bug fixed
	************************************************************
	- When user select wholesale option from configurable then extension not working for wholesale user, now this issue fixed.
	- Also not validation are there when user without select any product and click on add to card then form is submit and 
	  message display product add to cart successfully. so now this issue also fixed.
	- For Magento 2.1.X -> when user run di:compile command was giving error about pageConfig class exist in context, so this Issue fixed now.
	
	************************************************************
	File list
	************************************************************
	Mageants\FastOrder\Block\FastOrder.php
	Mageants\FastOrder\Controller\Index\Add.php