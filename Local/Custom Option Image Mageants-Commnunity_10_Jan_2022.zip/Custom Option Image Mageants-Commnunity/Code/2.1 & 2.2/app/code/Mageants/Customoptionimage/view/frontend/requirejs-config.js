var config = {
    map: {
        '*': {
            mageants_preview_dropdown: 'Mageants_Customoptionimage/js/image_preview_dropdown',
            mageants_preview_multiple: 'Mageants_Customoptionimage/js/image_preview_multiple',
            mageants_preview_radio: 'Mageants_Customoptionimage/js/image_preview_radio',
            mageants_preview_checkbox: 'Mageants_Customoptionimage/js/image_preview_checkbox',
            mageants_preview_static_select: 'Mageants_Customoptionimage/js/image-preview-static'
        }
    }
};
