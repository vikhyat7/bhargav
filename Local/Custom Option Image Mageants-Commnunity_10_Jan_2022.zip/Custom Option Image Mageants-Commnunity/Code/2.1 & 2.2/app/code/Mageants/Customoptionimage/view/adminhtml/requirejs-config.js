var config = {
    map: {
        '*': {
            mageants_custoption_m200: 'Mageants_Customoptionimage/js/mageants_custoption_m200'
        }
    }
};