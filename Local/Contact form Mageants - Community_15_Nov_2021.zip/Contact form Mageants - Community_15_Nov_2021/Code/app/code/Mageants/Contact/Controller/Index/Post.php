<?php
/**
 * @category  Magento Contact
 * @package   Mageants_Contact
 * @copyright Copyright (c) 2017 Magento
 * @author    Mageants Team <support@mageants.com>
 */	
namespace Mageants\Contact\Controller\Index;

use Magento\Framework\App\Request\DataPersistorInterface;


class Post extends \Magento\Contact\Controller\Index\Post
{
    /**
     * Post action
     */	

	protected $inlineTranslation;

	

   //  public function __construct(\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig)
   // {
   //   $this->_scopeConfig = $scopeConfig;
   // }
    public function execute()
    {
		
		$isEnabled = $this->_objectManager->create('Mageants\Contact\Helper\Data')->getContactConfig('mageants_contact/contact/enabled');
		// echo $isEnabled;
		// exit;
		if($isEnabled)
		{		

			$data = $this->getRequest()->getPostValue(); 
			$model = $this->_objectManager->create('Mageants\Contact\Model\Contact');
		$_scopeConfig = $this->_objectManager->create('Magento\Framework\App\Config\ScopeConfigInterface');
		$messageManager = $this->_objectManager->create('Magento\Framework\Message\ManagerInterface');
	$inlineTranslation = $this->_objectManager->create('Magento\Framework\Translate\Inline\StateInterface');
			$model->setData($data);			
			if($model->save())
			{        		
				try {
					// echo"1hello";
					/* Send Email to Customer*/
					$storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
					$to = $data['email'];
					$templateVars = array(
										'name' => $data['name'],
										'message' => 'Thanks for the inquiry we will contact you  soon.',
										);
					$from = $_scopeConfig->getValue('contact/email/sender_email_identity', $storeScope);
					// echo"ttt";
					
					$templateOptions = array('area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $this->storeManager->getStore()->getId());

					$transport = $this->_transportBuilder
					->setTemplateIdentifier('send_email_email_template')
					->setTemplateOptions($templateOptions)
					->setTemplateVars($templateVars)
					->setFrom($from)
					->addTo($data['email'],$data['name'])
					->setReplyTo($_scopeConfig->getValue('contact/email/recipient_email', $storeScope))
					->getTransport();
					$transport->sendMessage(); 
					

					/* Email Sent  to Customer */
					
					/* Email Send to Admin */					
					$templateVars = array(
										'name' => $data['name'],
										'email' => $data['email'],
										'telephone' => $data['telephone'],
										'comment' => $data['comment'],
										);
					$from = $_scopeConfig->getValue('contact/email/sender_email_identity', $storeScope);	
					$templateOptions = array('area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $this->storeManager->getStore()->getId());						 
					$transport = $this->_transportBuilder
					->setTemplateIdentifier('send_email_admin_template')
					->setTemplateOptions($templateOptions)
					->setTemplateVars($templateVars)
					->setFrom($from)
					->addTo($_scopeConfig->getValue('contact/email/recipient_email', $storeScope))
					->setReplyTo($_scopeConfig->getValue('contact/email/recipient_email', $storeScope))
					->getTransport();
					$transport->sendMessage(); 					
					/* Email Sent to Admin */
					
					$messageManager->addSuccess(
						__('Thanks for contacting us with your comments and questions. We\'ll respond to you very soon.')
					);
					$this->_redirect('contact/index');
					return;				
				}
				catch (\Exception $e) {	
				// $inlineTranslation = $this->_objectManager->create('Mageants\Contact\Helper\Data')->getContactConfig('mageants_contact/contact/enabled');			
					$inlineTranslation->resume();
					$messageManager->addSuccess(
						__('Thanks for contacting us with your comments and questions. There are some mailing isseu so contact on '.$_scopeConfig->getValue('contact/email/recipient_email'))
					);
					// echo"hello";
					
					$this->_redirect('contact/index');
					return;
				}
			}
		}
		else
		{
			return parent::execute();
		}
	} 
}
