<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */
namespace Mageants\ProductLabels\Ui\Component\Listing\Column;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;
use Mageants\ProductLabels\Model\Plcategory;

/**
 * Category Page columns class
 */
class CategoryText extends Column
{

     /**
      * @var \Mageants\ProductLabels\Model\Plcategory
      */
    protected $_plcategory;

    /**
     * @param \Magento\Framework\View\Element\UiComponent\ContextInterface $context
     * @param \Magento\Framework\View\Element\UiComponentFactory $uiComponentFactory
     * @param Mageants\ProductLabels\Model\Plcategory $plcategory
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        Plcategory $plcategory,
        array $components = [],
        array $data = []
    ) {
        $this->_plcategory = $plcategory;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }
    
    /**
     * Prepare Data Source for account column
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as & $item) {
                if ($this->getData('name')=='category_page_text') {
                        $labels = $this->_plcategory->getCollection()->addFieldToFilter('plist_id', $item['pl_id']);

                }
                foreach ($labels as $label) {
                    $item[$this->getData('name')]=$label->getPlCatlabeltext();
                }
            }
        }
        return $dataSource;
    }
}
