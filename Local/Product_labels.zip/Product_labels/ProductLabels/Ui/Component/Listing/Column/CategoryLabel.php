<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */
namespace Mageants\ProductLabels\Ui\Component\Listing\Column;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;
use Mageants\ProductLabels\Model\Plcategory;
use Magento\Catalog\Helper\Image;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Category Page columns class
 */
class CategoryLabel extends Column
{
    /**
     * @var \Magento\Framework\View\Asset\Repository
     */
    protected $assetRepo;
    /**
     * @var constant string
     */
    const ALT_FIELD = 'title';

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Mageants\ProductLabels\Model\Plcategory
     */
    protected $_plcategory;

    /**
     * @param Magento\Framework\View\Element\UiComponent\ContextInterface $context
     * @param array $components
     * @param Magento\Framework\View\Element\UiComponentFactory $uiComponentFactory
     * @param Magento\Catalog\Helper\Image $imageHelper
     * @param Mageants\ProductLabels\Model\Plcategory $plcategory
     * @param Magento\Store\Model\StoreManagerInterface $storeManager
     * @param Magento\Framework\View\Asset\Repository $assetRepo
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        Image $imageHelper,
        Plcategory $plcategory,
        StoreManagerInterface $storeManager,
        \Magento\Framework\View\Asset\Repository $assetRepo,
        \Magento\Framework\Filesystem\Io\File $file,
        array $components = [],
        array $data = []
    ) {
        $this->storeManager = $storeManager;
        $this->imageHelper = $imageHelper;
        $this->_plcategory = $plcategory;
        $this->assetRepo = $assetRepo;
        $this->file = $file;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }
    
    /**
     * Prepare Data Source for account column
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as & $item) {
                     $url = '';
                if ($this->getData('name')=='category_page_label') {
                      $labels = $this->_plcategory->getCollection()->addFieldToFilter('plist_id', $item['pl_id']);

                }
                foreach ($labels as $label) {
                    $labelpath='';
                    if ($label->getPlCatlabeltyperadio()==0) {
                        $ext = $this->file->getPathInfo($label->getPlCatlabeltype());
                        $extension = $ext['extension'];
                        if ($extension == 'svg') {

                                $labelpath='productlabels/labels/';
                                $url = $this->assetRepo->getUrl(
                                    'Mageants_ProductLabels::images/productlabels/labels/'
                                ).'/'.$label->getPlCatlabeltype();
                        } else {
                            $labelpath='productlabels/category/tmp/';
                            $url = $this->storeManager->getStore()->getBaseUrl(
                                \Magento\Framework\UrlInterface::URL_TYPE_MEDIA
                            ).$labelpath.$label->getPlCatlabeltype();
                        }
                    } else {
                        $labelpath='productlabels/category/tmp/';
                        $url = $this->storeManager->getStore()->getBaseUrl(
                            \Magento\Framework\UrlInterface::URL_TYPE_MEDIA
                        ).$labelpath.$label->getPlCatlabeltype();
                    }
                }
                $item[$this->getData('name') . '_src'] = $url;
                $item[$this->getData('name') . '_alt'] = $this->getAlt($item) ?: '';
                $item[$this->getData('name') . '_orig_src'] = $url;
            }
        }
        return $dataSource;
    }

     /**
      * @param array $row
      *
      * @return null|string
      */
    protected function getAlt($row)
    {
        $altField = $this->getData('config/altField') ?: self::ALT_FIELD;
        return isset($row[$altField]) ? $row[$altField] : null;
    }
}
