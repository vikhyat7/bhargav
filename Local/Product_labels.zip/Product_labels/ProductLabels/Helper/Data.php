<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */
namespace Mageants\ProductLabels\Helper;

/**
 * Data class for Helper
 */
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * scope config
     *
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $_scopeConfig;

    /**
     * pl general
     *
     * @var \Mageants\ProductLabels\Model\Plgeneral
     */
    protected $_plgeneral;

    /**
     * pl product
     *
     * @var \Mageants\ProductLabels\Model\Plproduct
     */
    protected $_plproduct;

    /**
     * pl category
     *
     * @var \Mageants\ProductLabels\Model\Plcategory
     */
    protected $_plcategory;

    /**
     * pl conditions
     *
     * @var \Mageants\ProductLabels\Model\Plconditions
     */
    protected $_plconditions;

    /**
     * customer session
     *
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;
    
    /**
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Mageants\ProductLabels\Model\Plgeneral $plgeneral
     * @param \Mageants\ProductLabels\Model\Plproduct $plproduct
     * @param \Mageants\ProductLabels\Model\Plcategory $plcategory
     * @param \Mageants\ProductLabels\Model\Plconditions $plconditions
     * @param \Magento\Customer\Model\Session $customerSession
     */
    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Mageants\ProductLabels\Model\Plgeneral $plgeneral,
        \Mageants\ProductLabels\Model\Plproduct $plproduct,
        \Mageants\ProductLabels\Model\Plcategory $plcategory,
        \Mageants\ProductLabels\Model\Plconditions $plconditions,
        \Magento\Framework\Serialize\Serializer\Json $serializer = null,
        \Magento\Catalog\Model\CategoryFactory $categoryAll,
        \Magento\Inventory\Model\SourceItem $sourceItemInventory,
        \Magento\Customer\Model\Session $customerSession
    ) {
        $this->_scopeConfig = $scopeConfig;
        $this->_plgeneral=$plgeneral;
        $this->serializer = $serializer ?: \Magento\Framework\App\ObjectManager::getInstance()->get(
            \Magento\Framework\Serialize\Serializer\Json::class
        );
        $this->sourceItemInventory = $sourceItemInventory;
        $this->categoryAll = $categoryAll;
        $this->_plproduct = $plproduct;
        $this->_plcategory = $plcategory;
        $this->_plconditions = $plconditions;
        $this->_customerSession=$customerSession;
    }

    /**
     * @return Boolean
     */

    public function isEnabled()
    {
        return $this->_scopeConfig->getValue(
            'product_labels/general/enable',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * @return object
     */

    public function getProductLabelss()
    {
        $collection = $this->_plgeneral->getCollection()->addFieldToFilter(
            'pl_status',
            1
        )->setOrder(
            'pl_priority',
            'ASC'
        );
          $collection->getSelect()->join(
              'pl_product',
              // note this join clause!
              'main_table.pl_id = pl_product.plist_id',
              ['*']
          );

          $collection->getSelect()->join(
              'pl_condition',
              // note this join clause!
              'main_table.pl_id = pl_condition.plist_id',
              ['*']
          );
         return $collection;
    }

    /**
     * @return object
     */

    public function getCategoryLabel()
    {
        if ($this->isEnabled()) {
            $collection = $this->_plgeneral->getCollection()->addFieldToFilter(
                'pl_status',
                1
            )->setOrder(
                'pl_priority',
                'ASC'
            );
            $collection->getSelect()->join(
                'pl_category',
                // note this join clause!
                'main_table.pl_id = pl_category.plist_id',
                ['*']
            );

            $collection->getSelect()->join(
                'pl_condition',
                // note this join clause!
                'main_table.pl_id = pl_condition.plist_id',
                ['*']
            );
            return $collection;
        }
        return false;
    }

    /**
     * @return boolean
     */
    public function isValidCustomer($ids = '')
    {

        if ($ids!=='') {
            if ($this->_customerSession->isLoggedIn()) {
                if (strpos($ids, $this->_customerSession->getCustomerGroupId())!==false) {
                    return true;
                }
            } else {
                if (strpos($ids, '0')!==false) {
                    return true;
                }
                
            }
            return false;
        }
        return true;
    }

    /**
     * @return string
     */
    public function getOnsaleText()
    {
        $minText = $this->_scopeConfig->getValue(
            'product_labels/onsale/minamount',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        $minper = $this->_scopeConfig->getValue(
            'product_labels/onsale/minper',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        
        $rounding= $this->_scopeConfig->getValue(
            'product_labels/onsale/rouding_discount',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        $finalText='';
        if ($minText!='0') {
            $finalText.= $this->getRounding($rounding, $minText);
        }

        if ($minper!=='0') {
            if ($finalText!='') {
                $finalText.="-".$this->getRounding($rounding, $minper)."%";
            } else {
                $finalText= $this->getRounding($rounding, $minper);
            }
        }
        return $finalText;
    }

    /**
     * @return int
     */
    public function getRounding($rounding, $discount)
    {
        switch ($rounding) {
            case 'floor':
                $discount = floor($discount);
                break;
            case 'round':
                $discount = round($discount);
                break;
            case 'ceil':
                $discount = ceil($discount);
                break;
                
            default:
                $discount = round($discount);
                break;
        }
            return $discount;
    }

    /**
     * @return boolean
     */
    public function isValidatedDate()
    {
        return $this->_scopeConfig->getValue(
            'product_labels/isnew/useisnewcondition',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
    /**
     * @return boolean
     */
    public function useCreationDate()
    {
        return $this->_scopeConfig->getValue(
            'product_labels/isnew/isnewdate',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * Retrieve serialize setting
     *
     * @return array
     */
    public function serializeSetting($data)
    {
         return $this->serializer->serialize($data);
    }
        
    /**
     * Retrieve unserialize setting
     *
     * @return array
     */
    public function unserializeSetting($string)
    {
        $data['setting'] = [];
        
        if (!empty($string)) {
            return $this->serializer->unserialize($string);
        } else {
            return $data;
        }
    }
    /**
     * @return boolean
     */
    // @codingStandardsIgnoreStart
    public function getValidCondition($conditions = null, $product = null)
    {
        $value=1;
        $found=1;
        $aggregator = 'any';
        $attribute='';
        $operator='';
        $attrvalue='';
        $result=[];
        $categoryArray = [];
        
        if ($conditions!==null && $product !== null) {
            $serializedArray = $this->serializer->unserialize($conditions);
            
            foreach ($serializedArray as $serialize) {
                foreach ($serialize as $conds) {
                    if ($conds['type']== \Magento\SalesRule\Model\Rule\Condition\Combine::class) {
                                $value=$conds['value'];
                                $aggregator = $conds['aggregator'];
                    }
                    if ($conds['type']== \Magento\SalesRule\Model\Rule\Condition\Product\Found::class) {
                            $value=$conds['value'];
                            $aggregator = $conds['aggregator'];
                    }
                                
                    if ($conds['type']== \Magento\SalesRule\Model\Rule\Condition\Product::class) {

                          $attribute=$conds['attribute'];
                          $operator=$conds['operator'];
                          $attrvalue=$conds['value'];
                    }
                    if ($attribute!=='') {
                        if ($attribute=='category_ids') {
                            if ($operator=="==" || $operator=="()") {
                                $categoryArray = explode(',', $attrvalue);
                                if (in_array($product->getCategoryId(), $categoryArray)!==false) {
                                        $result[]=true;

                                } else {
                                    $result[]=false;

                                }
                                      
                            } elseif ($operator=="!=" || $operator=="!()") {
                                if (strpos($attrvalue, $product->getCategoryId()) === false) {
                                        $result[]=true;
                                } else {
                                    $result[]=false;
                                                                                        
                                }
                                      
                            } elseif ($operator=="<=") {
                                $result[]= ($attrvalue <= $product->getCategoryId() ? true : false);
                                                      
                            } elseif ($operator==">=") {
                                $result[]= ($attrvalue >= $product->getCategoryId() ? true : false);
                                                      
                            } elseif ($operator=="<") {
                                $result[]= ($attrvalue < $product->getCategoryId() ? true : false);
                                                      
                            } elseif ($operator==">") {
                                $result[]= ($attrvalue > $product->getCategoryId() ? true : false);
                                                      
                            }
                        }
                        if ($attribute=='sku') {
                            if ($operator=="==" || $operator=="()") {
                                if (strpos($attrvalue, $product->getSku())!==false) {
                                    $result[]=true;
                                } else {
                                     $result[]=false;

                                }

                            } elseif ($operator=="!=" || $operator=="!()") {
                                if (strpos($attrvalue, $product->getSku())===false) {
                                              $result[]=true;
                                } else {
                                    $result[]=false;

                                }
                            } elseif ($operator=="<=") {
                                if (is_numeric($attrvalue)) {
                                      $result[]= ($attrvalue <= $product->getSku() ? true : false);
                                }
                                                      
                            } elseif ($operator==">=") {
                                if (is_numeric($attrvalue)) {
                                        $result[]= ($attrvalue >= $product->getSku() ? true : false);
                                }
                                                      
                            } elseif ($operator=="<") {
                                if (is_numeric($attrvalue)) {
                                    $result[]= ($attrvalue < $product->getSku() ? true : false);
                                }
                                                      
                            } elseif ($operator==">") {
                                if (is_numeric($attrvalue)) {
                                    $result[]= ($attrvalue > $product->getSku() ? true : false);
                                }
                                                      
                            }
                                       
                        }
                        if ($attribute=='weight') {
                            if ($product->getWeight()==null) {
                                $result[]=false;
                            } elseif ($operator=="==" || $operator=="()") {
                                $result[]= ($product->getWeight() == $attrvalue ? true : false);

                            } elseif ($operator=="!=" || $operator=="!()") {
                                $result[]= ($product->getWeight() != $attrvalue ? true : false);
                            } elseif ($operator=="<=") {
                                $result[]= ($attrvalue <= $product->getWeight() ? true : false);
                                                      
                            } elseif ($operator==">=") {
                                $result[]= ($attrvalue >= $product->getWeight() ? true : false);
                            } elseif ($operator=="<") {
                                $result[]= ($attrvalue < $product->getWeight() ? true : false);
                            } elseif ($operator==">") {
                                $result[]= ($attrvalue > $product->getWeight() ? true : false);
                            }
                                       
                        }

                        if ($attribute=='attribute_set_id') {
                            if ($operator=="==" || $operator=="()") {
                                $result[]= ($product->getAttributeSetId() == $attrvalue ? true : false);
                                    
                            } elseif ($operator=="!=" || $operator=="!()") {
                                        $result[]= ($product->getAttributeSetId() != $attrvalue ? true : false);
                            } elseif ($operator=="<=") {
                                $result[]= ($product->getAttributeSetId() >= $attrvalue ? true : false);
                            } elseif ($operator==">=") {
                                $result[]= ($product->getAttributeSetId() <= $attrvalue ? true : false);
                            } elseif ($operator=="<") {
                                $result[]= ($product->getAttributeSetId() > $attrvalue ? true : false);
                            } elseif ($operator==">") {
                                $result[]= ($product->getAttributeSetId() < $attrvalue ? true : false);
                            }

                        }
                                  
                    }
                              
                    if ($product->getCustomAttribute($attribute)!==null) {
                          $attr= $product->getCustomAttribute($attribute)->getValue();
                        if ($operator=="==" || $operator=="()") {
                            if (is_array($attr)) {

                                if (in_array($attrvalue, $attr) || in_array($attrvalue, $attr)) {
                                              
                                    $result[]= true;
                                }
                            } elseif ($product->getCustomAttribute($attribute)->getValue() == $attrvalue) {
                                $result[]= true;
                            } else {
                                $result[]=false;
                            }
                        }
                        if ($operator=="!=" || $operator=='!()') {
                            if (is_array($attr)) {

                                if (!in_array($attrvalue, $attr)) {
                                              
                                          $result[]= true;
                                }
                            } elseif ($product->getCustomAttribute($attribute)->getValue() == $attrvalue) {
                                $result[]= true;
                            } else {
                                $result[]=false;
                            }
                        } elseif ($operator=="<=") {
                            if (!is_array($attr)) {
                                $result[]= ($product->getCustomAttribute($attribute)
                                  ->getValue() >= $attrvalue ? true : false);
                            }
                        } elseif ($operator==">=") {
                            if (!is_array($attr)) {
                                $result[]= ($product->getCustomAttribute($attribute)
                                  ->getValue() <= $attrvalue ? true : false);
                            }
                        } elseif ($operator==">") {
                            if (!is_array($attr)) {
                                 $result[]= ($product->getCustomAttribute(
                                     $attribute
                                 )->getValue() < $attrvalue ? true : false);
                            }
                                      
                        } elseif ($operator    =="<") {
                            if (!is_array($attr)) {
                                 $result[]= ($product->getCustomAttribute(
                                     $attribute
                                 )->getValue() > $attrvalue ? true : false);
                            }
                                      
                        }
                    }
                }
            }
        }

        if ($aggregator=='all') {
            if ($value) {

                if (in_array('', $result)) {
                    return false;
                }
                return true;
            }
            if (!$value) {
                if (in_array(true, $result)) {

                    return false;
                }
                return true;
            }
        }

        if ($aggregator=='any') {
            if ($value) {
                if (in_array(true, $result)) {
                    return true;
                }
                return false;
            }
            if (!$value) {
                if (in_array('', $result)) {
                    return true;
                }
                return false;
            }
        }
    }
    // @codingStandardsIgnoreEnd
    public function getStockInventoryForConfigProduct($sku = '')
    {
        $totalQty=0;
        $likeField = 'sku';
        $likeArray = ['like' => $sku.'%'];
        $data = $this->sourceItemInventory->getCollection()
                                          ->addFieldToFilter($likeField, $likeArray)
                                          ->getData();
        foreach ($data as $value) {
            $totalQty  += $value['quantity'];
        }

        return $totalQty;
    }

    public function getAllChildCategory($categoryID = '')
    {
        $childid=[(string)$categoryID];
        $category = $this->categoryAll->create()->load($categoryID);
        //Get category collection
        $collection = $category->getCollection()
                               ->addAttributeToSelect('entity_id')
                               ->addIsActiveFilter()
                               ->addOrderField('name')
                               ->addIdFilter($category->getChildren());
        
        if (count($collection->getItems()) >0) {
            foreach ($collection->getItems() as $item) {
                   $childid[] = $item->getEntityId();
                   $subChildData = $item->getChildrenCategories()->getItems();
                if (count($subChildData)>0) {
                    foreach ($item->getChildrenCategories()->getItems() as $children) {
                        $childid[] = $children->getEntityId();
                    }

                }
            }
        }
        asort($childid);
           return implode(",", $childid);
    }
}
