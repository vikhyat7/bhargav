 /**
 * Mageants ProductLabels Magento2 Extension                           
 */
var config = {
    map: {
        '*': {
            'mage/gallery/gallery.html': 'Mageants_ProductLabels/lib/mage/gallery/gallery.html',
            'mage/gallery/gallery': 'Mageants_ProductLabels/lib/mage/gallery/gallery'
        }
    }
};