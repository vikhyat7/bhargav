 /**
 * Mageants ProductLabels Magento2 Extension                           
 */
var config = {
    map: {
        '*': {
            categorylabel: 'Mageants_ProductLabels/js/categorylabel',
            productlabels: 'Mageants_ProductLabels/js/productlabels',
            'Magento_Ui/js/form/element/file-uploader':'Mageants_ProductLabels/js/form/element/file-uploader'
        }
    }
};