define([
    'underscore',
    'uiRegistry',
    'Magento_Ui/js/form/element/select',
    'Magento_Ui/js/modal/modal'
], function (_, uiRegistry, select, modal) {
    'use strict';

    return select.extend({

        /**
         * On value change handler.
         *
         * @param {String} value
         */
        onUpdate: function (value) {

            var labelupload = uiRegistry.get('index = pl_labeltype_upload');
            if (labelupload.visibleValue == value) {
                labelupload.show();
                jQuery(".image-labels-section").closest("div").hide();
            } else {
                labelupload.hide();
                jQuery(".image-labels-section").closest("div").show();
            }

            return this._super();
        },
    });
});