define([
    'underscore',
    'uiRegistry',
    'Magento_Ui/js/form/element/select',
    'Magento_Ui/js/modal/modal'
], function (_, uiRegistry, select, modal) {
    'use strict';

    return select.extend({

        /**
         * On value change handler.
         *
         * @param {String} value
         */
        onUpdate: function (value) {
            var customer = uiRegistry.get('index = customer_group_ids');
            if (customer.visibleValue == value) {
                customer.show();
            } else {
                customer.hide();
            }

            
            return this._super();
        },
    });
});