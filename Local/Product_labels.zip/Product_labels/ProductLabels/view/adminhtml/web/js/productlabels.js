/**
  * Mageants ProductLabels Magento2 Extension                           
*/
require(["jquery","productlabels"], function($) {
        	jQuery(document).ready(function(){
			  jQuery(".pl-bg").click(function(){
			  	jQuery(this).siblings("input").attr('checked',true);
			  	var imgsrc = jQuery(this).siblings("input").val();
			  	var img = jQuery(".produtlabelurl").val() + imgsrc;
			  	jQuery(".imagebox").attr('src',img);
			  });
			  jQuery(".position").click(function(){
			  	if(jQuery(".product_label_select").find("#2").attr('checked')=='checked' || jQuery(".product_label_select").find("#4").attr('checked')=='checked'){
			 	 	if(jQuery(".product-label-bg").find('img').attr('src')!==undefined || jQuery(".preview-image").attr('src')!==null){
			  			jQuery(".imagebox").attr('src',jQuery(".product-label-bg").find('img').attr('src'));	
			  		}
			  	}	
			  	jQuery(this).children("label").children("input").attr('checked',true);
			  	var pos = jQuery(this).children("label").children("input").val();
			    jQuery(this).css('background-color','rgb(186,64,0)').siblings('.position').css('background-color','#fff')	
			  	 
			  	 jQuery('.image-box').attr('style',getLabelPosition(pos));
			    
 			  });
 			  jQuery(".product_label_text").find("input").blur(function(){
				jQuery(".imagelabel").text(jQuery(this).val());
			 });

 			 jQuery(".product_label_size").find("input").blur(function(){
 			 	jQuery(".image-box").css('width',jQuery(this).val());
			 });
			 jQuery(".product_text_size").find("input").blur(function(){
			 	jQuery(".imagelabel").css('font-size', jQuery(this).val());
			 });
			  jQuery(".product_label_style").find("textarea").blur(function(){
			  	jQuery(".image-with-label").attr('style', jQuery(this).val());
			 });
			    jQuery(".product_label_color").find("input").blur(function(){
			  	jQuery(".imagelabel").css('color', jQuery(this).val());
			 });

			})
        	
			function getLabelPosition(pos){
				//var position= new array();
				switch(pos) {
				    case '1':
				        position='left:0px; top:0px;';
				        break;
				    case '2':
				    	position='left:95px; top:0px;';
				        break;
				     case '3':
				     position='left:195px; top:0px;';
				        break;
				     case '4':
				     position='left:0px; top:80px;';
				        break;   
				    case '5':
				     position='left:95px; top:80px;';
				        break;   
				     case '6':
				     position='left:195px; top:80px;';
				        break;         
				      case '7':
				     position='left:0px; bottom:0px;';
				        break;         
				         case '8':
				     position='left:95px; bottom:0px;';
				        break;         
				      case '9':
				     position='left:195px; bottom:0px;';
				        break;            
				      
				    default:
				    position='left:0px; top:0px;';
				        break;
				}
				return position;

			}
   });
