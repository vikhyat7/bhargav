/**
  * Mageants ProductLabels Magento2 Extension                           
*/
require(["jquery","categorylabel"], function($) {
        	jQuery(document).ready(function(){
			   jQuery(".catbg").click(function(){
				jQuery(this).siblings("input").attr('checked',true);
			  	var imgsrc = jQuery(this).siblings("input").val();
			  	jQuery(".catimagebox").attr('src',jQuery(".catlabelurl").val() + jQuery(this).siblings("input").val());
 			  });

			  jQuery(".catposition").click(function(){
			  	if(jQuery(".cat_label_option").find("#2").attr('checked')=="checked" || jQuery(".cat_label_option").find("#4").attr('checked')=="checked"){
			  		if(jQuery(".cat_label_option").find('img').attr('src')!==undefined || jQuery(".preview-image").attr('src')!==null){
			  		jQuery(".catimagebox").attr('src',jQuery(".product-labelcat-bg").find('img').attr('src'));	
			  		}
			  	}	
			  	jQuery(this).children("label").children("input").attr('checked',true);
			  	var pos = jQuery(this).children("label").children("input").val();
			    jQuery(this).css('background-color','rgb(186,64,0)').siblings('.catposition').css('background-color','#fff')	
			  	 jQuery('.cat-image-box').attr('style',getLabelPosition(pos));
 			  });
 			  jQuery(".cat_label_text").find("input").blur(function(){
				jQuery(".catimagelabel").text(jQuery(this).val());
			 });
        	jQuery(".cat_label_size").find("input").blur(function(){
				jQuery(".image-with-catlabel").css('width', jQuery(this).val());
			 });
        	jQuery(".cat_text_size").find("input").blur(function(){
        		jQuery(".catimagelabel").css('font-size', jQuery(this).val());
			 });
        	jQuery(".cat_text_style").find("textarea").blur(function(){
        		jQuery(".image-with-catlabel").attr('style', jQuery(this).val());
			 });
        	jQuery(".product_label_catcolor").find("input").blur(function(){
        		jQuery(".catimagelabel").css('color', jQuery(this).val());
			 });
			})
        	
			function getLabelPosition(pos){
				//var position= new array();
				switch(pos) {
				    case '1':
				        position='left:0px; top:0px;';
				        break;
				    case '2':
				    	position='left:95px; top:0px;';
				        break;
				     case '3':
				     position='left:195px; top:0px;';
				        break;
				     case '4':
				     position='left:0px; top:80px;';
				        break;   
				    case '5':
				     position='left:95px; top:80px;';
				        break;   
				     case '6':
				     position='left:195px; top:80px;';
				        break;         
				      case '7':
				     position='left:0px; bottom:0px;';
				        break;         
				         case '8':
				     position='left:95px; bottom:0px;';
				        break;         
				      case '9':
				     position='left:195px; bottom:0px;';
				        break;            
				      
				    default:
				    position='left:0px; top:0px;';
				        break;
				}
				return position;


			}
   });
