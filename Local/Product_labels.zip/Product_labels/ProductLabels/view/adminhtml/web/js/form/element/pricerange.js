define([
    'underscore',
    'uiRegistry',
    'Magento_Ui/js/form/element/select',
    'Magento_Ui/js/modal/modal'
], function (_, uiRegistry, select, modal) {
    'use strict';

    return select.extend({

        /**
         * On value change handler.
         *
         * @param {String} value
         */
        onUpdate: function (value) {
            var byprice = uiRegistry.get('index = pl_by_range');
            if (byprice.visibleValue == value) {
                byprice.show();
            } else {
                byprice.hide();
            }

            var minprice = uiRegistry.get('index = pl_min_price');
            if (minprice.visibleValue == value) {
                minprice.show();
            } else {
                minprice.hide();
            }

            var maxprice = uiRegistry.get('index = pl_max_price');
            if (maxprice.visibleValue == value) {
                maxprice.show();
            } else {
                maxprice.hide();
            }

            return this._super();
        },
    });
});