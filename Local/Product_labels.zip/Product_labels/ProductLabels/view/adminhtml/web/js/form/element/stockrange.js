define([
    'underscore',
    'uiRegistry',
    'Magento_Ui/js/form/element/select',
    'Magento_Ui/js/modal/modal'
], function (_, uiRegistry, select, modal) {
    'use strict';

    return select.extend({

        /**
         * On value change handler.
         *
         * @param {String} value
         */
        onUpdate: function (value) {
            var minstock = uiRegistry.get('index = pl_min_stock');
            if (minstock.visibleValue == value) {
                minstock.show();
            } else {
                minstock.hide();
            }

            var maxstock = uiRegistry.get('index = pl_max_stock');
            if (maxstock.visibleValue == value) {
                maxstock.show();
            } else {
                maxstock.hide();
            }

            return this._super();
        },
    });
});