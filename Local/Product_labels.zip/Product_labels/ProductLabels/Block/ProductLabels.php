<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */

namespace Mageants\ProductLabels\Block;

use Mageants\ProductLabels\Model\Plgeneral;
use Mageants\ProductLabels\Model\Plproduct;
use Mageants\ProductLabels\Model\Plconditions;
use \Mageants\ProductLabels\Model\Rule\ProductFactory;
use \Magento\Framework\Registry;
use Magento\CatalogRule\Model\RuleFactory;

/**
 * Product Label Class for productlabels
 */
class ProductLabels extends \Magento\Framework\View\Element\Template
{
    /**
     * plproduct
     *
     * @var Mageants\ProductLabels\Model\Plproduct
     */

    protected $plproduct;

    /**
     * plgeneral
     *
     * @var Mageants\ProductLabels\Model\Plgeneral
     */
    protected $plgeneral;

    /**
     * plcondtions
     *
     * @var Mageants\ProductLabels\Model\Plconditions
     */
    protected $plcondtions;

    /**
     * helper
     *
     * @var \Mageants\ProductLabels\Helper
     */
    public $_helper;

    /**
     * Store Manager
     *
     * @var \Magento\Catalog\Block\Product\Context $context->getStoreMnager(),
     */
    protected $storeManager;

    /**
     * stock registry
     *
     * @var \Magento\Catalog\Block\Product\Context $context->getStockRegistry(),
     */
    protected $_stockRegistry;

    /**
     *  registry
     *
     * @var \Magento\Catalog\Block\Product\Context $context->getRegistry(),
     */
    protected $_registry;

    /**
     * label path of file
     *
     * @var constant string
     */
    const LABELPATH = 'productlabels/labels/';

    /**
     *  product label path of file
     *
     * @var constant string
     */
    const PRODUCTLABELPATH = 'productlabels/product/tmp/';

    /**
     *  time zone interface
     *
     * @var string \Magento\Framework\Stdlib\DateTime\DateTime $date
     */
    protected $_timezoneInterface;
    public $_customerSession;

    /**
     * AssignProducts constructor.
     *
     * @param \Magento\Backend\Block\Template\Context  $context
     * @param \Mageants\ProductLabels\Helper\Data $helper,
     * @param array  $data
     * @param Plgeneral,
     * @param Plproduct,
     * @param Plconditions,
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $date
     */
    public function __construct(
        \Magento\Catalog\Block\Product\Context $context,
        \Mageants\ProductLabels\Helper\Data $helper,
        Plgeneral $plgeneral,
        Plproduct $plproduct,
        Plconditions $plcondtions,
        \Magento\SalesRule\Model\RuleFactory $ruleFactory,
        ProductFactory $productRuleFactory,
        Registry $coreRegistry,
        \Magento\Framework\Stdlib\DateTime\DateTime $date,
        \Magento\Customer\Model\Session $customerSession,
        RuleFactory $catalogruleFactory,
        array $data = []
    ) {
        $this->_stockRegistry=$context->getStockRegistry();
        $this->_registry=$context->getRegistry();
        $this->storeManager = $context->getStoreManager();
        $this->plgeneral=$plgeneral;
        $this->plproduct =$plproduct;
        $this->plcondtions=$plcondtions;
        $this->_helper=$helper;
        $this->_timezoneInterface = $date;
        $this->ruleFactory = $ruleFactory;
        $this->_coreRegistry = $coreRegistry;
        $this->productRuleFactory = $productRuleFactory;
        $this->_customerSession = $customerSession;
        $this->_catalogruleFactory = $catalogruleFactory;
        parent::__construct($context, $data);
    }

    /**
     *
     *
     * @return object
     */
    public function getProductLabelss()
    {
        return  $this->_helper->getProductLabelss();
    }

    /**
     * @param label type
     *
     * @return string
     */
    // @codingStandardsIgnoreStart
    public function getLabelPath($labelType = '', $type)
    {
    // @codingStandardsIgnoreEnd
        if ($labelType=='0') {
            if ($type == 'svg') {
                return $this->getViewFileUrl('Mageants_ProductLabels::images/productlabels/labels/');
            } else {
                return  $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).
                'productlabels/category/tmp';
            }
        } else {
            if ($type == 'svg') {
                return $this->getViewFileUrl('Mageants_ProductLabels::images/productlabels/labels/');
            } else {
                return $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).
                self::PRODUCTLABELPATH;

            }
        }
    }

    /**
     * @param pos
     *
     * @return string
     */
    public function getLabelPosition($pos = 0)
    {
        $posArray='';
        switch ($pos) {
            case '1':
                $posArray='left:0%; top:0%';
                break;
            case '2':
                $posArray='left:30%; top:0%';
                break;
            case '3':
                $posArray='left:80%; top:0%';
                break;
            case '4':
                $posArray='left:0%; top:40%';
                break;
            case '5':
                $posArray='left:30%; top:40%';
                break;
            case '6':
                $posArray='left:80%; top:40%';
                break;
            case '7':
                $posArray='left:0%; bottom:40%';
                break;
            case '8':
                $posArray='left:30%; bottom:40%';
                break;
            case '9':
                $posArray='left:80%; bottom:40%';
                break;
            
            default:
                $posArray='left:0%, top:0%';
                break;
        }
        return $posArray;
    }

    /**
     * @param ids
     *
     * @return boolean
     */
    public function isValidCustomer($ids = '')
    {
        if ($ids!=='') {
            return $this->_helper->isValidCustomer($ids);
        }
        return true;
    }

    /**
     * @param stock
     *
     * @return boolean
     */
    public function isValidStock($stock = '')
    {
        if ($stock!=='') {
            // this is true for out of stock
            if ($stock == '1') {
                if ($this->_stockRegistry->getProductStockStatus($this->_registry->registry('product')->getId())==0) {
                    return true; //is stock out of stock
                }
                return false; //in stock
            }
            // this is true for in stock
            if ($stock=='2') {
                if ($this->_stockRegistry->getProductStockStatus($this->_registry->registry('product')->getId())==0) {
                    return false; //out of stock
                }
                return true;    // instock
            }
        }
        return true;
    }

    /**
     * @param min stock
     * @param max stock
     * @return boolean
     */
    public function isValidStockRange($minstock = '', $maxstock = '')
    {
        if ($minstock!=='' || $maxstock!=='') {
            if (!$this->_registry->registry('product')->getTypeId()=="configurable") {
                $stock = $this->_stockRegistry->getStockItem($this->_registry->registry('product')->getId())->getQty();
            } else {
                $stock = $this->_helper->getStockInventoryForConfigProduct(
                    $this->_registry->registry('product')->getSku()
                );
            }
            $var1 = 1;
            $var2 = 1;

            if ($minstock != '') {
                if ((int)$stock >= (int)$minstock) {
                    $var1 = 1;
                } else {
                    $var1 = 0;
                }
            }
            if ($maxstock != '') {
                if ((int)$stock <= (int)$maxstock) {
                    $var2 = 1;
                } else {
                    $var2 = 0;
                }
            }
            if ($var1 == 1 && $var2 == 1) {
                return true;
            } else {
                return false;
            }
        }
        return true;
    }

    /**
     * @param by price
     * @param min price
     * @param maxprice
     * @return boolean
     */
    public function isValidPrice($byprice = '', $minprice = '', $maxprice = '')
    {
        if ($byprice!=='' || $minprice !== '' || $maxprice!=='') {
            
            $price_range = true;
            $price=0;
            switch ($byprice) {
                case '0':
                    $price = $this->_registry->registry('product')->getPrice();
                    break;
                case '1':
                    $price = $this->_registry->registry('product')->getSpecialPrice();
                    break;
                case '2':
                    $price = $this->_registry->registry('product')->getFinalPrice();
                    break;
                case '3':
                    $price = $this->_registry->registry('product')->getCalculatedFinalPrice();
                    break;
                
                default:
                    $price = $this->_registry->registry('product')->getPrice();
                    break;
            }

            if ($price==null) {
                return false;
            }
            if ($byprice=='4') {
                if ($price >= $minprice) {
                    return true;
                }
                return flase;
            }
            if ($byprice == '5') {
                if ($price >= $maxprice) {
                    return true;
                }
                return flase;
            }

            if ($price >= $minprice && $price <= $maxprice) {
                return true;
            }
            return false;
        }
        return true;
    }

    /**
     * @param state
     *
     * @return boolean
     */
    // @codingStandardsIgnoreStart
    public function isValidNew($state = '')
    {
        if ($state!=='') {
            if ($state=='1') {
                if ($this->_registry->registry('product')->getCustomAttribute('isnew')) {
                    if ($this->_registry->registry('product')->getCustomAttribute('isnew')->getValue()==1) {
                       
                        $from_to_date = 1;
                        $current_date = 1;

                        $currentDate = $this->_timezoneInterface->date();
                        if ($this->_helper->isValidatedDate()) {
                             $fromDate = '';
                            $toDate = '';
                            if ($this->_registry->registry('product')->getCustomAttribute('news_from_date')!== null) {
                                $fromDate= $this->_registry->registry('product')->
                                getCustomAttribute('news_from_date')->getValue();
                            }

                            if ($this->_registry->registry('product')->getCustomAttribute('news_to_date')!==null) {
                                $toDate= $this->_registry->registry('product')->
                                getCustomAttribute('news_to_date')->getValue();
                            }

                            if ($fromDate!==null && $toDate !==null) {
                                if ($fromDate < $currentDate && $toDate > $currentDate) {
                                    $from_to_date = 1;
                                } else {
                                    $from_to_date = 0;
                                }
                            }
                            if ($fromDate!==null && $toDate == null) {
                                if ($fromDate < $currentDate) {
                                    $from_to_date = 1;
                                } else {
                                    $from_to_date = 0;
                                }
                            }
                            if ($fromDate == null && $toDate !==null) {
                                if ($toDate > $currentDate) {
                                    $from_to_date = 1;
                                } else {
                                    $from_to_date = 0;
                                }
                            }
                            
                        }
                        if ($this->_helper->useCreationDate()) {
                            $currentdates = explode(' ', $currentDate);
                            $createdates = explode(' ', $this->_registry->registry('product')->getCreatedAt());
                            if ($currentdates[0] == $createdates[0]) {
                                $current_date = 1;
                            } else {
                                $current_date = 0;

                            }
                        }
                        
                        if ($this->_helper->isValidatedDate() == '1' && $this->_helper->useCreationDate() == "1") {
                           
                            if ($from_to_date == 1 || $current_date == 1) {
                                return false;
                            } else {
                                return true;
                            }
                        } else {
                            if ($from_to_date == 1 && $current_date == 1) {
                                return false;
                            } else {
                                return true;
                            }
                        }
                        // return true;
                    } else {
                        return true;
                    }
                } else {
                    return true;
                }
                return false;
            }
            if ($state=='2') {
                if ($this->_registry->registry('product')->getCustomAttribute('isnew')) {
                    if ($this->_registry->registry('product')->getCustomAttribute('isnew')->getValue()==1) {
                   
                              $from_to_date = 1;
                              $current_date = 1;

                              $currentDate = $this->_timezoneInterface->date();
                        if ($this->_helper->isValidatedDate()) {
                            $fromDate = '';
                            $toDate = '';
                            if ($this->_registry->registry('product')->getCustomAttribute('news_from_date')!== null) {
                                $fromDate= $this->_registry->registry('product')->
                                getCustomAttribute('news_from_date')->getValue();
                            }

                            if ($this->_registry->registry('product')->getCustomAttribute('news_to_date')!==null) {
                                $toDate= $this->_registry->registry('product')->
                                getCustomAttribute('news_to_date')->getValue();
                            }

                            if ($fromDate!==null && $toDate !==null) {
                                if ($fromDate < $currentDate && $toDate > $currentDate) {
                                    $from_to_date = 1;
                                } else {
                                    $from_to_date = 0;
                                }
                            }
                            if ($fromDate!==null && $toDate == null) {
                                if ($fromDate < $currentDate) {
                                    $from_to_date = 1;
                                } else {
                                    $from_to_date = 0;
                                }
                            }
                            if ($fromDate == null && $toDate !==null) {
                                if ($toDate > $currentDate) {
                                    $from_to_date = 1;
                                } else {
                                    $from_to_date = 0;
                                }
                            }
                        
                        }
                        if ($this->_helper->useCreationDate()) {
                            $currentdates = explode(' ', $currentDate);
                            $createdates = explode(' ', $this->_registry->registry('product')->getCreatedAt());
                            if ($currentdates[0] == $createdates[0]) {
                                $current_date = 1;
                            } else {
                                $current_date = 0;

                            }
                        }
                        if ($this->_helper->isValidatedDate() == '1' && $this->_helper->useCreationDate() == "1") {
                        
                            if ($from_to_date == 1 || $current_date == 1) {
                                return true;
                            } else {
                                return false;
                            }
                        } else {
                            if ($from_to_date == 1 && $current_date == 1) {
                                return true;
                            } else {
                                return false;
                            }
                        }
                      // return true;
                    }
                    return false;
                }
                return false;
            }
            return true;
        }
         return true;
    }
    // @codingStandardsIgnoreEnd

    /**
     * @param state
     *
     * @return boolean
     */
    public function isValidOnSale($state = '')
    {
        if ($state!=='') {
            if ($state=='1') {
                if ($this->_registry->registry('product')->getCustomAttribute('onsale')) {
                    if ($this->_registry->registry('product')->getCustomAttribute('onsale')->getValue()==0) {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return true;
                }
                return false;
            }
            if ($state=='2') {
                if ($this->_registry->registry('product')->getCustomAttribute('onsale')) {
                    if ($this->_registry->registry('product')->getCustomAttribute('onsale')->getValue()==1) {
                         return true;
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }
                return false;
            }
            return true;
        }
         return true;
    }

    /**
     * @param $parentStatus
     *
     * @return boolean
     */
    public function getConfigurableProductLabels($parentStatus = '')
    {
        if ($this->_registry->registry('product')->getTypeId()=="configurable" ||
            $this->_registry->registry('product')->getTypeId()=="grouped") {
            if ($parentStatus!=='') {
                return ($parentStatus ? true : false);
            }
            return false;
        }
        return true;
    }

    /**
     * @param catids
     *
     * @return boolean
     */
    public function getValidCategory($catIds = '')
    {
        $cats = $this->_registry->registry('product')->getCategoryIds();
        $catIdsArray = explode(',', $catIds);
        foreach ($catIdsArray as $value) {
            $data[] = $this->_helper->getAllChildCategory($value);
        }
        $catIds = implode(",", $data);
        
        foreach ($cats as $cat) {
                $cids = explode(',', $catIds);
            if (in_array($cat, $cids)) {
                return true;
            }
        }
        return false;
    }

    public function getNewValidCondition($condition = null)
    {
        $product = $this->_coreRegistry->registry('current_product');
        if ($condition!==null) {

            $tmpRule = $this->_catalogruleFactory->create();

            $tmpRule->setConditionsSerialized($condition);

            if ($tmpRule->getConditions()->validate($product)) {
                return true;
            }
        }
        return false;
    }

      /**
       * @param $conditions
       *
       * @return boolean
       */
    public function getValidCondition($condition = null)
    {
        $serialCondition= '';

        $this->_currentProduct = $this->_coreRegistry->registry('current_product');
        
        $currentProductId = $this->_currentProduct->getId();

        if ($condition!==null) {

            $this->_settings =  $this->_helper->unserializeSetting($condition);
            $rules = $this->getRules();
            if (isset($rules) && !empty($rules)) {
                $this->productRule = $this->productRuleFactory->create();

                $this->productRule->setConditions([])
                    ->getConditions()
                    ->loadArray($rules);
                    $match = $this->productRule->getMatchingProductIds($currentProductId);
                if (!in_array($currentProductId, $match)) {
                    $serialCondition = false;
                } else {
                    $serialCondition = true;
                }
            }
            
        }
        return $serialCondition;
    }
    /**
     *
     * @return array
     */
    public function getRules()
    {
        return isset($this->_settings['rule']) ? $this->_settings['rule'] : [];
    }
    public function getCustomerSession()
    {
        return $this->_customerSession;
    }
}
