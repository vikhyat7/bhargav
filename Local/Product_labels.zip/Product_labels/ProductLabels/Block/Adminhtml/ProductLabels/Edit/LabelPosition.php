<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */
 
namespace Mageants\ProductLabels\Block\Adminhtml\ProductLabels\Edit;

/**
 * Label class to show template
 */
class LabelPosition extends \Magento\Backend\Block\Template
{
    /**
     * Block template.
     *
     * @var string
     */
    protected $_template = 'labelposition.phtml';

    /**
     * AssignProducts constructor.
     *
     * @param \Magento\Backend\Block\Template\Context  $context
     * @param array                                    $data
     */

    protected $_mediaUrl;

    /**
     * label folder
     *
     *
     * @param const string
     */
    const LABEL_DIR = 'productlabels/labels/';

     /**
      *
      * @param \Magento\Backend\Block\Template\Context  $context,
      * @param array      $data
      */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->_mediaUrl =  $context->getStoreManager();
    }
     /**
      *
      * @return string
      */

    public function getLabelUrl()
    {
        return $this->getViewFileUrl('Mageants_ProductLabels::images/productlabels/labels/').'/';
    }
}
