<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */
 
namespace Mageants\ProductLabels\Block\Adminhtml\ProductLabels\Edit;

use Mageants\ProductLabels\Model\Plcategory;

/**
 * Label class to show template
 */
class CatLabel extends \Magento\Backend\Block\Template
{
    /**
     * Block template.
     *
     * @var string
     */
    protected $_template = 'catlabel.phtml';

    /**
     * store manager
     *
     * @var object
     */
    protected $_storeManager;

    /**
     * product label dir in media
     *
     * @var constant string
     */
    const PRODUCT_LABEL_DIR = "productlabels/category/tmp/";

     /**
     *  label dir in media
     *
     * @var constant string
     */
    const LABEL_DIR = "productlabels/labels/";
    /**
     *   \Magento\Framework\App\Request\Http $request
     *
     * @var  string
     */
    protected $request;

    /**
     *  Plcategory
     *
     * @var  string
     */
    protected $plcategory;

    /**
     * @param \Magento\Backend\Block\Template\Context  $context
     * @param \Magento\Framework\App\Request\Http $request,
     * @param Plcategory $plcategory
     * @param array     $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\App\Request\Http $request,
        \Magento\Framework\Filesystem\Io\File $file,
        \Magento\Framework\HTTP\Client\Curl $curl,
        Plcategory $plcategory,
        array $data = []
    ) {
        $this->request = $request;
        $this->file = $file;
        $this->curlClient = $curl;
        $this->plcategory =$plcategory;
        parent::__construct($context, $data);
    }

    /**
     *
     * @return int
     */
    public function getPlID()
    {
        return $this->request->getParam('pl_id');
    }

    /**
     *
     * @return object
     */
    public function getCategoryData()
    {
        return $this->plcategory->getCollection()->addFieldToFilter('plist_id', $this->getPlID());
    }

    /**
     *
     * @return string
     */
    public function getLabelPosition()
    {
        $position='';
        if ($this->getPlID()) {
            if ($categoryData = $this->getCategoryData()) {
                foreach ($categoryData as $catdata) {
                    $position=$this->getLabelCodes($catdata->getPlCatlabelposition());
                }
            }
        }

        return $position;
    }

    /**
     *
     * @return int
     */
    public function getCurrentBox()
    {
        $position=0;
        if ($this->getPlID()) {
            if ($categoryData = $this->getCategoryData()) {
                foreach ($categoryData as $catdata) {
                    $position=$catdata->getPlCatlabelposition();
                }
            }
        }

        return $position;
    }

    /**
     *
     * @return string
     */
    public function getLabelType()
    {
        $labeltype='';
        if ($this->getPlID()) {
            if ($categoryData = $this->getCategoryData()) {
                foreach ($categoryData as $catdata) {
                    $labeltype=$catdata->getPlCatlabeltype();
                }
            }
        }
        return $labeltype;
    }

    /**
     *
     * @return string
     */
    public function getCategoryImage()
    {
        if ($this->getPlID()) {
            $categoryData=$this->getCategoryData();
            $categoryLabel='';
            $cattype=0;
            if ($categoryData) {
                foreach ($categoryData as $catdata) {
                    if ($catdata->getPlCatlabeltyperadio()==0) {
                        
                        $ext = $this->file->getPathInfo($catdata->getPlCatlabeltype());
                        $extension = $ext['extension'];
                        if ($extension == 'svg') {
                            $categoryLabel = $this->getLabelUrl().$catdata->getPlCatlabeltype();

                        } else {
                            $categoryLabel = $this->_storeManager->getStore()
                            ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).
                            'productlabels/category/tmp/'.$catdata->getPlCatlabeltype();
                            ;
                        }
                    } else {
                        $categoryLabel=$this->getProductLabelsUrl().$catdata->getPlCatlabeltype();
                    }
                }
            }
            return $categoryLabel;
        }
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $session = $objectManager->create(\Magento\Backend\Model\Session::class);
        if ($session->getCatLabelImg()) {
            return $this->getProductLabelsUrl().$session->getCatLabelImg();
        }
        return false;
    }

    /**
     *
     * @return string
     */
    public function getProductLabelsUrl()
    {
        return $this->_storeManager->getStore()->getBaseUrl(
            \Magento\Framework\UrlInterface::URL_TYPE_MEDIA
        ).self::PRODUCT_LABEL_DIR;
    }

    /**
     *
     * @return string
     */
    public function getLabelUrl()
    {
        return $this->getViewFileUrl('Mageants_ProductLabels::images/productlabels/labels/').'/';
    }

    /**
     *
     * @return string
     */
    public function getLabelCodes($pos = 0)
    {
        $posArray='';
        switch ($pos) {
            case '1':
                $posArray='left:0%; top:0%';
                break;
            case '2':
                $posArray='left:40%; top:0%';
                break;
            case '3':
                $posArray='left:73%; top:0%';
                break;
            case '4':
                $posArray='left:0%; top:40%';
                break;
            case '5':
                $posArray='left:40%; top:40%';
                break;
            case '6':
                $posArray='left:73%; top:40%';
                break;
            case '7':
                $posArray='left:0%; bottom:0%';
                break;
            case '8':
                $posArray='left:40%; bottom:0%';
                break;
            case '9':
                $posArray='left:73%; bottom:0%';
                break;
            
            default:
                $posArray='left:0%, top:0%';
                break;
        }
        return $posArray;
    }
    public function getFileExist($url)
    {
        // $file_headers = @get_headers($url);
        $file_headers = $this->curlClient->getHeaders($url);
        if ($file_headers[0] == 'HTTP/1.0 404 Not Found') {
            $file_exists = false;
        } else {
            $file_exists = true;
        }
        return $file_exists;
    }
}
