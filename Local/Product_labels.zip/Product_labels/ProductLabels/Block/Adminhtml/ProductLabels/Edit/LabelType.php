<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */
 
namespace Mageants\ProductLabels\Block\Adminhtml\ProductLabels\Edit;

/**
 * CatLabelType class to show template
 */
class LabelType extends \Magento\Backend\Block\Template
{
    /**
     * Block template.
     *
     * @var string
     */
    protected $_template = 'labeltype.phtml';

    /**
     * store manager
     *
     * @var object
     */
    protected $_storeManager;
     /**
     *  label dir in media
     *
     * @var constant string
     */
    const LABEL_DIR = "productlabels/labels/";

     /**
      *
      * @return string
      */
    public function getCategoryImage()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $session = $objectManager->create(\Magento\Backend\Model\Session::class);
        if ($session->getCatLabelImg()) {
            return $this->getProductLabelsUrl().$session->getCatLabelImg();
        }
        return false;
    }

     /**
      *
      * @return string
      */

    public function getLabelUrl()
    {
        return $this->getViewFileUrl('Mageants_ProductLabels::images/productlabels/labels/').'/';
    }
}
