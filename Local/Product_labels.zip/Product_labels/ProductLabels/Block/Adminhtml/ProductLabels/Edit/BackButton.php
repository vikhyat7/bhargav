<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */

namespace Mageants\ProductLabels\Block\Adminhtml\ProductLabels\Edit;

use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;
use Magento\Framework\Controller\ResultFactory;

class BackButton implements ButtonProviderInterface
{
     
    protected $_urlinterface;
    public function __construct(\Magento\Framework\UrlInterface $urlInterface)
    {
        $this->_urlinterface = $urlInterface;
    }

    /**
     * back button
     *
     * @return array
     */
    public function getButtonData()
    {
        return [
            'label' => __('Back'),
            'on_click' => sprintf("location.href = '%s';", $this->getBackUrl()),
            'class' => 'back',
            'sort_order' => 10,
         ];
    }
    /**
     * Get URL for back (reset) button
     *
     * @return string
     */
    public function getBackUrl()
    {
        return $this->_urlinterface->getUrl('productlabels/index/index');
    }
}
