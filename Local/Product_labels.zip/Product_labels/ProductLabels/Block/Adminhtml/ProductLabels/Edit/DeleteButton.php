<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */

namespace Mageants\ProductLabels\Block\Adminhtml\ProductLabels\Edit;

use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;

class DeleteButton extends GenericButton implements ButtonProviderInterface
{
    
    protected $request;

     /**
      * Url Builder
      *
      * @var \Magento\Framework\UrlInterface
      */
    protected $urlBuilder;

    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        \Magento\Framework\App\Request\Http $request
    ) {
       
        $this->request = $request;
        $this->urlBuilder = $context->getUrlBuilder();
    }
    /**
     * Delete button
     *
     * @return array
     */
    public function getButtonData()
    {
          
        if ($this->request->getParam('pl_id')) {
            return [
                'id' => 'delete',
                'label' => __('Delete'),
                'on_click' => sprintf("location.href = '%s';", $this->getDeleteUrl()),
                'class' => 'delete',
                'sort_order' => 10
            ];
        }
    }

    /**
     * @param array $args
     * @return string
     */
    public function getDeleteUrl(array $args = [])
    {
        $params = array_merge($this->getDefaultUrlParams(), $args);
          return $this->urlBuilder->getUrl('productlabels/index/delete', $params);
    }

    /**
     * @return array
     */
    protected function getDefaultUrlParams()
    {
        return ['_current' => true, '_query' => ['isAjax' => null]];
    }
}
