<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */
 
namespace Mageants\ProductLabels\Block\Adminhtml\ProductLabels\Edit;

use Mageants\ProductLabels\Model\Plproduct;

/**
 * Label class to show template
 */
class Label extends \Magento\Backend\Block\Template
{
    /**
     * Block template.
     *
     * @var string
     */
    protected $_template = 'label.phtml';

    /**
     * store manager
     *
     * @var object
     */
    protected $_storeManager;

    /**
     *  plproduct
     *
     * @var  string
     */
    protected $plproduct;
    /**
     * product label dir in media
     *
     * @var constant string
     */
    const PRODUCT_LABEL_DIR = "productlabels/product/tmp/";

     /**
     *  label dir in media
     *
     * @var constant string
     */
    const LABEL_DIR = "productlabels/labels/";

    /**
     *   \Magento\Framework\App\Request\Http $request
     *
     * @var  string
     */
    protected $request;
    /**
     *
     * @param \Magento\Backend\Block\Template\Context  $context,
     * @param   \Magento\Framework\App\Request\Http $request,
     * @param Plproduct $product
     * @param array      $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\App\Request\Http $request,
        \Magento\Framework\Filesystem\Io\File $file,
        \Magento\Framework\HTTP\Client\Curl $curl,
        Plproduct $plproduct,
        array $data = []
    ) {
        $this->request = $request;
        $this->file = $file;
        $this->curlClient = $curl;
        $this->plproduct =$plproduct;
        parent::__construct($context, $data);
    }
    
    /**
     *
     *
     * @return string
     */
    public function getCategoryImage()
    {
        
        if ($this->getPlID()) {
            $productData=$this->getProductData();
            $productLabel='';
            $type=0;
            if ($productData) {
                foreach ($productData as $prodata) {
                    if ($prodata->getPlLabeltyperadio()==0) {
                        $ext = $this->file->getPathInfo($prodata->getPlLabeltype());
                        $extension = $ext['extension'];
                        if ($extension == 'svg') {
                            $productLabel = $this->getLabelUrl().$prodata->getPlLabeltype();
                        } else {
                            $productLabel = $this->_storeManager->getStore()
                            ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).
                            'productlabels/product/tmp/'.$prodata->getPlLabeltype();
                        }
                    } else {
                        $ext = $this->file->getPathInfo($prodata->getPlLabeltype());
                        $extension = $ext['extension'];
                        if ($extension == 'svg') {
                            $productLabel = $this->getLabelUrl().$prodata->getPlLabeltype();
                        } else {
                            $productLabel=$this->getProductLabelsUrl().$prodata->getPlLabeltype();
                        }
                    }

                }
            }
            return $productLabel;
        }
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $session = $objectManager->create(\Magento\Backend\Model\Session::class);
        if ($session->getCatImg()) {
            return $this->getProductLabelsUrl().$session->getCatImg();
        }
        return false;
    }

    /**
     *
     *
     * @return string
     */
    public function getProductLabelsUrl()
    {
        return $this->_storeManager->getStore()->getBaseUrl(
            \Magento\Framework\UrlInterface::URL_TYPE_MEDIA
        ).self::PRODUCT_LABEL_DIR;
    }

    /**
     *
     *
     * @return string
     */
    public function getLabelUrl()
    {
        return $this->getViewFileUrl('Mageants_ProductLabels::images/productlabels/labels/').'/';
    }

    /**
     *
     *
     * @return int
     */
    public function getPlID()
    {
        return $this->request->getParam('pl_id');
    }

    /**
     *
     *
     * @return string
     */
    public function getProductData()
    {
        return $this->plproduct->getCollection()->addFieldToFilter('plist_id', $this->getPlID());
    }

    /**
     *
     *
     * @return string
     */
    public function getLabelPosition()
    {
        $position='';
        if ($this->getPlID()) {
            if ($productData = $this->getProductData()) {
                foreach ($productData as $prodata) {
                    $position=$this->getLabelCodes($prodata->getPlLabelposition());
                }
            }
        }
        return $position;
    }

    /**
     *
     *
     * @return string
     */
    public function getCurrentBox()
    {
        $position=0;
        if ($this->getPlID()) {
            if ($productData = $this->getProductData()) {
                foreach ($productData as $prodata) {
                    $position=$prodata->getPlLabelposition();
                }
            }
        }

        return $position;
    }

    /**
     *
     *
     * @return string
     */
    public function getLabelType()
    {
        $labeltype='';
        if ($this->getPlID()) {
            if ($productData = $this->getProductData()) {
                foreach ($productData as $prodata) {
                    $labeltype=$prodata->getPlLabeltype();
                }
            }
        }
        return $labeltype;
    }

    /**
     * @param pos int
     *
     * @return string
     */
    public function getLabelCodes($pos = 0)
    {
        $posArray='';
        switch ($pos) {
            case '1':
                $posArray='left:0%; top:0%';
                break;
            case '2':
                $posArray='left:40%; top:0%';
                break;
            case '3':
                $posArray='left:73%; top:0%';
                break;
            case '4':
                $posArray='left:0%; top:40%';
                break;
            case '5':
                $posArray='left:40%; top:40%';
                break;
            case '6':
                $posArray='left:73%; top:40%';
                break;
            case '7':
                $posArray='left:0%; bottom:0%';
                break;
            case '8':
                $posArray='left:40%; bottom:0%';
                break;
            case '9':
                $posArray='left:73%; bottom:0%';
                break;
            
            default:
                $posArray='left:0%, top:0%';
                break;
        }
        return $posArray;
    }
    public function getFileExist($url)
    {
        // $file_headers = @get_headers($url);
        $file_headers = $this->curlClient->getHeaders($url);
        if ($file_headers[0] == 'HTTP/1.0 404 Not Found') {
            $file_exists = false;
        } else {
            $file_exists = true;
        }
        return $file_exists;
    }
}
