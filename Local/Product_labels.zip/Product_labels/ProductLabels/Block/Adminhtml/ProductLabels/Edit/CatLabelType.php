<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */
 
namespace Mageants\ProductLabels\Block\Adminhtml\ProductLabels\Edit;

/**
 * CatLabelType class to show template
 */
class CatLabelType extends \Magento\Backend\Block\Template
{
    /**
     * Block template.
     *
     * @var string
     */
    protected $_template = 'catlabeltype.phtml';

    /**
     * store manager
     *
     * @var object
     */
    protected $_storeManager;
     /**
     *  label dir in media
     *
     * @var constant string
     */
    const LABEL_DIR = "productlabels/labels/";

    /**
     * AssignProducts constructor.
     *
     * @param \Magento\Backend\Block\Template\Context  $context
     * @param array                                    $data
     */
    // @codingStandardsIgnoreStart
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        array $data = []
    ) {

        parent::__construct($context, $data);
    }
    // @codingStandardsIgnoreEnd
    /**
     *
     * @return string | boolean
     */
    public function getCategoryImage()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $session = $objectManager->create(\Magento\Backend\Model\Session::class);
        if ($session->getCatLabelImg()) {
            return $this->getProductLabelsUrl().$session->getCatLabelImg();
        }
        return false;
    }
    /**
     *
     * @return string
     */
    public function getLabelUrl()
    {
        return $this->getViewFileUrl('Mageants_ProductLabels::images/productlabels/labels/').'/';
    }
}
