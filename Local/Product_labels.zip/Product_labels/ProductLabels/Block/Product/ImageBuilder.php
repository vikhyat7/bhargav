<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);
namespace Mageants\ProductLabels\Block\Product;

use Magento\Catalog\Helper\ImageFactory as HelperFactory;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Block\Product\ImageFactory;
use \Mageants\ProductLabels\Model\Rule\ProductFactory;
use \Magento\Framework\Registry;
use Magento\CatalogRule\Model\RuleFactory;

class ImageBuilder extends \Magento\Catalog\Block\Product\ImageBuilder
{
    /**
     * @var ImageFactory
     */
    protected $imageFactory;

    /**
     * @var HelperFactory
     */
    protected $helperFactory;

    /**
     * @var \Magento\Catalog\Model\Product
     */
    protected $product;

    /**
     * @var string
     */
    protected $imageId;

    /**
     * @var array
     */
    protected $attributes = [];

    /**
     * @var plconditions
     */
    protected $_plconditions;

     /**
      * @var helper
      */
    public $_helper;

    /**
     * @var constant string
     */
    const LABELPATH = 'productlabels/labels/';

    /**
     *  time zone interface
     *
     * @var string \Magento\Framework\Stdlib\DateTime\DateTime $date
     */
    protected $_timezoneInterface;
    protected $assetRepo;
    protected $_customerSession;
    protected $_catalogruleFactory;

    /**
     * @var constant string
     */
    const PRODUCTLABELPATH = 'productlabels/category/tmp/';

    /**
     * @param HelperFactory $helperFactory
     * @param ImageFactory $imageFactory
     */
    public function __construct(
        HelperFactory $helperFactory,
        ImageFactory $imageFactory,
        \Mageants\ProductLabels\Helper\Data $helper,
        \Magento\Framework\Stdlib\DateTime\DateTime $date,
        ProductFactory $productRuleFactory,
        Registry $coreRegistry,
        Product $product,
        \Magento\Framework\Serialize\Serializer\Json $serializer,
        \Magento\Framework\View\Asset\Repository $assetRepo,
        \Magento\Customer\Model\Session $customerSession,
        RuleFactory $catalogruleFactory,
        \Magento\Framework\Filesystem\Io\File $file
    ) {
        parent::__construct($helperFactory, $imageFactory);
        $this->_helper =$helper;
        $this->_timezoneInterface = $date;
        $this->productRuleFactory = $productRuleFactory;
        $this->serializer = $serializer;
        $this->_coreRegistry = $coreRegistry;
        $this->product = $product;
        $this->assetRepo = $assetRepo;
        $this->_customerSession = $customerSession;
        $this->_catalogruleFactory = $catalogruleFactory;
        $this->file = $file;
    }

    /**
     * Set product
     *
     * @param \Magento\Catalog\Model\Product $product
     * @return $this
     */
    public function setProduct(Product $product)
    {
        $this->product = $product;
        return $this;
    }

    /**
     * Set image ID
     *
     * @param string $imageId
     * @return $this
     */
    public function setImageId($imageId)
    {
        $this->imageId = $imageId;
        return $this;
    }

    /**
     * Set custom attributes
     *
     * @param array $attributes
     * @return $this
     */
    public function setAttributes(array $attributes)
    {
        $this->attributes = $attributes;
        return $this;
    }

    /**
     * Retrieve image custom attributes for HTML element
     *
     * @return string
     */
    protected function getCustomAttributes()
    {
        $result = [];
        foreach ($this->attributes as $name => $value) {
            $result[] = $name . '="' . $value . '"';
        }
        return !empty($result) ? implode(' ', $result) : '';
    }

    /**
     * Calculate image ratio
     *
     * @param \Magento\Catalog\Helper\Image $helper
     * @return float|int
     */
    protected function getRatio(\Magento\Catalog\Helper\Image $helper)
    {
        $width = $helper->getWidth();
        $height = $helper->getHeight();
        if ($width && $height) {
            return $height / $width;
        }
        return 1;
    }

    /**
     * Create image block
     *
     * @return \Magento\Catalog\Block\Product\Image
     */
    // @codingStandardsIgnoreStart
    public function create(
        Product $product = null,
        string $imageId = null,
        array $attributes = null
    ) {
        $product = $product ?? $this->product;
        $imageId = $imageId ?? $this->imageId;
        $attributes = $attributes ?? $this->attributes;
        $currentProductId = $product->getId();
        $categoryLabels = $this->getCategoryLabel();
        
        $catLabels=[];
        if ($categoryLabels) {
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $storeManager  = $objectManager->get(\Magento\Store\Model\StoreManagerInterface::class);
            $storeID = $storeManager->getStore()->getStoreId();
            $stockState = $objectManager->get(\Magento\CatalogInventory\Model\Stock\Item::class);
            foreach ($categoryLabels as $catlabel) {
                $validstore = '1';
                $validnewLabel=true;
                $serialCondition = false;
                $validCustomerLabel = true;
                $validStockLabel=true;
                $validPriceRangeLabel=true;
                $validSaleLabel=true;
                $validStockRangeLabel = true;
                $configLabel= true;
                $validCategory = false;
                $onsaleText='';
                    
                if ($catlabel->getPlShowin() != 0 && $catlabel->getPlShowin() != $storeID) {
                    $validstore = '0';
                }
                    $configLabel = $this->getConfigurableProductLabels($product, $catlabel->getPlIsparent());
                if ($catlabel->getCondition()) {
                    $validCategory= $this->getValidCategory($catlabel->getCondition(), $product);
                }
                    
                if ($catlabel->getIsNew()!='0') {
                    $validnewLabel=$this->isValidNew($product, $catlabel->getIsNew());
                }
                   
                if ($catlabel->getSerializedCondition()!='') {
                    $serialCondition = $this->getLabelValidCondition($product, $catlabel->getSerializedCondition());
                } elseif ($catlabel->getSerializedCondition()=='') {
                    $serialCondition = true;
                }

                if ($catlabel->getPlIsCustomergropup()=='1') {
                    if ($catlabel->getCustomerGroupIds() !='') {
                          $customerGroupIds=explode(',', $catlabel->getCustomerGroupIds());
                        if ($customerGroupIds) {
                            if (!in_array($this->_customerSession->getCustomer()->getGroupId(), $customerGroupIds)) {
                                   $validCustomerLabel = false;
                            }
                        }
                    }
                }
                if ($catlabel->getPlStock()!='0') {
                    $stockItem = $stockState->load($product->getId(), 'product_id');
                    if ($catlabel->getPlStock()=='1') {
                        if ($stockItem->getIsInStock() == true) {
                            $validStockLabel=false;
                        } else {
                            $validStockLabel=true;
                        }
                    } elseif ($catlabel->getPlStock()=='2') {
                        if ($stockItem->getIsInStock() == true) {
                            $validStockLabel=true;
                        } else {
                            $validStockLabel=false;
                        }
                    }
                }
                if ($catlabel->getPlStockRange()!='0') {
                      $validStockRangeLabel=$this->isValidStockRange(
                          $product->getId(),
                          $product->getStore()->getId(),
                          $catlabel->getPlMinStock(),
                          $catlabel->getPlMaxStock()
                      );
                }
                if ($catlabel->getPlPriceRange()!='0') {
                     $validPriceRangeLabel=$this->isValidPrice(
                         $product,
                         $catlabel->getPlByRange(),
                         $catlabel->getPlMinPrice(),
                         $catlabel->getPlMaxPrice()
                     );
                }
                if ($catlabel->getPlOnsale()!='0') {
                        $validSaleLabel=$this->isValidOnSale($product, $catlabel->getPlOnsale());
                    if ($catlabel->getPlOnsale() != '1') {
                        $onsaleText=$this->_helper->getOnsaleText();
                    }
                }
                    $ext = $this->file->getPathInfo($catlabel->getPlCatlabeltype());
                    $extension = $ext['extension'];
                    $catLabels[$catlabel->getId()] = ['validstore'=>$validstore,
                    'validnewLabel'=>$validnewLabel,
                    'serialCondition'=>$serialCondition,
                    'validCustomerLabel'=>$validCustomerLabel,
                    'validStockLabel'=>$validStockLabel,
                    'validStockRangeLabel'=>$validStockRangeLabel,
                    'validPriceRangeLabel'=>$validPriceRangeLabel,
                    'validSaleLabel'=>$validSaleLabel,
                    'onsaleText'=>$onsaleText,
                    'labelPosition'=>$this->getLabelPosition($catlabel->
                        getPlCatlabelposition()),
                    'configLabel'=>$configLabel,
                    'validCategory'=>$validCategory,
                    'labelpath'=>$this->getLabelPath($catlabel->
                        getPlCatlabeltyperadio(), $extension).$catlabel->
                    getPlCatlabeltype(),
                    'getPlCatlabelsize'=>$catlabel->getPlCatlabelsize(),
                    'getPlCatstyle'=>$catlabel->getPlCatstyle(),
                    'getPlCattextsize'=>$catlabel->getPlCattextsize(),
                    'getPlCatlabeltext'=>$catlabel->getPlCatlabeltext(),
                    'getPlCatcolor'=>$catlabel->getPlCatcolor(),
                    'getPlName'=>$catlabel->getPlName(),
                    'imagename'=>$catlabel->getPlCatlabeltype()];
            }
        }

        return $this->imageFactory->create($product, $imageId, $attributes, $catLabels);
    }
    // @codingStandardsIgnoreEnd
    public function getLabelValidCondition($product, $condition = null)
    {
        if ($condition!==null) {

            $tmpRule = $this->_catalogruleFactory->create();

            $tmpRule->setConditionsSerialized($condition);

            if ($tmpRule->getConditions()->validate($product)) {
                return true;
            }
        }
        return false;
    }

    /**
     *
     * @return object
     */
    public function getCategoryLabel()
    {
        return $this->_helper->getCategoryLabel();
    }
    /**
     *
     * @return string
     */
    public function getLabelPath($labelType = '', $type = '')
    {
        $objectManager =  \Magento\Framework\App\ObjectManager::getInstance();
        $storeManager = $objectManager->get(\Magento\Store\Model\StoreManagerInterface::class);
       
        if ($labelType=='0') {
            if ($type == 'svg') {
                return $this->assetRepo->getUrl('Mageants_ProductLabels::images/productlabels/labels/').'/';
            } else {
                return  $storeManager->getStore()
                        ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'productlabels/category/tmp/';
            }
        } else {
            if ($type == 'svg') {
                return $this->assetRepo->getUrl('Mageants_ProductLabels::images/productlabels/labels/').'/';
            } else {
                return $storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).
                self::PRODUCTLABELPATH;

            }
        }
    }

    /**
     * @param id int
     * @return boolean
     */
    public function isValidCustomer($ids = '')
    {
        if ($ids!=='') {
            return $this->_helper->isValidCustomer($ids);
        }
        return true;
    }

    /**
     * @param pos int
     * @return string
     */
    public function getLabelPosition($pos = 0)
    {
        $posArray=[];
        switch ($pos) {
            case '1':
                $posArray='left:0%; top:0%';
                break;
            case '2':
                $posArray='left:40%; top:0%';
                break;
            case '3':
                $posArray='right:0%; top:0%';
                break;
            case '4':
                $posArray='left:0%; top:30%';
                break;
            case '5':
                $posArray='left:40%; top:30%';
                break;
            case '6':
                $posArray='right:0%; top:30%';
                break;
            case '7':
                $posArray='left:0%; bottom:15%';
                break;
            case '8':
                $posArray='left:40%; bottom:15%';
                break;
            case '9':
                $posArray='right:0%; bottom:15%';
                break;
        
            default:
                $posArray='left:0%; top:0%';
                break;
        }
        return $posArray;
    }

    /**
     * @param productid
     * @param storeid
     * @param minstock
     * @param maxstock
     * @return boolean
     */
    // @codingStandardsIgnoreStart
    public function isValidStockRange($productId = '', $storeId, $minstock = '', $maxstock = '')
    {
    // @codingStandardsIgnoreEnd

        if ($productId!=='' || $storeId || $minstock!=='' || $maxstock!=='') {
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $product = $objectManager->create(\Magento\Catalog\Model\Product::class)
                                     ->load($productId);
            $sku = $product->getSku();
            $stock = $this->_helper->getStockInventoryForConfigProduct($sku);
            $var1 = 1;
            $var2 = 1;

            if ($minstock != '') {
                if ((int)$stock >= (int)$minstock) {
                    $var1 = 1;
                } else {
                    $var1 = 0;
                }
            }
            if ($maxstock != '') {
                if ((int)$stock <= (int)$maxstock) {
                    $var2 = 1;
                } else {
                    $var2 = 0;
                }
            }
            if ($var1 == 1 && $var2 == 1) {
                return true;
            } else {
                return false;
            }
        }
        return true;
    }

    /**
     * @param product
     * @param byprice
     * @param minprice
     * @param maxprice
     * @return boolean
     */
    public function isValidPrice($product = null, $byprice = '', $minprice = '', $maxprice = '')
    {
        if ($product!==null || $byprice!=='' || $minprice !== '' || $maxprice!=='') {
            
            $price_range = true;
            $price=0;
            switch ($byprice) {
                case '0':
                    $price = $product->getPrice();
                    break;
                case '1':
                    $price = $product->getSpecialPrice();
                    break;
                case '2':
                    $price = $product->getFinalPrice();
                    break;
                case '3':
                    $price = $product->getCalculatedFinalPrice();
                    break;
                
                default:
                    $price = $product->getPrice();
                    break;
            }
            if ($price==null) {
                return false;
            }
            if ($byprice=='4') {
                if ($price >= $minprice) {
                    return true;
                }
                return flase;
            }
            if ($byprice == '5') {
                if ($price >= $maxprice) {
                    return true;
                }
                return flase;
            }

            if ($price >= $minprice && $price <= $maxprice) {
                return true;
            }
            return false;
        }
        return true;
    }

    /**
     * @param product
     * @param state
     * @return boolean
     */
    // @codingStandardsIgnoreStart
    public function isValidNew(Product $product, $state = '')
    {
        if ($state!=='') {

            if ($state=='1') {
                if ($product->getCustomAttribute('isnew')) {
                    if ((int)$product->getCustomAttribute('isnew')->getValue()==1) {
                        $currentDate = $this->_timezoneInterface->date();
                    
                        $from_to_date = 1;
                        $current_date = 1;
                        if ($this->_helper->isValidatedDate()) {
                            $fromDate = '';
                            $toDate = '';

                            if ($product->getCustomAttribute('news_from_date')!==null) {
                                $fromDate= $product->getCustomAttribute('news_from_date')->getValue();
                            }

                            if ($product->getCustomAttribute('news_to_date')!==null) {
                                $toDate= $product->getCustomAttribute('news_to_date')->getValue();
                            }
                            if ($fromDate!==null && $toDate !==null) {
                                if ($fromDate < $currentDate && $toDate > $currentDate) {
                                    $from_to_date = 1;
                                } else {
                                    $from_to_date = 0;
                                }
                            }
                            if ($fromDate!==null && $toDate == null) {
                                if ($fromDate < $currentDate) {
                                    $from_to_date = 1;
                                } else {
                                    $from_to_date = 0;
                                }
                            }
                            if ($fromDate == null && $toDate !==null) {
                                if ($toDate > $currentDate) {
                                    $from_to_date = 1;
                                } else {
                                    $from_to_date = 0;
                                }
                            }
                        }
                        if ($this->_helper->useCreationDate()) {
                            $currentdates = explode(' ', $currentDate);
                            $createdates = explode(' ', $product->getCreatedAt());
                       
                            if ($currentdates[0] == $createdates[0]) {
                                $current_date = 1;
                            } else {
                                $current_date = 0;

                            }
                        }
                    
                        if ($this->_helper->isValidatedDate() == '1' && $this->_helper->useCreationDate() == "1") {
                            if ($from_to_date == 1 || $current_date == 1) {
                                return false;
                            } else {
                                return true;
                            }
                        } else {
                            if ($from_to_date == 1 && $current_date == 1) {
                                return false;
                            } else {
                                return true;
                            }
                        }
                    // return true;
                    } else {
                        return true;
                    }
                } else {
                    return true;
                }
                return false;
            }
            if ($state=='2') {
               
                if ($product->getCustomAttribute('isnew')) {
                    if ((int)$product->getCustomAttribute('isnew')->getValue()==1) {
                        $currentDate = $this->_timezoneInterface->date();
                    
                        $from_to_date = 1;
                        $current_date = 1;
                        if ($this->_helper->isValidatedDate()) {
                            $fromDate = '';
                            $toDate = '';

                            if ($product->getCustomAttribute('news_from_date')!==null) {
                                $fromDate= $product->getCustomAttribute('news_from_date')->getValue();
                            }

                            if ($product->getCustomAttribute('news_to_date')!==null) {
                                $toDate= $product->getCustomAttribute('news_to_date')->getValue();
                            }
                            if ($fromDate!==null && $toDate !==null) {
                                if ($fromDate < $currentDate && $toDate > $currentDate) {
                                    $from_to_date = 1;
                                } else {
                                    $from_to_date = 0;
                                }
                            }
                            if ($fromDate!==null && $toDate == null) {
                                if ($fromDate < $currentDate) {
                                    $from_to_date = 1;
                                } else {
                                    $from_to_date = 0;
                                }
                            }
                            if ($fromDate == null && $toDate !==null) {
                                if ($toDate > $currentDate) {
                                    $from_to_date = 1;
                                } else {
                                    $from_to_date = 0;
                                }
                            }
                            
                        }
                        if ($this->_helper->useCreationDate()) {
                            $currentdates = explode(' ', $currentDate);
                            $createdates = explode(' ', $product->getCreatedAt());
                           
                            if ($currentdates[0] == $createdates[0]) {
                                $current_date = 1;
                            } else {
                                $current_date = 0;

                            }
                        }
                        
                        if ($this->_helper->isValidatedDate() == '1' && $this->_helper->useCreationDate() == "1") {
                            if ($from_to_date == 1 || $current_date == 1) {
                                return true;
                            } else {
                                return false;
                            }
                        } else {
                            if ($from_to_date == 1 && $current_date == 1) {
                                return true;
                            } else {
                                return false;
                            }
                        }
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }
            }
            return true;
        }
         return true;
    }
    // @codingStandardsIgnoreEnd
    /**
     * @param product
     * @param state
     * @return boolean
     */
    public function isValidOnSale($product = null, $state = '')
    {
        if ($state!=='' || $product!==null) {
            if ($state=='1') {
                //print_r($product->getCustomAttributes());
                if ($product->getCustomAttribute('onsale')) {
                    if ($product->getCustomAttribute('onsale')->getValue()== 0) {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return true;
                }
                return false;
            }
            if ($state=='2') {
                if ($product->getCustomAttribute('onsale')) {
                    if ($product->getCustomAttribute('onsale')->getValue()==1) {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }
            }
            return true;
        }
         return true;
    }

    /**
     * @param product
     * @param parentStatus
     * @return boolean
     */
    public function getConfigurableProductLabels($product, $parentStatus = '')
    {
        if ($product->getTypeId()=="configurable" || $product->getTypeId()=="grouped") {
            if ($parentStatus!=='') {
                return ($parentStatus ? true : false);
            }
            return false;
        }
              return true;
    }
    /**
     * @param validCategory
     * @param catIds
     * @return boolean
     */
    // @codingStandardsIgnoreStart
    public function getValidCategory($catIds = '', $product)
    {
        $cats = $product->getCategoryIds();
        
        $catIdsArray = explode(',', $catIds);
        foreach ($catIdsArray as $value) {
            $data[] = $this->_helper->getAllChildCategory($value);
        }
        $catIds = implode(",", $data);

        foreach ($cats as $cat) {
                $cids = explode(',', $catIds);
            if (in_array($cat, $cids)) {
                return true;
            }
              
        }
        return false;
    }
    // @codingStandardsIgnoreEnd
    /**
     * @param product
     * @param condition
     * @return boolean
     */
    public function getValidCondition($condition = null)
    {
        if ($condition!==null) {
            return $this->_helper->getValidCondition($condition, $this->product);
            
        }
        return true;
    }

    public function getListCollection()
    {
            return $this->_coreRegistry->registry('product');
    }
        /**
         *
         * @return array
         */
    public function getRules()
    {
        return isset($this->_settings['rule']) ? $this->_settings['rule'] : [];
    }
}
