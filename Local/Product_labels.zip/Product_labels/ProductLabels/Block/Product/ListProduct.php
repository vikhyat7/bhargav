<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */

namespace Mageants\ProductLabels\Block\Product;

use Magento\Catalog\Api\CategoryRepositoryInterface;
use Mageants\ProductLabels\Model\Plgeneral;
use Mageants\ProductLabels\Model\Plcategory;
use Mageants\ProductLabels\Model\Plconditions;

class ListProduct extends \Magento\Catalog\Block\Product\ListProduct
{
    /**
     * Catalog layer
     *
     * @var \Magento\Catalog\Model\Layer
     */
    protected $_catalogLayer;

    /**
     * stock registry
     *
     * @var \Magento\Catalog\Block\Product\Context $context->getStockRegistry(),
     */
    protected $_stockRegistry;

    /**
     *  registry
     *
     * @var \Magento\Catalog\Block\Product\Context $context->getRegistry(),
     */
    protected $_registry;

    /**
     * @var \Magento\Framework\Data\Helper\PostHelper
     */
    protected $_postDataHelper;

    /**
     * @var \Magento\Framework\Url\Helper\Data
     */
    protected $urlHelper;

    /**
     * @var CategoryRepositoryInterface
     */
    protected $categoryRepository;

    /**
     * @var plgeneral
     */
    protected $_plgeneral;

    /**
     * @var plcategory
     */
    protected $_plcategory;

    /**
     * @var plconditions
     */
    protected $_plconditions;

     /**
      * @var helper
      */
    public $_helper;

    /**
     * label path of file
     *
     * @var constant string
     */
    const LABELPATH = 'productlabels/labels/';

    /**
     *  time zone interface
     *
     * @var string \Magento\Framework\Stdlib\DateTime\DateTime $date
     */
    protected $_timezoneInterface;

    /**
     *  product label path of file
     *
     * @var constant string
     */
    const PRODUCTLABELPATH = 'productlabels/category/tmp/';

    /**
     * Store Manager
     *
     * @var \Magento\Catalog\Block\Product\Context $context->getStoreMnager(),
     */
    protected $storeManager;

    /**
     * @param  \Magento\Catalog\Block\Product\Context $context,
     * @param \Magento\Framework\Data\Helper\PostHelper $postDataHelper
     * @param \Magento\Catalog\Model\Layer\Resolver $layerResolver
     * @param CategoryRepositoryInterface $categoryRepository
     * @param \Magento\Framework\Url\Helper\Data $urlHelper
     * @param \Mageants\ProductLabels\Helper\Data $helper,
     * @param Plgeneral $plgeneral,
     * @param Plcategory $plcategory,
     * @param Plconditions $plconditions,
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $date,
     * @param array $data
     */
    public function __construct(
        \Magento\Catalog\Block\Product\Context $context,
        \Magento\Framework\Data\Helper\PostHelper $postDataHelper,
        \Magento\Catalog\Model\Layer\Resolver $layerResolver,
        CategoryRepositoryInterface $categoryRepository,
        \Magento\Framework\Url\Helper\Data $urlHelper,
        \Mageants\ProductLabels\Helper\Data $helper,
        Plgeneral $plgeneral,
        Plcategory $plcategory,
        Plconditions $plconditions,
        \Magento\Framework\Stdlib\DateTime\DateTime $date,
        \Magento\SalesRule\Model\RuleFactory $ruleFactory,
        array $data = []
    ) {
        $this->_stockRegistry=$context->getStockRegistry();
        $this->_registry=$context->getRegistry();
        $this->_catalogLayer = $layerResolver->get();
        $this->_postDataHelper = $postDataHelper;
        $this->categoryRepository = $categoryRepository;
        $this->urlHelper = $urlHelper;
        $this->_plgeneral = $plgeneral;
        $this->_plcategory = $plcategory;
        $this->_plconditions = $plconditions;
        $this->_helper =$helper;
        $this->_timezoneInterface = $date;
        $this->storeManager = $context->getStoreManager();
        $this->ruleFactory = $ruleFactory;
        parent::__construct(
            $context,
            $postDataHelper,
            $layerResolver,
            $categoryRepository,
            $urlHelper,
            $data
        );
    }

    /**
     *
     * @return object
     */
    public function getCategoryLabel()
    {
        return $this->_helper->getCategoryLabel();
    }
    /**
     *
     * @return string
     */
    public function getLabelPath($labelType = '')
    {
        if ($labelType=='0') {
            return $this->getViewFileUrl('Mageants_ProductLabels::images/productlabels/labels/');
        } else {
            return $this->getViewFileUrl('Mageants_ProductLabels::images/productlabels/labels/');
        }
    }

    /**
     * @param id int
     * @return boolean
     */
    public function isValidCustomer($ids = '')
    {
        if ($ids!=='') {
            return $this->_helper->isValidCustomer($ids);
        }
        return true;
    }

    /**
     * @param pos int
     * @return string
     */
    public function getLabelPosition($pos = 0)
    {
        $posArray=[];
        switch ($pos) {
            case '1':
                $posArray='left:0%; top:0%';
                break;
            case '2':
                $posArray='left:40%; top:0%';
                break;
            case '3':
                $posArray='right:0%; top:0%';
                break;
            case '4':
                $posArray='left:0%; top:30%';
                break;
            case '5':
                $posArray='left:40%; top:30%';
                break;
            case '6':
                $posArray='right:0%; top:30%';
                break;
            case '7':
                $posArray='left:0%; bottom:15%';
                break;
            case '8':
                $posArray='left:40%; bottom:15%';
                break;
            case '9':
                $posArray='right:0%; bottom:15%';
                break;
        
            default:
                $posArray='left:0%; top:0%';
                break;
        }
        return $posArray;
    }

    /**
     * @param productid
     * @param storeid
     * @param minstock
     * @param maxstock
     * @return boolean
     */
    // @codingStandardsIgnoreStart
    public function isValidStockRange($productId = '', $storeId, $minstock = '', $maxstock = '')
    {

        if ($productId!=='' || $storeId || $minstock!=='' || $maxstock!=='') {
            $stock = $this->_stockRegistry->getStockItem($productId, $storeId)->getQty();

            if ($stock >= $minstock && $stock <= $maxstock) {
                return true;
            }
            return false;
        }
        return true;
    }
    // @codingStandardsIgnoreEnd

    /**
     * @param product
     * @param byprice
     * @param minprice
     * @param maxprice
     * @return boolean
     */
    public function isValidPrice($product = null, $byprice = '', $minprice = '', $maxprice = '')
    {
        if ($product!==null || $byprice!=='' || $minprice !== '' || $maxprice!=='') {
            
            $price_range = true;
            $price=0;
            switch ($byprice) {
                case '0':
                    $price = $product->getPrice();
                    break;
                case '1':
                    $price = $product->getSpecialPrice();
                    break;
                case '2':
                    $price = $product->getFinalPrice();
                    break;
                case '3':
                    $price = $product->getCalculatedFinalPrice();
                    break;
                
                default:
                    $price = $product->getPrice();
                    break;
            }
            if ($price==null) {
                return false;
            }
            if ($byprice=='4') {
                if ($price >= $minprice) {
                    return true;
                }
                return flase;
            }
            if ($byprice == '5') {
                if ($price >= $maxprice) {
                    return true;
                }
                return flase;
            }

            if ($price >= $minprice && $price <= $maxprice) {
                return true;
            }
            return false;
        }
        return true;
    }

    /**
     * @param product
     * @param state
     * @return boolean
     */
    // @codingStandardsIgnoreStart
    public function isValidNew($product = null, $state = '')
    {
        if ($state!=='' || $product!==null) {
            if ($state=='1') {
                if ($product->getCustomAttribute('isnew')->getValue()==0) {
                    return true;
                }
                return false;
            }
            if ($state=='2') {
                if ($product->getCustomAttribute('isnew')->getValue()==1) {
                    $currentDate = $this->_timezoneInterface->date();
                    if ($this->_helper->isValidatedDate()) {
                        if ($product->getCustomAttribute('news_from_date')!==null) {
                            $fromDate= $this->_registry->registry('product')->
                            getCustomAttribute('news_from_date')->getValue();
                        }

                        if ($product->getCustomAttribute('news_to_date')!==null) {
                            $toDate= $this->_registry->registry('product')->
                            getCustomAttribute('news_to_date')->getValue();
                        }
                        
                        if ($fromDate!==null && $toDate !==null) {
                            if ($fromDate < $currentDate && $toDate > $currentDate) {
                                return true;
                            }
                            return false;
                        }
                        if ($fromDate!==null && $toDate == null) {
                            if ($fromDate < $currentDate) {
                                return true;
                            }
                            return false;
                        }
                        if ($fromDate == null && $toDate !==null) {
                            if ($toDate > $currentDate) {
                                return true;
                            }
                            return false;
                        }
                        
                    }
                    if ($this->_helper->useCreationDate()) {
                        if ($currentDate == $product->getCreatedAt()) {

                            return true;
                        }

                        return false;
                    }
       
                    return true;
                }
                return false;
            }
            return true;
        }
         return true;
    }
    // @codingStandardsIgnoreEnd

    /**
     * @param product
     * @param state
     * @return boolean
     */
    public function isValidOnSale($product = null, $state = '')
    {
        if ($state!=='' || $product!==null) {
            if ($state=='1') {
                if ($product->getCustomAttribute('onsale')->getValue()==0) {
                    return true;
                }
                return false;
            }
            if ($state=='2') {
                if ($product->getCustomAttribute('onsale')->getValue()==1) {
                    return true;
                }
                return false;
            }
            return true;
        }
         return true;
    }

    /**
     * @param product
     * @param parentStatus
     * @return boolean
     */
    public function getConfigurableProductLabels($product = null, $parentStatus = '')
    {
        if ($product!==null) {
            if ($product->getTypeId()=="configurable" || $product->getTypeId()=="grouped") {
                if ($parentStatus!=='') {
                    return ($parentStatus ? true : false);
                }
                return false;
            }
        }
        return true;
    }

    /**
     * @param validCategory
     * @param catIds
     * @return boolean
     */
    public function getValidCategory($product = null, $catIds = '')
    {
        if ($catIds!=='' && $product!==null) {
              
            if (strpos($catIds, $product->getCategoryId())!==false) {
                 return true;
            }
             return false;
        }
    }

    /**
     * @param product
     * @param condition
     * @return boolean
     */
    public function getValidCondition($product = null, $condition = null)
    {
        if ($condition!==null && $product!==null) {
            return $this->_helper->getValidCondition($condition, $product);
            
        }
        return true;
    }
}
