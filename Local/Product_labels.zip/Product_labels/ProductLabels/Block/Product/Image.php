<?php
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Mageants\ProductLabels\Block\Product;

use Magento\Catalog\Api\CategoryRepositoryInterface;
use Mageants\ProductLabels\Model\Plgeneral;
use Mageants\ProductLabels\Model\Plcategory;
use Mageants\ProductLabels\Model\Plconditions;
use Magento\Catalog\Block\Product\ListProduct;

/**
 * @method string getImageUrl()
 * @method string getWidth()
 * @method string getHeight()
 * @method string getLabel()
 * @method mixed getResizedImageWidth()
 * @method mixed getResizedImageHeight()
 * @method float getRatio()
 * @method string getCustomAttributes()
 */
class Image extends \Magento\Catalog\Block\Product\Image
{
     /**
      * Catalog layer
      *
      * @var \Magento\Catalog\Model\Layer
      */
    protected $_catalogLayer;

    /**
     * stock registry
     *
     * @var \Magento\Catalog\Block\Product\Context $context->getStockRegistry(),
     */
    protected $_stockRegistry;

    /**
     *  registry
     *
     * @var \Magento\Catalog\Block\Product\Context $context->getRegistry(),
     */
    protected $_registry;

    /**
     * @var \Magento\Framework\Data\Helper\PostHelper
     */
    protected $_postDataHelper;

    /**
     * @var \Magento\Framework\Url\Helper\Data
     */
    protected $urlHelper;

    /**
     * @var CategoryRepositoryInterface
     */
    protected $categoryRepository;

    /**
     * @var plgeneral
     */
    protected $_plgeneral;

    /**
     * @var plcategory
     */
    protected $_plcategory;

    /**
     * @var plconditions
     */
    protected $_plconditions;

     /**
      * @var helper
      */
    public $_helper;

    /**
     * label path of file
     *
     * @var constant string
     */
    const LABELPATH = 'productlabels/labels/';

    /**
     *  time zone interface
     *
     * @var string \Magento\Framework\Stdlib\DateTime\DateTime $date
     */
    protected $_timezoneInterface;

    /**
     *  product label path of file
     *
     * @var constant string
     */
    const PRODUCTLABELPATH = 'productlabels/category/tmp/';

    /**
     * Store Manager
     *
     * @var \Magento\Catalog\Block\Product\Context $context->getStoreMnager(),
     */
    protected $storeManager;

    /**
     * @var \Magento\Catalog\Helper\Image
     */
    protected $imageHelper;

    /**
     * @var \Magento\Catalog\Model\Product
     */
    protected $product;

    /**
     * @var array
     */
    protected $attributes = [];

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param  \Magento\Catalog\Block\Product\Context $context,
     * @param \Magento\Framework\Data\Helper\PostHelper $postDataHelper
     * @param \Magento\Catalog\Model\Layer\Resolver $layerResolver
     * @param CategoryRepositoryInterface $categoryRepository
     * @param \Magento\Framework\Url\Helper\Data $urlHelper
     * @param \Mageants\ProductLabels\Helper\Data $helper,
     * @param Plgeneral $plgeneral,
     * @param Plcategory $plcategory,
     * @param Plconditions $plconditions,
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $date,
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Mageants\ProductLabels\Helper\Data $helper,
        array $data = []
    ) {
        $this->_helper =$helper;
        $this->plabeldata = $data;
        $this->setTemplate('Mageants_ProductLabels::product/image_with_borders.phtml');
        unset($data['template']);
        parent::__construct($context, $data);
    }

    /**
     *
     * @return object
     */
    public function getCategoryLabel()
    {

        return $this->plabeldata;
    }
}
