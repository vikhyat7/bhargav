<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */
namespace Mageants\ProductLabels\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Eav\Setup\EavSetup;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\DB\Ddl\Table;

/**
 * InstallSchema for Update Database for Product label
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * Store Manager
     *
     * @var Magento\Store\Model\StoreManagerInterface $storeManager
     */
    protected $StoreManager;

    /**
     *
     *
     * @param Magento\Store\Model\StoreManagerInterface $storeManager
     */
    public function __construct(StoreManagerInterface $StoreManager, \Magento\Framework\HTTP\Client\Curl $curl)
    {
        $this->StoreManager=$StoreManager;
        $this->curlClient = $curl;
    }

    /**
     * install Database for Product Label
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();
        /* create table pl_general */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('pl_general')
        )
         ->addColumn(
             'pl_id',
             \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
             null,
             ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
             'Product Label Id'
         )->addColumn(
             'pl_name',
             \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
             255,
             ['nullable' => false],
             'Product Label Name'
         )->addColumn(
             'pl_priority',
             \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
             null,
             ['nullable' => false],
             'product label priority'
         )->addColumn(
             'pl_status',
             \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
             1,
             ['nullable' => false],
             'Label Status'
         )->addColumn(
             'pl_ishide',
             \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
             1,
             ['nullable' => false],
             'Hide if priority already applied'
         )->addColumn(
             'pl_isparent',
             \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
             1,
             ['nullable' => false],
             'Use For parent'
         )->addColumn(
             'pl_showin',
             \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
             255,
             ['nullable' => false],
             'Show in stores'
         )->addColumn(
             'condition',
             \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
             null,
             ['nullable' => false],
             'Label Condition'
         )->addIndex(
             $setup->getIdxName(
                 $setup->getTable('pl_general'),
                 ['pl_name'],
                 \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT
             ),
             ['pl_name'],
             ['type' => \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT]
         )->setComment(
             'Mageants Product Label General Setting'
         );
        $installer->getConnection()->createTable($table);
        
        /* create table pl_product */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('pl_product')
        )
         ->addColumn(
             'id',
             \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
             null,
             ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
             'id'
         )->addColumn(
             'pl_labeltype',
             \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
             255,
             ['nullable' => false],
             'label type either shape or image'
         )->addColumn(
             'pl_labeltyperadio',
             \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
             6,
             ['nullable' => false],
             'Label Type Radio'
         )->addColumn(
             'pl_labelposition',
             \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
             6,
             ['nullable' => false],
             'Position for of label on media'
         )->addColumn(
             'pl_labelsize',
             \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
             3,
             ['nullable' => false],
             'Label size in %'
         )->addColumn(
             'pl_labeltext',
             \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
             255,
             ['nullable' => false],
             'code_set_id'
         )->addColumn(
             'pl_color',
             \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
             255,
             ['nullable' => false],
             'color of text'
         )->addColumn(
             'pl_textsize',
             \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
             255,
             ['nullable' => false],
             'text size in pixel'
         )->addColumn(
             'pl_style',
             \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
             null,
             ['nullable' => false],
             'More CSS'
         )->addColumn(
             'plist_id',
             \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
             null,
             [ 'unsigned' => true, 'nullable' => false],
             'plist_id'
         )->addForeignKey(
             $installer->getFkName('pl_product', 'plist_id', 'pl_general', 'pl_id'),
             'plist_id',
             $installer->getTable('pl_general'),
             'pl_id',
             \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
         )->addIndex(
             $setup->getIdxName(
                 $setup->getTable('pl_product'),
                 ['pl_labeltype', 'pl_labeltext'],
                 \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT
             ),
             ['pl_labeltype', 'pl_labeltext'],
             ['type' => \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT]
         )
            ->setComment(
                'Mageants Product Label For Product Page'
            );
        $installer->getConnection()->createTable($table);

        /* create table pl_category */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('pl_category')
        )
         ->addColumn(
             'id',
             \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
             null,
             ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
             'id'
         )->addColumn(
             'pl_catlabeltype',
             \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
             255,
             ['nullable' => false],
             'label type either shape or image'
         )->addColumn(
             'pl_catlabelposition',
             \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
             6,
             ['nullable' => false],
             'Position for of label on media'
         )->addColumn(
             'pl_catlabeltyperadio',
             \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
             6,
             ['nullable' => false],
             'Label Type Radio'
         )->addColumn(
             'pl_catlabelsize',
             \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
             3,
             ['nullable' => false],
             'Label size in %'
         )->addColumn(
             'pl_catlabeltext',
             \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
             255,
             ['nullable' => false],
             'code_set_id'
         )->addColumn(
             'pl_catcolor',
             \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
             255,
             ['nullable' => false],
             'color of text'
         )->addColumn(
             'pl_cattextsize',
             \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
             255,
             ['nullable' => false],
             'text size in pixel'
         )->addColumn(
             'pl_catstyle',
             \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
             null,
             ['nullable' => false],
             'More CSS'
         )->addColumn(
             'plist_id',
             \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
             null,
             ['unsigned' => true, 'nullable' => false],
             'plist_id'
         )->addForeignKey(
             $installer->getFkName(
                 'pl_category',
                 'plist_id',
                 'pl_general',
                 'pl_id'
             ),
             'plist_id',
             $installer->getTable('pl_general'),
             'pl_id',
             \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
         )->addIndex(
             $setup->getIdxName(
                 $setup->getTable('pl_category'),
                 ['pl_catlabeltype', 'pl_catlabeltext'],
                 \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT
             ),
             ['pl_catlabeltype', 'pl_catlabeltext'],
             ['type' => \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT]
         ) ->setComment(
             'Mageants Product Label For Category Page'
         );
        $installer->getConnection()->createTable($table);
        /* create table pl_condition */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('pl_condition')
        )
         ->addColumn(
             'id',
             \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
             null,
             ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
             'id'
         )->addColumn(
             'is_new',
             \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
             1,
             ['nullable' => false],
             'label attribute is_new selected'
         )->addColumn(
             'pl_onsale',
             \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
             1,
             ['nullable' => false],
             'label attribute pl_onsale selected'
         )->addColumn(
             'pl_stock',
             \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
             1,
             ['nullable' => false],
             'Is in stock'
         )->addColumn(
             'pl_stock_range',
             \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
             1,
             ['nullable' => false],
             'is Stock range?'
         )->addColumn(
             'pl_min_stock',
             \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
             255,
             ['nullable' => false],
             'pl_min_stock'
         )->addColumn(
             'pl_max_stock',
             \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
             255,
             ['nullable' => false],
             'pl_max_stock'
         )->addColumn(
             'pl_price_range',
             \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
             1,
             ['nullable' => false],
             'pl_price_range'
         )->addColumn(
             'pl_by_range',
             \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
             1,
             ['nullable' => false],
             'More CSS'
         )->addColumn(
             'pl_min_price',
             \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
             255,
             ['nullable' => false],
             'pl_min_price'
         )->addColumn(
             'pl_max_price',
             \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
             255,
             ['nullable' => false],
             'pl_max_price'
         )->addColumn(
             'pl_is_customergropup',
             \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
             1,
             ['nullable' => false],
             'pl_is_customergropup'
         )->addColumn(
             'customer_group_ids',
             \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
             255,
             ['nullable' => false],
             'customer_group_ids'
         )->addColumn(
             'serialized_condition',
             \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
             '2M',
             ['nullable' => false],
             'serialized_condition'
         )->addColumn(
             'plist_id',
             \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
             null,
             ['unsigned' => true, 'nullable' => false],
             'plist_id'
         )->addForeignKey(
             $installer->getFkName(
                 'pl_condition',
                 'plist_id',
                 'pl_general',
                 'pl_id'
             ),
             'plist_id',
             $installer->getTable('pl_general'),
             'pl_id',
             \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
         )->setComment(
             'Mageants Product Label Conditions'
         );
        $installer->getConnection()->createTable($table);

        $installer->getConnection()
        ->addColumn(
            $installer->getTable('salesrule'),
            'plist_id',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                'length' => 6,
                'nullable' => false,
                'default' => 0,
                'comment' => 'Product Label Attribute'
            ]
        );
        $service_url = 'https://www.mageants.com/index.php/rock/register/live?ext_name=Mageants_ProductLabels&dom_name='.
        $this->StoreManager->getStore()->getBaseUrl();
        $this->curlClient->get($service_url);
        //response will contain the output in form of JSON string
        $response = $this->curlClient->getBody();
        $installer->endSetup();
    }
}
