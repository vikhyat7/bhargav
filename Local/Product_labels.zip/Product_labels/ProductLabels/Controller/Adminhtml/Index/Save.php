<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */

namespace Mageants\ProductLabels\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\SalesRule\Model\Rule;
use \Mageants\ProductLabels\Helper\Data;

/**
 * Perform save action for ProductLabels
 */
class Save extends Action
{
    /**
     * @var \Mageants\ProductLabels\Model\Plgeneral
     */
    protected $_general;
    
    /**
     * @var \Mageants\ProductLabels\Model\Plproduct
     */
    protected $_plproduct;

    /**
     * @var \Mageants\ProductLabels\Model\Plcategory
     */
    protected $_plcategory;
    protected $_helper;

    /**
     * @var \Mageants\ProductLabels\Model\Plcategory
     */
    protected $_plcondition;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param  \Mageants\ProductLabels\Model\Plgeneral $general
     * @param  \Mageants\ProductLabels\Model\Plproduct $plproduct
     * @param  \Mageants\ProductLabels\Model\Plcategory $plcategory
     */
    public function __construct(
        Action\Context $context,
        \Mageants\ProductLabels\Model\Plgeneral $general,
        \Mageants\ProductLabels\Model\Plproduct $plproduct,
        \Mageants\ProductLabels\Model\Plcategory $plcategory,
        \Mageants\ProductLabels\Model\Plconditions $plconditions,
        \Magento\Framework\Serialize\Serializer\Json $serializer = null,
        \Mageants\ProductLabels\Helper\Data $helper,
        Rule $rule
    ) {
        $this->_general = $general;
        $this->_plproduct = $plproduct;
        $this->_plcategory = $plcategory;
        $this->_plcondition = $plconditions;
        $this->_rule= $rule;
        $this->_helper = $helper;
        $this->serializer = $serializer ?: \Magento\Framework\App\ObjectManager::getInstance()->get(
            \Magento\Framework\Serialize\Serializer\Json::class
        );
        parent::__construct($context);
    }

    /**
     * Execuite save action
     */
    public function execute()
    {
        $data = $this->getRequest()->getParams();
        $tmpData = [];
        $temp = 0;

        $data['condition_serialized'] = '';
      
        if (isset($data['rule'])) {
            $temp = 1;
            $tmpData = ['conditions'=>$data['rule']['conditions']];
            $tmpRule = $this->_objectManager->create(
                \Mageants\ProductLabels\Model\TmpRule::class
            );
            $tmpRule->loadPost($tmpData);
            $data['condition_serialized'] = $tmpRule->getSerializedConditions();
            unset($data['rule']);
        }
     
        $serialized_condition='';
        if (array_key_exists('rule', $data)) {
            unset($data['rule']['conditions'][1]);
            $serialized_condition=$this->serializer->serialize($data['rule']);
        }

        $product_label_type='';
        $category_label_type='';
        if (array_key_exists('pl_labeltype_upload', $data)) {
            foreach ($data['pl_labeltype_upload'] as $uploaded) {
                $product_label_type= $uploaded['name'];
            }
        } else {
            if (array_key_exists('pl_type', $data)) {
                $product_label_type= $data['pl_type'];
            } else {
                $product_label_type='' ;
            }
        }
      
        if (array_key_exists('pl_catlabeltype_upload', $data) && $data['pl_catlabeltyperadio'] == 1) {
            foreach ($data['pl_catlabeltype_upload'] as $uploaded) {
                $category_label_type= $uploaded['name'];
            }
        } else {
            if (array_key_exists('pl_cattype', $data) && $data['pl_catlabeltyperadio'] == 0) {
                $category_label_type= $data['pl_cattype'];
            } else {
                $data['pl_catlabeltyperadio'] = 0;
                $category_label_type='' ;
            }
        }
        $showin='';
        $customerIds='';
        $categories='';
        if (is_array($data['pl_showin'])) {
            $showin = implode(",", $data['pl_showin']);
        } else {
            $showin = $data['pl_showin'];
        }

        if (array_key_exists('customer_group_ids', $data)) {
            if (is_array($data['customer_group_ids'])) {
                $customerIds= implode(",", $data['customer_group_ids']);
            } else {
                $customerIds= $data['customer_group_ids'];
            }
        }
        if (array_key_exists('condition', $data)) {
            if (is_array($data['condition'])) {
                $categories= implode(",", $data['condition']);
            } else {
                $categories= $data['condition'];
            }
        }

        $generalData = ['pl_name'=>$data['pl_name'],
        'pl_status'=>$data['pl_status'],
        'pl_priority'=>$data['pl_priority'],
        'pl_isparent'=>$data['pl_isparent'],
        'pl_showin'=>$showin,
        'condition'=>$categories];
        if ($product_label_type=='') {
            $productData=['pl_labelsize'=>$data['pl_labelsize'],
            'pl_labeltext'=>$data['pl_labeltext'],
            'pl_color'=>$data['pl_color'],
            'pl_textsize'=>$data['pl_textsize'],
            'pl_style'=>$data['pl_style'],
            'pl_labeltyperadio'=>$data['pl_labeltyperadio']];
        } else {
            $productData=['pl_labeltype'=>$product_label_type,
            'pl_labelposition'=>$data['labelpos'],
            'pl_labelsize'=>$data['pl_labelsize'],
            'pl_labeltext'=>$data['pl_labeltext'],
            'pl_color'=>$data['pl_color'],
            'pl_textsize'=>$data['pl_textsize'],
            'pl_style'=>$data['pl_style'],
            'pl_labeltyperadio'=>$data['pl_labeltyperadio']];
        }

        if ($category_label_type=='') {
            $categoryData = ['pl_catlabelsize'=>$data['pl_catlabelsize'],
            'pl_catlabeltext'=>$data['pl_catlabeltext'],
            'pl_catcolor'=>$data['pl_catcolor'],
            'pl_cattextsize'=>$data['pl_cattextsize'],
            'pl_catstyle'=>$data['pl_catstyle'],
            'pl_catlabeltyperadio'=>$data['pl_catlabeltyperadio']];
        } else {
            $categoryData = ['pl_catlabeltype'=>$category_label_type,
            'pl_catlabelposition'=>$data['catlabelpos'],
            'pl_catlabelsize'=>$data['pl_catlabelsize'],
            'pl_catlabeltext'=>$data['pl_catlabeltext'],
            'pl_catcolor'=>$data['pl_catcolor'],
            'pl_cattextsize'=>$data['pl_cattextsize'],
            'pl_catstyle'=>$data['pl_catstyle'],
            'pl_catlabeltyperadio'=>$data['pl_catlabeltyperadio']];
        }
         
        $rul_cond=[];
        if ($serialized_condition!=='') {
            $rul_cond = ['conditions_serialized'=>$serialized_condition, 'name'=>$data['pl_name'], 'is_active'=>0];
        }
        try {
            $this->_general->setData($generalData);
            if (isset($data['pl_id'])) {
                    $this->_general->setPlId($data['pl_id']);
            }

            $id=$this->_general->save()->getId();
            $productData['plist_id']=$id;
            $categoryData['plist_id']=$id;
            $condtionsData['plist_id']=$id;
            $this->_plproduct->setData($productData);
            if (isset($data['pl_id'])) {
                    $this->_plproduct->setId($id);
            }
            $this->_plproduct->save();
            $this->_plcategory->setData($categoryData);
            if (isset($data['pl_id'])) {
                $this->_plcategory->setId($id);
            }
            $this->_plcategory->save();
            $serialized_condition_array = [];
            $serialized_condition_array['rule'] = null;
            $serialized_condition_array = $this->serializeSetting($serialized_condition_array);

            if (!array_key_exists('rule', $data)) {
                $cond_collection = $this->_plcondition->getCollection()->addFieldToFilter('plist_id', $id);

                if ($cond_collection && count($cond_collection) > 0) {
                    foreach ($cond_collection as $key => $value) {
                        if ($id == $value->getId() && $temp == 1) {
                            $condtionsData = ['plist_id'=>$id,
                            'is_new'=>$data['is_new'],
                            'pl_onsale'=>$data['pl_onsale'],
                            'pl_stock'=>$data['pl_stock'],
                            'pl_stock_range'=>$data['pl_stock_range'],
                            'pl_min_stock'=>$data['pl_min_stock'],
                            'pl_max_stock'=>$data['pl_max_stock'],
                            'pl_price_range'=>$data['pl_price_range'],
                            'pl_by_range'=>$data['pl_by_range'],
                            'pl_min_price'=>$data['pl_min_price'],
                            'pl_max_price'=>$data['pl_max_price'],
                            'pl_is_customergropup'=>$data['pl_is_customergropup'],
                            'customer_group_ids'=>$customerIds,
                            'serialized_condition'=>$data['condition_serialized']];
                        }
                    }
                } else {
                    $condtionsData = ['plist_id'=>$id,'is_new'=>$data['is_new'],
                    'pl_onsale'=>$data['pl_onsale'],
                    'pl_stock'=>$data['pl_stock'],
                    'pl_stock_range'=>$data['pl_stock_range'],
                    'pl_min_stock'=>$data['pl_min_stock'],
                    'pl_max_stock'=>$data['pl_max_stock'],
                    'pl_price_range'=>$data['pl_price_range'],
                    'pl_by_range'=>$data['pl_by_range'],
                    'pl_min_price'=>$data['pl_min_price'],
                    'pl_max_price'=>$data['pl_max_price'],
                    'pl_is_customergropup'=>$data['pl_is_customergropup'],
                    'customer_group_ids'=>$customerIds,
                    'serialized_condition'=>$data['condition_serialized']];
                }
            } else {
                $condtionsData = ['plist_id'=>$id,'is_new'=>$data['is_new'],
                'pl_onsale'=>$data['pl_onsale'],
                'pl_stock'=>$data['pl_stock'],
                'pl_stock_range'=>$data['pl_stock_range'],
                'pl_min_stock'=>$data['pl_min_stock'],
                'pl_max_stock'=>$data['pl_max_stock'],
                'pl_price_range'=>$data['pl_price_range'],
                'pl_by_range'=>$data['pl_by_range'],
                'pl_min_price'=>$data['pl_min_price'],
                'pl_max_price'=>$data['pl_max_price'],
                'pl_is_customergropup'=>$data['pl_is_customergropup'],
                'customer_group_ids'=>$customerIds,
                'serialized_condition'=>$data['condition_serialized']];
            }

            $this->_plcondition->setData($condtionsData);
            if (isset($data['pl_id'])) {
                $conditionId = 0;
                $collection = $this->_plcondition->getCollection()->addFieldToFilter('plist_id', $id);
                foreach ($collection as $key => $value) {
                    $conditionId = $value->getId();
                }
                $this->_plcondition->setId($conditionId);
            }
            $this->_plcondition->save();
        } catch (Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
        }
        $this->messageManager->addSuccess("Label Saved Successfully");
        if ($this->getRequest()->getParam('back')) {
            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            return $resultRedirect->setPath('*/*/addLabel', ['pl_id' => $id, '_current' => true]);
            // $this->_redirect($this->_redirect->getRefererUrl());
            // return;
        }

        $this->_redirect('productlabels/index/index');
    }
   /**
    * Get conditions data recursively
    *
    * @param array $data
    * @param array $allowedKeys
    * @return array
    */
    private function convertRuleFlatDataAsRecursive(array $data, $allowedKeys = [])
    {
        $result = [];
        foreach ($data as $key => $value) {
            if (in_array($key, $allowedKeys) && is_array($value)) {
                foreach ($value as $id => $data) {
                    $path = explode('--', $id);
                    $node = & $result;
                    for ($i = 0, $l = count($path); $i < $l; $i++) {
                        if (!isset($node[$key][$path[$i]])) {
                            $node[$key][$path[$i]] = [];
                        }
                        $node = & $node[$key][$path[$i]];
                    }
                    foreach ($data as $k => $v) {
                        $node[$k] = $v;
                    }
                }
            }
        }
    
        return $result;
    }

    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Mageants_ProductLabels::save');
    }
    public function serializeSetting($data)
    {
        return $this->serializer->serialize($data);
    }
}
