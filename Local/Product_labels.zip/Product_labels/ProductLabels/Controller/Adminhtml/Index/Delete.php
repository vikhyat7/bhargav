<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */

namespace Mageants\ProductLabels\Controller\Adminhtml\Index;
 
use Magento\Backend\App\Action\Context;

/**
 * Perform delete action for ProductLabels
 */
class Delete extends \Magento\Backend\App\Action
{
    /**
     * pl general
     *
     * @var Mageants\ProductLabels\Model\Plgeneral
     */

    protected $plgeneral;

    /**
     * pl product
     *
     * @var Mageants\ProductLabels\Model\Plprocuct
     */

    protected $plproduct;

    /**
     * pl category
     *
     * @var Mageants\ProductLabels\Model\plcategory
     */

    protected $plcategory;

    /**
     * pl plconditions
     *
     * @var Mageants\ProductLabels\Model\plconditions
     */
    protected $plconditions;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Mageants\ProductLabels\Model\Plgeneral $plgeneral
     * @param \Mageants\ProductLabels\Model\Plproduct $plproduct
     * @param \Mageants\ProductLabels\Model\Plcategory $plcategory
     * @param \Mageants\ProductLabels\Model\Plconditions $plcondition
     */
    public function __construct(
        Context $context,
        \Mageants\ProductLabels\Model\Plgeneral $plgeneral,
        \Mageants\ProductLabels\Model\Plproduct $plproduct,
        \Mageants\ProductLabels\Model\Plcategory $plcategory,
        \Mageants\ProductLabels\Model\Plconditions $plconditions
    ) {
        $this->plgeneral=$plgeneral;
        $this->plproduct=$plproduct;
        $this->plcategory=$plcategory;
        $this->plcondition=$plconditions;
        parent::__construct($context);
    }

    /**
     * Perform Delete Action
     */
    public function execute()
    {
        if ($this->getRequest()->getParam('pl_id')!='') {
            $id = $this->getRequest()->getParam('pl_id');
            try {
                $generalData= $this->plgeneral->load($id);
                $productData = $this->plproduct->getCollection()->addFieldToFilter('plist_id', $id);
                $categoryData = $this->plcategory->getCollection()->addFieldToFilter('plist_id', $id);
                $condionData =$this->plcondition->getCollection()->addFieldToFilter('plist_id', $id);

                $generalData->delete();
                foreach ($productData as $pdata) {
                    $pdata->delete();
                }
                foreach ($categoryData as $cdata) {
                    $cdata->delete();
                }
                foreach ($condionData as $cdata) {
                    $pdata->delete();
                }
            } catch (Exception $e) {
                $this->messageManager->addError(__($ex->getMessage()));
            }
            $count = 0;
            if ($this->getRequest()->getParam('pl_id')) {
                $count++;
            }
            $this->messageManager->addSuccess(__('A total of %1 record(s) have been deleted.', $count));
        }
        $this->_redirect('productlabels/index/index');
    }

    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Mageants_ProductLabels::delete');
    }
}
