<?php
 /**
  * @category Mageants Advance Size Chart
  * @package Mageants_Advancesizechart
  * @copyright Copyright (c) 2017 Mageants
  * @author Mageants Team <info@mageants.com>
  */

namespace Mageants\ProductLabels\Controller\Adminhtml\Index;

use Magento\Rule\Model\Condition\AbstractCondition;
use Mageants\ProductLabels\Model\Rule\Product as ProductRule;

class NewRuleHtml extends \Magento\CatalogRule\Controller\Adminhtml\Promo\Catalog
{

    /**
     * @return void
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        
        $formName = $this->getRequest()->getParam('form_namespace');
        
        $typeArr = explode('|', str_replace('-', '/', $this->getRequest()->getParam('type')));
        
        $type = $typeArr[0];

        $prefix = 'rule';
        
        if ($this->getRequest()->getParam('prefix')) {
            $prefix = $this->getRequest()->getParam('prefix');
        }

        $rule = ProductRule::class;
        $this->_objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $model = $this->_objectManager->create($type)
                                      ->setId($id)
                                      ->setType($type)
                                      ->setRule($this->_objectManager->create($rule))
                                      ->setPrefix($prefix);

        if (!empty($typeArr[1])) {
            $model->setAttribute($typeArr[1]);
        }

        if ($model instanceof AbstractCondition) {
            $model->setJsFormObject($this->getRequest()->getParam('form'));
            $model->setFormName($formName);
            $html = $model->asHtmlRecursive();
        } else {
            $html = '';
        }
        $this->getResponse()->setBody($html);
    }
}
