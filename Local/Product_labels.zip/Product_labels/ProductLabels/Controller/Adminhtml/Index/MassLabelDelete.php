<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */

namespace Mageants\ProductLabels\Controller\Adminhtml\Index;

use Magento\Framework\Controller\ResultFactory;
use Magento\Backend\App\Action\Context;
use Magento\Ui\Component\MassAction\Filter;
use Mageants\ProductLabels\Model\ResourceModel\Plgeneral\CollectionFactory;

/**
 * Perform MassDelete controller Action
 */
class MassLabelDelete extends \Magento\Backend\App\Action
{
    /**
     * Filter
     *
     * @var \Magento\Ui\Component\MassAction\Filter
     */
    protected $_filter;

    /**
     * plgeneral
     *
     * @var \Mageants\ProductLabels\Model\Plgeneral
     */
    protected $plgeneral;

    /**
     * plporduct
     *
     * @var \Mageants\ProductLabels\Model\Plproduct
     */
    protected $plproduct;

    /**
     * plcategory
     *
     * @var \Mageants\ProductLabels\Model\Plcategory
     */
    protected $plcategory;

    /**
     * plconditions
     *
     * @var \Mageants\ProductLabels\Model\Plconditions
     */
    protected $plconditions;

    /**
     * Collection factory
     *
     * @var \Mageants\ProductLabels\Model\ResourceModel\Plgeneral\CollectionFactory
     */
    protected $_collectionFactory;
    
    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Ui\Component\MassAction\Filter $filter
     * @param  \Mageants\ProductLabels\Model\ResourceModel\Plgeneral\CollectionFactory $collectionFactory
     * @param \Mageants\ProductLabels\Model\Plproduct $plproduct
     * @param \Mageants\ProductLabels\Model\Plcategory $plcategory
     * @param \Mageants\ProductLabels\Model\Plconditions $plconditions
     */
    public function __construct(
        Context $context,
        Filter $filter,
        \Mageants\ProductLabels\Model\Plgeneral $plgeneral,
        \Mageants\ProductLabels\Model\Plproduct $plproduct,
        \Mageants\ProductLabels\Model\Plcategory $plcategory,
        \Mageants\ProductLabels\Model\Plconditions $plconditions,
        CollectionFactory $collectionFactory
    ) {
        $this->_filter = $filter;
        $this->plgeneral = $plgeneral;
        $this->plproduct = $plproduct;
        $this->plcategory = $plcategory;
        $this->plconditions = $plconditions;
        $this->_collectionFactory = $collectionFactory;
        parent::__construct($context);
    }
    
    /**
     * Perform MassDelete Action
     */
    public function execute()
    {
        $collection = $this->_filter->getCollection($this->_collectionFactory->create());
        $collectionSize = $collection->getSize();
        foreach ($collection as $items) {
            $id = $items->getId();
            $generalData = $this->plgeneral->load($id);
            $productData = $this->plproduct->getCollection()->addFieldToFilter('plist_id', $id);
            $categoryData = $this->plcategory->getCollection()->addFieldToFilter('plist_id', $id);
            $condtionData = $this->plconditions->getCollection()->addFieldToFilter('plist_id', $id);
            try {
                $generalData->delete();
                foreach ($productData as $pdata) {
                    $pdata->delete();
                }
                foreach ($categoryData as $cdata) {
                    $cdata->delete();
                }
                foreach ($condtionData as $cdata) {
                        $cdata->delete();
                }
            } catch (Exception $e) {
                $this->messageManager->addError($e->getMessage());
            }
        }
            $this->messageManager->addSuccess(
                __('A total of %1 record(s) have been deleted.', $collectionSize)
            );
 
            return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setPath('*/*/index');
    }

    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Mageants_ProductLabels::massdelete');
    }
}
