<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */
namespace Mageants\ProductLabels\Controller\Adminhtml\Index;

use Magento\Framework\Controller\ResultFactory;

/**
 * Index Controller for CodeList
 */
class Index extends \Mageants\ProductLabels\Controller\Adminhtml\Index
{
    /**
     * Perform Index Action
     */
    public function execute()
    {
        
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Mageants_ProductLabels::productlabels');
        $resultPage->addBreadcrumb(__('Product Labels'), __('Product Labels'));
        $resultPage->addBreadcrumb(__('Product Labels'), __('Product Labels'));
        $resultPage->getConfig()->getTitle()->prepend(__('Product Labels'));
        return $resultPage;
    }

    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Mageants_ProductLabels::productlabels');
    }
}
