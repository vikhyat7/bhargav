<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */

namespace Mageants\ProductLabels\Controller\Adminhtml\Index;

use Magento\Framework\Controller\ResultFactory;

/**
 * ProductLabels class for add new ProductLabels
 */
class Addlabel extends \Magento\Backend\App\Action
{
   
    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $coreRegistry,
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry
    ) {
        parent::__construct($context);
        $this->_coreRegistry = $coreRegistry;
    }
    
    /**
     * Label Form
     */
    public function execute()
    {
        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        $title =  __('Add Labels');
        $resultPage->getConfig()->getTitle()->prepend($title);
        $sizechartid  = (int) $this->getRequest()->getParam('pl_id');
        $sizechart = '';
        /** @var \Mageants\Advancesizechart\Model\Sizechart $sizechart */
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $model =  $objectManager->create(\Mageants\ProductLabels\Model\Plconditions::class);
        
        if ($sizechartid) {
            $model->load($sizechartid);
        }
        $this->_coreRegistry->register('pl_condition', $model);

        return $resultPage;
    }
    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Mageants_ProductLabels::addlabel');
    }
}
