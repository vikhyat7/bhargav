<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2020 Mageants
 * @author Mageants Team <support@mageants.com>
 */

namespace Mageants\ProductLabels\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Mageants\ProductLabels\Model\ProductLabels;
use Magento\Catalog\Api\ProductRepositoryInterface;

/**
 * AfterCustomerSaveObserver class for store credit amount update on after customer save
 */
class AfterProductSaveObserver implements ObserverInterface
{
    /**
     * @var $logger,$productRepository,$scopeConfig
     */
    protected $logger;
    protected $productRepository;
    protected $scopeConfig;

    /**
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Mageants\StoreCredit\Helper\Email $helperEmail
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param array $data
     */
    public function __construct(
        \Psr\Log\LoggerInterface $logger,
        ProductRepositoryInterface $productRepository,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
    ) {
        $this->_logger = $logger;
        $this->productRepository = $productRepository;
        $this->scopeConfig = $scopeConfig;
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $product_id = $observer->getProduct()->getId();  // you will get product object
        $newattributeValue = $observer->getProduct()->getCustomAttribute('new')->getValue();
        $saleattributeValue = $observer->getProduct()->getCustomAttribute('sale')->getValue();

        $product = $this->productRepository->getById($product_id);
        /*$product->setData('new', $newattributeValue);
        $product->setData('sale', $saleattributeValue);
        $this->productRepository->save($product);*/
    }
}
