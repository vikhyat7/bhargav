<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */
namespace Mageants\ProductLabels\Model\ResourceModel\Plgeneral;

/**
 * Plgeneral model collection
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
     /**
      * @var string
      */
    protected $_idFieldName = 'pl_id';
    
    /**
     * init constructor
     */
    protected function _construct()
    {
        $this->_init(
            \Mageants\ProductLabels\Model\Plgeneral::class,
            \Mageants\ProductLabels\Model\ResourceModel\Plgeneral::class
        );
    }
}
