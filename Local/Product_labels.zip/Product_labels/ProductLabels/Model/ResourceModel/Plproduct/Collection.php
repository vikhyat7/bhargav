<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */

namespace Mageants\ProductLabels\Model\ResourceModel\Plproduct;

/**
 * Account model collection
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    
    /**
     * init constructor
     */
    protected function _construct()
    {
        $this->_init(
            \Mageants\ProductLabels\Model\Plproduct::class,
            \Mageants\ProductLabels\Model\ResourceModel\Plproduct::class
        );
    }
}
