<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */
namespace Mageants\ProductLabels\Model\ResourceModel\Plconditions;

/**
 * Plgeneral model collection
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * init constructor
     */
    protected function _construct()
    {
        $this->_init(
            \Mageants\ProductLabels\Model\Plconditions::class,
            \Mageants\ProductLabels\Model\ResourceModel\Plconditions::class
        );
    }

     /**
      * @param string $formName
      * @return string
      */
    public function getConditionsFieldSetId($formName = '')
    {
        return $formName . 'rule_conditions_fieldset_';
    }
}
