<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */
namespace Mageants\ProductLabels\Model;

/**
 * plgeneral Model class
 */
class Plgeneral extends \Magento\Framework\Model\AbstractModel
{
    /**
     * init Model class
     */
    protected function _construct()
    {
        $this->_init(\Mageants\ProductLabels\Model\ResourceModel\Plgeneral::class);
    }
}
