<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */
namespace Mageants\ProductLabels\Model;

/**
 * PlproductProduct Model class
 */
class Plproduct extends \Magento\Framework\Model\AbstractModel
{
    /**
     * init of model
     */
    protected function _construct()
    {
        $this->_init(\Mageants\ProductLabels\Model\ResourceModel\Plproduct::class);
    }
}
