<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */
namespace Mageants\ProductLabels\Model\Config\Source;

use \Magento\Store\Model\StoreRepository;

/**
 * Stores Class return array
 */
class IsRange implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @return Array
     */
    public function toOptionArray()
    {
        return [
            ['value' => '0', 'label' => __('No')],
            ['value' => '1', 'label' => __('Yes')],
        ];
    }
}
