<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */
namespace Mageants\ProductLabels\Model\Config\Source;

use \Magento\Store\Model\StoreRepository;

/**
 * Stores Class return array
 */
class ByPrice implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @return Array
     */
    public function toOptionArray()
    {
        return [
            ['value' => '0', 'label' => __('Base Price')],
            ['value' => '1', 'label' => __('Special Price')],
            ['value' => '2', 'label' => __('Final Price')],
            ['value' => '3', 'label' => __('Final Price Incl Tax')],
            ['value' => '4', 'label' => __('Starting From Price')],
            ['value' => '5', 'label' => __('Starting To Price')],
        ];
    }
}
