<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */
namespace Mageants\ProductLabels\Model\Config\Source;

use \Magento\Store\Model\StoreRepository;

/**
 * Stores Class return array
 */
class Stores implements \Magento\Framework\Option\ArrayInterface
{
/**
 * @var Rate
 */
    protected $_storeRepository;
      
    /**
     * @param StoreRepository      $storeRepository
     */
    public function __construct(
        StoreRepository $storeRepository
    ) {
        $this->_storeRepository = $storeRepository;
    }
   
    /**
     * @return Array
     */
    public function toOptionArray()
    {
        $stores = $this->_storeRepository->getList();
        $websiteIds = [];
        $storeList = [];
        foreach ($stores as $store) {
            $websiteId = $store["website_id"];
            $storeId = $store["store_id"];
            $storeName = $store["name"];
            $storeList = [
                            $store["store_id"] => [
                                'label' => $store['name'],
                                'value' => $store["store_id"]
                            ],
                      ];
            
            array_push($websiteIds, $websiteId);
        }
        return $storeList;
    }
}
