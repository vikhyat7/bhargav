<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */
namespace Mageants\ProductLabels\Model\Config\Source;

/**
 * LabeltypeLabeltype Class return array
 */
class LabelImages implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @return Array
     */
    public function toOptionArray()
    {
        return [
            ['value' => '0', 'label' => __('Select The Label Shape')],
            ['value' => '1', 'label' => __('Upload Custom Label Image')],
        ];
    }
}
