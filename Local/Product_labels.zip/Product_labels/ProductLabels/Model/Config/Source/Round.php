<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */
namespace Mageants\ProductLabels\Model\Config\Source;

/**
 * Round Class return array
 */
class Round implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @return Array
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'floor', 'label' => __('The next lowest integer value')],
            ['value' => 'round', 'label' => __('By rules of mathematical rounding')],
            ['value' => 'ceil', 'label' => __('The next highest integer value')],
        ];
    }
}
