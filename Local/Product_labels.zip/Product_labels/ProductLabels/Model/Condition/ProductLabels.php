<?php

namespace Mageants\ProductLabels\Model\Condition;

class ProductLabels extends \Magento\Rule\Model\Condition\AbstractCondition
{
    
}
