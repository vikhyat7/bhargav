<?php
/**
 * @category Mageants ProductLabels
 * @package Mageants_ProductLabels
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */
namespace Mageants\ProductLabels\Model;

use Mageants\ProductLabels\Model\ResourceModel\Plgeneral\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
 
class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider
{
    /**
     * @var array
     */
    protected $_loadedData;

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;
    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $plgeneral
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $plgeneral,
        DataPersistorInterface $dataPersistor,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $plgeneral->create();
        $this->dataPersistor = $dataPersistor;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }
 
    /**
     * Get data
     *
     * @return array
     */
    public function getData()
    {
        if (isset($this->_loadedData)) {
            return $this->_loadedData;
        }
        
        $this->collection->getSelect()->join(
            'pl_product',
            // note this join clause!
            'main_table.pl_id = pl_product.plist_id',
            ['*']
        );
        $this->collection->getSelect()->join(
            'pl_category',
            // note this join clause!
            'main_table.pl_id = pl_category.plist_id',
            ['*']
        );
         $this->collection->getSelect()->join(
             'pl_condition',
             // note this join clause!
             'main_table.pl_id = pl_condition.plist_id',
             ['*']
         );

        $items = $this->collection->getItems();
        foreach ($items as $item) {
            $this->_loadedData[$item->getId()] = $item->getData();
            $this->dataPersistor->set('pl_cond', $item->getSerializedCondition());
        }

        return $this->_loadedData;
    }
}
