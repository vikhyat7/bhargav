define([
    'underscore',
    'Magento_Ui/js/form/element/abstract',
    'uiRegistry'
], function (_, Component, registry) {
    'use strict';

    return Component.extend({
        defaults: {
            imports: {
                selectedAccountData: '${ $.provider }:data.account_selected'
            },
            exports: {
                selectedAccountData: '${ $.provider }:data.account_selected'
            },
            listens: {
                selectedAccountData: 'processSelectedAccountData'
            },
            affiliateIdFormFieldQuery: '${ $.ns }.${ $.ns }.transaction_details.affiliate_id'
        },

        /**
         * @inheritdoc
         */
        initialize: function () {
            this._super()
                .checkIsVisible();

            return this;
        },

        /**
         * Process selected account data
         */
        processSelectedAccountData: function() {
            this.updateAffiliateIdValue();
            this.updateAffiliateEmail();
            this.checkIsVisible();
        },

        /**
         * Update account name
         */
        updateAffiliateEmail: function() {
            this.value(this.getCurrentSelectedAccountData().email);
        },

        /**
         * Set affiliate_id value to hidden field
         */
        updateAffiliateIdValue: function() {
            var affiliateIdField = registry.get(this.affiliateIdFormFieldQuery);

            affiliateIdField.value(this.getCurrentSelectedAccountData().account_id);
        },

        /**
         * Get current selected account data
         * @returns {Array}
         */
        getCurrentSelectedAccountData: function() {
            var preparedData = [];

            if (this.selectedAccountData.length) {
                preparedData = this.selectedAccountData[0];
            }
            return preparedData;
        },

        /**
         * Check is visible
         */
        checkIsVisible: function () {
            var isValuePresent = !_.isEmpty(this.value());
            
            this.visible(isValuePresent);
        }
    });
});
