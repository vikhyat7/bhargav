<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Coupon;

use Aheadworks\Affiliate\Api\CouponRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\CouponInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;

/**
 * Class Resolver
 * @package Aheadworks\Affiliate\Model\Coupon
 */
class Resolver
{
    /**
     * @var CouponRepositoryInterface;
     */
    private $couponRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    private $searchCriteriaBuilder;

    /**
     * @param CouponRepositoryInterface $couponRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     */
    public function __construct(
        CouponRepositoryInterface $couponRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder
    ) {
        $this->couponRepository = $couponRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
    }

    /**
     * Retrieve sales rule id by campaign id
     *
     * @param int $campaignId
     * @return int|null
     */
    public function getSalesRuleIdByCampaignId($campaignId)
    {
        $ruleId = null;
        $searchCriteria = $this->searchCriteriaBuilder
            ->addFilter(CouponInterface::CAMPAIGN_ID, $campaignId)
            ->setPageSize(1)
            ->create();
        $searchResult = $this->couponRepository->getList($searchCriteria)->getItems();

        if (count($searchResult)) {
            /** @var CouponInterface $coupon */
            $coupon = array_shift($searchResult);
            $ruleId = $coupon->getSalesRuleId();
        }

        return $ruleId;
    }

    /**
     * Retrieve coupon by coupon code
     *
     * @param string $code
     * @return CouponInterface|null
     */
    public function getCouponByCode($code)
    {
        $coupon = null;
        $searchCriteria = $this->searchCriteriaBuilder
            ->addFilter(CouponInterface::COUPON_CODE, $code)
            ->setPageSize(1)
            ->create();
        $searchResult = $this->couponRepository->getList($searchCriteria)->getItems();

        if (count($searchResult)) {
            $coupon = array_shift($searchResult);
        }

        return $coupon;
    }

    /**
     * Retrieve affiliate coupons by account id
     *
     * @param int $affiliateId
     * @return CouponInterface[]
     */
    public function getCouponsByAffiliateId($affiliateId)
    {
        $searchCriteria = $this->searchCriteriaBuilder
            ->addFilter(CouponInterface::AFFILIATE_ID, $affiliateId)
            ->create();
        return $this->couponRepository->getList($searchCriteria)->getItems();
    }
}
