<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model;

use Aheadworks\Affiliate\Api\Data\LinkStatisticInterface;
use Magento\Framework\Model\AbstractModel;
use Aheadworks\Affiliate\Model\ResourceModel\LinkStatistic as LinkStatisticResource;

/**
 * Class LinkStatistic
 * @package Aheadworks\Affiliate\Model
 */
class LinkStatistic extends AbstractModel implements LinkStatisticInterface
{
    /**
     * {@inheritdoc}
     */
    protected function _construct()
    {
        $this->_init(LinkStatisticResource::class);
    }

    /**
     * {@inheritdoc}
     */
    public function getHitId()
    {
        return $this->getData(self::HIT_ID);
    }

    /**
     * {@inheritdoc}
     */
    public function setHitId($hitId)
    {
        return $this->setData(self::HIT_ID, $hitId);
    }

    /**
     * {@inheritdoc}
     */
    public function getAccountId()
    {
        return $this->getData(self::ACCOUNT_ID);
    }

    /**
     * {@inheritdoc}
     */
    public function setAccountId($accountId)
    {
        return $this->setData(self::ACCOUNT_ID, $accountId);
    }

    /**
     * {@inheritdoc}
     */
    public function getCampaignId()
    {
        return $this->getData(self::CAMPAIGN_ID);
    }

    /**
     * {@inheritdoc}
     */
    public function setCampaignId($campaignId)
    {
        return $this->setData(self::CAMPAIGN_ID, $campaignId);
    }

    /**
     * {@inheritdoc}
     */
    public function getTrafficSource()
    {
        return $this->getData(self::TRAFFIC_SOURCE);
    }

    /**
     * {@inheritdoc}
     */
    public function setTrafficSource($trafficSource)
    {
        return $this->setData(self::TRAFFIC_SOURCE, $trafficSource);
    }

    /**
     * {@inheritdoc}
     */
    public function getCreatedAt()
    {
        return $this->getData(self::CREATED_AT);
    }

    /**
     * {@inheritdoc}
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }
    
    /**
     * {@inheritdoc}
     */
    public function getOrdersCount()
    {
        return $this->getData(self::ORDERS_COUNT);
    }
    
    /**
     * {@inheritdoc}
     */
    public function setOrdersCount($ordersCount)
    {
        return $this->setData(self::ORDERS_COUNT, $ordersCount);
    }
}
