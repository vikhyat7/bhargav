<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Customer\Layout\Processor\Affiliate;

use Aheadworks\Affiliate\Api\AccountRepositoryInterface;
use Aheadworks\Affiliate\Model\Layout\LayoutProcessorInterface;
use Magento\Framework\Stdlib\ArrayManager;
use Aheadworks\Affiliate\Api\AffiliateGroupRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\AffiliateGroupInterface;
use Aheadworks\Affiliate\Model\ValueFormatter\Commission as CommissionFormatter;

/**
 * Class AffiliateGroupData
 * @package Aheadworks\Affiliate\Model\Customer\Layout\Processor\Affiliate
 */
class AffiliateGroupData implements LayoutProcessorInterface
{
    /**#@+
     * Constants defined for keys of the data array.
     */
    const COMMISSION_FORMATTED = 'commission_formatted';
    const IS_NEED_DISPLAY_GROUP_INFO = 'is_need_display_group_info';
    /**#@-*/

    /**
     * @var ArrayManager
     */
    private $arrayManager;

    /**
     * @var AffiliateGroupRepositoryInterface
     */
    private $affiliateGroupRepository;

    /**
     * @var AccountRepositoryInterface
     */
    private $accountRepository;

    /**
     * @var CommissionFormatter
     */
    private $commissionFormatter;

    /**
     * @param ArrayManager $arrayManager
     * @param AffiliateGroupRepositoryInterface $affiliateGroupRepository
     * @param AccountRepositoryInterface $accountRepository
     * @param CommissionFormatter $commissionFormatter
     */
    public function __construct(
        ArrayManager $arrayManager,
        AffiliateGroupRepositoryInterface $affiliateGroupRepository,
        AccountRepositoryInterface $accountRepository,
        CommissionFormatter $commissionFormatter
    ) {
        $this->arrayManager = $arrayManager;
        $this->affiliateGroupRepository = $affiliateGroupRepository;
        $this->accountRepository = $accountRepository;
        $this->commissionFormatter = $commissionFormatter;
    }

    /**
     * {@inheritdoc}
     */
    public function process($jsLayout, $customerId, $websiteId)
    {
        $groupInfoConfigProviderPath = 'components/awAffGroupInfoProvider';
        $jsLayout = $this->arrayManager->merge(
            $groupInfoConfigProviderPath,
            $jsLayout,
            [
                'data' => $this->getAffiliateGroupData($customerId, $websiteId)
            ]
        );

        return $jsLayout;
    }

    /**
     * Retrieve affiliate group data for the current affiliate
     *
     * @param int|null $customerId
     * @param int|null $websiteId
     * @return array
     */
    private function getAffiliateGroupData($customerId, $websiteId)
    {
        try {
            /** @var AffiliateGroupInterface $affiliateGroup */
            $account = $this->accountRepository->getByCustomerId($customerId, $websiteId);
            $affiliateGroup = $this->affiliateGroupRepository->getById($account->getAffiliateGroupId());
            $affiliateGroupData = [
                self::IS_NEED_DISPLAY_GROUP_INFO => $affiliateGroup->getCommissionValue() > 0,
                AffiliateGroupInterface::NAME => $affiliateGroup->getName(),
                self::COMMISSION_FORMATTED => $this->commissionFormatter->getFormattedCommissionValue(
                    $affiliateGroup->getCommissionValue(),
                    $affiliateGroup->getCommissionType(),
                    $websiteId
                )
            ];
        } catch (\Exception $exception) {
            $affiliateGroupData = [];
        }
        return $affiliateGroupData;
    }
}
