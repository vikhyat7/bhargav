<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Campaign;

use Aheadworks\Affiliate\Model\Source\Campaign\Status;

/**
 * Class Enable
 *
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Campaign
 */
class Enable extends AbstractChangeStatusAction
{
    /**
     * {@inheritdoc}
     */
    protected function getStatusToSet()
    {
        return Status::ACTIVE;
    }

    /**
     * {@inheritdoc}
     */
    protected function getSuccessMessage()
    {
        return __('The campaign was successfully enabled.');
    }

    /**
     * {@inheritdoc}
     */
    protected function getErrorMessage()
    {
        return __('Something went wrong while enabling the campaign.');
    }
}
