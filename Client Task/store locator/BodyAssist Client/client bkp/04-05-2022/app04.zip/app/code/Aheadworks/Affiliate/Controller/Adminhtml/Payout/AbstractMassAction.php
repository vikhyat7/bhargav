<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Payout;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Aheadworks\Affiliate\Api\PayoutRepositoryInterface;
use Aheadworks\Affiliate\Api\PayoutManagementInterface;
use Aheadworks\Affiliate\Api\Data\PayoutInterface;
use Aheadworks\Affiliate\Model\ResourceModel\Payout\CollectionFactory;
use Aheadworks\Affiliate\Model\ResourceModel\Payout\Collection;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Ui\Component\MassAction\Filter;
use Magento\Framework\Exception\LocalizedException;

/**
 * Class AbstractMassAction
 *
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Payout
 */
abstract class AbstractMassAction extends Action
{
    /**
     * {@inheritdoc}
     */
    const ADMIN_RESOURCE = 'Aheadworks_Affiliate::payouts';

    /**
     * @var CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @var Filter
     */
    protected $filter;

    /**
     * @var PayoutManagementInterface
     */
    protected $payoutManagement;

    /**
     * @var PayoutRepositoryInterface
     */
    protected $payoutRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * @param Context $context
     * @param CollectionFactory $collectionFactory
     * @param PayoutManagementInterface $payoutManagement
     * @param PayoutRepositoryInterface $payoutRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param Filter $filter
     */
    public function __construct(
        Context $context,
        CollectionFactory $collectionFactory,
        PayoutManagementInterface $payoutManagement,
        PayoutRepositoryInterface $payoutRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        Filter $filter
    ) {
        parent::__construct($context);
        $this->collectionFactory = $collectionFactory;
        $this->filter = $filter;
        $this->payoutManagement = $payoutManagement;
        $this->payoutRepository = $payoutRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        try {
            $payoutsArray = $this->getPayoutsForMassAction();
            $this->massAction($payoutsArray);
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        }

        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $resultRedirect->setPath('*/*/index');
        return $resultRedirect;
    }

    /**
     * Retrieve array of payouts for mass action
     *
     * @return PayoutInterface[]
     */
    protected function getPayoutsForMassAction()
    {
        $payoutsForMassAction = [];
        try {
            /** @var Collection $collection */
            $collection = $this->filter->getCollection($this->collectionFactory->create());
            $searchCriteria = $this->searchCriteriaBuilder
                ->addFilter(PayoutInterface::ID, $collection->getAllIds(), 'in')
                ->create();
            $payoutsForMassAction = $this->payoutRepository->getList($searchCriteria)->getItems();
        } catch (LocalizedException $exception) {
            $payoutsForMassAction = [];
        }

        return $payoutsForMassAction;
    }

    /**
     * Perform mass action
     *
     * @param PayoutInterface[] $payouts
     */
    abstract protected function massAction($payouts);
}
