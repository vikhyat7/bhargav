<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Customer\Layout\Processor\Affiliate;

use Aheadworks\Affiliate\Model\Layout\LayoutProcessorInterface;
use Magento\Framework\Stdlib\ArrayManager;
use Aheadworks\Affiliate\Api\AccountRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Aheadworks\Affiliate\Model\BoundCustomer\Layout\Processor as LayoutBoundCustomer;

/**
 * Class BoundCustomersData
 * @package Aheadworks\Affiliate\Model\Customer\Layout\Processor\Affiliate
 */
class BoundCustomersData implements LayoutProcessorInterface
{
    /**
     * @var ArrayManager
     */
    private $arrayManager;

    /**
     * @var AccountRepositoryInterface
     */
    private $accountRepository;

    /**
     * @var LayoutBoundCustomer
     */
    private $layoutBoundCustomer;

    /**
     * @var array
     */
    private $boundCustomerFields = [];

    /**
     * @param ArrayManager $arrayManager
     * @param AccountRepositoryInterface $accountRepository
     * @param LayoutBoundCustomer $layoutBoundCustomer
     * @param array $boundCustomerFields
     */
    public function __construct(
        ArrayManager $arrayManager,
        AccountRepositoryInterface $accountRepository,
        LayoutBoundCustomer $layoutBoundCustomer,
        array $boundCustomerFields = []
    ) {
        $this->arrayManager = $arrayManager;
        $this->accountRepository = $accountRepository;
        $this->boundCustomerFields = $boundCustomerFields;
        $this->layoutBoundCustomer = $layoutBoundCustomer;
    }

    /**
     * {@inheritdoc}
     */
    public function process($jsLayout, $customerId, $websiteId)
    {
        $balanceInfoProviderPath = 'components/awAffBoundCustomersProvider';
        $jsLayout = $this->arrayManager->merge(
            $balanceInfoProviderPath,
            $jsLayout,
            [
                'data' => $this->getBoundCustomersData($customerId, $websiteId)
            ]
        );

        return $jsLayout;
    }

    /**
     * Retrieve bound customers data
     *
     * @param int|null $customerId
     * @param int|null $websiteId
     * @return array
     */
    private function getBoundCustomersData($customerId, $websiteId)
    {
        $boundCustomersData = [];

        try {
            /** @var AccountInterface $account */
            $account = $this->accountRepository->getByCustomerId($customerId, $websiteId);
            $boundCustomersInfo = $this->layoutBoundCustomer->getBoundCustomerInfo($account->getAccountId(), $websiteId);

            foreach ($this->boundCustomerFields as $boundCustomerField) {
                $boundCustomersData[] = [
                    'value' => $boundCustomersInfo[$boundCustomerField['key']],
                    'label' => __($boundCustomerField['label'])
                ];
            }
        } catch (\Exception $exception) {
            $boundCustomersData = [];
        }

        return $boundCustomersData;
    }
}
