<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model;

use Aheadworks\Affiliate\Api\LinkStatisticRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\LinkStatisticInterface;
use Aheadworks\Affiliate\Api\Data\LinkStatisticInterfaceFactory;
use Aheadworks\Affiliate\Api\Data\LinkStatisticSearchResultsInterface;
use Aheadworks\Affiliate\Api\Data\LinkStatisticSearchResultsInterfaceFactory;
use Aheadworks\Affiliate\Model\LinkStatistic as LinkStatisticModel;
use Aheadworks\Affiliate\Model\ResourceModel\LinkStatistic as LinkStatisticResourceModel;
use Aheadworks\Affiliate\Model\ResourceModel\LinkStatistic\Collection
    as LinkStatisticCollection;
use Aheadworks\Affiliate\Model\ResourceModel\LinkStatistic\CollectionFactory
    as LinkStatisticCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;

/**
 * Class LinkStatisticRepository
 * @package Aheadworks\Affiliate\Model
 */
class LinkStatisticRepository implements LinkStatisticRepositoryInterface
{
    /**
     * @var LinkStatisticResourceModel
     */
    private $resource;

    /**
     * @var LinkStatisticInterfaceFactory
     */
    private $linkStatisticInterfaceFactory;

    /**
     * @var LinkStatisticCollectionFactory
     */
    private $linkStatisticCollectionFactory;

    /**
     * @var LinkStatisticSearchResultsInterfaceFactory
     */
    private $searchResultsFactory;

    /**
     * @var JoinProcessorInterface
     */
    private $extensionAttributesJoinProcessor;

    /**
     * @var CollectionProcessorInterface
     */
    private $collectionProcessor;

    /**
     * @var DataObjectHelper
     */
    private $dataObjectHelper;

    /**
     * @var DataObjectProcessor
     */
    private $dataObjectProcessor;

    /**
     * @var array
     */
    private $linkStatistics = [];

    /**
     * @param LinkStatisticResourceModel $resource
     * @param LinkStatisticInterfaceFactory $linkStatisticInterfaceFactory
     * @param LinkStatisticCollectionFactory $linkStatisticCollectionFactory
     * @param LinkStatisticSearchResultsInterfaceFactory $searchResultsFactory
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param CollectionProcessorInterface $collectionProcessor
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     */
    public function __construct(
        LinkStatisticResourceModel $resource,
        LinkStatisticInterfaceFactory $linkStatisticInterfaceFactory,
        LinkStatisticCollectionFactory $linkStatisticCollectionFactory,
        LinkStatisticSearchResultsInterfaceFactory $searchResultsFactory,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        CollectionProcessorInterface $collectionProcessor,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor
    ) {
        $this->resource = $resource;
        $this->linkStatisticInterfaceFactory = $linkStatisticInterfaceFactory;
        $this->linkStatisticCollectionFactory = $linkStatisticCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->collectionProcessor = $collectionProcessor;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataObjectProcessor = $dataObjectProcessor;
    }

    /**
     * {@inheritdoc}
     */
    public function save(LinkStatisticInterface $linkStatistic)
    {
        try {
            $this->resource->save($linkStatistic);
            $this->linkStatistics[$linkStatistic->getHitId()] = $linkStatistic;
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__($exception->getMessage()));
        }

        return $linkStatistic;
    }

    /**
     * {@inheritdoc}
     */
    public function getById($linkStatisticId)
    {
        if (!isset($this->linkStatistics[$linkStatisticId])) {
            /** @var LinkStatisticInterface $linkStatistic */
            $linkStatistic = $this->linkStatisticInterfaceFactory->create();
            $this->resource->load($linkStatistic, $linkStatisticId);
            if (!$linkStatistic->getHitId()) {
                throw NoSuchEntityException::singleField(LinkStatisticInterface::HIT_ID, $linkStatisticId);
            }
            $this->linkStatistics[$linkStatisticId] = $linkStatistic;
        }
        return $this->linkStatistics[$linkStatisticId];
    }

    /**
     * {@inheritdoc}
     */
    public function getList(SearchCriteriaInterface $searchCriteria)
    {
        /** @var LinkStatisticCollection $collection */
        $collection = $this->linkStatisticCollectionFactory->create();

        $this->extensionAttributesJoinProcessor->process($collection, LinkStatisticInterface::class);
        $this->collectionProcessor->process($searchCriteria, $collection);

        /** @var LinkStatisticSearchResultsInterface $searchResults */
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($searchCriteria);
        $searchResults->setTotalCount($collection->getSize());

        $objects = [];
        /** @var LinkStatisticModel $item */
        foreach ($collection->getItems() as $item) {
            $objects[] = $this->getDataObject($item);
        }
        $searchResults->setItems($objects);

        return $searchResults;
    }

    /**
     * Retrieves data object using model
     *
     * @param LinkStatisticModel $model
     * @return LinkStatisticInterface
     */
    private function getDataObject($model)
    {
        /** @var LinkStatisticInterface $object */
        $object = $this->linkStatisticInterfaceFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $object,
            $this->dataObjectProcessor->buildOutputDataArray($model, LinkStatisticInterface::class),
            LinkStatisticInterface::class
        );
        return $object;
    }
}
