define([
    'Magento_Ui/js/form/element/abstract',
    'uiRegistry'
], function (Component, registry) {
    'use strict';

    return Component.extend({
        defaults: {
            generatedLinkComponentName: '${ $.parentName }.generated_link'
        },

        /**
         * {@inheritdoc}
         */
        onUpdate: function () {
            var generatedLinkComponent = this.getGeneratedLinkComponent();

            this._super();
            if (generatedLinkComponent && generatedLinkComponent.visible()) {
                generatedLinkComponent.hide();
            }
        },

        /**
         * @return {Object}|null
         */
        getGeneratedLinkComponent: function () {
            return registry.get(this.generatedLinkComponentName);
        }
    });
});
