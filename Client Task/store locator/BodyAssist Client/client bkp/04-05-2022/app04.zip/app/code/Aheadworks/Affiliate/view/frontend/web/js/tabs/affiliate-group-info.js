define([
    'uiComponent'
], function (Component) {
    'use strict';

    return Component.extend({
        defaults: {
            template: 'Aheadworks_Affiliate/tabs/affiliate-group-info',
            imports: {
                groupInfo: '${ $.groupInfoProvider }:data'
            },
            noticeStr: 'Being a member of a {group_name} affiliate group gives you {commission_formatted} '
                + 'premium from each item purchase (in addition to the regular commission).'
        },

        /**
         * Check is need to display block
         *
         * @return {boolean}
         */
        isNeedToDisplay: function () {
            return this.groupInfo.is_need_display_group_info;
        },

        /**
         * Retrieve notice message
         */
        getNoticeMessage: function () {
            return this.noticeStr
                .replace('{group_name}', this.groupInfo.name)
                .replace('{commission_formatted}', this.groupInfo.commission_formatted);
        }
    });
});