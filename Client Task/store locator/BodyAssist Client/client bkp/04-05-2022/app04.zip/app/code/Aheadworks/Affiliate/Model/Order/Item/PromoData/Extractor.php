<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Order\Item\PromoData;

use Magento\Sales\Api\Data\OrderItemInterface;
use Aheadworks\Affiliate\Api\CampaignRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Aheadworks\Affiliate\Api\AffiliateGroupRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\AffiliateGroupInterface;
use Aheadworks\Affiliate\Api\AccountRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Class Extractor
 *
 * @package Aheadworks\Affiliate\Model\Order\Item\PromoData
 */
class Extractor
{
    /**
     * @var CampaignRepositoryInterface
     */
    private $campaignRepository;

    /**
     * @var AffiliateGroupRepositoryInterface
     */
    private $affiliateGroupRepository;

    /**
     * @var AccountRepositoryInterface
     */
    private $accountRepository;

    /**
     * @param CampaignRepositoryInterface $campaignRepository
     * @param AffiliateGroupRepositoryInterface $affiliateGroupRepository
     * @param AccountRepositoryInterface $accountRepository
     */
    public function __construct(
        CampaignRepositoryInterface $campaignRepository,
        AffiliateGroupRepositoryInterface $affiliateGroupRepository,
        AccountRepositoryInterface $accountRepository
    ) {
        $this->campaignRepository = $campaignRepository;
        $this->affiliateGroupRepository = $affiliateGroupRepository;
        $this->accountRepository = $accountRepository;
    }

    /**
     * Retrieve affiliate campaign for specific order item
     *
     * @param OrderItemInterface $orderItem
     * @return CampaignInterface
     * @throws NoSuchEntityException
     */
    public function getCampaign($orderItem)
    {
        $campaignId = $orderItem->getAwAffCampaignId();
        return $this->campaignRepository->getById($campaignId);
    }

    /**
     * Retrieve affiliate account for specific order item
     *
     * @param OrderItemInterface $orderItem
     * @return AccountInterface
     * @throws NoSuchEntityException
     */
    public function getAccount($orderItem)
    {
        $accountId = $orderItem->getAwAffAccountId();
        return $this->accountRepository->getById($accountId);
    }

    /**
     * Retrieve affiliate group for specific order item
     *
     * @param OrderItemInterface $orderItem
     * @return AffiliateGroupInterface
     * @throws NoSuchEntityException
     */
    public function getAffiliateGroup($orderItem)
    {
        $account = $this->getAccount($orderItem);
        return $this->affiliateGroupRepository->getById($account->getAffiliateGroupId());
    }
}
