<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Observer\Magento\Customer;

use Aheadworks\Affiliate\Api\AccountRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Aheadworks\Affiliate\Model\Customer\DeleteProcessor as CustomerDeleteProcessor;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Customer\Model\Backend\Customer as BackendCustomer;

/**
 * Class DeleteBefore
 * @package Aheadworks\Affiliate\Observer\Magento\Customer
 */
class DeleteBefore implements ObserverInterface
{
    /**
     * @var AccountRepositoryInterface
     */
    private $accountRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    private $searchCriteriaBuilder;

    /**
     * @var CustomerDeleteProcessor
     */
    private $customerDeleteProcessor;

    /**
     * @param AccountRepositoryInterface $accountRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param CustomerDeleteProcessor $customerDeleteProcessor
     */
    public function __construct(
        AccountRepositoryInterface $accountRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        CustomerDeleteProcessor $customerDeleteProcessor
    ) {
        $this->accountRepository = $accountRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->customerDeleteProcessor = $customerDeleteProcessor;
    }

    /**
     * {@inheritdoc}
     */
    public function execute(Observer $observer)
    {
        $customerId = $this->resolveCustomerId($observer);

        foreach ($this->getAccountsToProcess($customerId) as $account) {
            $this->customerDeleteProcessor->process($account);
        }

        return $this;
    }

    /**
     * Resolve customer id value
     *
     * @param Observer $observer
     * @return int
     */
    private function resolveCustomerId($observer)
    {
        /** @var BackendCustomer $customer */
        $customer = $observer->getEvent()->getCustomer();

        return $customer ? $customer->getEntityId() : 0;
    }

    /**
     * Retrieve accounts to process
     *
     * @param int $customerId
     * @return AccountInterface[]
     */
    private function getAccountsToProcess($customerId)
    {
        $searchCriteria = $this->searchCriteriaBuilder
            ->addFilter(AccountInterface::CUSTOMER_ID, $customerId)
            ->create();

        return $this->accountRepository->getList($searchCriteria)->getItems();
    }
}
