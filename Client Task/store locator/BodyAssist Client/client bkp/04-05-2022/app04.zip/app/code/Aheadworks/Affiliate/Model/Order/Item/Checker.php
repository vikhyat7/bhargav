<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Order\Item;

use Aheadworks\Affiliate\Api\BoundCustomerRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\BoundCustomerInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Sales\Model\Order\Item as OrderItem;
use Aheadworks\Affiliate\Api\Data\PromoDataInterface;
use Aheadworks\Affiliate\Api\Data\PromoDataInterfaceFactory;
use Aheadworks\Affiliate\Model\PromoData\Validator as PromoDataValidator;
use Aheadworks\Affiliate\Model\Source\Transaction\EntityType as TransactionEntityType;
use Aheadworks\Affiliate\Model\Source\Order\Item\Status as OrderItemStatus;
use Aheadworks\Affiliate\Api\TransactionRepositoryInterface;
use Aheadworks\Affiliate\Model\Config;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Aheadworks\Affiliate\Model\Order\Item\Checker\Status as OrderItemStatusChecker;
use Aheadworks\Affiliate\Model\BoundCustomer\Resolver as BoundCustomerResolver;

/**
 * Class Checker
 *
 * @package Aheadworks\Affiliate\Model\Order\Item
 */
class Checker
{
    /**
     * @var PromoDataInterfaceFactory
     */
    private $promoDataFactory;

    /**
     * @var PromoDataValidator
     */
    private $promoDataValidator;

    /**
     * @var TransactionRepositoryInterface
     */
    private $transactionRepository;

    /**
     * @var Config
     */
    private $config;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * @var OrderItemStatusChecker
     */
    private $orderItemStatusChecker;

    /**
     * @var BoundCustomerRepositoryInterface
     */
    private $boundCustomerRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    private $searchCriteriaBuilder;

    /**
     * @var BoundCustomerResolver
     */
    private $boundCustomerResolver;

    /**
     * @param PromoDataInterfaceFactory $promoDataFactory
     * @param PromoDataValidator $promoDataValidator
     * @param TransactionRepositoryInterface $transactionRepository
     * @param Config $config
     * @param StoreManagerInterface $storeManager
     * @param OrderItemStatusChecker $orderItemStatusChecker
     * @param BoundCustomerRepositoryInterface $boundCustomerRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param BoundCustomerResolver $boundCustomerResolver
     */
    public function __construct(
        PromoDataInterfaceFactory $promoDataFactory,
        PromoDataValidator $promoDataValidator,
        TransactionRepositoryInterface $transactionRepository,
        Config $config,
        StoreManagerInterface $storeManager,
        OrderItemStatusChecker $orderItemStatusChecker,
        BoundCustomerRepositoryInterface $boundCustomerRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        BoundCustomerResolver $boundCustomerResolver
    ) {
        $this->promoDataFactory = $promoDataFactory;
        $this->promoDataValidator = $promoDataValidator;
        $this->transactionRepository = $transactionRepository;
        $this->config = $config;
        $this->storeManager = $storeManager;
        $this->orderItemStatusChecker = $orderItemStatusChecker;
        $this->boundCustomerRepository = $boundCustomerRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->boundCustomerResolver = $boundCustomerResolver;
    }

    /**
     * Check if order item has valid affiliate promo data
     *
     * @param OrderItem $orderItem
     * @return bool
     */
    public function hasValidPromoData($orderItem)
    {
        /** @var PromoDataInterface $promoData */
        $promoData = $this->promoDataFactory->create();
        $promoData->setAccountId($orderItem->getAwAffAccountId());
        $promoData->setCampaignId($orderItem->getAwAffCampaignId());
        $promoData->setTrafficSource($orderItem->getAwAffTrafficSource());
        return $this->promoDataValidator->validate($promoData, $orderItem->getStoreId());
    }

    /**
     * Check if affiliate promo commission transaction has been added for order item earlier
     *
     * @param OrderItem $orderItem
     * @return bool
     */
    public function isTransactionCreated($orderItem)
    {
        $transactionId = $this->transactionRepository->getTransactionIdForEntity(
            TransactionEntityType::ORDER_ITEM,
            $orderItem->getItemId()
        );
        return !empty($transactionId);
    }

    /**
     * Check if affiliate promo commission transaction has been added for order item earlier
     *
     * @param OrderItem $orderItem
     * @return bool
     */
    public function isCustomerAdded($orderItem)
    {
        if ($this->config->isLifetimeAttributionCustomerAffiliateEnabled($this->getOrderItemWebsiteId($orderItem))) {
            $customerId = $orderItem->getOrder()->getCustomerId();

            if ($customerId) {
                if ($this->boundCustomerResolver->getBoundCustomerByCustomerId($customerId)) {
                    return true;
                }
            }

            if ($this->boundCustomerResolver->getBoundCustomerByEmail($orderItem->getOrder()->getCustomerEmail())) {
                if ($customerId) {
                    return false;
                } else {
                    return true;
                }
            } else {
                return false;
            }
        }

        return true;
    }

    /**
     * Check if order item status allows to create transaction
     *
     * @param OrderItem $orderItem
     * @return bool
     */
    public function isTransactionCreationAllowed($orderItem)
    {
        $statusForTransactionCreation = $this->config->getOrderItemStatusForCommissionAdding(
            $this->getOrderItemWebsiteId($orderItem)
        );

        $isTransactionCreationAllowed =
            $this->orderItemStatusChecker->isItemInStatus(
                $orderItem,
                OrderItemStatus::getDefaultValueForAddingCommission()
            )
            || $this->orderItemStatusChecker->isItemInStatus(
                $orderItem,
                $statusForTransactionCreation
            )
        ;
        return $isTransactionCreationAllowed;
    }

    /**
     * Check if order item status allows to create transaction
     *
     * @param OrderItem $orderItem
     * @return bool
     */
    public function isTransactionCancellationAllowed($orderItem)
    {
        $isTransactionCancellationAllowed = false;
        $statusesForTransactionCancellation = $this->config->getOrderItemStatusesForCommissionDeduction(
            $this->getOrderItemWebsiteId($orderItem)
        );
        foreach ($statusesForTransactionCancellation as $statusId) {
            if ($this->orderItemStatusChecker->isItemInStatus($orderItem, $statusId)) {
                $isTransactionCancellationAllowed = true;
                break;
            }
        }

        return $isTransactionCancellationAllowed;
    }

    /**
     * Retrieve website id where order item has been placed
     *
     * @param OrderItem $orderItem
     * @return int|null
     */
    private function getOrderItemWebsiteId($orderItem)
    {
        try {
            $orderItemWebsiteId = $this->storeManager->getStore($orderItem->getStoreId())->getWebsiteId();
        } catch (NoSuchEntityException $exception) {
            $orderItemWebsiteId = null;
        }
        return $orderItemWebsiteId;
    }
}
