<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\BoundCustomer\Layout;

use Aheadworks\Affiliate\Api\Data\BoundCustomerInterface;
use Aheadworks\Affiliate\Model\BoundCustomer\DataProvider;
use Aheadworks\Affiliate\Model\ValueFormatter\Price as PriceFormatter;

/**
 * Class Processor
 *
 * @package Aheadworks\Affiliate\Model\BoundCustomer\Layout
 */
class Processor
{
    /**
     * @var DataProvider
     */
    private $dataProvider;

    /**
     * @var PriceFormatter
     */
    private $priceFormatter;

    /**
     * @param DataProvider $dataProvider
     * @param PriceFormatter $priceFormatter
     */
    public function __construct(
        DataProvider $dataProvider,
        PriceFormatter $priceFormatter
    ) {
        $this->dataProvider = $dataProvider;
        $this->priceFormatter = $priceFormatter;
    }

    /**
     * Retrieve bound customer info
     *
     * @param int $accountId
     * @param int|null $websiteId
     * @return array
     */
    public function getBoundCustomerInfo($accountId, $websiteId = null )
    {
        return [
            BoundCustomerInterface::EARNED_COMMISSIONS => $this->priceFormatter->getFormattedValue(
                $this->dataProvider->getBoundCustomersCommissionAmount($accountId),
                $websiteId
            ),
            BoundCustomerInterface::ORDERS => count(array_unique($this->dataProvider->getBoundCustomerOrderIds($accountId)))
        ];
    }
}
