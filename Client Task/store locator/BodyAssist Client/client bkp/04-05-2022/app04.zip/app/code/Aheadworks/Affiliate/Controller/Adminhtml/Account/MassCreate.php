<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Account;

use Aheadworks\Affiliate\Model\PostData\ProcessorComposite as PostDataProcessorComposite;
use Magento\Backend\App\Action;
use Aheadworks\Affiliate\Model\Data\OperationInterface as DataOperationInterface;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Exception\LocalizedException;
use Psr\Log\LoggerInterface as Logger;

/**
 * Class MassCreate
 *
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Account
 */
class MassCreate extends Action
{
    /**
     * {@inheritdoc}
     */
    const ADMIN_RESOURCE = 'Aheadworks_Affiliate::accounts';

    /**
     * @var PostDataProcessorComposite
     */
    private $postDataProcessorComposite;

    /**
     * @var DataOperationInterface
     */
    private $dataOperation;

    /**
     * @var Logger
     */
    private $logger;

    /**
     * @param Context $context
     * @param PostDataProcessorComposite $postDataProcessorComposite
     * @param DataOperationInterface $dataOperation
     * @param Logger $logger
     */
    public function __construct(
        Context $context,
        PostDataProcessorComposite $postDataProcessorComposite,
        DataOperationInterface $dataOperation,
        Logger $logger
    ) {
        parent::__construct($context);
        $this->postDataProcessorComposite = $postDataProcessorComposite;
        $this->dataOperation = $dataOperation;
        $this->logger = $logger;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();

        if ($postData = $this->getRequest()->getPostValue()) {
            try {
                $preparedData = $this->postDataProcessorComposite->prepareData($postData);

                $createdAccountsQty = $this->createAccounts($preparedData);

                $successMessage = ($createdAccountsQty > 0)
                    ? __('A total of %1 affiliate account(s) have been created.', $createdAccountsQty)
                    : __('No affiliate accounts have been created.')
                ;
                $this->messageManager->addSuccessMessage($successMessage);

            } catch (\Exception $exception) {
                $this->messageManager->addErrorMessage($exception->getMessage());
            }
        }

        return $resultRedirect->setPath('*/*/index');
    }

    /**
     * Create affiliate accounts
     *
     * @param array $preparedData
     * @return int
     */
    private function createAccounts($preparedData)
    {
        $createdAccountsQty = 0;
        foreach ($preparedData as $affiliateAccountDataRow) {
            try {
                if ($this->dataOperation->execute($affiliateAccountDataRow)) {
                    $createdAccountsQty++;
                }
            } catch (LocalizedException $exception) {
                $this->logger->warning($exception->getMessage());
            }
        }
        return $createdAccountsQty;
    }
}
