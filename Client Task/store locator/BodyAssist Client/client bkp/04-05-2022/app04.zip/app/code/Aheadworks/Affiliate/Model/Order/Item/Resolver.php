<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Order\Item;

use Magento\Sales\Api\Data\OrderItemInterface;
use Aheadworks\Affiliate\Model\Order\Item\Total\Calculator as TotalCalculator;

/**
 * Class Resolver
 *
 * @package Aheadworks\Affiliate\Model\Order\Item
 */
class Resolver
{
    /**
     * @var TotalCalculator
     */
    private $totalCalculator;

    /**
     * @param TotalCalculator $totalCalculator
     */
    public function __construct(
        TotalCalculator $totalCalculator
    ) {
        $this->totalCalculator = $totalCalculator;
    }

    /**
     * Retrieve quantity to calculate order item commission
     *
     * @param OrderItemInterface $orderItem
     * @return float
     */
    public function getQtyToCalculateCommission($orderItem)
    {
        return $orderItem->getQtyOrdered();
    }

    /**
     * Retrieve amount to calculate order item commission
     *
     * @param OrderItemInterface $orderItem
     * @return float
     */
    public function getAmountToCalculateCommission($orderItem)
    {
        $amount = 0.0;
        if ($orderItem->getHasChildren() && $orderItem->isChildrenCalculated()) {
            $childItems = $orderItem->getChildrenItems();
            foreach ($childItems as $childOrderItem) {
                $amount += $this->totalCalculator->calculate($childOrderItem);
            }
        } else {
            $amount = $this->totalCalculator->calculate($orderItem);
        }
        return $amount;
    }
}
