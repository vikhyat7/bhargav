<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Source\Account;

use Magento\Framework\Data\OptionSourceInterface;

/**
 * Class PaymentType
 * @package Aheadworks\Affiliate\Model\Source\Account
 */
class PaymentType implements OptionSourceInterface
{
    /**#@+
     * Payment type values
     */
    const OTHER = 1;
    const PAYPAL = 2;
    /**#@-*/

    /**
     * {@inheritdoc}
     */
    public function toOptionArray()
    {
        return [
            [
                'value' => self::PAYPAL,
                'label' => __('PayPal')
            ],
            [
                'value' => self::OTHER,
                'label' => __('Other')
            ]
        ];
    }
}
