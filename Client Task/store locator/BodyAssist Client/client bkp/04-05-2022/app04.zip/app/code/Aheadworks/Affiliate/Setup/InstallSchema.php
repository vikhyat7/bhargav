<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table as DataDefinition;
use Aheadworks\Affiliate\Model\ResourceModel\Campaign as CampaignResource;
use Aheadworks\Affiliate\Model\ResourceModel\AffiliateGroup as AffiliateGroupResource;
use Aheadworks\Affiliate\Model\ResourceModel\Transaction as TransactionResource;
use Aheadworks\Affiliate\Model\ResourceModel\Account as AffiliateAccountResource;
use Aheadworks\Affiliate\Model\ResourceModel\Payout as AffiliatePayoutResource;
use Aheadworks\Affiliate\Model\ResourceModel\Signup as AffiliateSignupResource;
use Aheadworks\Affiliate\Model\ResourceModel\Coupon as CouponResource;
use Aheadworks\Affiliate\Model\ResourceModel\LinkStatistic as LinkStatisticResource;
use Aheadworks\Affiliate\Model\ResourceModel\Account\Balance as AffiliateBalanceResource;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Aheadworks\Affiliate\Setup\Updater\Schema as SchemaUpdater;

/**
 * Class InstallSchema
 *
 * @package Aheadworks\Affiliate\Setup
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * @var SchemaUpdater
     */
    private $schemaUpdater;

    /**
     * @param SchemaUpdater $schemaUpdater
     */
    public function __construct(
        SchemaUpdater $schemaUpdater
    ) {
        $this->schemaUpdater = $schemaUpdater;
    }

    /**
     * {@inheritdoc}
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();

        $this
            ->createCampaignTable($installer)
            ->createCampaignCouponUsageTable($installer)
            ->createCampaignRecommendedProductTable($installer)
            ->createAffiliateGroupTable($installer)
            ->createCampaignAffiliateGroupTable($installer)
            ->createAffiliateSignupTable($installer)
            ->createAffiliateAccountTable($installer)
            ->createAffiliateBalanceTable($installer)
            ->createCouponTable($installer)
            ->createTransactionTable($installer)
            ->createTransactionEntityTable($installer)
            ->createAffiliatePayoutTable($installer)
            ->createLinkStatisticsTable($installer)
            ->createLinkStatisticsIndexTable($installer)
        ;

        $this->schemaUpdater
            ->update110($installer)
            ->update120($installer);

        $installer->endSetup();
    }

    /**
     * Create campaign table
     *
     * @param SchemaSetupInterface $installer
     * @return $this
     * @throws \Exception
     */
    private function createCampaignTable(SchemaSetupInterface $installer)
    {
        $table = $installer
            ->getConnection()
            ->newTable(
                $installer->getTable(CampaignResource::MAIN_TABLE_NAME)
            )->addColumn(
                CampaignResource::MAIN_TABLE_ID_FIELD_NAME,
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'identity' => true,
                    'primary' => true
                ],
                'Campaign ID'
            )->addColumn(
                'name',
                DataDefinition::TYPE_TEXT,
                128,
                [
                    'nullable' => false
                ],
                'Campaign name'
            )->addColumn(
                'description',
                DataDefinition::TYPE_TEXT,
                null,
                [
                    'nullable' => true
                ],
                'Campaign description'
            )->addColumn(
                'status',
                DataDefinition::TYPE_SMALLINT,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false
                ],
                'Status'
            )->addColumn(
                'website_id',
                DataDefinition::TYPE_SMALLINT,
                null,
                [
                    'unsigned' => true,
                    'nulable' => false
                ],
                'Website Id'
            )->addColumn(
                'commission_type',
                DataDefinition::TYPE_SMALLINT,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false
                ],
                'Commission type'
            )->addColumn(
                'commission_value',
                DataDefinition::TYPE_DECIMAL,
                '12,4',
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'default' => '0.0000'
                ],
                'Commission value'
            )->addColumn(
                'is_link_generation_allowed',
                DataDefinition::TYPE_SMALLINT,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false
                ],
                'Is link generation allowed'
            )->addColumn(
                'tracking_gap',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false
                ],
                'Tracking gap, days'
            )->addColumn(
                'coupon_usage_mode',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false
                ],
                'Coupon usage mode'
            )->addColumn(
                'cart_condition',
                DataDefinition::TYPE_TEXT,
                '2M',
                [
                    'nullable' => false
                ],
                'Cart condition serialized'
            )->addIndex(
                $installer->getIdxName(CampaignResource::MAIN_TABLE_NAME, ['website_id']),
                ['website_id']
            )->addForeignKey(
                $installer->getFkName(
                    CampaignResource::MAIN_TABLE_NAME,
                    'website_id',
                    'store_website',
                    'website_id'
                ),
                'website_id',
                $installer->getTable('store_website'),
                'website_id',
                DataDefinition::ACTION_CASCADE
            )->setComment('AW Affiliate Campaign Table');
        $installer->getConnection()->createTable($table);
        
        return $this;
    }

    /**
     * Create campaign coupon usage table
     *
     * @param SchemaSetupInterface $installer
     * @return $this
     * @throws \Exception
     */
    private function createCampaignCouponUsageTable(SchemaSetupInterface $installer)
    {
        $table = $installer
            ->getConnection()
            ->newTable(
                $installer->getTable(CampaignResource::COUPON_USAGE_TABLE_NAME)
            )->addColumn(
                'campaign_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'primary' => true
                ],
                'Campaign ID'
            )->addColumn(
                'coupon_code_template',
                DataDefinition::TYPE_TEXT,
                128,
                [
                    'nullable' => false
                ],
                'Coupon code'
            )->addColumn(
                'coupon_uses_per_affiliate',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'default' => '0'
                ],
                'Uses per affiliate'
            )->addColumn(
                'coupon_discount_type',
                DataDefinition::TYPE_SMALLINT,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false
                ],
                'Coupon discount type'
            )->addColumn(
                'coupon_discount_amount',
                DataDefinition::TYPE_DECIMAL,
                '12,4',
                [
                    'nullable' => false,
                    'unsigned' => true,
                    'default' => '0.0000'
                ],
                'Coupon discount amount'
            )->addForeignKey(
                $installer->getFkName(
                    CampaignResource::COUPON_USAGE_TABLE_NAME,
                    'campaign_id',
                    CampaignResource::MAIN_TABLE_NAME,
                    CampaignResource::MAIN_TABLE_ID_FIELD_NAME
                ),
                'campaign_id',
                $installer->getTable(CampaignResource::MAIN_TABLE_NAME),
                CampaignResource::MAIN_TABLE_ID_FIELD_NAME,
                DataDefinition::ACTION_CASCADE
            )->setComment('AW Affiliate Campaign Coupon Usage Table');
        $installer->getConnection()->createTable($table);

        return $this;
    }

    /**
     * Create campaign recommended product table
     *
     * @param SchemaSetupInterface $installer
     * @return $this
     * @throws \Exception
     */
    private function createCampaignRecommendedProductTable(SchemaSetupInterface $installer)
    {
        $table = $installer
            ->getConnection()
            ->newTable(
                $installer->getTable(CampaignResource::RECOMMENDED_PRODUCT_TABLE_NAME)
            )->addColumn(
                'campaign_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'primary' => true
                ],
                'Campaign ID'
            )->addColumn(
                CampaignResource::RECOMMENDED_PRODUCT_TABLE_RECOMMENDED_PRODUCT_ID_FIELD_NAME,
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'primary' => true
                ],
                'Recommended product ID'
            )->addForeignKey(
                $installer->getFkName(
                    CampaignResource::RECOMMENDED_PRODUCT_TABLE_NAME,
                    'campaign_id',
                    CampaignResource::MAIN_TABLE_NAME,
                    CampaignResource::MAIN_TABLE_ID_FIELD_NAME
                ),
                'campaign_id',
                $installer->getTable(CampaignResource::MAIN_TABLE_NAME),
                CampaignResource::MAIN_TABLE_ID_FIELD_NAME,
                DataDefinition::ACTION_CASCADE
            )->addForeignKey(
                $installer->getFkName(
                    CampaignResource::RECOMMENDED_PRODUCT_TABLE_NAME,
                    CampaignResource::RECOMMENDED_PRODUCT_TABLE_RECOMMENDED_PRODUCT_ID_FIELD_NAME,
                    'catalog_product_entity',
                    'entity_id'
                ),
                CampaignResource::RECOMMENDED_PRODUCT_TABLE_RECOMMENDED_PRODUCT_ID_FIELD_NAME,
                $installer->getTable('catalog_product_entity'),
                'entity_id',
                DataDefinition::ACTION_CASCADE
            )->setComment('AW Affiliate Campaign Recommended Product Table');
        $installer->getConnection()->createTable($table);

        return $this;
    }

    /**
     * Create affiliate group table
     *
     * @param SchemaSetupInterface $installer
     * @return $this
     * @throws \Exception
     */
    private function createAffiliateGroupTable(SchemaSetupInterface $installer)
    {
        $table = $installer
            ->getConnection()
            ->newTable(
                $installer->getTable(AffiliateGroupResource::MAIN_TABLE_NAME)
            )->addColumn(
                'affiliate_group_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'identity' => true,
                    'primary' => true
                ],
                'Affiliate group ID'
            )->addColumn(
                'name',
                DataDefinition::TYPE_TEXT,
                128,
                [
                    'nullable' => false
                ],
                'Affiliate group name'
            )->addColumn(
                'commission_type',
                DataDefinition::TYPE_SMALLINT,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false
                ],
                'Commission type'
            )->addColumn(
                'commission_value',
                DataDefinition::TYPE_DECIMAL,
                '12,4',
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'default' => '0.0000'
                ],
                'Commission value'
            )->addColumn(
                'commission_holding_period',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false
                ],
                'Commission holding period'
            )->setComment('AW Affiliate Group Table');
        $installer->getConnection()->createTable($table);

        return $this;
    }

    /**
     * Create campaign affiliate group table
     *
     * @param SchemaSetupInterface $installer
     * @return $this
     * @throws \Exception
     */
    private function createCampaignAffiliateGroupTable(SchemaSetupInterface $installer)
    {
        $table = $installer
            ->getConnection()
            ->newTable(
                $installer->getTable(CampaignResource::AFFILIATE_GROUP_TABLE_NAME)
            )->addColumn(
                'campaign_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false
                ],
                'Campaign ID'
            )->addColumn(
                'affiliate_group_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => true
                ],
                'Affiliate group ID'
            )->addForeignKey(
                $installer->getFkName(
                    CampaignResource::AFFILIATE_GROUP_TABLE_NAME,
                    'campaign_id',
                    CampaignResource::MAIN_TABLE_NAME,
                    CampaignResource::MAIN_TABLE_ID_FIELD_NAME
                ),
                'campaign_id',
                $installer->getTable(CampaignResource::MAIN_TABLE_NAME),
                CampaignResource::MAIN_TABLE_ID_FIELD_NAME,
                DataDefinition::ACTION_CASCADE
            )->addForeignKey(
                $installer->getFkName(
                    CampaignResource::AFFILIATE_GROUP_TABLE_NAME,
                    'affiliate_group_id',
                    AffiliateGroupResource::MAIN_TABLE_NAME,
                    AffiliateGroupResource::MAIN_TABLE_ID_FIELD_NAME
                ),
                'affiliate_group_id',
                $installer->getTable(AffiliateGroupResource::MAIN_TABLE_NAME),
                AffiliateGroupResource::MAIN_TABLE_ID_FIELD_NAME,
                DataDefinition::ACTION_CASCADE
            )->setComment('AW Affiliate Campaign Affiliate Group Table');
        $installer->getConnection()->createTable($table);

        return $this;
    }

    /**
     * Create affiliate signup table
     *
     * @param SchemaSetupInterface $installer
     * @return $this
     * @throws \Exception
     */
    private function createAffiliateSignupTable(SchemaSetupInterface $installer)
    {
        $table = $installer
            ->getConnection()
            ->newTable(
                $installer->getTable(AffiliateSignupResource::MAIN_TABLE_NAME)
            )->addColumn(
                'signup_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'identity' => true,
                    'primary' => true
                ],
                'Signup ID'
            )->addColumn(
                'customer_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true
                ],
                'Customer ID'
            )->addColumn(
                'store_id',
                DataDefinition::TYPE_SMALLINT,
                null,
                [
                    'unsigned' => true,
                    'nullable' => true
                ],
                'Store ID'
            )->addColumn(
                'status',
                DataDefinition::TYPE_SMALLINT,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false
                ],
                'Status'
            )->addColumn(
                'signup_date',
                DataDefinition::TYPE_TIMESTAMP,
                null,
                [
                    'nullable' => true,
                    'default' => DataDefinition::TIMESTAMP_INIT
                ],
                'Signup date'
            )->addColumn(
                'referral_website',
                DataDefinition::TYPE_TEXT,
                255,
                [
                    'nullable' => false
                ],
                'Referral website'
            )->addColumn(
                'signup_message',
                DataDefinition::TYPE_TEXT,
                null,
                [
                    'nullable' => true
                ],
                'Signup message'
            )->addColumn(
                'decline_reason',
                DataDefinition::TYPE_TEXT,
                null,
                [
                    'nullable' => true
                ],
                'Decline reason'
            )->addIndex(
                $installer->getIdxName(AffiliateSignupResource::MAIN_TABLE_NAME, ['status']),
                ['status']
            )->addForeignKey(
                $installer->getFkName(
                    AffiliateSignupResource::MAIN_TABLE_NAME,
                    'customer_id',
                    $installer->getTable('customer_entity'),
                    'entity_id'
                ),
                'customer_id',
                $installer->getTable('customer_entity'),
                'entity_id',
                DataDefinition::ACTION_SET_NULL
            )->addForeignKey(
                $installer->getFkName(
                    AffiliateSignupResource::MAIN_TABLE_NAME,
                    'store_id',
                    $installer->getTable('store'),
                    'store_id'
                ),
                'store_id',
                $installer->getTable('store'),
                'store_id',
                DataDefinition::ACTION_SET_NULL
            )->setComment('AW Affiliate Signup Table');
        $installer->getConnection()->createTable($table);

        return $this;
    }

    /**
     * Create affiliate account table
     *
     * @param SchemaSetupInterface $installer
     * @return $this
     * @throws \Exception
     */
    private function createAffiliateAccountTable(SchemaSetupInterface $installer)
    {
        $table = $installer
            ->getConnection()
            ->newTable(
                $installer->getTable(AffiliateAccountResource::MAIN_TABLE_NAME)
            )->addColumn(
                'account_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'identity' => true,
                    'primary' => true
                ],
                'Account ID'
            )->addColumn(
                'customer_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => true
                ],
                'Customer ID'
            )->addColumn(
                'website_id',
                DataDefinition::TYPE_SMALLINT,
                null,
                [
                    'unsigned' => true
                ],
                'Website Id'
            )->addColumn(
                'status',
                DataDefinition::TYPE_SMALLINT,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false
                ],
                'Status'
            )->addColumn(
                'prefix',
                DataDefinition::TYPE_TEXT,
                40,
                [
                    'nullable' => true
                ],
                'Prefix'
            )->addColumn(
                'firstname',
                DataDefinition::TYPE_TEXT,
                255,
                [
                    'nullable' => false
                ],
                'First name'
            )->addColumn(
                'middlename',
                DataDefinition::TYPE_TEXT,
                255,
                [
                    'nullable' => true
                ],
                'Middle name'
            )->addColumn(
                'lastname',
                DataDefinition::TYPE_TEXT,
                255,
                [
                    'nullable' => false
                ],
                'Last name'
            )->addColumn(
                'suffix',
                DataDefinition::TYPE_TEXT,
                40,
                [
                    'nullable' => true
                ],
                'Suffix'
            )->addColumn(
                'email',
                DataDefinition::TYPE_TEXT,
                255,
                [
                    'nullable' => false
                ],
                'Email'
            )->addColumn(
                'signup_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => true
                ],
                'Signup ID'
            )->addColumn(
                'signup_approval_date',
                DataDefinition::TYPE_TIMESTAMP,
                null,
                [
                    'nullable' => false,
                    'default' => DataDefinition::TIMESTAMP_INIT
                ],
                'Signup approval date'
            )->addColumn(
                'affiliate_group_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'default' => '1'
                ],
                'Affiliate group ID'
            )->addColumn(
                'referral_website',
                DataDefinition::TYPE_TEXT,
                255,
                [
                    'nullable' => false
                ],
                'Referral website'
            )->addColumn(
                'unique_coupon_prefix',
                DataDefinition::TYPE_TEXT,
                40,
                [
                    'nullable' => true,
                    'default' => null
                ],
                'Unique coupon prefix'
            )->addColumn(
                'payment_type',
                DataDefinition::TYPE_SMALLINT,
                null,
                [
                    'nullable' => true
                ],
                'Payment type'
            )->addColumn(
                'payment_info',
                DataDefinition::TYPE_TEXT,
                null,
                [
                    'nullable' => true
                ],
                'Payment info'
            )->addIndex(
                $installer->getIdxName(AffiliateAccountResource::MAIN_TABLE_NAME, ['status']),
                ['status']
            )->addIndex(
                $installer->getIdxName(
                    AffiliateAccountResource::MAIN_TABLE_NAME,
                    [
                        'email',
                        'website_id'
                    ],
                    AdapterInterface::INDEX_TYPE_UNIQUE
                ),
                [
                    'email',
                    'website_id'
                ],
                ['type' => AdapterInterface::INDEX_TYPE_UNIQUE]
            )->addIndex(
                $installer->getIdxName(AffiliateAccountResource::MAIN_TABLE_NAME, ['website_id']),
                ['website_id']
            )->addIndex(
                $installer->getIdxName(AffiliateAccountResource::MAIN_TABLE_NAME, ['firstname']),
                ['firstname']
            )->addIndex(
                $installer->getIdxName(AffiliateAccountResource::MAIN_TABLE_NAME, ['lastname']),
                ['lastname']
            )->addIndex(
                $installer->getIdxName(AffiliateAccountResource::MAIN_TABLE_NAME, ['payment_type']),
                ['payment_type']
            )->addForeignKey(
                $installer->getFkName(
                    AffiliateAccountResource::MAIN_TABLE_NAME,
                    'affiliate_group_id',
                    AffiliateGroupResource::MAIN_TABLE_NAME,
                    AffiliateGroupResource::MAIN_TABLE_ID_FIELD_NAME
                ),
                'affiliate_group_id',
                $installer->getTable(AffiliateGroupResource::MAIN_TABLE_NAME),
                AffiliateGroupResource::MAIN_TABLE_ID_FIELD_NAME,
                DataDefinition::ACTION_NO_ACTION
            )->addForeignKey(
                $installer->getFkName(
                    AffiliateAccountResource::MAIN_TABLE_NAME,
                    'customer_id',
                    $installer->getTable('customer_entity'),
                    'entity_id'
                ),
                'customer_id',
                $installer->getTable('customer_entity'),
                'entity_id',
                DataDefinition::ACTION_SET_NULL
            )->addForeignKey(
                $installer->getFkName(
                    AffiliateGroupResource::MAIN_TABLE_NAME,
                    'website_id',
                    'store_website',
                    'website_id'
                ),
                'website_id',
                $installer->getTable('store_website'),
                'website_id',
                DataDefinition::ACTION_SET_NULL
            )->addForeignKey(
                $installer->getFkName(
                    AffiliateGroupResource::MAIN_TABLE_NAME,
                    'signup_id',
                    AffiliateSignupResource::MAIN_TABLE_NAME,
                    'signup_id'
                ),
                'signup_id',
                $installer->getTable(AffiliateSignupResource::MAIN_TABLE_NAME),
                'signup_id',
                DataDefinition::ACTION_SET_NULL
            )->setComment('AW Affiliate Account Table');
        $installer->getConnection()->createTable($table);

        return $this;
    }

    /**
     * Create affiliate balance table
     *
     * @param SchemaSetupInterface $installer
     * @return $this
     * @throws \Exception
     */
    private function createAffiliateBalanceTable(SchemaSetupInterface $installer)
    {
        $table = $installer
            ->getConnection()
            ->newTable(
                $installer->getTable(AffiliateBalanceResource::MAIN_TABLE_NAME)
            )->addColumn(
                'affiliate_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'primary' => true
                ],
                'Affiliate ID'
            )->addColumn(
                'pending_commissions',
                DataDefinition::TYPE_DECIMAL,
                '12,4',
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'default' => '0.0000'
                ],
                'Pending commissions'
            )->addColumn(
                'available_commissions',
                DataDefinition::TYPE_DECIMAL,
                '12,4',
                [
                    'unsigned' => false,
                    'nullable' => false,
                    'default' => '0.0000'
                ],
                'Available commissions'
            )->addColumn(
                'processing_commissions',
                DataDefinition::TYPE_DECIMAL,
                '12,4',
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'default' => '0.0000'
                ],
                'Processing commissions'
            )->addColumn(
                'paid_commissions',
                DataDefinition::TYPE_DECIMAL,
                '12,4',
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'default' => '0.0000'
                ],
                'Paid commissions'
            )->addForeignKey(
                $installer->getFkName(
                    AffiliateBalanceResource::MAIN_TABLE_NAME,
                    'affiliate_id',
                    AffiliateAccountResource::MAIN_TABLE_NAME,
                    AffiliateAccountResource::MAIN_TABLE_ID_FIELD_NAME
                ),
                'affiliate_id',
                $installer->getTable(AffiliateAccountResource::MAIN_TABLE_NAME),
                AffiliateAccountResource::MAIN_TABLE_ID_FIELD_NAME,
                DataDefinition::ACTION_CASCADE
            )->setComment('AW Affiliate Balance Table');
        $installer->getConnection()->createTable($table);

        return $this;
    }

    /**
     * Create coupon table
     *
     * @param SchemaSetupInterface $installer
     * @return $this
     * @throws \Exception
     */
    private function createCouponTable(SchemaSetupInterface $installer)
    {
        $table = $installer
            ->getConnection()
            ->newTable(
                $installer->getTable(CouponResource::MAIN_TABLE_NAME)
            )->addColumn(
                'coupon_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'primary' => true
                ],
                'Coupon ID'
            )->addColumn(
                'coupon_code',
                DataDefinition::TYPE_TEXT,
                255,
                [
                    'nullable' => false
                ],
                'Coupon code'
            )->addColumn(
                'sales_rule_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'primary' => true
                ],
                'Sales rule ID'
            )->addColumn(
                'campaign_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'primary' => true
                ],
                'Campaign ID'
            )->addColumn(
                'affiliate_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'primary' => true
                ],
                'Affiliate ID'
            )->addIndex(
                $installer->getIdxName(AffiliateSignupResource::MAIN_TABLE_NAME, ['coupon_code']),
                ['coupon_code']
            )->addForeignKey(
                $installer->getFkName(
                    CouponResource::MAIN_TABLE_NAME,
                    'sales_rule_id',
                    'salesrule',
                    'rule_id'
                ),
                'sales_rule_id',
                $installer->getTable('salesrule'),
                'rule_id',
                DataDefinition::ACTION_CASCADE
            )->addForeignKey(
                $installer->getFkName(
                    CouponResource::MAIN_TABLE_NAME,
                    'campaign_id',
                    CampaignResource::MAIN_TABLE_NAME,
                    CampaignResource::MAIN_TABLE_ID_FIELD_NAME
                ),
                'campaign_id',
                $installer->getTable(CampaignResource::MAIN_TABLE_NAME),
                CampaignResource::MAIN_TABLE_ID_FIELD_NAME,
                DataDefinition::ACTION_CASCADE
            )->addForeignKey(
                $installer->getFkName(
                    CouponResource::MAIN_TABLE_NAME,
                    CouponResource::MAIN_TABLE_ID_FIELD_NAME,
                    'salesrule_coupon',
                    'coupon_id'
                ),
                CouponResource::MAIN_TABLE_ID_FIELD_NAME,
                $installer->getTable('salesrule_coupon'),
                'coupon_id',
                DataDefinition::ACTION_CASCADE
            )->addForeignKey(
                $installer->getFkName(
                    CouponResource::MAIN_TABLE_NAME,
                    'affiliate_id',
                    AffiliateAccountResource::MAIN_TABLE_NAME,
                    AffiliateAccountResource::MAIN_TABLE_ID_FIELD_NAME
                ),
                'affiliate_id',
                $installer->getTable(AffiliateAccountResource::MAIN_TABLE_NAME),
                AffiliateAccountResource::MAIN_TABLE_ID_FIELD_NAME,
                DataDefinition::ACTION_CASCADE
            )->setComment('AW Affiliate Coupon Table');
        $installer->getConnection()->createTable($table);

        return $this;
    }

    /**
     * Create transaction table
     *
     * @param SchemaSetupInterface $installer
     * @return $this
     * @throws \Exception
     */
    private function createTransactionTable(SchemaSetupInterface $installer)
    {
        $table = $installer
            ->getConnection()
            ->newTable(
                $installer->getTable(TransactionResource::MAIN_TABLE_NAME)
            )->addColumn(
                'transaction_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'identity' => true,
                    'primary' => true
                ],
                'Transaction ID'
            )->addColumn(
                'affiliate_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false
                ],
                'Affiliate ID'
            )->addColumn(
                'created_at',
                DataDefinition::TYPE_TIMESTAMP,
                null,
                [
                    'nullable' => false,
                    'default' => DataDefinition::TIMESTAMP_INIT
                ],
                'Created At'
            )->addColumn(
                'updated_at',
                DataDefinition::TYPE_TIMESTAMP,
                null,
                [
                    'nullable' => false,
                    'default' => DataDefinition::TIMESTAMP_INIT_UPDATE
                ],
                'Updated At'
            )->addColumn(
                'holding_period_expiration',
                DataDefinition::TYPE_TIMESTAMP,
                null,
                [
                    'nullable' => true,
                    'default' => null
                ],
                'Holding period expiration'
            )->addColumn(
                'type',
                DataDefinition::TYPE_TEXT,
                128,
                [
                    'nullable' => false
                ],
                'Type'
            )->addColumn(
                'status',
                DataDefinition::TYPE_TEXT,
                128,
                [
                    'unsigned' => true,
                    'nullable' => false
                ],
                'Status'
            )->addColumn(
                'amount',
                DataDefinition::TYPE_DECIMAL,
                '12,4',
                [
                    'unsigned' => false,
                    'nullable' => false,
                    'default' => '0.0000'
                ],
                'Amount'
            )->addColumn(
                'campaign_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => true
                ],
                'Campaign ID'
            )->addColumn(
                'comment',
                DataDefinition::TYPE_TEXT,
                255,
                [
                    'nullable' => false
                ],
                'Comment'
            )->addColumn(
                'traffic_source',
                DataDefinition::TYPE_TEXT,
                255,
                [
                    'nullable' => true
                ],
                'Traffic source'
            )->addIndex(
                $installer->getIdxName(
                    TransactionResource::MAIN_TABLE_NAME,
                    ['type', 'status', 'holding_period_expiration']
                ),
                ['type', 'status', 'holding_period_expiration']
            )->addForeignKey(
                $installer->getFkName(
                    TransactionResource::MAIN_TABLE_NAME,
                    'affiliate_id',
                    AffiliateAccountResource::MAIN_TABLE_NAME,
                    AffiliateAccountResource::MAIN_TABLE_ID_FIELD_NAME
                ),
                'affiliate_id',
                $installer->getTable(AffiliateAccountResource::MAIN_TABLE_NAME),
                AffiliateAccountResource::MAIN_TABLE_ID_FIELD_NAME,
                DataDefinition::ACTION_CASCADE
            )->addForeignKey(
                $installer->getFkName(
                    TransactionResource::MAIN_TABLE_NAME,
                    'campaign_id',
                    CampaignResource::MAIN_TABLE_NAME,
                    CampaignResource::MAIN_TABLE_ID_FIELD_NAME
                ),
                'campaign_id',
                $installer->getTable(CampaignResource::MAIN_TABLE_NAME),
                CampaignResource::MAIN_TABLE_ID_FIELD_NAME,
                DataDefinition::ACTION_SET_NULL
            )->setComment('AW Affiliate Transaction Table');
        $installer->getConnection()->createTable($table);

        return $this;
    }

    /**
     * Create transaction entity table
     *
     * @param SchemaSetupInterface $installer
     * @return $this
     * @throws \Exception
     */
    private function createTransactionEntityTable(SchemaSetupInterface $installer)
    {
        $table = $installer
            ->getConnection()
            ->newTable(
                $installer->getTable(TransactionResource::ENTITY_TABLE_NAME)
            )->addColumn(
                'transaction_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'primary' => true
                ],
                'Transaction ID'
            )->addColumn(
                'entity_type',
                DataDefinition::TYPE_TEXT,
                128,
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'primary' => true
                ],
                'Entity type'
            )->addColumn(
                'entity_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'primary' => true
                ],
                'Entity ID'
            )->addIndex(
                $installer->getIdxName(
                    TransactionResource::ENTITY_TABLE_NAME,
                    ['transaction_id', 'entity_type', 'entity_id']
                ),
                ['transaction_id', 'entity_type', 'entity_id']
            )->addForeignKey(
                $installer->getFkName(
                    TransactionResource::ENTITY_TABLE_NAME,
                    'transaction_id',
                    TransactionResource::MAIN_TABLE_NAME,
                    TransactionResource::MAIN_TABLE_ID_FIELD_NAME
                ),
                'transaction_id',
                $installer->getTable(TransactionResource::MAIN_TABLE_NAME),
                TransactionResource::MAIN_TABLE_ID_FIELD_NAME,
                DataDefinition::ACTION_CASCADE
            )->setComment('AW Affiliate Transaction Entity Table');
        $installer->getConnection()->createTable($table);

        return $this;
    }

    /**
     * Create affiliate payout table
     *
     * @param SchemaSetupInterface $installer
     * @return $this
     * @throws \Exception
     */
    private function createAffiliatePayoutTable(SchemaSetupInterface $installer)
    {
        $table = $installer
            ->getConnection()
            ->newTable(
                $installer->getTable(AffiliatePayoutResource::MAIN_TABLE_NAME)
            )->addColumn(
                'payout_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'identity' => true,
                    'primary' => true
                ],
                'Payout ID'
            )->addColumn(
                'affiliate_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false
                ],
                'Affiliate ID'
            )->addColumn(
                'amount',
                DataDefinition::TYPE_DECIMAL,
                '12,4',
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'default' => '0.0000'
                ],
                'Amount'
            )->addColumn(
                'type',
                DataDefinition::TYPE_TEXT,
                128,
                [
                    'nullable' => false
                ],
                'Type'
            )->addColumn(
                'status',
                DataDefinition::TYPE_TEXT,
                128,
                [
                    'nullable' => false
                ],
                'Status'
            )->addColumn(
                'created_at',
                DataDefinition::TYPE_TIMESTAMP,
                null,
                [
                    'nullable' => false,
                    'default' => DataDefinition::TIMESTAMP_INIT
                ],
                'Created At'
            )->addColumn(
                'updated_at',
                DataDefinition::TYPE_TIMESTAMP,
                null,
                [
                    'nullable' => false,
                    'default' => DataDefinition::TIMESTAMP_INIT_UPDATE
                ],
                'Updated At'
            )->addColumn(
                'affiliate_payment_type',
                DataDefinition::TYPE_SMALLINT,
                null,
                [
                    'nullable' => true
                ],
                'Affiliate Payment type'
            )->addColumn(
                'affiliate_payment_info',
                DataDefinition::TYPE_TEXT,
                null,
                [
                    'nullable' => true
                ],
                'Affiliate Payment info'
            )->addIndex(
                $installer->getIdxName(AffiliatePayoutResource::MAIN_TABLE_NAME, ['status']),
                ['status']
            )->addIndex(
                $installer->getIdxName(AffiliatePayoutResource::MAIN_TABLE_NAME, ['type']),
                ['type']
            )->addForeignKey(
                $installer->getFkName(
                    AffiliatePayoutResource::MAIN_TABLE_NAME,
                    'affiliate_id',
                    AffiliateAccountResource::MAIN_TABLE_NAME,
                    AffiliateAccountResource::MAIN_TABLE_ID_FIELD_NAME
                ),
                'affiliate_id',
                $installer->getTable(AffiliateAccountResource::MAIN_TABLE_NAME),
                AffiliateAccountResource::MAIN_TABLE_ID_FIELD_NAME,
                DataDefinition::ACTION_CASCADE
            )->setComment('AW Affiliate Payout Table');
        $installer->getConnection()->createTable($table);

        return $this;
    }

    /**
     * Create link statistics table
     *
     * @param SchemaSetupInterface $installer
     * @return $this
     * @throws \Exception
     */
    private function createLinkStatisticsTable(SchemaSetupInterface $installer)
    {
        $table = $installer
            ->getConnection()
            ->newTable(
                $installer->getTable(LinkStatisticResource::MAIN_TABLE_NAME)
            )->addColumn(
                'hit_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'identity' => true,
                    'unsigned' => true,
                    'nullable' => false,
                    'primary' => true
                ],
                'Hit ID'
            )->addColumn(
                'account_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false
                ],
                'Account ID'
            )->addColumn(
                'campaign_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false
                ],
                'Campaign ID'
            )->addColumn(
                'traffic_source',
                DataDefinition::TYPE_TEXT,
                255,
                [
                    'nullable' => false
                ],
                'Traffic source'
            )->addColumn(
                'created_at',
                DataDefinition::TYPE_TIMESTAMP,
                null,
                [
                    'nullable' => false,
                    'default' => DataDefinition::TIMESTAMP_INIT
                ],
                'Created At'
            )->addColumn(
                'orders_count',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'default' => 0
                ],
                'Orders count'
            )->addIndex(
                $installer->getIdxName(LinkStatisticResource::MAIN_TABLE_NAME, ['created_at']),
                ['created_at']
            )->addIndex(
                $installer->getIdxName(LinkStatisticResource::MAIN_TABLE_NAME, ['traffic_source']),
                ['traffic_source']
            )->addForeignKey(
                $installer->getFkName(
                    LinkStatisticResource::MAIN_TABLE_NAME,
                    'account_id',
                    AffiliateAccountResource::MAIN_TABLE_NAME,
                    AffiliateAccountResource::MAIN_TABLE_ID_FIELD_NAME
                ),
                'account_id',
                $installer->getTable(AffiliateAccountResource::MAIN_TABLE_NAME),
                AffiliateAccountResource::MAIN_TABLE_ID_FIELD_NAME,
                DataDefinition::ACTION_CASCADE
            )->addForeignKey(
                $installer->getFkName(
                    LinkStatisticResource::MAIN_TABLE_NAME,
                    'campaign_id',
                    CampaignResource::MAIN_TABLE_NAME,
                    CampaignResource::MAIN_TABLE_ID_FIELD_NAME
                ),
                'campaign_id',
                $installer->getTable(CampaignResource::MAIN_TABLE_NAME),
                CampaignResource::MAIN_TABLE_ID_FIELD_NAME,
                DataDefinition::ACTION_CASCADE
            )->setComment('AW Affiliate Link Statistics Table');
        $installer->getConnection()->createTable($table);

        return $this;
    }

    /**
     * Create link statistics index table
     *
     * @param SchemaSetupInterface $installer
     * @return $this
     * @throws \Exception
     */
    private function createLinkStatisticsIndexTable(SchemaSetupInterface $installer)
    {
        $table = $installer
            ->getConnection()
            ->newTable(
                $installer->getTable(LinkStatisticResource::INDEX_TABLE_NAME)
            )->addColumn(
                'record_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'identity' => true,
                    'unsigned' => true,
                    'nullable' => false,
                    'primary' => true
                ],
                'Record ID'
            )->addColumn(
                'account_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false
                ],
                'Account ID'
            )->addColumn(
                'campaign_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false
                ],
                'Campaign ID'
            )->addColumn(
                'traffic_source',
                DataDefinition::TYPE_TEXT,
                255,
                [
                    'nullable' => false
                ],
                'Traffic source'
            )->addColumn(
                'hits_count',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'default' => 0
                ],
                'Hits count'
            )->addColumn(
                'orders_count',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'default' => 0
                ],
                'Orders count'
            )->addColumn(
                'unique_buyers_count',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'default' => 0
                ],
                'Unique buyers count'
            )->addColumn(
                'commission_amount',
                DataDefinition::TYPE_DECIMAL,
                '12,4',
                [
                    'unsigned' => false,
                    'nullable' => false,
                    'default' => '0.0000'
                ],
                'Commission amount'
            )->addColumn(
                'conversion',
                DataDefinition::TYPE_DECIMAL,
                '12,2',
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'default' => '0.00'
                ],
                'Conversion'
            )->addIndex(
                $installer->getIdxName(LinkStatisticResource::INDEX_TABLE_NAME, ['traffic_source']),
                ['traffic_source']
            )->addForeignKey(
                $installer->getFkName(
                    LinkStatisticResource::INDEX_TABLE_NAME,
                    'account_id',
                    AffiliateAccountResource::MAIN_TABLE_NAME,
                    AffiliateAccountResource::MAIN_TABLE_ID_FIELD_NAME
                ),
                'account_id',
                $installer->getTable(AffiliateAccountResource::MAIN_TABLE_NAME),
                AffiliateAccountResource::MAIN_TABLE_ID_FIELD_NAME,
                DataDefinition::ACTION_CASCADE
            )->addForeignKey(
                $installer->getFkName(
                    LinkStatisticResource::INDEX_TABLE_NAME,
                    'campaign_id',
                    CampaignResource::MAIN_TABLE_NAME,
                    CampaignResource::MAIN_TABLE_ID_FIELD_NAME
                ),
                'campaign_id',
                $installer->getTable(CampaignResource::MAIN_TABLE_NAME),
                CampaignResource::MAIN_TABLE_ID_FIELD_NAME,
                DataDefinition::ACTION_CASCADE
            )->setComment('AW Affiliate Link Statistics Index Table');
        $installer->getConnection()->createTable($table);

        return $this;
    }
}
