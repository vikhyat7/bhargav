<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model;

use Aheadworks\Affiliate\Model\Account\DefaultDataPreparer;
use Magento\Framework\Model\AbstractModel;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Aheadworks\Affiliate\Model\ResourceModel\Account as AccountResource;
use Aheadworks\Affiliate\Model\Account\Validator;
use Magento\Framework\Model\Context;
use Magento\Framework\Registry;
use Magento\Framework\Model\ResourceModel\AbstractResource;
use Magento\Framework\Data\Collection\AbstractDb;

/**
 * Class AffiliateGroup
 * @package Aheadworks\Affiliate\Model
 */
class Account extends AbstractModel implements AccountInterface
{
    /**
     * @var Validator
     */
    private $validator;

    /**
     * @var DefaultDataPreparer
     */
    private $defaultDataPreparer;

    /**
     * @param Context $context
     * @param Registry $registry
     * @param Validator $validator
     * @param DefaultDataPreparer $defaultDataPreparer
     * @param AbstractResource|null $resource
     * @param AbstractDb|null $resourceCollection
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        Validator $validator,
        DefaultDataPreparer $defaultDataPreparer,
        AbstractResource $resource = null,
        AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        parent::__construct(
            $context,
            $registry,
            $resource,
            $resourceCollection,
            $data
        );
        $this->validator = $validator;
        $this->defaultDataPreparer = $defaultDataPreparer;
    }

    /**
     * {@inheritdoc}
     */
    protected function _construct()
    {
        $this->_init(AccountResource::class);
    }

    /**
     * {@inheritdoc}
     */
    public function getAccountId()
    {
        return $this->getData(self::ID);
    }

    /**
     * {@inheritdoc}
     */
    public function setAccountId($id)
    {
        return $this->setData(self::ID, $id);
    }

    /**
     * {@inheritdoc}
     */
    public function getCustomerId()
    {
        return $this->getData(self::CUSTOMER_ID);
    }

    /**
     * {@inheritdoc}
     */
    public function setCustomerId($customerId)
    {
        return $this->setData(self::CUSTOMER_ID, $customerId);
    }

    /**
     * {@inheritdoc}
     */
    public function getWebsiteId()
    {
        return $this->getData(self::WEBSITE_ID);
    }

    /**
     * {@inheritdoc}
     */
    public function setWebsiteId($websiteId)
    {
        return $this->setData(self::WEBSITE_ID, $websiteId);
    }

    /**
     * {@inheritdoc}
     */
    public function getStatus()
    {
        return $this->getData(self::STATUS);
    }

    /**
     * {@inheritdoc}
     */
    public function setStatus($status)
    {
        return $this->setData(self::STATUS, $status);
    }

    /**
     * {@inheritdoc}
     */
    public function getPrefix()
    {
        return $this->getData(self::PREFIX);
    }

    /**
     * {@inheritdoc}
     */
    public function setPrefix($prefix)
    {
        return $this->setData(self::PREFIX, $prefix);
    }

    /**
     * {@inheritdoc}
     */
    public function getFirstname()
    {
        return $this->getData(self::FIRSTNAME);
    }

    /**
     * {@inheritdoc}
     */
    public function setFirstname($firstName)
    {
        return $this->setData(self::FIRSTNAME, $firstName);
    }

    /**
     * {@inheritdoc}
     */
    public function getMiddlename()
    {
        return $this->getData(self::MIDDLENAME);
    }

    /**
     * {@inheritdoc}
     */
    public function setMiddlename($middleName)
    {
        return $this->setData(self::MIDDLENAME, $middleName);
    }

    /**
     * {@inheritdoc}
     */
    public function getLastname()
    {
        return $this->getData(self::LASTNAME);
    }

    /**
     * {@inheritdoc}
     */
    public function setLastname($lastName)
    {
        return $this->setData(self::LASTNAME, $lastName);
    }

    /**
     * {@inheritdoc}
     */
    public function getSuffix()
    {
        return $this->getData(self::SUFFIX);
    }

    /**
     * {@inheritdoc}
     */
    public function setSuffix($suffix)
    {
        return $this->setData(self::SUFFIX, $suffix);
    }

    /**
     * {@inheritdoc}
     */
    public function getEmail()
    {
        return $this->getData(self::EMAIL);
    }

    /**
     * {@inheritdoc}
     */
    public function setEmail($email)
    {
        return $this->setData(self::EMAIL, $email);
    }

    /**
     * {@inheritdoc}
     */
    public function getSignupId()
    {
        return $this->getData(self::SIGNUP_ID);
    }

    /**
     * {@inheritdoc}
     */
    public function setSignupId($signupId)
    {
        return $this->setData(self::SIGNUP_ID, $signupId);
    }

    /**
     * {@inheritdoc}
     */
    public function getSignupApprovalDate()
    {
        return $this->getData(self::SIGNUP_APPROVAL_DATE);
    }

    /**
     * {@inheritdoc}
     */
    public function setSignupApprovalDate($date)
    {
        return $this->setData(self::SIGNUP_APPROVAL_DATE, $date);
    }

    /**
     * {@inheritdoc}
     */
    public function getAffiliateGroupId()
    {
        return $this->getData(self::AFFILIATE_GROUP_ID);
    }

    /**
     * {@inheritdoc}
     */
    public function setAffiliateGroupId($groupId)
    {
        return $this->setData(self::AFFILIATE_GROUP_ID, $groupId);
    }

    /**
     * {@inheritdoc}
     */
    public function getReferralWebsite()
    {
        return $this->getData(self::REFERRAL_WEBSITE);
    }

    /**
     * {@inheritdoc}
     */
    public function setReferralWebsite($website)
    {
        return $this->setData(self::REFERRAL_WEBSITE, $website);
    }

    /**
     * {@inheritdoc}
     */
    public function getUniqueCouponPrefix()
    {
        return $this->getData(self::UNIQUE_COUPON_PREFIX);
    }

    /**
     * {@inheritdoc}
     */
    public function setUniqueCouponPrefix($prefix)
    {
        return $this->setData(self::UNIQUE_COUPON_PREFIX, $prefix);
    }

    /**
     * {@inheritdoc}
     */
    public function getPaymentType()
    {
        return $this->getData(self::PAYMENT_TYPE);
    }

    /**
     * {@inheritdoc}
     */
    public function setPaymentType($type)
    {
        return $this->setData(self::PAYMENT_TYPE, $type);
    }

    /**
     * {@inheritdoc}
     */
    public function getPaymentInfo()
    {
        return $this->getData(self::PAYMENT_INFO);
    }

    /**
     * {@inheritdoc}
     */
    public function setPaymentInfo($info)
    {
        return $this->setData(self::PAYMENT_INFO, $info);
    }

    /**
     * {@inheritdoc}
     */
    public function getExtensionAttributes()
    {
        return $this->getData(self::EXTENSION_ATTRIBUTES_KEY);
    }

    /**
     * {@inheritdoc}
     */
    public function setExtensionAttributes(
        \Aheadworks\Affiliate\Api\Data\AccountExtensionInterface $extensionAttributes
    ) {
        return $this->setData(self::EXTENSION_ATTRIBUTES_KEY, $extensionAttributes);
    }

    /**
     * {@inheritdoc}
     */
    protected function _getValidationRulesBeforeSave()
    {
        return $this->validator;
    }

    /**
     * {@inheritdoc}
     */
    public function beforeSave()
    {
        $this->defaultDataPreparer->prepareData($this);
        return parent::beforeSave();
    }
}
