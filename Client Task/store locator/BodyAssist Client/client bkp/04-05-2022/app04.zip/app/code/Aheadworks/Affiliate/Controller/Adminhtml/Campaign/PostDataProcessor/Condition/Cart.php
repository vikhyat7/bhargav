<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Campaign\PostDataProcessor\Condition;

use Aheadworks\Affiliate\Model\PostData\ProcessorInterface as PostDataProcessorInterface;
use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Aheadworks\Affiliate\Api\Data\ConditionInterface;
use Aheadworks\Affiliate\Model\Campaign\Condition\Cart\Rule as CartConditionRule;
use Aheadworks\Affiliate\Model\Campaign\Condition\Cart\RuleFactory as CartConditionRuleFactory;
use Aheadworks\Affiliate\Model\Campaign\Converter\Condition as ConditionConverter;
use Magento\Framework\Serialize\SerializerInterface;

/**
 * Class Cart
 *
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Campaign\PostDataProcessor\Condition
 */
class Cart implements PostDataProcessorInterface
{
    /**
     * @var ConditionConverter
     */
    private $conditionConverter;

    /**
     * @var CartConditionRuleFactory
     */
    private $cartConditionRuleFactory;

    /**
     * @var SerializerInterface
     */
    private $serializer;

    /**
     * @param ConditionConverter $conditionConverter
     * @param CartConditionRuleFactory $cartConditionRuleFactory
     * @param SerializerInterface $serializer
     */
    public function __construct(
        ConditionConverter $conditionConverter,
        CartConditionRuleFactory $cartConditionRuleFactory,
        SerializerInterface $serializer
    ) {
        $this->conditionConverter = $conditionConverter;
        $this->cartConditionRuleFactory = $cartConditionRuleFactory;
        $this->serializer = $serializer;
    }

    /**
     * {@inheritdoc}
     */
    public function process($data)
    {
        $data[CampaignInterface::CART_CONDITION] = $this->prepareCartConditionData(
            $data,
            CartConditionRule::CONDITIONS_PREFIX
        );
        return $data;
    }

    /**
     * Prepare cart condition data
     *
     * @param array $data
     * @param string $conditionsKey
     * @return ConditionInterface|string
     */
    private function prepareCartConditionData(array $data, $conditionsKey)
    {
        $conditionData = [];
        if (isset($data['rule'][$conditionsKey])) {
            $conditionsArray = $this->convertFlatToRecursive($data['rule'], [$conditionsKey]);
            if (is_array($conditionsArray[$conditionsKey]['1'])) {
                $conditionData = $conditionsArray[$conditionsKey]['1'];
            }
        } else {
            if (isset($data[CampaignInterface::CART_CONDITION])) {
                $conditionData = $this->serializer->unserialize($data[CampaignInterface::CART_CONDITION]);
            } else {
                $cartConditionRule = $this->cartConditionRuleFactory->create();
                $defaultConditions = [];
                $defaultConditions['rule'] = [];
                $defaultConditions['rule'][$conditionsKey] = $cartConditionRule
                    ->setConditions([])
                    ->getConditions()
                    ->asArray();
                $conditionData = $this->convertFlatToRecursive($defaultConditions, [$conditionsKey]);
            }
        }
        return $this->conditionConverter->arrayToDataModel($conditionData);
    }

    /**
     * Get conditions data recursively
     *
     * @param array $data
     * @param array $allowedKeys
     * @return array
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * phpcs:disable Generic.Metrics.NestingLevel
     */
    private function convertFlatToRecursive(array $data, $allowedKeys = [])
    {
        $result = [];
        foreach ($data as $key => $value) {
            if (in_array($key, $allowedKeys) && is_array($value)) {
                foreach ($value as $id => $data) {
                    $path = explode('--', $id);
                    $node = & $result;

                    for ($i = 0, $l = count($path); $i < $l; $i++) {
                        if (!isset($node[$key][$path[$i]])) {
                            $node[$key][$path[$i]] = [];
                        }
                        $node = & $node[$key][$path[$i]];
                    }
                    foreach ($data as $k => $v) {
                        if (is_array($v)) {
                            foreach ($v as $dk => $dv) {
                                if (empty($dv)) {
                                    unset($v[$dk]);
                                }
                            }
                            if (!count($v)) {
                                continue;
                            }
                        }

                        $node[$k] = $v;
                    }
                }
            }
        }

        return $result;
    }
}
