<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Report;

use Magento\Framework\Stdlib\DateTime as StdlibDateTime;

/**
 * Class DateProvider
 * @package Aheadworks\Affiliate\Model\Report
 */
class DateProvider
{
    /**
     * Report data period in months
     */
    const REPORT_STATISTIC_PERIOD = 3;

    /**
     * @var StdlibDateTime
     */
    private $dateTime;

    /**
     * @param StdlibDateTime $dateTime
     */
    public function __construct(
        StdlibDateTime $dateTime
    ) {
        $this->dateTime = $dateTime;
    }

    /**
     * Retrieve report date from
     *
     * @return string
     */
    public function getReportDateFrom()
    {
        $now = new \DateTime('now');
        $now->modify('-' . self::REPORT_STATISTIC_PERIOD . ' month');

        return $this->dateTime->formatDate($now, false);
    }
}
