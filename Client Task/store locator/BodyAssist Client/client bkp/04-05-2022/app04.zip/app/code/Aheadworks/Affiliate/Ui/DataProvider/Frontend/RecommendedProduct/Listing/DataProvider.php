<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Ui\DataProvider\Frontend\RecommendedProduct\Listing;

use Magento\Framework\View\Element\UiComponent\DataProvider\DataProvider as FrameworkDataProvider;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\Search\ReportingInterface;
use Magento\Framework\Api\Search\SearchCriteriaBuilder;
use Magento\Framework\Api\Search\SearchResultInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\EntityManager\HydratorPool;
use Magento\Framework\EntityManager\Hydrator;
use Magento\Catalog\Api\Data\ProductRenderInterface;
use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Aheadworks\Affiliate\Api\CampaignRepositoryInterface;
use Aheadworks\Affiliate\Ui\DataProvider\Frontend\RecommendedProduct\ProductRenderList;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Class ListingDataProvider
 *
 * @package Aheadworks\Affiliate\Ui\DataProvider\Frontend\RecommendedProduct\Listing
 */
class DataProvider extends FrameworkDataProvider
{
    /**#@+
     * Constants defined for retrieving grid rendering params from the request
     */
    const PARAMETERS_REQUEST_PARAM_NAME = 'parameters';
    const CAMPAIGN_ID_REQUEST_PARAM_NAME = 'campaign_id';
    /**#@-*/

    /**
     * @var ProductRenderList
     */
    protected $productRenderList;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * @var HydratorPool
     */
    private $hydratorPool;

    /**
     * @var CampaignRepositoryInterface
     */
    private $campaignRepositoryInterface;

    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param ReportingInterface $reporting
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param RequestInterface $request
     * @param FilterBuilder $filterBuilder
     * @param ProductRenderList $productRenderList
     * @param StoreManagerInterface $storeManager
     * @param HydratorPool $hydratorPool
     * @param CampaignRepositoryInterface $campaignRepositoryInterface
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        ReportingInterface $reporting,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        RequestInterface $request,
        FilterBuilder $filterBuilder,
        ProductRenderList $productRenderList,
        StoreManagerInterface $storeManager,
        HydratorPool $hydratorPool,
        CampaignRepositoryInterface $campaignRepositoryInterface,
        array $meta = [],
        array $data = []
    ) {
        parent::__construct(
            $name,
            $primaryFieldName,
            $requestFieldName,
            $reporting,
            $searchCriteriaBuilder,
            $request,
            $filterBuilder,
            $meta,
            $data
        );
        $this->productRenderList = $productRenderList;
        $this->storeManager = $storeManager;
        $this->hydratorPool = $hydratorPool;
        $this->campaignRepositoryInterface = $campaignRepositoryInterface;
    }

    /**
     * {@inheritdoc
     */
    protected function searchResultToOutput(SearchResultInterface $searchResult)
    {
        $arrItems = [];

        /** @var Hydrator $hydrator */
        $hydrator = $this->hydratorPool->getHydrator(ProductRenderInterface::class);
        /** @var ProductRenderInterface $item */
        foreach ($searchResult->getItems() as $item) {
            $arrItems['items'][] = $hydrator->extract($item);
        }
        $arrItems['totalRecords'] = $searchResult->getTotalCount();

        return $arrItems;
    }

    /**
     * {@inheritdoc
     */
    public function getSearchResult()
    {
        $storeId = $this->getStoreId();
        $currencyCode = $this->getCurrencyCode();
        $campaignId = $this->getCampaignId();

        $this->addCampaignFilter($campaignId);
        $this->addOrder('minimal_price', 'desc');

        return $this->productRenderList->getList($this->getSearchCriteria(), $storeId, $currencyCode, $campaignId);
    }

    /**
     * Retrieve current store id
     *
     * @return int|null
     */
    protected function getStoreId()
    {
        try {
            $storeId = $this->storeManager->getStore()->getId();
        } catch (\Exception $exception) {
            $storeId = null;
        }
        return $storeId;
    }

    /**
     * Retrieve current currency code
     *
     * @return string|null
     */
    protected function getCurrencyCode()
    {
        try {
            $currencyCode = $this->storeManager->getStore()->getCurrentCurrencyCode();
        } catch (\Exception $exception) {
            $currencyCode = null;
        }
        return $currencyCode;
    }

    /**
     * Retrieve campaign id from the request grid params
     *
     * @return int|null
     */
    protected function getCampaignId()
    {
        $parameters = $this->request->getParam(self::PARAMETERS_REQUEST_PARAM_NAME, []);
        $campaignId = isset($parameters[self::CAMPAIGN_ID_REQUEST_PARAM_NAME])
            ? $parameters[self::CAMPAIGN_ID_REQUEST_PARAM_NAME]
            : null
        ;
        return $campaignId;
    }

    /**
     * Add filter by campaign
     *
     * @param int $campaignId
     */
    protected function addCampaignFilter($campaignId)
    {
        $filter = $this->filterBuilder
            ->setField('entity_id')
            ->setValue($this->getProductIds($campaignId))
            ->setConditionType('in')
            ->create();
        $this->addFilter($filter);
    }

    /**
     * Retrieve array of recommended product ids by campaign
     *
     * @param $campaignId
     * @return array
     */
    protected function getProductIds($campaignId)
    {
        try {
            /** @var CampaignInterface $campaign */
            $campaign = $this->campaignRepositoryInterface->getById($campaignId);
            $productIds = $campaign->getRecommendedProductIds();
        } catch (NoSuchEntityException $exception) {
            $productIds = [];
        }
        return $productIds;
    }
}
