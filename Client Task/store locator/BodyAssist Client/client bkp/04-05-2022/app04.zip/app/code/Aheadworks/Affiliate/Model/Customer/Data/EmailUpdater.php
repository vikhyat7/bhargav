<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Customer\Data;

use Magento\Framework\Stdlib\DateTime;

class EmailUpdater
{
    /**#@+
     * Constants to update email;
     */
    const SIMPLY_FORMAT = '%s DELETED';
    const DATETIME_FORMAT = '%s DELETED ON %s';
    /**#@-*/

    /**
     * Retrieve updated email
     *
     * @param string $email
     * @return string
     */
    public function getConcatenatedEmail($email)
    {
        try {
            $date = $this->getCurrentDateTime();
            $email = sprintf(self::DATETIME_FORMAT, $email, $date);
        } catch (\Exception $e) {
            $email = $this->getSimplyConcatenatedEmail($email);
        }

        return $email;
    }

    /**
     * Retrieve simply updated email
     *
     * @param string $email
     * @return string
     */
    public function getSimplyConcatenatedEmail($email)
    {
        return sprintf(self::SIMPLY_FORMAT, $email);
    }

    /**
     * Current date/time
     *
     * @return string
     * @throws \Exception
     */
    private function getCurrentDateTime()
    {
        return (new \DateTime())->format(DateTime::DATETIME_PHP_FORMAT);
    }
}
