<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model;

use Magento\Framework\Model\AbstractModel;
use Aheadworks\Affiliate\Api\Data\SignupInterface;
use Aheadworks\Affiliate\Model\ResourceModel\Signup as SignupResource;
use Aheadworks\Affiliate\Model\Signup\Validator;
use Magento\Framework\Model\Context;
use Magento\Framework\Registry;
use Magento\Framework\Model\ResourceModel\AbstractResource;
use Magento\Framework\Data\Collection\AbstractDb;

/**
 * Class AffiliateGroup
 * @package Aheadworks\Affiliate\Model
 */
class Signup extends AbstractModel implements SignupInterface
{
    /**
     * @var Validator
     */
    private $validator;

    /**
     * @param Context $context
     * @param Registry $registry
     * @param Validator $validator
     * @param AbstractResource|null $resource
     * @param AbstractDb|null $resourceCollection
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        Validator $validator,
        AbstractResource $resource = null,
        AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        parent::__construct(
            $context,
            $registry,
            $resource,
            $resourceCollection,
            $data
        );
        $this->validator = $validator;
    }

    /**
     * {@inheritdoc}
     */
    protected function _construct()
    {
        $this->_init(SignupResource::class);
    }

    /**
     * {@inheritdoc}
     */
    public function getSignupId()
    {
        return $this->getData(self::ID);
    }

    /**
     * {@inheritdoc}
     */
    public function setSignupId($id)
    {
        return $this->setData(self::ID, $id);
    }

    /**
     * {@inheritdoc}
     */
    public function getCustomerId()
    {
        return $this->getData(self::CUSTOMER_ID);
    }

    /**
     * {@inheritdoc}
     */
    public function setCustomerId($customerId)
    {
        return $this->setData(self::CUSTOMER_ID, $customerId);
    }

    /**
     * {@inheritdoc}
     */
    public function getStoreId()
    {
        return $this->getData(self::STORE_ID);
    }

    /**
     * {@inheritdoc}
     */
    public function setStoreId($storeId)
    {
        return $this->setData(self::STORE_ID, $storeId);
    }

    /**
     * {@inheritdoc}
     */
    public function getStatus()
    {
        return $this->getData(self::STATUS);
    }

    /**
     * {@inheritdoc}
     */
    public function setStatus($status)
    {
        return $this->setData(self::STATUS, $status);
    }

    /**
     * {@inheritdoc}
     */
    public function getSignupDate()
    {
        return $this->getData(self::SIGNUP_DATE);
    }

    /**
     * {@inheritdoc}
     */
    public function setSignupDate($date)
    {
        return $this->setData(self::SIGNUP_DATE, $date);
    }

    /**
     * {@inheritdoc}
     */
    public function getReferralWebsite()
    {
        return $this->getData(self::REFERRAL_WEBSITE);
    }

    /**
     * {@inheritdoc}
     */
    public function setReferralWebsite($website)
    {
        return $this->setData(self::REFERRAL_WEBSITE, $website);
    }

    /**
     * {@inheritdoc}
     */
    public function getSignupMessage()
    {
        return $this->getData(self::SINGUP_MESSAGE);
    }

    /**
     * {@inheritdoc}
     */
    public function setSignupMessage($message)
    {
        return $this->setData(self::SINGUP_MESSAGE, $message);
    }

    /**
     * {@inheritdoc}
     */
    public function getDeclineReason()
    {
        return $this->getData(self::DECLINE_REASON);
    }

    /**
     * {@inheritdoc}
     */
    public function setDeclineReason($reason)
    {
        return $this->setData(self::DECLINE_REASON, $reason);
    }

    /**
     * {@inheritdoc}
     */
    public function getExtensionAttributes()
    {
        return $this->getData(self::EXTENSION_ATTRIBUTES_KEY);
    }

    /**
     * {@inheritdoc}
     */
    public function setExtensionAttributes(
        \Aheadworks\Affiliate\Api\Data\SignupExtensionInterface $extensionAttributes
    ) {
        return $this->setData(self::EXTENSION_ATTRIBUTES_KEY, $extensionAttributes);
    }

    /**
     * {@inheritdoc}
     */
    protected function _getValidationRulesBeforeSave()
    {
        return $this->validator;
    }
}
