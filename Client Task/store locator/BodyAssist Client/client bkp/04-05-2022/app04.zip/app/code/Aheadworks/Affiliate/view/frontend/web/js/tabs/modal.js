define([
    'Magento_Ui/js/lib/view/utils/async',
    'Magento_Ui/js/modal/modal-component'
], function ($, Component) {
    'use strict';

    return Component.extend({

        /**
         * {@inheritdoc}
         */
        initializeContent: function () {
            $.async({
                component: this.name,
                ctx: 'div',
                selector: '*'
            }, this.initModal);
        }
    });
});