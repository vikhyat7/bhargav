define([
    'ko',
    'underscore',
    'uiCollection',
    'mageUtils'
], function (ko, _, Collection, utils) {
    'use strict';

    return Collection.extend({
        defaults: {
            template: 'Aheadworks_Affiliate/ui/grid/parameters',
            appliedParameters: {},
            parameters: {},
            exports: {
                appliedParameters: '${ $.provider }:params.parameters'
            }
        },

        /**
         * Apply grid parameters
         *
         * @returns {Parameters} Chainable
         */
        apply: function() {
            if (!this.isValidForm()) {
                this.set('appliedParameters', utils.copy(this.parameters));
            }
            return this;
        },

        /**
         * Validates each element and returns true, if all elements are valid
         *
         * @returns {Boolean}
         */
        isValidForm: function () {
            this.set('params.invalid', false);
            this.trigger('data.validate');

            return this.get('params.invalid');
        }
    });
});
