<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\BoundCustomer;

use Aheadworks\Affiliate\Api\Data\BoundCustomerInterface;
use Aheadworks\Affiliate\Api\Data\BoundCustomerInterfaceFactory;
use Aheadworks\Affiliate\Model\BoundCustomer\Resolver as BoundCustomerResolver;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Sales\Model\Order\Item as OrderItem;

/**
 * Class Processor
 *
 * @package Aheadworks\Affiliate\Model\BoundCustomer
 */
class Processor
{
    /**
     * @var BoundCustomerInterfaceFactory
     */
    private $boundCustomerDataFactory;

    /**
     * @var DataObjectHelper
     */
    private $dataObjectHelper;

    /**
     * @var BoundCustomerResolver
     */
    private $boundCustomerResolver;

    /**
     * @param BoundCustomerInterfaceFactory $boundCustomerDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param BoundCustomerResolver $boundCustomerResolver
     */
    public function __construct(
        BoundCustomerInterfaceFactory $boundCustomerDataFactory,
        DataObjectHelper $dataObjectHelper,
        BoundCustomerResolver $boundCustomerResolver
    ) {
        $this->boundCustomerDataFactory = $boundCustomerDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->boundCustomerResolver = $boundCustomerResolver;
    }

    /**
     * Retrieve bound customer data by order item
     *
     * @param OrderItem $orderItem
     * @return BoundCustomerInterface
     */
    public function getBoundCustomerByOrderItem($orderItem)
    {
        $boundCustomer = null;
        $boundCustomer = $this->boundCustomerResolver->getBoundCustomerByEmail($orderItem->getOrder()->getCustomerEmail());

        $data = [
            BoundCustomerInterface::CUSTOMER_EMAIL => $orderItem->getOrder()->getCustomerEmail(),
            BoundCustomerInterface::ACCOUNT_ID => $orderItem->getAwAffAccountId(),
            BoundCustomerInterface::CUSTOMER_ID => $orderItem->getOrder()->getCustomerId()
        ];

        if ($boundCustomer){
            $data[BoundCustomerInterface::BOUND_ID] = $boundCustomer->getBoundId();
        }

        return $this->getBoundObject($data);
    }

    /**
     * Get object
     *
     * @param array $data
     * @return BoundCustomerInterface
     */
    private function getBoundObject($data)
    {
        /** @var BoundCustomerInterface $boundCustomerObject */
        $boundCustomerObject = $this->boundCustomerDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $boundCustomerObject,
            $data,
            BoundCustomerInterface::class
        );
        return $boundCustomerObject;
    }
}
