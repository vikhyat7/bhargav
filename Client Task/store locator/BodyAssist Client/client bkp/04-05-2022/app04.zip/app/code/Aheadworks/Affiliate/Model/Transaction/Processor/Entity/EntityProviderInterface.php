<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Transaction\Processor\Entity;

use Aheadworks\Affiliate\Api\Data\PayoutInterface;
use Magento\Sales\Api\Data\OrderItemInterface;

/**
 * Interface EntityProviderInterface
 * @package Aheadworks\Affiliate\Model\Transaction\Processor\Entity
 */
interface EntityProviderInterface
{
    /**
     * Get entity type
     *
     * @return string
     */
    public function getEntityType();

    /**
     * Get entity id
     *
     * @param PayoutInterface|OrderItemInterface|null $entity
     * @return int|null
     */
    public function getEntityId($entity);
}
