<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Observer\Frontend\Controller;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Event\Observer;
use Psr\Log\LoggerInterface;
use Aheadworks\Affiliate\Api\PromoLinkManagementInterface;
use Magento\Framework\Exception\LocalizedException;

/**
 * Class PromoLinkChecker
 *
 * @package Aheadworks\Affiliate\Observer\Frontend\Controller
 */
class PromoLinkChecker implements ObserverInterface
{
    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var PromoLinkManagementInterface
     */
    private $promoLinkService;

    /**
     * @param LoggerInterface $logger
     * @param PromoLinkManagementInterface $promoLinkService
     */
    public function __construct(
        LoggerInterface $logger,
        PromoLinkManagementInterface $promoLinkService
    ) {
        $this->logger = $logger;
        $this->promoLinkService = $promoLinkService;
    }

    /**
     * Check if url contains affiliate promo params and process those values
     *
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer)
    {
        /** @var RequestInterface $request */
        $request = $observer->getEvent()->getRequest();
        try {
            $this->promoLinkService->processRequest($request);
        } catch (LocalizedException $exception) {
            $this->logger->critical($exception);
        }
    }
}
