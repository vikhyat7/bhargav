<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Campaign;

use Magento\Backend\App\Action;
use Aheadworks\Affiliate\Api\CampaignManagementInterface;
use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Aheadworks\Affiliate\Api\Data\CampaignInterfaceFactory;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\App\Request\DataPersistorInterface;
use Aheadworks\Affiliate\Ui\DataProvider\Campaign\FormDataProvider;
use Aheadworks\Affiliate\Model\PostData\ProcessorComposite as PostDataProcessorComposite;
use Aheadworks\Affiliate\Model\Campaign\Copier as CampaignCopier;

/**
 * Class Save
 *
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Campaign
 */
class Save extends Action
{
    /**
     * {@inheritdoc}
     */
    const ADMIN_RESOURCE = 'Aheadworks_Affiliate::campaigns';

    /**
     * @var CampaignManagementInterface
     */
    private $campaignService;

    /**
     * @var CampaignInterfaceFactory
     */
    private $campaignDataFactory;

    /**
     * @var DataObjectHelper
     */
    private $dataObjectHelper;

    /**
     * @var DataPersistorInterface
     */
    private $dataPersistor;

    /**
     * @var PostDataProcessorComposite
     */
    private $postDataProcessorComposite;

    /**
     * @var CampaignCopier
     */
    private $campaignCopier;

    /**
     * @param Context $context
     * @param CampaignManagementInterface $campaignService
     * @param CampaignInterfaceFactory $campaignDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataPersistorInterface $dataPersistor
     * @param PostDataProcessorComposite $postDataProcessorComposite
     * @param CampaignCopier $campaignCopier
     */
    public function __construct(
        Context $context,
        CampaignManagementInterface $campaignService,
        CampaignInterfaceFactory $campaignDataFactory,
        DataObjectHelper $dataObjectHelper,
        DataPersistorInterface $dataPersistor,
        PostDataProcessorComposite $postDataProcessorComposite,
        CampaignCopier $campaignCopier
    ) {
        parent::__construct($context);
        $this->campaignService = $campaignService;
        $this->campaignDataFactory = $campaignDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataPersistor = $dataPersistor;
        $this->postDataProcessorComposite = $postDataProcessorComposite;
        $this->campaignCopier = $campaignCopier;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        $preparedData = [];
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($postData = $this->getRequest()->getPostValue()) {
            try {
                $preparedData = $this->postDataProcessorComposite->prepareData($postData);
                $campaign = $this->performSave($preparedData);
                $this->dataPersistor->clear(FormDataProvider::DATA_PERSISTOR_FORM_DATA_KEY);
                $this->messageManager->addSuccessMessage(__('The campaign was successfully saved.'));
                $action = isset($preparedData['action']) ? $preparedData['action'] : false;
                if ($action == 'duplicate') {
                    $newCampaign = $this->campaignCopier->copy($campaign);
                    $this->messageManager->addSuccessMessage(__('The campaign was successfully duplicated.'));
                    return $resultRedirect->setPath(
                        '*/*/edit',
                        [
                            CampaignInterface::ID => $newCampaign->getCampaignId(),
                            '_current' => true
                        ]
                    );
                }
                return $resultRedirect->setPath('*/*/');
            } catch (CouldNotSaveException $exception) {
                $this->messageManager->addErrorMessage($exception->getMessage());
            } catch (\Exception $exception) {
                $this->messageManager->addExceptionMessage(
                    $exception,
                    __('Something went wrong while saving the campaign.')
                );
            }
            $this->dataPersistor->set(
                FormDataProvider::DATA_PERSISTOR_FORM_DATA_KEY,
                $this->prepareDataToSet($preparedData)
            );
            if ($this->isCampaignAlreadyExist($preparedData)) {
                return $resultRedirect->setPath(
                    '*/*/edit',
                    [CampaignInterface::ID => $preparedData[CampaignInterface::ID], '_current' => true]
                );
            }
            return $resultRedirect->setPath('*/*/new', ['_current' => true]);
        }
        return $resultRedirect->setPath('*/*/');
    }

    /**
     * Perform campaign saving
     *
     * @param array $postData
     * @return CampaignInterface
     * @throws CouldNotSaveException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    private function performSave($postData)
    {
        $campaignObject = $this->campaignDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $campaignObject,
            $postData,
            CampaignInterface::class
        );

        $savedCampaign = $this->isCampaignAlreadyExist($postData)
            ? $this->campaignService->updateCampaign($campaignObject)
            : $this->campaignService->createCampaign($campaignObject);

        return $savedCampaign;
    }

    /**
     * Check if campaign already exists
     *
     * @param array $campaignData
     * @return bool
     */
    private function isCampaignAlreadyExist($campaignData)
    {
        return isset($campaignData[CampaignInterface::ID])
            && !empty($campaignData[CampaignInterface::ID]);
    }

    /**
     * Prepare data to set
     *
     * @param array $data
     * @return array
     */
    private function prepareDataToSet($data)
    {
        unset($data[CampaignInterface::CART_CONDITION]);

        return $data;
    }
}
