<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\SampleData\Installer;

use Aheadworks\Affiliate\Model\SampleData\Reader;
use Magento\Cms\Api\Data\PageInterface;
use Magento\Cms\Api\Data\PageInterfaceFactory;
use Magento\Cms\Api\PageRepositoryInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Setup\SampleData\InstallerInterface as SampleDataInstallerInterface;
use Magento\Framework\Api\DataObjectHelper;

/**
 * Class CmsPage
 *
 * @package Aheadworks\Affiliate\Model\SampleData\Installer
 */
class CmsPage implements SampleDataInstallerInterface
{
    /**
     * @var Reader
     */
    private $reader;

    /**
     * @var PageInterfaceFactory
     */
    private $pageDataFactory;

    /**
     * @var PageRepositoryInterface
     */
    private $pageRepository;

    /**
     * @var DataObjectHelper
     */
    private $dataObjectHelper;

    /**
     * @var SearchCriteriaBuilder
     */
    private $searchCriteriaBuilder;

    /**
     * @var string
     */
    private $fileName = 'Aheadworks_Affiliate::fixtures/cms_pages.csv';

    /**
     * @param Reader $reader
     * @param PageInterfaceFactory $pageDataFactory
     * @param PageRepositoryInterface $pageRepository
     * @param DataObjectHelper $dataObjectHelper
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     */
    public function __construct(
        Reader $reader,
        PageInterfaceFactory $pageDataFactory,
        PageRepositoryInterface $pageRepository,
        DataObjectHelper $dataObjectHelper,
        SearchCriteriaBuilder $searchCriteriaBuilder
    ) {
        $this->reader = $reader;
        $this->pageDataFactory = $pageDataFactory;
        $this->pageRepository = $pageRepository;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
    }

    /**
     * {@inheritdoc}
     */
    public function install()
    {
        $rows = $this->reader->readFile($this->fileName);
        foreach ($rows as $row) {
            if (isset($row[PageInterface::IDENTIFIER]) && !$this->isCmsPageExists($row[PageInterface::IDENTIFIER])) {
                $this->createCmsPage($row);
            }
        }
    }

    /**
     * Check if cms page with specified identifier exists
     *
     * @param string $identifier
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    private function isCmsPageExists($identifier)
    {
        $this->searchCriteriaBuilder
            ->addFilter(PageInterface::IDENTIFIER, $identifier)
            ->setCurrentPage(1)
            ->setPageSize(1);
        $pages = $this->pageRepository->getList($this->searchCriteriaBuilder->create())->getItems();

        return count($pages) > 0;
    }

    /**
     * Create cms page
     *
     * @param array $row
     * @throws \Exception
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    private function createCmsPage($row)
    {
        /** @var PageInterface $page */
        $page = $this->pageDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $page,
            $row,
            PageInterface::class
        );

        $this->pageRepository->save($page);
    }
}
