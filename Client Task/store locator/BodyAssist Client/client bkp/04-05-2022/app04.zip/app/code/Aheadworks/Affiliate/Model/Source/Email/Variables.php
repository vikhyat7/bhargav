<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Source\Email;

/**
 * Class Variables
 * @package Aheadworks\Affiliate\Model\Source\Email
 */
class Variables
{
    /**#@+
     *  Email variables
     */
    const RECIPIENT_NAME = 'recipient_name';
    const CUSTOMER_NAME = 'customer_name';
    const STORE = 'store';
    const SIGNUP_URL = 'signup_url';
    const ACCOUNT_INFO_URL = 'account_info_url';
    const DECLINE_REASON = 'decline_reason';
    const PAYOUT_GRID_URL = 'payout_grid_url';
    const FORMATTED_AMOUNT = 'formatted_amount';
    const TERMS_AND_CONDITIONS_URL = 'terms_and_conditions_url';
    /**#@-*/
}
