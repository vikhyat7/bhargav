<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Ui\DataProvider\Campaign\FormDataProcessor;

use Aheadworks\Affiliate\Ui\DataProvider\FormDataProcessor\ProcessorInterface;
use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Helper\Image as ImageHelper;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Catalog\Model\Product\Visibility as ProductVisibility;
use Magento\Catalog\Model\Product\Type as ProductType;
use Magento\Eav\Api\AttributeSetRepositoryInterface;
use Magento\Catalog\Model\Product\Attribute\Source\Status as StatusSource;
use Magento\Store\Model\System\Store as SystemStore;
use Magento\Catalog\Model\Product\Attribute\Source\Status;
use Magento\Directory\Model\Currency;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Aheadworks\Affiliate\Model\ValueFormatter\Price as PriceValueFormatter;

/**
 * Class RecommendedProducts
 *
 * @package Aheadworks\Affiliate\Ui\DataProvider\Campaign\FormDataProcessor
 */
class RecommendedProducts implements ProcessorInterface
{
    /**
     * Name of the field with recommended products data
     */
    const RECOMMENDED_PRODUCTS_DATA_FIELD_NAME = 'recommended_products_selection';

    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;

    /**
     * @var ImageHelper
     */
    protected $imageHelper;

    /**
     * @var ProductVisibility
     */
    protected $productVisibility;

    /**
     * @var ProductType
     */
    protected $productType;

    /**
     * @var AttributeSetRepositoryInterface
     */
    protected $attributeSetRepository;

    /**
     * @var StatusSource
     */
    protected $statusSource;

    /**
     * @var SystemStore
     */
    protected $systemStore;

    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @var PriceValueFormatter
     */
    protected $priceValueFormatter;

    /**
     * @param ProductRepositoryInterface $productRepository
     * @param ImageHelper $imageHelper
     * @param ProductVisibility $productVisibility
     * @param ProductType $productType
     * @param AttributeSetRepositoryInterface $attributeSetRepository
     * @param StatusSource $statusSource,
     * @param SystemStore $systemStore
     * @param ScopeConfigInterface $scopeConfig
     * @param PriceValueFormatter $priceValueFormatter
     */
    public function __construct(
        ProductRepositoryInterface $productRepository,
        ImageHelper $imageHelper,
        ProductVisibility $productVisibility,
        ProductType $productType,
        AttributeSetRepositoryInterface $attributeSetRepository,
        StatusSource $statusSource,
        SystemStore $systemStore,
        ScopeConfigInterface $scopeConfig,
        PriceValueFormatter $priceValueFormatter
    ) {
        $this->productRepository = $productRepository;
        $this->imageHelper = $imageHelper;
        $this->productVisibility = $productVisibility;
        $this->productType = $productType;
        $this->attributeSetRepository = $attributeSetRepository;
        $this->statusSource = $statusSource;
        $this->systemStore = $systemStore;
        $this->scopeConfig = $scopeConfig;
        $this->priceValueFormatter = $priceValueFormatter;
    }

    /**
     * {@inheritdoc}
     */
    public function process($data)
    {
        if (isset($data[CampaignInterface::RECOMMENDED_PRODUCT_IDS])) {
            $recommendedProductsData = [];
            foreach ($data[CampaignInterface::RECOMMENDED_PRODUCT_IDS] as $productId) {
                try {
                    /** @var Product $product */
                    $product = $this->productRepository->getById($productId, false);
                    $productData = [
                        'id' => $product->getId(),
                        'thumbnail_url' => $this->imageHelper
                            ->init($product, 'product_listing_thumbnail')
                            ->getUrl(),
                        'name' => $product->getName(),
                        'type_label' => $this->productType->getOptionText($product->getTypeId()),
                        'attribute_set_label' => $this->attributeSetRepository
                            ->get($product->getAttributeSetId())
                            ->getAttributeSetName(),
                        'sku' => $product->getSku(),
                        'price_label' => $this->getPriceLabel($product->getPrice()),
                        'visibility_label' => $this->productVisibility->getOptionText($product->getVisibility()),
                        'status_label' => $this->statusSource->getOptionText($product->getStatus()),
                        'websites_label' => $this->getWebsitesLabel($product->getWebsiteIds()),
                    ];
                    $recommendedProductsData[] = $productData;
                } catch (NoSuchEntityException $exception) {
                    $recommendedProductsData = [];
                }
            }
            $data[self::RECOMMENDED_PRODUCTS_DATA_FIELD_NAME] = $recommendedProductsData;
        }
        return $data;
    }

    /**
     * Retrieve websites label
     *
     * @param array $websiteIds
     * @return string
     */
    private function getWebsitesLabel($websiteIds)
    {
        $websiteLabels = [];
        foreach ($websiteIds as $websiteId) {
            if (!empty($websiteName = $this->systemStore->getWebsiteName($websiteId))) {
                $websiteLabels[] = $websiteName;
            }
        }
        return implode(', ', $websiteLabels);
    }

    /**
     * Retrieve price label
     *
     * @param float $productPrice
     * @return string
     */
    private function getPriceLabel($productPrice)
    {
        $priceLabel = '';
        try {
            $currencyCode = $this->scopeConfig->getValue(
                Currency::XML_PATH_CURRENCY_BASE,
                ScopeConfigInterface::SCOPE_TYPE_DEFAULT
            );
            $priceLabel = $this->priceValueFormatter->getFormattedValueByCurrencyCode($productPrice, $currencyCode);
        } catch (\Exception $exception) {
            $priceLabel = '';
        }
        return $priceLabel;
    }
}
