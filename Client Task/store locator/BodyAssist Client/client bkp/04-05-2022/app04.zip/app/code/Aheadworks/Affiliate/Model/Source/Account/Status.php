<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Source\Account;

use Magento\Framework\Data\OptionSourceInterface;
use Aheadworks\Affiliate\Model\Source\Campaign\Status as CampaignStatusSource;

/**
 * Class Status
 * @package Aheadworks\Affiliate\Model\Source\Account
 */
class Status extends CampaignStatusSource implements OptionSourceInterface
{
    /**
     * Deleted status value
     */
    const DELETED = 3;

    /**
     * {@inheritdoc}
     */
    public function toOptionArray()
    {
        $options = parent::toOptionArray();
        array_push(
            $options,
            [
                'value' => self::DELETED,
                'label' => __('Deleted')
            ]
        );

        return $options;
    }

    /**
     * Get default affiliate status
     *
     * @return int
     * phpcs:disable Magento2.Functions.StaticFunction
     */
    public static function getDefaultStatus()
    {
        return self::ACTIVE;
    }
}
