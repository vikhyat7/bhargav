<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Transaction\Comment;

use Magento\Sales\Api\Data\OrderItemInterface;
use Aheadworks\Affiliate\Api\Data\PayoutInterface;

/**
 * Interface ArgumentProviderInterface
 * @package Aheadworks\Affiliate\Model\Transaction\Comment
 */
interface ArgumentProviderInterface
{
    /**
     * Retrieve arguments
     *
     * @param PayoutInterface|OrderItemInterface|null $entity
     * @return array
     */
    public function get($entity);
}
