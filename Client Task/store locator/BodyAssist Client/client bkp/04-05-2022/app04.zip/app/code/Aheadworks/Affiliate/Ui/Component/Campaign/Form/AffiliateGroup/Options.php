<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Ui\Component\Campaign\Form\AffiliateGroup;

use Aheadworks\Affiliate\Model\Source\AffiliateGroup as AffiliateGroupSource;

/**
 * Class Options
 * @package Aheadworks\Affiliate\Ui\Component\Campaign\Form\AffiliateGroup
 */
class Options extends AffiliateGroupSource
{
    /**
     * @var array
     */
    private $options;

    /**
     * {@inheritdoc}
     */
    public function toOptionArray()
    {
        if (null === $this->options) {
            $options = [['value' => AffiliateGroupSource::ALL_GROUPS_VALUE, 'label' => __('All Groups')]];
            $this->options = array_merge($options, parent::toOptionArray());
        }

        return $this->options;
    }
}
