<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Account;

use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Class AbstractMassChangeStatus
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Account
 */
abstract class AbstractMassChangeStatus extends AbstractMassAction
{
    /**
     * Change status for accounts
     *
     * @param AccountInterface[] $accounts
     */
    protected function massAction($accounts)
    {
        $recordsCounter = 0;
        /** @var AccountInterface $item */
        foreach ($accounts as $item) {
            try {
                if ($this->getStatusToSet() != $item->getStatus()) {
                    $this->updateStatus($item);
                    $recordsCounter++;
                }
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            }
        }
        if ($recordsCounter) {
            $this->messageManager->addSuccessMessage($this->getSuccessMessage($recordsCounter));
        } else {
            $this->messageManager->addSuccessMessage($this->getMessageForNoChanges());
        }
    }

    /**
     * Update status
     *
     * @param AccountInterface $account
     * @throws CouldNotSaveException
     * @throws NoSuchEntityException
     */
    abstract protected function updateStatus($account);

    /**
     * Retrieve status id to set
     *
     * @return int
     */
    abstract protected function getStatusToSet();

    /**
     * Retrieve success message
     *
     * @param int $changedRecordsCounter
     * @return string
     */
    abstract protected function getSuccessMessage($changedRecordsCounter);

    /**
     * Retrieve error message
     *
     * @return string
     */
    abstract protected function getMessageForNoChanges();
}
