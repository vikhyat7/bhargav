<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Payout;

use Magento\Backend\App\Action\Context;
use Aheadworks\Affiliate\Api\PayoutRepositoryInterface;
use Aheadworks\Affiliate\Api\PayoutManagementInterface;
use Aheadworks\Affiliate\Api\Data\PayoutInterface;
use Aheadworks\Affiliate\Model\ResourceModel\Payout\CollectionFactory;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Ui\Component\MassAction\Filter;
use Magento\Framework\Exception\LocalizedException;
use Aheadworks\Affiliate\Model\Payout\StatusResolver;

/**
 * Class AbstractMassChangeStatus
 *
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Payout
 */
abstract class AbstractMassChangeStatus extends AbstractMassAction
{
    /**
     * @var StatusResolver
     */
    protected $statusResolver;

    /**
     * @param Context $context
     * @param CollectionFactory $collectionFactory
     * @param PayoutManagementInterface $payoutManagement
     * @param PayoutRepositoryInterface $payoutRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param Filter $filter
     * @param StatusResolver $statusResolver
     */
    public function __construct(
        Context $context,
        CollectionFactory $collectionFactory,
        PayoutManagementInterface $payoutManagement,
        PayoutRepositoryInterface $payoutRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        Filter $filter,
        StatusResolver $statusResolver
    ) {
        $this->statusResolver = $statusResolver;
        parent::__construct(
            $context,
            $collectionFactory,
            $payoutManagement,
            $payoutRepository,
            $searchCriteriaBuilder,
            $filter
        );
    }

    /**
     * Change status for payouts
     *
     * @param PayoutInterface[] $payouts
     */
    protected function massAction($payouts)
    {
        $recordsCounter = 0;
        /** @var PayoutInterface $item */
        foreach ($payouts as $item) {
            try {
                if ($this->statusResolver->isStatusAllowedForPayout($this->getStatusToSet(), $item->getStatus())) {
                    $item->setStatus($this->getStatusToSet());
                    $this->updateStatus($item->getPayoutId());
                    $recordsCounter++;
                }
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            }
        }
        if ($recordsCounter) {
            $this->messageManager->addSuccessMessage($this->getSuccessMessage($recordsCounter));
        } else {
            $this->messageManager->addSuccessMessage($this->getMessageForNoChanges());
        }
    }

    /**
     * Update status
     *
     * @param int $payoutId
     * @return int
     * @throws LocalizedException
     */
    abstract protected function updateStatus($payoutId);

    /**
     * Retrieve status to set
     *
     * @return string
     */
    abstract protected function getStatusToSet();

    /**
     * Retrieve success message
     *
     * @param int $changedRecordsCounter
     * @return string
     */
    abstract protected function getSuccessMessage($changedRecordsCounter);

    /**
     * Retrieve error message
     *
     * @return string
     */
    protected function getMessageForNoChanges()
    {
        return __('No payout(s) were changed.');
    }
}
