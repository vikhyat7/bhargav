<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Group;

use Aheadworks\Affiliate\Api\Data\AffiliateGroupInterface;
use Aheadworks\Affiliate\Api\Data\AffiliateGroupInterfaceFactory;
use Aheadworks\Affiliate\Api\AffiliateGroupRepositoryInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Backend\App\Action;

/**
 * Class Save
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Group
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Save extends Action
{
    /**
     * {@inheritdoc}
     */
    const ADMIN_RESOURCE = 'Aheadworks_Affiliate::affiliate_groups';

    /**
     * @var AffiliateGroupInterfaceFactory
     */
    private $affiliateGroupDataFactory;

    /**
     * @var DataObjectHelper
     */
    private $dataObjectHelper;

    /**
     * @var DataPersistorInterface
     */
    private $dataPersistor;

    /**
     * @var AffiliateGroupRepositoryInterface
     */
    private $affiliateGroupRepository;

    /**.
     * @param Context $context
     * @param AffiliateGroupInterfaceFactory $affiliateGroupDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataPersistorInterface $dataPersistor
     * @param AffiliateGroupRepositoryInterface $affiliateGroupRepository
     */
    public function __construct(
        Context $context,
        AffiliateGroupInterfaceFactory $affiliateGroupDataFactory,
        DataObjectHelper $dataObjectHelper,
        DataPersistorInterface $dataPersistor,
        AffiliateGroupRepositoryInterface $affiliateGroupRepository
    ) {
        parent::__construct($context);
        $this->affiliateGroupDataFactory = $affiliateGroupDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataPersistor = $dataPersistor;
        $this->affiliateGroupRepository = $affiliateGroupRepository;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($postData = $this->getRequest()->getPostValue()) {
            try {
                $affiliateGroup = $this->performSave($postData);
                $this->dataPersistor->clear('aw_affiliate_group_form');
                $this->messageManager->addSuccessMessage(__('The affiliate group was successfully saved.'));
                $back = $this->getRequest()->getParam('back');
                if ($back == 'edit') {
                    return $resultRedirect->setPath(
                        '*/*/' . $back,
                        [
                            AffiliateGroupInterface::ID => $affiliateGroup->getId(),
                            '_current' => true
                        ]
                    );
                }
                return $resultRedirect->setPath('*/*/');
            } catch (CouldNotSaveException $exception) {
                $this->messageManager->addErrorMessage($exception->getMessage());
            } catch (\Exception $exception) {
                $this->messageManager->addExceptionMessage(
                    $exception,
                    __('Something went wrong while saving the affiliate group.')
                );
            }
            $this->dataPersistor->set('aw_affiliate_group_form', $postData);
            if ($this->isGroupAlreadyExist($postData)) {
                return $resultRedirect->setPath(
                    '*/*/edit',
                    [AffiliateGroupInterface::ID => $postData[AffiliateGroupInterface::ID], '_current' => true]
                );
            }
            return $resultRedirect->setPath('*/*/new', ['_current' => true]);
        }
        return $resultRedirect->setPath('*/*/');
    }

    /**
     * Perform affiliateGroup save
     *
     * @param array $postData
     * @return AffiliateGroupInterface
     * @throws CouldNotSaveException
     */
    private function performSave($postData)
    {
        $affiliateGroupObject = $this->affiliateGroupDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $affiliateGroupObject,
            $postData,
            AffiliateGroupInterface::class
        );

        $savedAffiliateGroup = $this->affiliateGroupRepository->save($affiliateGroupObject);

        return $savedAffiliateGroup;
    }

    /**
     * Check if affiliateGroup already exists
     *
     * @param array $affiliateGroupData
     * @return bool
     */
    private function isGroupAlreadyExist($affiliateGroupData)
    {
        return isset($affiliateGroupData[AffiliateGroupInterface::ID])
            && !empty($affiliateGroupData[AffiliateGroupInterface::ID]);
    }
}
