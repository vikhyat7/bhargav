<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Customer\Layout\Processor\Affiliate;

use Aheadworks\Affiliate\Model\Layout\LayoutProcessorInterface;
use Magento\Framework\Stdlib\ArrayManager;
use Aheadworks\Affiliate\Api\AccountRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterface;

/**
 * Class AccountCouponPrefixConfig
 * @package Aheadworks\Affiliate\Model\Customer\Layout\Processor\Affiliate
 */
class AccountCouponPrefixConfig implements LayoutProcessorInterface
{
    /**
     * @var ArrayManager
     */
    private $arrayManager;

    /**
     * @var AccountRepositoryInterface
     */
    private $accountRepository;

    /**
     * @param ArrayManager $arrayManager
     * @param AccountRepositoryInterface $accountRepository
     */
    public function __construct(
        ArrayManager $arrayManager,
        AccountRepositoryInterface $accountRepository
    ) {
        $this->arrayManager = $arrayManager;
        $this->accountRepository = $accountRepository;
    }

    /**
     * {@inheritdoc}
     */
    public function process($jsLayout, $customerId, $websiteId)
    {
        $accountInfoConfigProviderPath = 'components/awAffUniqueCouponPrefixFormProvider';
        $jsLayout = $this->arrayManager->merge(
            $accountInfoConfigProviderPath,
            $jsLayout,
            [
                'data' => $this->getAffiliateCouponPrefixFormData($customerId, $websiteId)
            ]
        );

        return $jsLayout;
    }

    /**
     * Retrieve affiliate unique coupon prefix data
     *
     * @param int|null $customerId
     * @param int|null $websiteId
     * @return array
     */
    private function getAffiliateCouponPrefixFormData($customerId, $websiteId)
    {
        try {
            $data = [
                AccountInterface::UNIQUE_COUPON_PREFIX =>
                    $this->accountRepository->getByCustomerId($customerId, $websiteId)->getUniqueCouponPrefix()
            ];
        } catch (\Exception $exception) {
            $data = [];
        }
        return $data;
    }
}
