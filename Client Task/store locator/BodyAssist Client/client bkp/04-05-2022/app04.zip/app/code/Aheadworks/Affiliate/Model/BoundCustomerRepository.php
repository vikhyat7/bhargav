<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model;

use Aheadworks\Affiliate\Api\BoundCustomerRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\BoundCustomerInterface;
use Aheadworks\Affiliate\Api\Data\BoundCustomerInterfaceFactory;
use Aheadworks\Affiliate\Api\Data\BoundCustomerSearchResultsInterfaceFactory;
use Aheadworks\Affiliate\Model\ResourceModel\BoundCustomer as BoundCustomerResourceModel;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Aheadworks\Affiliate\Model\BoundCustomer as BoundCustomerModel;
use Aheadworks\Affiliate\Model\ResourceModel\BoundCustomer\Collection as BoundCustomerCollection;
use Aheadworks\Affiliate\Model\ResourceModel\BoundCustomer\CollectionFactory as BoundCustomerCollectionFactory;
use Magento\Framework\Reflection\DataObjectProcessor;

/**
 * Class BoundCustomerRepository
 *
 * @package Aheadworks\Affiliate\Model
 */
class BoundCustomerRepository implements BoundCustomerRepositoryInterface
{
    /**
     * @var BoundCustomerResourceModel
     */
    private $resource;

    /**
     * @var BoundCustomerInterfaceFactory
     */
    private $boundCustomerInterfaceFactory;

    /**
     * @var BoundCustomerCollectionFactory
     */
    private $boundCustomerCollectionFactory;

    /**
     * @var BoundCustomerSearchResultsInterfaceFactory
     */
    private $searchResultsFactory;

    /**
     * @var JoinProcessorInterface
     */
    private $extensionAttributesJoinProcessor;

    /**
     * @var CollectionProcessorInterface
     */
    private $collectionProcessor;

    /**
     * @var DataObjectHelper
     */
    private $dataObjectHelper;

    /**
     * @var DataObjectProcessor
     */
    private $dataObjectProcessor;

    /**
     * @var array
     */
    private $boundCustomers = [];

    /**
     * @param BoundCustomerResourceModel $resource
     * @param BoundCustomerInterfaceFactory $boundCustomerInterfaceFactory
     * @param BoundCustomerCollectionFactory $boundCustomerCollectionFactory
     * @param BoundCustomerSearchResultsInterfaceFactory $searchResultsFactory
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param CollectionProcessorInterface $collectionProcessor
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     */
    public function __construct(
        BoundCustomerResourceModel $resource,
        BoundCustomerInterfaceFactory $boundCustomerInterfaceFactory,
        BoundCustomerCollectionFactory $boundCustomerCollectionFactory,
        BoundCustomerSearchResultsInterfaceFactory $searchResultsFactory,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        CollectionProcessorInterface $collectionProcessor,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor
    ) {
        $this->resource = $resource;
        $this->boundCustomerInterfaceFactory = $boundCustomerInterfaceFactory;
        $this->boundCustomerCollectionFactory = $boundCustomerCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->collectionProcessor = $collectionProcessor;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataObjectProcessor = $dataObjectProcessor;
    }

    /**
     * @inheritDoc
     */
    public function save(BoundCustomerInterface $boundCustomer)
    {
        try {
            $this->resource->save($boundCustomer);
            $this->boundCustomers[$boundCustomer->getBoundId()] = $boundCustomer;
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__($exception->getMessage()));
        }

        return $boundCustomer;
    }

    /**
     * @inheritDoc
     */
    public function getById($boundId)
    {
        if (!isset($this->boundCustomers[$boundId])) {
            /** @var BoundCustomerInterface $boundCustomer */
            $boundCustomer = $this->boundCustomerInterfaceFactory->create();
            $this->resource->load($boundCustomer, $boundId);
            if (!$boundCustomer->getBoundId()) {
                throw NoSuchEntityException::singleField(BoundCustomerInterface::BOUND_ID, $boundId);
            }
            $this->boundCustomers[$boundId] = $boundCustomer;
        }
        return $this->boundCustomers[$boundId];
    }

    /**
     * @inheritDoc
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria)
    {
        /** @var BoundCustomerCollection $collection */
        $collection = $this->boundCustomerCollectionFactory->create();

        $this->extensionAttributesJoinProcessor->process($collection, BoundCustomerInterface::class);
        $this->collectionProcessor->process($searchCriteria, $collection);

        /** @var BoundCustomerSearchResultsInterface $searchResults */
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($searchCriteria);
        $searchResults->setTotalCount($collection->getSize());

        $objects = [];
        /** @var BoundCustomerModel $item */
        foreach ($collection->getItems() as $item) {
            $objects[] = $this->getDataObject($item);
        }
        $searchResults->setItems($objects);

        return $searchResults;
    }

    /**
     * Retrieves data object using model
     *
     * @param BoundCustomerModel $model
     * @return BoundCustomerInterface
     */
    private function getDataObject($model)
    {
        /** @var BoundCustomerInterface $object */
        $object = $this->boundCustomerInterfaceFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $object,
            $this->dataObjectProcessor->buildOutputDataArray($model, BoundCustomerInterface::class),
            BoundCustomerInterface::class
        );
        return $object;
    }
}
