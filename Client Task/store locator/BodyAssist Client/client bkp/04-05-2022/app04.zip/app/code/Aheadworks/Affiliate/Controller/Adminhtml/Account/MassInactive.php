<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Account;

use Aheadworks\Affiliate\Model\Source\Account\Status;

/**
 * Class MassInactive
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Account
 */
class MassInactive extends AbstractMassChangeStatus
{
    /**
     * {@inheritdoc}
     */
    protected function updateStatus($account)
    {
        $account->setStatus(Status::INACTIVE);
        $this->accountManagement->updateAccount($account);
    }

    /**
     * {@inheritdoc}
     */
    protected function getStatusToSet()
    {
        return Status::INACTIVE;
    }

    /**
     * {@inheritdoc}
     */
    protected function getSuccessMessage($changedRecordsCounter)
    {
        return __('A total of %1 account(s) were deactivated.', $changedRecordsCounter);
    }

    /**
     * {@inheritdoc}
     */
    protected function getMessageForNoChanges()
    {
        return __('No accounts were deactivated.');
    }
}
