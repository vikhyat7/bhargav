<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Source\Order\Item;

use Magento\Framework\Data\OptionSourceInterface;
use Magento\Sales\Model\Order\Item as OrderItem;

/**
 * Class Status
 *
 * @package Aheadworks\Affiliate\Model\Source\Order\Item
 */
class Status implements OptionSourceInterface
{
    /**
     * {@inheritdoc}
     */
    public function toOptionArray()
    {
        $orderItemStatusOptionArray = [];
        $orderItemStatuses = OrderItem::getStatuses();
        foreach ($orderItemStatuses as $statusValue => $statusLabel) {
            $orderItemStatusOptionArray[] = [
                'value' => $statusValue,
                'label' => $statusLabel
            ];
        }
        return $orderItemStatusOptionArray;
    }

    /**
     * Return array of options for adding commission
     *
     * @return array
     */
    public function getAddingCommissionOptions()
    {
        return [
            [
                'value' => OrderItem::STATUS_PENDING,
                'label' => OrderItem::getStatusName(OrderItem::STATUS_PENDING)
            ],
            [
                'value' => OrderItem::STATUS_INVOICED,
                'label' => OrderItem::getStatusName(OrderItem::STATUS_INVOICED)
            ],
            [
                'value' => OrderItem::STATUS_SHIPPED,
                'label' => OrderItem::getStatusName(OrderItem::STATUS_SHIPPED)
            ]
        ];
    }

    /**
     * Retrieve default order item status for adding commission
     *
     * @return int
     * phpcs:disable Magento2.Functions.StaticFunction
     */
    public static function getDefaultValueForAddingCommission()
    {
        return OrderItem::STATUS_SHIPPED;
    }

    /**
     * Return array of options for deduction commission
     *
     * @return array
     */
    public function getDeductionCommissionOptions()
    {
        return [
            [
                'value' => OrderItem::STATUS_CANCELED,
                'label' => OrderItem::getStatusName(OrderItem::STATUS_CANCELED)
            ],
            [
                'value' => OrderItem::STATUS_REFUNDED,
                'label' => OrderItem::getStatusName(OrderItem::STATUS_REFUNDED)
            ],
            [
                'value' => OrderItem::STATUS_RETURNED,
                'label' => OrderItem::getStatusName(OrderItem::STATUS_RETURNED)
            ]
        ];
    }
}
