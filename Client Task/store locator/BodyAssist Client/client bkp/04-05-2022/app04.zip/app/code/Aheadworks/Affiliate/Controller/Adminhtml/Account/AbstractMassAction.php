<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Account;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Aheadworks\Affiliate\Api\AccountRepositoryInterface;
use Aheadworks\Affiliate\Api\AccountManagementInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Aheadworks\Affiliate\Model\ResourceModel\Account\CollectionFactory;
use Aheadworks\Affiliate\Model\ResourceModel\Account\Collection;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Ui\Component\MassAction\Filter;
use Magento\Framework\Exception\LocalizedException;

/**
 * Class AbstractMassAction
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Account
 */
abstract class AbstractMassAction extends Action
{
    /**
     * {@inheritdoc}
     */
    const ADMIN_RESOURCE = 'Aheadworks_Affiliate::accounts';

    /**
     * @var CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @var Filter
     */
    protected $filter;

    /**
     * @var AccountManagementInterface
     */
    protected $accountManagement;

    /**
     * @var AccountRepositoryInterface
     */
    protected $accountRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * @param Context $context
     * @param CollectionFactory $collectionFactory
     * @param AccountManagementInterface $accountManagement
     * @param AccountRepositoryInterface $accountRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param Filter $filter
     */
    public function __construct(
        Context $context,
        CollectionFactory $collectionFactory,
        AccountManagementInterface $accountManagement,
        AccountRepositoryInterface $accountRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        Filter $filter
    ) {
        parent::__construct($context);
        $this->collectionFactory = $collectionFactory;
        $this->filter = $filter;
        $this->accountManagement = $accountManagement;
        $this->accountRepository = $accountRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        try {
            $accountsArray = $this->getAccountsForMassAction();
            $this->massAction($accountsArray);
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        }

        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $resultRedirect->setPath('*/*/index');
        return $resultRedirect;
    }

    /**
     * Retrieve array of accounts for mass action
     *
     * @return AccountInterface[]
     */
    protected function getAccountsForMassAction()
    {
        $accountsForMassAction = [];
        try {
            /** @var Collection $collection */
            $collection = $this->filter->getCollection($this->collectionFactory->create());
            $searchCriteria = $this->searchCriteriaBuilder
                ->addFilter(AccountInterface::ID, $collection->getAllIds(), 'in')
                ->create();
            $accountsForMassAction = $this->accountRepository->getList($searchCriteria)->getItems();
        } catch (LocalizedException $exception) {
            $accountsForMassAction = [];
        }

        return $accountsForMassAction;
    }

    /**
     * Perform mass action
     *
     * @param AccountInterface[] $accounts
     * @throws NoSuchEntityException
     * @throws CouldNotSaveException
     */
    abstract protected function massAction($accounts);
}
