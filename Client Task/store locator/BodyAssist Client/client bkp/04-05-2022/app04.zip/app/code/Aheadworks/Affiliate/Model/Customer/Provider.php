<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Customer;

use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Api\Data\CustomerInterface;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Exception\LocalizedException;

/**
 * Class Provider
 *
 * @package Aheadworks\Affiliate\Model\Customer
 */
class Provider
{
    /**
     * @var CustomerRepositoryInterface
     */
    private $customerRepository;

    /**
     * @var ExtensibleDataObjectConverter
     */
    private $extensibleDataObjectConverter;

    /**
     * @param CustomerRepositoryInterface $customerRepository
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     */
    public function __construct(
        CustomerRepositoryInterface $customerRepository,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter
    ) {
        $this->customerRepository = $customerRepository;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
    }

    /**
     * Retrieve customer data array
     *
     * @param int $customerId
     * @return array
     */
    public function getData($customerId)
    {
        try {
            $customer = $this->customerRepository->getById($customerId);
            $customerData = $this->extensibleDataObjectConverter->toNestedArray(
                $customer,
                [],
                CustomerInterface::class
            );
        } catch (LocalizedException $exception) {
            $customerData = [];
        }
        return $customerData;
    }
}
