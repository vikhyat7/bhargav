define([
    'Magento_Ui/js/form/element/select',
    'underscore'
], function (Select, _) {
    'use strict';

    return Select.extend({
        /**
         * @inheritdoc
         */
        getInitialValue: function () {
            this.prepareIndexedOptions();
            return this._super();
        },

        /**
         * Prepare indexed options in case if parent initialization finished incorrectly (options are imported)
         */
        prepareIndexedOptions: function () {
            if (_.isEmpty(this.indexedOptions)) {
                this.setOptions(this.options());
            }
        }
    });
});