<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Source\Signup;

use Magento\Framework\Data\OptionSourceInterface;

/**
 * Class Status
 *
 * @package Aheadworks\Affiliate\Model\Source\Signup
 */
class Status implements OptionSourceInterface
{
    /**#@+
     * Signup status values
     */
    const PENDING = 1;
    const APPROVED = 2;
    const DECLINED = 3;
    /**#@-*/

    /**
     * {@inheritdoc}
     */
    public function toOptionArray()
    {
        return [
            [
                'value' => self::PENDING,
                'label' => __('Pending')
            ],
            [
                'value' => self::APPROVED,
                'label' => __('Approved')
            ],
            [
                'value' => self::DECLINED,
                'label' => __('Declined')
            ]
        ];
    }

    /**
     * Retrieve default status
     *
     * @return int
     * phpcs:disable Magento2.Functions.StaticFunction
     */
    public static function getDefaultStatus()
    {
        return self::PENDING;
    }

    /**
     * Retrieve statuses for active signup requests
     *
     * @return array
     * phpcs:disable Magento2.Functions.StaticFunction
     */
    public static function getActiveStatuses()
    {
        return [self::PENDING];
    }
}
