<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Campaign;

use Magento\Backend\App\Action\Context;
use Aheadworks\Affiliate\Api\CampaignRepositoryInterface;
use Aheadworks\Affiliate\Api\CampaignManagementInterface;
use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Aheadworks\Affiliate\Model\ResourceModel\Campaign\CollectionFactory;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Ui\Component\MassAction\Filter;
use Magento\Framework\Exception\CouldNotSaveException;
use Aheadworks\Affiliate\Model\Campaign\StatusResolver;

/**
 * Class AbstractMassChangeStatus
 *
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Campaign
 */
abstract class AbstractMassChangeStatus extends AbstractMassAction
{
    /**
     * @var StatusResolver
     */
    protected $statusResolver;

    /**
     * @param Context $context
     * @param CollectionFactory $collectionFactory
     * @param CampaignManagementInterface $campaignManagement
     * @param CampaignRepositoryInterface $campaignRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param Filter $filter
     * @param StatusResolver $statusResolver
     */
    public function __construct(
        Context $context,
        CollectionFactory $collectionFactory,
        CampaignManagementInterface $campaignManagement,
        CampaignRepositoryInterface $campaignRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        Filter $filter,
        StatusResolver $statusResolver
    ) {
        $this->statusResolver = $statusResolver;
        parent::__construct(
            $context,
            $collectionFactory,
            $campaignManagement,
            $campaignRepository,
            $searchCriteriaBuilder,
            $filter
        );
    }

    /**
     * Change status for campaigns
     *
     * @param CampaignInterface[] $campaigns
     */
    protected function massAction($campaigns)
    {
        $recordsCounter = 0;
        /** @var CampaignInterface $item */
        foreach ($campaigns as $item) {
            try {
                if ($this->statusResolver->isStatusAllowedForCampaign($this->getStatusToSet(), $item->getStatus())) {
                    $item->setStatus($this->getStatusToSet());
                    $this->campaignManagement->updateCampaign($item);
                    $recordsCounter++;
                }
            } catch (CouldNotSaveException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            }
        }
        if ($recordsCounter) {
            $this->messageManager->addSuccessMessage($this->getSuccessMessage($recordsCounter));
        } else {
            $this->messageManager->addSuccessMessage($this->getMessageForNoChanges());
        }
    }

    /**
     * Retrieve status id to set
     *
     * @return int
     */
    abstract protected function getStatusToSet();

    /**
     * Retrieve success message
     *
     * @param int $changedRecordsCounter
     * @return string
     */
    abstract protected function getSuccessMessage($changedRecordsCounter);

    /**
     * Retrieve error message
     *
     * @return string
     */
    abstract protected function getMessageForNoChanges();
}
