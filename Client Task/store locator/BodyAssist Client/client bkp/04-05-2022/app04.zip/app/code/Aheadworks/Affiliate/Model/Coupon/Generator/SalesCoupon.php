<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Coupon\Generator;

use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\SalesRule\Api\Data\CouponInterface as SalesCouponInterface;
use Magento\SalesRule\Api\Data\CouponInterfaceFactory as SalesCouponInterfaceFactory;
use Magento\SalesRule\Api\CouponRepositoryInterface as SalesCouponRepositoryInterface;

/**
 * Class SalesCoupon
 * @package Aheadworks\Affiliate\Model\Coupon\Generator
 */
class SalesCoupon
{
    /**
     * @var SalesCouponInterfaceFactory
     */
    private $salesCouponFactory;

    /**
     * @var SalesCouponRepositoryInterface
     */
    private $salesCouponRepository;

    /**
     * @param SalesCouponInterfaceFactory $salesCouponFactory
     * @param SalesCouponRepositoryInterface $salesCouponRepository
     */
    public function __construct(
        SalesCouponInterfaceFactory $salesCouponFactory,
        SalesCouponRepositoryInterface $salesCouponRepository
    ) {
        $this->salesCouponFactory = $salesCouponFactory;
        $this->salesCouponRepository = $salesCouponRepository;
    }

    /**
     * Generate coupon
     *
     * @param string $couponCode
     * @param int $salesRuleId
     * @return SalesCouponInterface
     * @throws InputException
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function generateCoupon($couponCode, $salesRuleId)
    {
        /** @var SalesCouponInterface $salesCoupon */
        $salesCoupon = $this->salesCouponFactory->create();
        $salesCoupon
            ->setRuleId($salesRuleId)
            ->setCode($couponCode)
            ->setCreatedAt(new \DateTime('now'))
            ->setType(SalesCouponInterface::TYPE_GENERATED);

        return $this->salesCouponRepository->save($salesCoupon);
    }
}
