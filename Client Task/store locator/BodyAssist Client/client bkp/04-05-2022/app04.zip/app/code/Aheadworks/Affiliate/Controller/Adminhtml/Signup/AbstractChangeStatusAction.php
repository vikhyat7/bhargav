<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Signup;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Aheadworks\Affiliate\Api\SignupRepositoryInterface;
use Aheadworks\Affiliate\Api\SignupManagementInterface;
use Aheadworks\Affiliate\Api\Data\SignupInterface;
use Magento\Framework\Exception\CouldNotSaveException;

/**
 * Class AbstractChangeStatusAction
 *
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Signup
 */
abstract class AbstractChangeStatusAction extends Action
{
    /**
     * {@inheritdoc}
     */
    const ADMIN_RESOURCE = 'Aheadworks_Affiliate::signups';

    /**
     * @var SignupRepositoryInterface
     */
    protected $signupRepository;

    /**
     * @var SignupManagementInterface
     */
    protected $signupService;

    /**
     * @param Context $context
     * @param SignupRepositoryInterface $signupRepository
     * @param SignupManagementInterface $signupService
     */
    public function __construct(
        Context $context,
        SignupRepositoryInterface $signupRepository,
        SignupManagementInterface $signupService
    ) {
        parent::__construct($context);
        $this->signupRepository = $signupRepository;
        $this->signupService = $signupService;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($signupId = $this->getRequest()->getParam(SignupInterface::ID, false)) {
            try {
                /** @var SignupInterface $signup */
                $signup = $this->signupRepository->getById($signupId);
                $this->updateStatus($signup->getSignupId());
                $this->messageManager->addSuccessMessage($this->getSuccessMessage());
                return $resultRedirect->setPath('*/*/');
            } catch (CouldNotSaveException $exception) {
                $this->messageManager->addErrorMessage($exception->getMessage());
            } catch (\Exception $exception) {
                $this->messageManager->addExceptionMessage(
                    $exception,
                    $this->getErrorMessage()
                );
            }
        }
        return $resultRedirect->setPath('*/*/');
    }

    /**
     * Retrieve error message
     *
     * @return string
     */
    private function getErrorMessage()
    {
        return __('Something went wrong while changing status.');
    }

    /**
     * Update status
     *
     * @param int $signupId
     * @return int
     * @throws CouldNotSaveException
     */
    abstract protected function updateStatus($signupId);

    /**
     * Retrieve success message
     *
     * @return string
     */
    abstract protected function getSuccessMessage();
}
