<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Observer\Magento\SalesRule;

use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Aheadworks\Affiliate\Model\CouponManager;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Class DeleteCoupons
 * @package Aheadworks\Affiliate\Observer\Magento\SalesRule
 */
class DeleteCoupons implements ObserverInterface
{
    /**
     * @var CouponManager
     */
    private $couponManager;

    /**
     * @param CouponManager $couponManager
     */
    public function __construct(
        CouponManager $couponManager
    ) {
        $this->couponManager = $couponManager;
    }

    /**
     * Delete coupons
     *
     * @param Observer $observer
     * @return $this
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function execute(Observer $observer)
    {
        /** @var CampaignInterface $campaign */
        $campaign = $observer->getEvent()->getEntity();
        if ($campaign instanceof CampaignInterface) {
            $this->couponManager->deleteCouponsByCampaign($campaign);
        }

        return $this;
    }
}
