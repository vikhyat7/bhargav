<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Source;

use Magento\Framework\Data\OptionSourceInterface;
use Aheadworks\Affiliate\Model\ResourceModel\AffiliateGroup\CollectionFactory as GroupCollectionFactory;
use Aheadworks\Affiliate\Model\ResourceModel\AffiliateGroup\Collection as GroupCollection;

/**
 * Class AffiliateGroup
 * @package Aheadworks\Affiliate\Model\Source
 */
class AffiliateGroup implements OptionSourceInterface
{
    const ALL_GROUPS_VALUE = 0;

    /**
     * @var GroupCollection
     */
    private $affiliateGroupCollection;

    /**
     * @var array
     */
    private $options;

    /**
     * @param GroupCollectionFactory $affiliateGroupCollectionFactory
     */
    public function __construct(GroupCollectionFactory $affiliateGroupCollectionFactory)
    {
        $this->affiliateGroupCollection = $affiliateGroupCollectionFactory->create();
    }

    /**
     * {@inheritdoc}
     */
    public function toOptionArray()
    {
        if (null === $this->options) {
            $this->options = $this->affiliateGroupCollection->toOptionArray();
        }

        return $this->options;
    }
}
