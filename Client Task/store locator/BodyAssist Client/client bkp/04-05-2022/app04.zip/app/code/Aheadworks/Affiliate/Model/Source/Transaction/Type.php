<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Source\Transaction;

use Magento\Framework\Data\OptionSourceInterface;

/**
 * Class Type
 * @package Aheadworks\Affiliate\Model\Source\Transaction
 */
class Type implements OptionSourceInterface
{
    /**#@+
     * Transaction type values
     */
    const COMMISSION = 'commission';
    const ADMIN_CHANGES = 'admin_changes';
    const PAYOUT = 'payout';
    /**#@-*/

    /**
     *  {@inheritdoc}
     */
    public function toOptionArray()
    {
        return [
            [
                'value' => self::COMMISSION,
                'label' => __('Commission')
            ],
            [
                'value' => self::ADMIN_CHANGES,
                'label' => __('Admin changes')
            ],
            [
                'value' => self::PAYOUT,
                'label' => __('Payout')
            ]
        ];
    }
}
