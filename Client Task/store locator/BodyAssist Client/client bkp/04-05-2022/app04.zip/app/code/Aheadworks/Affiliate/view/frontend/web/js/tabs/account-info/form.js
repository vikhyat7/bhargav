define([
    'jquery',
    'Aheadworks_Affiliate/js/ui/form/form'
], function ($, Component) {
    'use strict';

    return Component.extend({
        defaults: {
            imports: {
                isCustomerHasAccount: '${ $.globalConfigProvider }:data.is_customer_has_account'
            },
            template: 'Aheadworks_Affiliate/tabs/account-info/form'
        },

        /**
         * Check if need to render form
         *
         * @returns {boolean}
         */
        isNeedToRenderForm: function () {
            return (this.isCustomerHasAccount === true);
        }
    });
});
