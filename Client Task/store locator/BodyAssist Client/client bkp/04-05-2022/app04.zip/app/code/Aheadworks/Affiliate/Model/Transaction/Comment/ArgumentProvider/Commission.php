<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Transaction\Comment\ArgumentProvider;

use Aheadworks\Affiliate\Model\Transaction\Comment\ArgumentProviderInterface;
use Magento\Sales\Api\Data\OrderItemInterface;

/**
 * Class Commission
 * @package Aheadworks\Affiliate\Model\Transaction\Comment\ArgumentProvider
 */
class Commission implements ArgumentProviderInterface
{
    /**
     * {@inheritdoc}
     */
    public function get($entity)
    {
        $arguments = [];

        if ($entity instanceof OrderItemInterface) {
            $arguments = [
                OrderItemInterface::NAME => $entity->getName(),
                OrderItemInterface::SKU => $entity->getSku(),
                OrderItemInterface::ORDER_ID => '#' . $entity->getOrder()->getIncrementId()
            ];
        }

        return $arguments;
    }
}
