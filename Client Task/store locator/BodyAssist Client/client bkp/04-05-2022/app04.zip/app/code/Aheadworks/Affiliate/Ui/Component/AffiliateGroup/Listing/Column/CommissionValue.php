<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Ui\Component\AffiliateGroup\Listing\Column;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;
use Aheadworks\Affiliate\Model\ValueFormatter\GroupCommission as CommissionValueFormatter;
use Aheadworks\Affiliate\Api\Data\AffiliateGroupInterface;
use Magento\Framework\Stdlib\ArrayManager;

/**
 * Class CommissionValue
 * @package Aheadworks\Affiliate\Ui\Component\AffiliateGroup\Listing\Column
 */
class CommissionValue extends Column
{
    const DEFAULT_WEBSITE_ID = 1;

    /**
     * @var CommissionValueFormatter
     */
    private $commissionValueFormatter;

    /**
     * @var ArrayManager
     */
    private $arrayManager;

    /**
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param CommissionValueFormatter $commissionValueFormatter
     * @param ArrayManager $arrayManager
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        CommissionValueFormatter $commissionValueFormatter,
        ArrayManager $arrayManager,
        array $components = [],
        array $data = []
    ) {
        parent::__construct($context, $uiComponentFactory, $components, $data);
        $this->commissionValueFormatter = $commissionValueFormatter;
        $this->arrayManager = $arrayManager;
    }

    /**
     * {@inheritdoc}
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$item) {
                $item[$this->getData('name')] = $this->commissionValueFormatter->getFormattedCommissionValue(
                    $this->arrayManager->get(AffiliateGroupInterface::COMMISSION_VALUE, $item),
                    $this->arrayManager->get(AffiliateGroupInterface::COMMISSION_TYPE, $item),
                    self::DEFAULT_WEBSITE_ID
                );
            }
        }
        return $dataSource;
    }
}
