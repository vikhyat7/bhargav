<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Coupon\SalesRule;

use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Aheadworks\Affiliate\Model\Source\Campaign\CouponDiscountType;
use Aheadworks\Affiliate\Model\Source\Campaign\CouponUsageMode;
use Aheadworks\Affiliate\Model\Source\Campaign\Status;
use Magento\Customer\Model\ResourceModel\Group\CollectionFactory as GroupCollectionFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\SalesRule\Api\Data\RuleInterface as SalesRuleInterface;
use Magento\SalesRule\Model\Converter\ToDataModel as SalesConditionConverter;
use Aheadworks\Affiliate\Model\Campaign\Converter\Condition as ConditionConverter;
use Magento\SalesRule\Model\Data\Condition;
use Magento\Framework\Serialize\Serializer\Json as JsonSerializer;

/**
 * Class DataPreparer
 * @package Aheadworks\Affiliate\Model\Coupon\SalesRule
 */
class DataPreparer
{
    /**
     * @var GroupCollectionFactory
     */
    private $groupCollectionFactory;

    /**
     * @var SalesConditionConverter
     */
    private $salesConditionConverter;

    /**
     * @var ConditionConverter
     */
    private $conditionsConverter;

    /**
     * @var JsonSerializer
     */
    private $serializer;

    /**
     * @param GroupCollectionFactory $groupCollectionFactory
     * @param SalesConditionConverter $salesConditionConverter
     * @param ConditionConverter $conditionConverter
     * @param JsonSerializer $jsonSerializer
     */
    public function __construct(
        GroupCollectionFactory $groupCollectionFactory,
        SalesConditionConverter $salesConditionConverter,
        ConditionConverter $conditionConverter,
        JsonSerializer $jsonSerializer
    ) {
        $this->groupCollectionFactory = $groupCollectionFactory;
        $this->salesConditionConverter = $salesConditionConverter;
        $this->conditionsConverter = $conditionConverter;
        $this->serializer = $jsonSerializer;
    }

    /**
     * Get prepared rule description
     *
     * @param CampaignInterface $campaign
     * @return string
     */
    public function getPreparedDescription($campaign)
    {
        $beginningText = __(
            'This rule has been auto-created by Affiliate extension (%1). ' .
            'Do not modify it\'s conditions and actions.',
            'Campaign # '. $campaign->getCampaignId() . ', <' . $campaign->getName() . '>'
        );
        $description = $beginningText . '   ' . $campaign->getDescription();

        return $description;
    }

    /**
     * Check if sales rule is active
     *
     * @param CampaignInterface $campaign
     * @return bool
     */
    public function isSalesRuleActive($campaign)
    {
        return $campaign->getStatus() == Status::ACTIVE
            && $campaign->getCouponUsageMode() == CouponUsageMode::SPECIFIC_COUPON;
    }

    /**
     * Retrieve customer group ids
     *
     * @return array
     */
    public function getCustomerGroupIds()
    {
        $collection = $this->groupCollectionFactory->create();

        return $collection->getColumnValues('customer_group_id');
    }

    /**
     * Get website ids
     *
     * @param CampaignInterface $campaign
     * @return array
     */
    public function getWebsiteIds($campaign)
    {
        return [$campaign->getWebsiteId()];
    }

    /**
     * Get coupon discount action
     *
     * @param CampaignInterface $campaign
     * @return string
     * @throws LocalizedException
     */
    public function getCouponDiscountAction($campaign)
    {
        switch ($campaign->getCouponDiscountType()) {
            case CouponDiscountType::PERCENT:
                $discountAction = SalesRuleInterface::DISCOUNT_ACTION_BY_PERCENT;
                break;
            case CouponDiscountType::FIXED:
                $discountAction = SalesRuleInterface::DISCOUNT_ACTION_FIXED_AMOUNT;
                break;
            default:
                throw new LocalizedException(__('Unsupported coupon discount type.'));
        }

        return $discountAction;
    }

    /**
     * Retrieve coupon action condition
     *
     * @param CampaignInterface $campaign
     * @return Condition
     */
    public function getCouponActionCondition($campaign)
    {
        $cartConditions = $campaign->getCartCondition();
        $conditions = is_string($cartConditions)
            ? $conditions = $this->serializer->unserialize($cartConditions)
            : $conditions = $this->conditionsConverter->dataModelToArray($cartConditions);

        return $this->salesConditionConverter->arrayToConditionDataModel($conditions);
    }
}
