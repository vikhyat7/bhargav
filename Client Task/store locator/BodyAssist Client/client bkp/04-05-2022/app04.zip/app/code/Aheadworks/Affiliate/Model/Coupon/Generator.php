<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Coupon;

use Aheadworks\Affiliate\Api\CouponRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Aheadworks\Affiliate\Api\Data\CouponInterface;
use Aheadworks\Affiliate\Api\Data\CouponInterfaceFactory;
use Aheadworks\Affiliate\Model\Coupon\Generator\SalesCoupon as SalesCouponGenerator;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Class Generator
 * @package Aheadworks\Affiliate\Model\Coupon
 */
class Generator
{
    /**
     * Delimiter between prefix and base coupon code
     */
    const DELIMITER = '-';

    /**
     * @var SalesCouponGenerator
     */
    private $salesCouponGenerator;

    /**
     * @var CouponRepositoryInterface
     */
    private $couponRepository;

    /**
     * @var CouponInterfaceFactory;
     */
    private $couponDataFactory;

    /**
     * @var GenerationValidator
     */
    private $generationValidator;

    /**
     * @var SalesRuleManager
     */
    private $salesRuleManager;

    /**
     * @param SalesCouponGenerator $salesCouponGenerator
     * @param CouponRepositoryInterface $couponRepository
     * @param CouponInterfaceFactory $couponDataFactory
     * @param GenerationValidator $generationValidator
     * @param SalesRuleManager $salesRuleManager
     */
    public function __construct(
        SalesCouponGenerator $salesCouponGenerator,
        CouponRepositoryInterface $couponRepository,
        CouponInterfaceFactory $couponDataFactory,
        GenerationValidator $generationValidator,
        SalesRuleManager $salesRuleManager
    ) {
        $this->salesCouponGenerator = $salesCouponGenerator;
        $this->couponRepository = $couponRepository;
        $this->couponDataFactory = $couponDataFactory;
        $this->generationValidator = $generationValidator;
        $this->salesRuleManager = $salesRuleManager;
    }

    /**
     * Generate coupon
     *
     * @param AccountInterface $account
     * @param CampaignInterface $campaign
     * @param int|null $salesRuleId
     * @return CouponInterface
     * @throws InputException
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function generateCoupon($account, $campaign, $salesRuleId)
    {
        $isFirstCoupon = false;
        $isCouponCodeSeparatorAllowed = (bool)$campaign->getIsCouponCodeSeparatorAllowed();
        $this->generationValidator->validate($account, $campaign);
        $couponCode = $this->generateCode(
            $account->getUniqueCouponPrefix(),
            $campaign->getCouponCodeTemplate(),
            $isCouponCodeSeparatorAllowed
        );
        if (!$salesRuleId) {
            $salesRuleId = $this->salesRuleManager->saveSalesRule($campaign)->getRuleId();
            $isFirstCoupon = true;
        }
        try {
            $salesCoupon = $this->salesCouponGenerator->generateCoupon($couponCode, $salesRuleId);
            /** @var CouponInterface $coupon */
            $coupon = $this->couponDataFactory->create();
            $coupon
                ->setCouponId($salesCoupon->getCouponId())
                ->setCouponCode($salesCoupon->getCode())
                ->setSalesRuleId($salesRuleId)
                ->setCampaignId($campaign->getCampaignId())
                ->setAffiliateId($account->getAccountId());

            return $this->couponRepository->save($coupon);
        } catch (\Exception $e) {
            if ($isFirstCoupon) {
                $this->salesRuleManager->deleteSalesRule($salesRuleId);
            }
            throw new LocalizedException(__($e->getMessage()));
        }
    }

    /**
     * Generate coupon code
     *
     * @param string $couponPrefix
     * @param string $couponBaseCode
     * @param boolean $isCouponSeparatorAllowed
     * @return string
     */
    private function generateCode($couponPrefix, $couponBaseCode, $isCouponSeparatorAllowed = true)
    {
        return $isCouponSeparatorAllowed ? $couponPrefix . self::DELIMITER . $couponBaseCode : $couponPrefix . $couponBaseCode;
    }
}
