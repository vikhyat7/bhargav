define([
    'Magento_Ui/js/form/element/abstract'
], function (Input) {
    'use strict';

    return Input.extend({

        /**
         * {@inheritdoc}
         */
        getInitialValue: function () {
            var value = this._super();

            return Number(value).toFixed(2);
        }
    });
});
