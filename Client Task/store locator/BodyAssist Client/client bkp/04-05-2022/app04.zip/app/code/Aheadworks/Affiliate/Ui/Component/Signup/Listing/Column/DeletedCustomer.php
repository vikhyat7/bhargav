<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Ui\Component\Signup\Listing\Column;

use Magento\Ui\Component\Listing\Columns\Column;
use Aheadworks\Affiliate\Api\Data\AccountInterface;

/**
 * Class DeletedCustomer
 * @package Aheadworks\Affiliate\Ui\Component\Signup\Listing\Column
 */
class DeletedCustomer extends Column
{
    /**
     * {@inheritdoc}
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$item) {
                if (!isset($item[AccountInterface::CUSTOMER_ID])) {
                    $item[$this->getData('name')] = $this->getPlaceholderName();
                }
            }
        }
        return $dataSource;
    }

    /**
     * Get placeholder customer name
     *
     * @return string
     */
    private function getPlaceholderName()
    {
        return __('Deleted Customer');
    }
}
