<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Transaction\Comment;

use Magento\Sales\Api\Data\OrderItemInterface;
use Magento\Framework\Phrase\Renderer\Placeholder as PlaceholderRenderer;
use Aheadworks\Affiliate\Api\Data\PayoutInterface;

/**
 * Class Renderer
 * @package Aheadworks\Affiliate\Model\Transaction\Comment
 */
class Renderer
{
    /**
     * @var PlaceholderRenderer
     */
    private $placeholderRenderer;

    /**
     * @var array
     */
    private $placeholders = [];

    /**
     * @var array
     */
    private $argumentProviders = [];

    /**
     * @param PlaceholderRenderer $placeholderRenderer
     * @param array $placeholders
     * @param array $argumentProviders
     */
    public function __construct(
        PlaceholderRenderer $placeholderRenderer,
        array $placeholders = [],
        array $argumentProviders = []
    ) {
        $this->placeholderRenderer = $placeholderRenderer;
        $this->placeholders = $placeholders;
        $this->argumentProviders = $argumentProviders;
    }

    /**
     * Render comment
     *
     * @param string $type
     * @param PayoutInterface|OrderItemInterface|null $entity
     * @return string
     */
    public function renderComment($type, $entity)
    {
        if (isset($this->placeholders[$type])) {
            return $this->placeholderRenderer->render(
                [$this->placeholders[$type]],
                $this->getArguments($type, $entity)
            );
        }

        return '';
    }

    /**
     * Get arguments
     *
     * @param string $type
     * @param PayoutInterface|OrderItemInterface|null $entity
     * @return array
     */
    private function getArguments($type, $entity)
    {
        $arguments = [];

        if (isset($this->argumentProviders[$type])
            && $this->argumentProviders[$type] instanceof ArgumentProviderInterface
        ) {
            /** @var ArgumentProviderInterface $argumentsProvider */
            $argumentsProvider = $this->argumentProviders[$type];
            $arguments = $argumentsProvider->get($entity);
        }

        return $arguments;
    }
}
