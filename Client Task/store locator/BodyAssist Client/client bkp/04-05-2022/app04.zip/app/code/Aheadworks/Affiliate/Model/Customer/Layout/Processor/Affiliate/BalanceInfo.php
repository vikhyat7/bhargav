<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Customer\Layout\Processor\Affiliate;

use Aheadworks\Affiliate\Api\Data\BoundCustomerInterface;
use Aheadworks\Affiliate\Model\Layout\LayoutProcessorInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Api\SimpleDataObjectConverter;
use Magento\Framework\Stdlib\ArrayManager;
use Aheadworks\Affiliate\Api\AccountRepositoryInterface;
use Aheadworks\Affiliate\Api\AccountBalanceManagementInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Aheadworks\Affiliate\Api\Data\Account\BalanceInterface;
use Aheadworks\Affiliate\Model\ValueFormatter\Price as PriceFormatter;
use Aheadworks\Affiliate\Api\BoundCustomerRepositoryInterface;

/**
 * Class BalanceInfo
 * @package Aheadworks\Affiliate\Model\Customer\Layout\Processor\Affiliate
 */
class BalanceInfo implements LayoutProcessorInterface
{
    /**
     * @var ArrayManager
     */
    private $arrayManager;

    /**
     * @var AccountRepositoryInterface
     */
    private $accountRepository;

    /**
     * @var AccountBalanceManagementInterface
     */
    private $accountBalanceManagement;

    /**
     * @var PriceFormatter
     */
    private $priceFormatter;

    /**
     * @var BoundCustomerRepositoryInterface
     */
    private $boundCustomerRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    private $searchCriteriaBuilder;

    /**
     * @var array
     */
    private $balanceInfoFields = [];

    /**
     * @param ArrayManager $arrayManager
     * @param AccountRepositoryInterface $accountRepository
     * @param AccountBalanceManagementInterface $accountBalanceManagement
     * @param PriceFormatter $priceFormatter
     * @param BoundCustomerRepositoryInterface $boundCustomerRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param array $balanceInfoFields
     */
    public function __construct(
        ArrayManager $arrayManager,
        AccountRepositoryInterface $accountRepository,
        AccountBalanceManagementInterface $accountBalanceManagement,
        PriceFormatter $priceFormatter,
        BoundCustomerRepositoryInterface $boundCustomerRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        array $balanceInfoFields = []
    ) {
        $this->arrayManager = $arrayManager;
        $this->accountRepository = $accountRepository;
        $this->accountBalanceManagement = $accountBalanceManagement;
        $this->priceFormatter = $priceFormatter;
        $this->boundCustomerRepository = $boundCustomerRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->balanceInfoFields = $balanceInfoFields;

    }

    /**
     * {@inheritdoc}
     */
    public function process($jsLayout, $customerId, $websiteId)
    {
        $balanceInfoProviderPath = 'components/awAffBalanceInfoProvider';
        $jsLayout = $this->arrayManager->merge(
            $balanceInfoProviderPath,
            $jsLayout,
            [
                'data' => $this->getBalanceInfo($customerId, $websiteId)
            ]
        );

        return $jsLayout;
    }

    /**
     * Retrieve balance info
     *
     * @param int|null $customerId
     * @param int|null $websiteId
     * @return array
     */
    private function getBalanceInfo($customerId, $websiteId)
    {
        $balanceInfo = [];

        try {
            /** @var AccountInterface $account */
            $account = $this->accountRepository->getByCustomerId($customerId, $websiteId);
            $balance = $this->accountBalanceManagement->getBalance($account->getAccountId());
            foreach ($this->balanceInfoFields as $balanceInfoField) {
                $balanceInfo[] = [
                    'value' => $this->priceFormatter->getFormattedValue(
                        $this->getBalanceFieldValue($balance, $balanceInfoField['key']),
                        $websiteId
                    ),
                    'label' => __($balanceInfoField['label'])
                ];
            }
            $balanceInfo[] = [
                'value' => $this->getBoundCustomersQty($account->getAccountId()),
                'label' => __('Bound Customers')
            ];
        } catch (\Exception $exception) {
            $balanceInfo = [];
        }

        return $balanceInfo;
    }

    /**
     * Retrieve balance field value
     *
     * @param BalanceInterface $balance
     * @param string $fieldKey
     * @return float
     */
    private function getBalanceFieldValue($balance, $fieldKey)
    {
        $method = 'get' . SimpleDataObjectConverter::snakeCaseToUpperCamelCase($fieldKey);

        return $balance->{$method}();
    }

    /**
     * Retrieve bound customers qty
     *
     * @param int $accountId
     * @return int
     */
    private function getBoundCustomersQty($accountId)
    {
        if ($accountId) {
            $searchCriteria = $this->searchCriteriaBuilder
                ->addFilter(BoundCustomerInterface::ACCOUNT_ID, $accountId)
                ->create();

            return count($this->boundCustomerRepository->getList($searchCriteria)->getItems());
        }

        return 0;
    }
}
