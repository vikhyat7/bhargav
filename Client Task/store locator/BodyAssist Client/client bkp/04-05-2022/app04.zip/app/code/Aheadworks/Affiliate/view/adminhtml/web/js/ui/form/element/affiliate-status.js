define([
    'underscore',
    'Magento_Ui/js/form/element/select'
], function (_, Select) {
    'use strict';

    return Select.extend({

        defaults: {
            triggerStatus: ''
        },

        /**
         * {@inheritDoc}
         */
        initialize: function () {
            this._super();

            if (!_.isEmpty(this.triggerStatus)) {
                this.changeOptions();
            }

            return this;
        },

        /**
         * Change status options
         */
        changeOptions: function () {
            var result = [];

            if (this.triggerStatus === this.value()) {
                result = this.removeOtherOptions();
            } else {
                result = this.removeFromOptions();
            }

            this.setOptions(result);
        },

        /**
         * Remove trigger status from options
         *
         * @return {*|void}
         */
        removeFromOptions: function () {
            var me = this;

            return _.filter(this.initialOptions, function (option) {
                return option.value !== me.triggerStatus ;
            });
        },

        /**
         * Remove other options except trigger status
         *
         * @return {*|void}
         */
        removeOtherOptions: function () {
            var me = this;

            return _.filter(this.initialOptions, function (option) {
                return option.value === me.triggerStatus ;
            });
        }
    });
});
