<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model;

use Aheadworks\Affiliate\Api\PayoutRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\PayoutInterface;
use Aheadworks\Affiliate\Api\Data\PayoutInterfaceFactory;
use Aheadworks\Affiliate\Api\Data\PayoutSearchResultsInterface;
use Aheadworks\Affiliate\Api\Data\PayoutSearchResultsInterfaceFactory;
use Aheadworks\Affiliate\Model\Payout as PayoutModel;
use Aheadworks\Affiliate\Model\ResourceModel\Payout as PayoutResourceModel;
use Aheadworks\Affiliate\Model\ResourceModel\Payout\Collection as PayoutCollection;
use Aheadworks\Affiliate\Model\ResourceModel\Payout\CollectionFactory as PayoutCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;

/**
 * Class PayoutRepository
 *
 * @package Aheadworks\Affiliate\Model
 */
class PayoutRepository implements PayoutRepositoryInterface
{
    /**
     * @var PayoutResourceModel
     */
    private $resource;

    /**
     * @var PayoutInterfaceFactory
     */
    private $payoutInterfaceFactory;

    /**
     * @var PayoutCollectionFactory
     */
    private $payoutCollectionFactory;

    /**
     * @var PayoutSearchResultsInterfaceFactory
     */
    private $searchResultsFactory;

    /**
     * @var JoinProcessorInterface
     */
    private $extensionAttributesJoinProcessor;

    /**
     * @var CollectionProcessorInterface
     */
    private $collectionProcessor;

    /**
     * @var DataObjectHelper
     */
    private $dataObjectHelper;

    /**
     * @var DataObjectProcessor
     */
    private $dataObjectProcessor;

    /**
     * @var array
     */
    private $payouts = [];

    /**
     * @param PayoutResourceModel $resource
     * @param PayoutInterfaceFactory $payoutInterfaceFactory
     * @param PayoutCollectionFactory $payoutCollectionFactory
     * @param PayoutSearchResultsInterfaceFactory $searchResultsFactory
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param CollectionProcessorInterface $collectionProcessor
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     */
    public function __construct(
        PayoutResourceModel $resource,
        PayoutInterfaceFactory $payoutInterfaceFactory,
        PayoutCollectionFactory $payoutCollectionFactory,
        PayoutSearchResultsInterfaceFactory $searchResultsFactory,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        CollectionProcessorInterface $collectionProcessor,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor
    ) {
        $this->resource = $resource;
        $this->payoutInterfaceFactory = $payoutInterfaceFactory;
        $this->payoutCollectionFactory = $payoutCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->collectionProcessor = $collectionProcessor;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataObjectProcessor = $dataObjectProcessor;
    }

    /**
     * {@inheritdoc}
     */
    public function save(PayoutInterface $payout)
    {
        try {
            $this->resource->save($payout);
            $this->payouts[$payout->getPayoutId()] = $payout;
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__($exception->getMessage()));
        }

        return $payout;
    }

    /**
     * {@inheritdoc}
     */
    public function getById($payoutId)
    {
        if (!isset($this->payouts[$payoutId])) {
            /** @var PayoutInterface $payout */
            $payout = $this->payoutInterfaceFactory->create();
            $this->resource->load($payout, $payoutId);
            if (!$payout->getPayoutId()) {
                throw NoSuchEntityException::singleField(PayoutInterface::ID, $payoutId);
            }
            $this->payouts[$payoutId] = $payout;
        }
        return $this->payouts[$payoutId];
    }

    /**
     * {@inheritdoc}
     */
    public function getList(SearchCriteriaInterface $searchCriteria)
    {
        /** @var PayoutCollection $collection */
        $collection = $this->payoutCollectionFactory->create();

        $this->extensionAttributesJoinProcessor->process($collection, PayoutInterface::class);
        $this->collectionProcessor->process($searchCriteria, $collection);

        /** @var PayoutSearchResultsInterface $searchResults */
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($searchCriteria);
        $searchResults->setTotalCount($collection->getSize());

        $objects = [];
        /** @var PayoutModel $item */
        foreach ($collection->getItems() as $item) {
            $objects[] = $this->getDataObject($item);
        }
        $searchResults->setItems($objects);

        return $searchResults;
    }

    /**
     * Retrieves data object using model
     *
     * @param PayoutModel $model
     * @return PayoutInterface
     */
    private function getDataObject($model)
    {
        /** @var PayoutInterface $object */
        $object = $this->payoutInterfaceFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $object,
            $this->dataObjectProcessor->buildOutputDataArray($model, PayoutInterface::class),
            PayoutInterface::class
        );
        return $object;
    }
}
