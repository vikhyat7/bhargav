<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Group;

use Aheadworks\Affiliate\Api\Data\AffiliateGroupInterface;
use Aheadworks\Affiliate\Api\AffiliateGroupRepositoryInterface;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\View\Result\PageFactory;

/**
 * Class Edit
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Group
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Edit extends Action
{
    /**
     * {@inheritdoc}
     */
    const ADMIN_RESOURCE = 'Aheadworks_Affiliate::affiliate_groups';

    /**
     * @var PageFactory
     */
    private $resultPageFactory;

    /**
     * @var AffiliateGroupRepositoryInterface
     */
    private $affiliateGroupRepository;

    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     * @param AffiliateGroupRepositoryInterface $affiliateGroupRepository
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        AffiliateGroupRepositoryInterface $affiliateGroupRepository
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->affiliateGroupRepository = $affiliateGroupRepository;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        $affiliateGroupId = (int)$this->getRequest()->getParam(AffiliateGroupInterface::ID);
        if ($affiliateGroupId) {
            try {
                /** @var AffiliateGroupInterface $affiliateGroup */
                $affiliateGroup = $this->affiliateGroupRepository->getById($affiliateGroupId);
            } catch (NoSuchEntityException $exception) {
                $this->messageManager->addErrorMessage(
                    __('This group no longer exists.')
                );
                $resultRedirect = $this->resultRedirectFactory->create();
                $resultRedirect->setPath('*/*/');
                return $resultRedirect;
            }
        }

        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage
            ->setActiveMenu('Aheadworks_Affiliate::affiliate_groups')
            ->getConfig()->getTitle()->prepend(
                $affiliateGroupId ? __('Edit Affiliate Group') : __('New Affiliate Group')
            );
        return $resultPage;
    }
}
