<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model;

use Aheadworks\Affiliate\Api\Data\PromoDataInterface;
use Magento\Framework\DataObject;

/**
 * Class PromoData
 *
 * @package Aheadworks\Affiliate\Model
 */
class PromoData extends DataObject implements PromoDataInterface
{
    /**
     * {@inheritdoc}
     */
    public function getAccountId()
    {
        return $this->getData(self::ACCOUNT_ID);
    }

    /**
     * {@inheritdoc}
     */
    public function setAccountId($accountId)
    {
        return $this->setData(self::ACCOUNT_ID, $accountId);
    }

    /**
     * {@inheritdoc}
     */
    public function getCampaignId()
    {
        return $this->getData(self::CAMPAIGN_ID);
    }

    /**
     * {@inheritdoc}
     */
    public function setCampaignId($campaignId)
    {
        return $this->setData(self::CAMPAIGN_ID, $campaignId);
    }

    /**
     * {@inheritdoc}
     */
    public function getTrafficSource()
    {
        return $this->getData(self::TRAFFIC_SOURCE);
    }

    /**
     * {@inheritdoc}
     */
    public function setTrafficSource($trafficSource)
    {
        return $this->setData(self::TRAFFIC_SOURCE, $trafficSource);
    }
}
