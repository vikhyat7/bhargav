<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Campaign;

use Magento\Backend\App\Action;
use Aheadworks\Affiliate\Api\CampaignManagementInterface;
use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Backend\App\Action\Context;

/**
 * Class Delete
 *
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Campaign
 */
class Delete extends Action
{
    /**
     * {@inheritdoc}
     */
    const ADMIN_RESOURCE = 'Aheadworks_Affiliate::campaigns';

    /**
     * @var CampaignManagementInterface
     */
    private $campaignService;

    /**
     * @param Context $context
     * @param CampaignManagementInterface $campaignService
     */
    public function __construct(
        Context $context,
        CampaignManagementInterface $campaignService
    ) {
        parent::__construct($context);
        $this->campaignService = $campaignService;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($campaignId = $this->getRequest()->getParam(CampaignInterface::ID, false)) {
            try {
                $this->campaignService->deleteCampaignById($campaignId);
                $this->messageManager->addSuccessMessage(__('The campaign was successfully deleted.'));
                return $resultRedirect->setPath('*/*/');
            } catch (CouldNotDeleteException $exception) {
                $this->messageManager->addErrorMessage($exception->getMessage());
            } catch (\Exception $exception) {
                $this->messageManager->addExceptionMessage(
                    $exception,
                    __('Something went wrong while deleting the campaign.')
                );
            }
            return $resultRedirect->setPath('*/*/edit', [CampaignInterface::ID => $campaignId]);
        }
        return $resultRedirect->setPath('*/*/');
    }
}
