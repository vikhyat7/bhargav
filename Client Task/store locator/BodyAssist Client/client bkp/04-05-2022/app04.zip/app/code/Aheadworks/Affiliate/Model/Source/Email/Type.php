<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Source\Email;

use Magento\Framework\Data\OptionSourceInterface;

/**
 * Class Type
 * @package Aheadworks\Affiliate\Model\Source\Email
 */
class Type implements OptionSourceInterface
{
    /**#@+
     * Email type values
     */
    const ADMIN_NEW_SIGNUP = 'new_signup';
    const ADMIN_NEW_MANUAL_PAYOUT = 'new_manual_payout';
    const ADMIN_PAYOUT_REMINDER = 'payout_reminder';
    const AFFILIATE_SIGNUP_APPROVED = 'signup_approved';
    const AFFILIATE_SIGNUP_DECLINED = 'signup_declined';
    const AFFILIATE_PAYOUT_COMPLETE = 'payout_complete';
    const AFFILIATE_PAYOUT_CANCELED = 'payout_canceled';
    /**#@-*/

    /**
     * @var array
     */
    protected $options;

    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        if ($this->options !== null) {
            return $this->options;
        }

        $this->options = [
            [
                'value' => self::ADMIN_NEW_SIGNUP,
                'label' => __('New Signup Request')
            ],
            [
                'value' => self::ADMIN_NEW_MANUAL_PAYOUT,
                'label' => __('New Payout Request')
            ],
            [
                'value' => self::ADMIN_PAYOUT_REMINDER,
                'label' => __('Payout Reminder')
            ],
            [
                'value' => self::AFFILIATE_PAYOUT_COMPLETE,
                'label' => __('Payout Complete')
            ],
            [
                'value' => self::AFFILIATE_PAYOUT_CANCELED,
                'label' => __('Payout Canceled')
            ],
            [
                'value' => self::AFFILIATE_SIGNUP_APPROVED,
                'label' => __('Affiliate Confirmation')
            ],
            [
                'value' => self::AFFILIATE_SIGNUP_DECLINED,
                'label' => __('Affiliate Rejection')
            ]
        ];

        return $this->options;
    }
}
