<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Setup\Updater;

use Aheadworks\Affiliate\Model\ResourceModel\Account as AffiliateAccountResource;
use Aheadworks\Affiliate\Model\ResourceModel\Campaign as CampaignResource;
use Magento\Framework\DB\Ddl\Table as DataDefinition;
use Magento\Framework\Setup\SchemaSetupInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Aheadworks\Affiliate\Model\ResourceModel\Account as AccountResourceModel;
use Aheadworks\Affiliate\Model\ResourceModel\BoundCustomer as BoundCustomerResource;
use Aheadworks\Affiliate\Api\Data\BoundCustomerInterface;

/**
 * Class Schema
 *
 * @package Aheadworks\Affiliate\Setup\Updater
 */
class Schema
{
    /**
     * Update to 1.1.0 version
     *
     * @param SchemaSetupInterface $setup
     * @return $this
     * @throws \Zend_Db_Exception
     */
    public function update110(SchemaSetupInterface $setup)
    {
        $this
            ->setAffiliateAccountReferralWebsiteColumnNullable($setup)
        ;

        return $this;
    }

    /**
     * Update to 1.2.0 version
     *
     * @param SchemaSetupInterface $setup
     * @return $this
     * @throws \Zend_Db_Exception
     * @throws \Exception
     */
    public function update120(SchemaSetupInterface $setup)
    {
        $this
            ->addIsCouponCodeSeparatorAllowedColumn($setup)
            ->createBoundCustomerTable($setup);

        return $this;
    }

    /**
     * Make 'referral_website' column nullable for affiliate account table
     *
     * @param SchemaSetupInterface $installer
     * @return $this
     */
    private function setAffiliateAccountReferralWebsiteColumnNullable(SchemaSetupInterface $installer)
    {
        $tableName = $installer->getTable(AccountResourceModel::MAIN_TABLE_NAME);
        $connection = $installer->getConnection();

        if ($connection->tableColumnExists($tableName, AccountInterface::REFERRAL_WEBSITE)) {
            $connection->modifyColumn(
                $tableName,
                AccountInterface::REFERRAL_WEBSITE,
                [
                    'type' => DataDefinition::TYPE_TEXT,
                    'length' => 255,
                    'nullable' => true,
                    'comment' => 'Referral website'
                ]
            );
        }

        return $this;
    }

    /**
     * Add is coupon code separator allowed column
     *
     * @param SchemaSetupInterface $setup
     * @return $this
     */
    private function addIsCouponCodeSeparatorAllowedColumn($setup)
    {
        $setup->getConnection()->addColumn(
            $setup->getTable(CampaignResource::COUPON_USAGE_TABLE_NAME),
            'is_coupon_code_separator_allowed',
            [
                'type' => DataDefinition::TYPE_SMALLINT,
                'nullable' => false,
                'unsigned' => true,
                'after' => 'coupon_discount_amount',
                'comment' => 'Is coupon code separator allowed'
            ]
        );

        return $this;
    }

    /**
     * Create bound customers table
     *
     * @param SchemaSetupInterface $setup
     * @return $this
     * @throws \Exception
     */
    private function createBoundCustomerTable(SchemaSetupInterface $setup)
    {
        $table = $setup
            ->getConnection()
            ->newTable(
                $setup->getTable(BoundCustomerResource::MAIN_TABLE_NAME)
            )->addColumn(
                BoundCustomerInterface::BOUND_ID,
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'identity' => true,
                    'unsigned' => true,
                    'nullable' => false,
                    'primary' => true
                ],
                'Record ID'
            )->addColumn(
                BoundCustomerInterface::CUSTOMER_EMAIL,
                DataDefinition::TYPE_TEXT,
                255,
                [
                    'nullable' => false
                ],
                'Traffic source'
            )->addColumn(
                BoundCustomerInterface::ACCOUNT_ID,
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false
                ],
                'Account ID'
            )->addColumn(
                'customer_id',
                DataDefinition::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => true
                ],
                'Customer ID'
            )->addForeignKey(
                $setup->getFkName(
                    BoundCustomerResource::MAIN_TABLE_NAME,
                    'customer_id',
                    $setup->getTable('customer_entity'),
                    'entity_id'
                ),
                'customer_id',
                $setup->getTable('customer_entity'),
                'entity_id',
                DataDefinition::ACTION_SET_NULL
            )->addForeignKey(
                $setup->getFkName(
                    BoundCustomerResource::MAIN_TABLE_NAME,
                    'account_id',
                    AffiliateAccountResource::MAIN_TABLE_NAME,
                    AffiliateAccountResource::MAIN_TABLE_ID_FIELD_NAME
                ),
                'account_id',
                $setup->getTable(AffiliateAccountResource::MAIN_TABLE_NAME),
                AffiliateAccountResource::MAIN_TABLE_ID_FIELD_NAME,
                DataDefinition::ACTION_CASCADE
            )->setComment('AW Bound Customers Table');
        $setup->getConnection()->createTable($table);

        return $this;
    }
}
