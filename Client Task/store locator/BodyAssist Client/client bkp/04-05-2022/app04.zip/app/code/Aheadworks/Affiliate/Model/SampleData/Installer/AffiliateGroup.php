<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\SampleData\Installer;

use Aheadworks\Affiliate\Api\AffiliateGroupRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\AffiliateGroupInterface;
use Aheadworks\Affiliate\Api\Data\AffiliateGroupInterfaceFactory;
use Aheadworks\Affiliate\Model\AffiliateGroup as AffiliateGroupModel;
use Aheadworks\Affiliate\Model\SampleData\Reader;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Setup\SampleData\InstallerInterface as SampleDataInstallerInterface;

/**
 * Class AffiliateGroup
 * @package Aheadworks\Affiliate\Model\SampleData\Installer
 */
class AffiliateGroup implements SampleDataInstallerInterface
{
    /**
     * @var Reader
     */
    private $reader;

    /**
     * @var AffiliateGroupInterfaceFactory
     */
    private $affiliateGroupFactory;

    /**
     * @var AffiliateGroupRepositoryInterface
     */
    private $affiliateGroupRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    private $searchCriteriaBuilder;

    /**
     * @var string
     */
    private $fileName = 'Aheadworks_Affiliate::fixtures/affiliate_groups.csv';

    /**
     * @param Reader $reader
     * @param AffiliateGroupInterfaceFactory $affiliateGroupFactory
     * @param AffiliateGroupRepositoryInterface $affiliateGroupRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     */
    public function __construct(
        Reader $reader,
        AffiliateGroupInterfaceFactory $affiliateGroupFactory,
        AffiliateGroupRepositoryInterface $affiliateGroupRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder
    ) {
        $this->reader = $reader;
        $this->affiliateGroupFactory = $affiliateGroupFactory;
        $this->affiliateGroupRepository = $affiliateGroupRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
    }

    /**
     * {@inheritdoc}
     */
    public function install()
    {
        $rows = $this->reader->readFile($this->fileName);
        foreach ($rows as $row) {
            if (!$this->ifAlreadyExists()) {
                $this->createDefaultAffiliateGroup($row);
            }
        }
    }

    /**
     * Check if default affiliate group exists
     *
     * @return bool
     */
    private function ifAlreadyExists()
    {
        $this->searchCriteriaBuilder
            ->addFilter(AffiliateGroupInterface::ID, AffiliateGroupInterface::DEFAULT_GROUP_ID)
            ->setCurrentPage(1)
            ->setPageSize(1);
        $ticketTypes = $this->affiliateGroupRepository->getList($this->searchCriteriaBuilder->create())->getItems();

        return count($ticketTypes) > 0;
    }

    /**
     * Create default affiliate group
     *
     * @param $row
     * @throws CouldNotSaveException
     */
    private function createDefaultAffiliateGroup($row)
    {
        /** @var AffiliateGroupModel $affiliateGroup */
        $affiliateGroup = $this->affiliateGroupFactory->create();
        $affiliateGroup
            ->setName($row[AffiliateGroupInterface::NAME])
            ->setCommissionType($row[AffiliateGroupInterface::COMMISSION_TYPE])
            ->setCommissionValue($row[AffiliateGroupInterface::COMMISSION_VALUE])
            ->setCommissionHoldingPeriod($row[AffiliateGroupInterface::COMMISSION_HOLDING_PERIOD]);

        $this->affiliateGroupRepository->save($affiliateGroup);
    }
}
