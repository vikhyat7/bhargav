<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Setup;

use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UninstallInterface;
use Aheadworks\Affiliate\Model\ResourceModel\Campaign as CampaignResource;
use Aheadworks\Affiliate\Model\ResourceModel\AffiliateGroup as AffiliateGroupResource;
use Aheadworks\Affiliate\Model\ResourceModel\Transaction as TransactionResource;
use Aheadworks\Affiliate\Model\ResourceModel\Account as AffiliateAccountResource;
use Aheadworks\Affiliate\Model\ResourceModel\Payout as AffiliatePayoutResource;
use Aheadworks\Affiliate\Model\ResourceModel\Signup as AffiliateSignupResource;
use Aheadworks\Affiliate\Model\ResourceModel\Coupon as CouponResource;
use Aheadworks\Affiliate\Model\ResourceModel\LinkStatistic as LinkStatisticResource;
use Aheadworks\Affiliate\Model\ResourceModel\Account\Balance as AffiliateBalanceResource;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Aheadworks\Affiliate\Model\ResourceModel\BoundCustomer as BoundCustomerResource;

/**
 * Class Uninstall
 * @package Aheadworks\Affiliate\Setup
 */
class Uninstall implements UninstallInterface
{
    /**
     * @var SalesSetupFactory
     */
    private $salesSetupFactory;

    /**
     * @var ModuleDataSetupInterface
     */
    private $dataSetup;

    /**
     * @param SalesSetupFactory $salesSetupFactory
     * @param ModuleDataSetupInterface $dataSetup
     */
    public function __construct(
        SalesSetupFactory $salesSetupFactory,
        ModuleDataSetupInterface $dataSetup
    ) {
        $this->salesSetupFactory = $salesSetupFactory;
        $this->dataSetup = $dataSetup;
    }

    /**
     * {@inheritdoc}
     */
    public function uninstall(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();

        $this
            ->uninstallTables($installer)
            ->uninstallConfigData($installer)
            ->uninstallFlagData($installer)
            ->uninstallSalesData()
        ;

        $installer->endSetup();
    }

    /**
     * Uninstall all module tables
     *
     * @param SchemaSetupInterface $installer
     * @return $this
     */
    private function uninstallTables(SchemaSetupInterface $installer)
    {
        $installer->getConnection()->dropTable(
            $installer->getTable(LinkStatisticResource::INDEX_TABLE_NAME)
        );
        $installer->getConnection()->dropTable(
            $installer->getTable(LinkStatisticResource::MAIN_TABLE_NAME)
        );
        $installer->getConnection()->dropTable(
            $installer->getTable(TransactionResource::ENTITY_TABLE_NAME)
        );
        $installer->getConnection()->dropTable(
            $installer->getTable(TransactionResource::MAIN_TABLE_NAME)
        );
        $installer->getConnection()->dropTable(
            $installer->getTable(AffiliatePayoutResource::MAIN_TABLE_NAME)
        );
        $installer->getConnection()->dropTable(
            $installer->getTable(CouponResource::MAIN_TABLE_NAME)
        );
        $installer->getConnection()->dropTable(
            $installer->getTable(AffiliateBalanceResource::MAIN_TABLE_NAME)
        );
        $installer->getConnection()->dropTable(
            $installer->getTable(AffiliateAccountResource::MAIN_TABLE_NAME)
        );
        $installer->getConnection()->dropTable(
            $installer->getTable(AffiliateSignupResource::MAIN_TABLE_NAME)
        );
        $installer->getConnection()->dropTable(
            $installer->getTable(CampaignResource::AFFILIATE_GROUP_TABLE_NAME)
        );
        $installer->getConnection()->dropTable(
            $installer->getTable(AffiliateGroupResource::MAIN_TABLE_NAME)
        );
        $installer->getConnection()->dropTable(
            $installer->getTable(CampaignResource::COUPON_USAGE_TABLE_NAME)
        );
        $installer->getConnection()->dropTable(
            $installer->getTable(CampaignResource::RECOMMENDED_PRODUCT_TABLE_NAME)
        );
        $installer->getConnection()->dropTable(
            $installer->getTable(CampaignResource::MAIN_TABLE_NAME)
        );
        $installer->getConnection()->dropTable(
            $installer->getTable(BoundCustomerResource::MAIN_TABLE_NAME)
        );

        return $this;
    }

    /**
     * Uninstall module data from config
     *
     * @param SchemaSetupInterface $installer
     * @return $this
     */
    private function uninstallConfigData(SchemaSetupInterface $installer)
    {
        $configTable = $installer->getTable('core_config_data');
        $installer->getConnection()->delete($configTable, "`path` LIKE 'aw_affiliate%'");
        return $this;
    }

    /**
     * Uninstall module data from flag table
     *
     * @param SchemaSetupInterface $installer
     * @return $this
     */
    private function uninstallFlagData(SchemaSetupInterface $installer)
    {
        $flagTable = $installer->getTable('flag');
        $installer->getConnection()->delete($flagTable, "`flag_code` LIKE 'aw_affiliate%'");
        return $this;
    }

    /**
     * Uninstall sales data
     *
     * @return $this
     */
    private function uninstallSalesData()
    {
        /** @var SalesSetup $salesSetup */
        $salesSetup = $this->salesSetupFactory->create(['setup' => $this->dataSetup]);
        $attributes = $salesSetup->getAttributesToInstall();
        foreach ($attributes as $attributeCode => $attributeParams) {
            $salesSetup->removeAttribute(
                $attributeParams['type'],
                $attributeParams['attribute']
            );
        }
        return $this;
    }
}
