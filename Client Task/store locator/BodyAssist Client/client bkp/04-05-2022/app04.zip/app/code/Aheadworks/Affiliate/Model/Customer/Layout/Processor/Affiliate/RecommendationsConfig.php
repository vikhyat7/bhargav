<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Customer\Layout\Processor\Affiliate;

use Aheadworks\Affiliate\Api\AccountRepositoryInterface;
use Aheadworks\Affiliate\Model\Layout\LayoutProcessorInterface;
use Magento\Framework\Stdlib\ArrayManager;
use Aheadworks\Affiliate\Model\Source\Campaign as CampaignSource;

/**
 * Class RecommendationsConfig
 *
 * @package Aheadworks\Affiliate\Model\Customer\Layout\Processor\Affiliate
 */
class RecommendationsConfig implements LayoutProcessorInterface
{
    /**
     * @var ArrayManager
     */
    private $arrayManager;

    /**
     * @var AccountRepositoryInterface
     */
    private $accountRepository;

    /**
     * @var CampaignSource
     */
    private $campaignSource;

    /**
     * @param ArrayManager $arrayManager
     * @param AccountRepositoryInterface $accountRepository
     * @param CampaignSource $campaignSource
     */
    public function __construct(
        ArrayManager $arrayManager,
        AccountRepositoryInterface $accountRepository,
        CampaignSource $campaignSource
    ) {
        $this->arrayManager = $arrayManager;
        $this->accountRepository = $accountRepository;
        $this->campaignSource = $campaignSource;
    }

    /**
     * {@inheritdoc}
     */
    public function process($jsLayout, $customerId, $websiteId)
    {
        $groupInfoConfigProviderPath = 'components/awAffRecommendationsConfigProvider';
        $jsLayout = $this->arrayManager->merge(
            $groupInfoConfigProviderPath,
            $jsLayout,
            [
                'data' => [
                    'available_campaigns_options' => $this->getAvailableCampaignsOptions($customerId, $websiteId),
                ]
            ]
        );

        return $jsLayout;
    }

    /**
     * Retrieve options array of campaigns, available for recommendations
     *
     * @param $customerId
     * @param $websiteId
     * @return array
     */
    private function getAvailableCampaignsOptions($customerId, $websiteId)
    {
        try {
            $account = $this->accountRepository->getByCustomerId($customerId, $websiteId);
            $availableCampaignsOptions = $this->campaignSource->getAvailableForRecommendationsOptions(
                $account->getAffiliateGroupId(),
                $websiteId
            );
        } catch (\Exception $exception) {
            $availableCampaignsOptions = [];
        }
        return $availableCampaignsOptions;
    }
}
