<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Coupon;

use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Aheadworks\Affiliate\Model\Coupon\SalesRule\DataPreparer;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\SalesRule\Api\Data\RuleInterface as SalesRuleInterface;
use Magento\SalesRule\Api\Data\RuleInterfaceFactory;
use Magento\SalesRule\Api\RuleRepositoryInterface;

/**
 * Class SalesRuleManager
 * @package Aheadworks\Affiliate\Model\Coupon
 */
class SalesRuleManager
{
    /**
     * @var RuleInterfaceFactory
     */
    private $ruleFactory;

    /**
     * @var RuleRepositoryInterface
     */
    private $ruleRepository;

    /**
     * @var DataPreparer
     */
    private $dataPreparer;

    /**
     * @param RuleInterfaceFactory $ruleFactory
     * @param RuleRepositoryInterface $ruleRepository
     * @param DataPreparer $dataPreparer
     */
    public function __construct(
        RuleInterfaceFactory $ruleFactory,
        RuleRepositoryInterface $ruleRepository,
        DataPreparer $dataPreparer
    ) {
        $this->ruleFactory = $ruleFactory;
        $this->ruleRepository = $ruleRepository;
        $this->dataPreparer = $dataPreparer;
    }

    /**
     * Save sales rule
     *
     * @param CampaignInterface $campaign
     * @param int|null $salesRuleId
     * @return SalesRuleInterface
     * @throws InputException
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function saveSalesRule($campaign, $salesRuleId = null)
    {
        /** @var SalesRuleInterface $salesRule */
        $salesRule = $this->ruleFactory->create();
        if ($salesRuleId) {
            $salesRule->setRuleId($salesRuleId);
        }
        $salesRule->setIsActive($this->dataPreparer->isSalesRuleActive($campaign));

        $salesRule->setCustomerGroupIds($this->dataPreparer->getCustomerGroupIds())
            ->setWebsiteIds($this->dataPreparer->getWebsiteIds($campaign))
            ->setCouponType(SalesRuleInterface::COUPON_TYPE_SPECIFIC_COUPON)
            ->setName($campaign->getName())
            ->setDescription($this->dataPreparer->getPreparedDescription($campaign))
            ->setDiscountAmount($campaign->getCouponDiscountAmount())
            ->setUsesPerCoupon($campaign->getCouponUsesPerAffiliate())
            ->setActionCondition($this->dataPreparer->getCouponActionCondition($campaign))
            ->setSortOrder(0)
            ->setUseAutoGeneration(true)
            ->setStopRulesProcessing(true)
            ->setSimpleAction($this->dataPreparer->getCouponDiscountAction($campaign));

        return $this->ruleRepository->save($salesRule);
    }

    /**
     * Delete sales rule
     *
     * @param int $salesRuleId
     * @return bool
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function deleteSalesRule($salesRuleId)
    {
        return $this->ruleRepository->deleteById($salesRuleId);
    }
}
