<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Plugin\SalesRule\Model;

use Aheadworks\Affiliate\Model\Quote\Address\DataUpdater;
use Magento\SalesRule\Model\RulesApplier;
use Magento\Quote\Model\Quote\Address;
use Magento\SalesRule\Model\Rule;

/**
 * Class RulesApplierPlugin
 * @package Aheadworks\Affiliate\Plugin\SalesRule\Model
 */
class RulesApplierPlugin
{
    /**
     * @var DataUpdater
     */
    private $dataUpdater;

    /**
     * @param DataUpdater $dataUpdater
     */
    public function __construct(
        DataUpdater $dataUpdater
    ) {
        $this->dataUpdater = $dataUpdater;
    }

    /**
     * @param RulesApplier $subject
     * @param RulesApplier $result
     * @param Address $address
     * @param Rule $rule
     * @return RulesApplier
     */
    public function afterAddDiscountDescription(
        RulesApplier $subject,
        $result,
        $address,
        $rule
    ) {
        $this->dataUpdater->updateDiscountLabel($address, $rule);

        return $result;
    }
}
