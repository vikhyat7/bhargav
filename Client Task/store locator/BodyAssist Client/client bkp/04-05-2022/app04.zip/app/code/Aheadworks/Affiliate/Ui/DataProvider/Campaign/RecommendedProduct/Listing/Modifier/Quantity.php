<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Ui\DataProvider\Campaign\RecommendedProduct\Listing\Modifier;

use Magento\Ui\DataProvider\Modifier\ModifierInterface;

/**
 * Class Quantity
 *
 * @package Aheadworks\Affiliate\Ui\DataProvider\Campaign\RecommendedProduct\Listing\Modifier
 */
class Quantity implements ModifierInterface
{
    /**
     * {@inheritdoc}
     */
    public function modifyData(array $data)
    {
        return $data;
    }

    /**
     * {@inheritdoc}
     */
    public function modifyMeta(array $meta)
    {
        if (isset($meta['product_columns']['children']['quantity_per_source'])) {
            unset($meta['product_columns']['children']['quantity_per_source']);
        }
        if (isset($meta['product_columns']['children']['qty'])) {
            unset($meta['product_columns']['children']['qty']);
        }
        return $meta;
    }
}
