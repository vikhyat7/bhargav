<?php
namespace PCAPredict\Addressy\Model;
interface SettingsDataInterface 
{

}