<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Order\Item\Total;

use Magento\Sales\Api\Data\OrderItemInterface;

/**
 * Class Calculator
 *
 * @package Aheadworks\Affiliate\Model\Order\Item\Total
 */
class Calculator
{
    /**
     * @var array
     */
    private $discounts = [];

    /**
     * @param array $discounts
     */
    public function __construct(
        $discounts = []
    ) {
        $this->discounts = $discounts;
    }

    /**
     * Calculate order item total
     *
     * @param OrderItemInterface $orderItem
     * @return float
     */
    public function calculate($orderItem)
    {
        $total = $orderItem->getBaseRowTotal()
            - $orderItem->getBaseDiscountAmount()
        ;

        if ($orderItem instanceof \Magento\Framework\DataObject) {
            foreach ($this->discounts as $fieldKey) {
                $discountAmount = $orderItem->getData($fieldKey);
                if (!empty($discountAmount)) {
                    $total -= $discountAmount;
                }
            }
        }

        return max(0.0, $total);
    }
}
