<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Ui\Component\RecommendedProduct\Listing\Column;

use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Catalog\Model\Product\Visibility as ProductVisibility;

/**
 * Class VisibilityLabel
 *
 * @package Aheadworks\Affiliate\Ui\Component\RecommendedProduct\Listing\Column
 */
class VisibilityLabel extends AbstractLabel
{
    /**
     * @var ProductVisibility
     */
    protected $productVisibility;

    /**
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param ProductVisibility $productVisibility
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        ProductVisibility $productVisibility,
        array $components = [],
        array $data = []
    ) {
        parent::__construct($context, $uiComponentFactory, $components, $data);
        $this->productVisibility = $productVisibility;
    }

    /**
     * {@inheritdoc}
     */
    protected function getFieldValue($itemData)
    {
        return isset($itemData[ProductInterface::VISIBILITY]) ? $itemData[ProductInterface::VISIBILITY] : null;
    }

    /**
     * {@inheritdoc}
     */
    protected function resolveFieldLabel($fieldValue)
    {
        return $this->productVisibility->getOptionText($fieldValue);
    }
}
