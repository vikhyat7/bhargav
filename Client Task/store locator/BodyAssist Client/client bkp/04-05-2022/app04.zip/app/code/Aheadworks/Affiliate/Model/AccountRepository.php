<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model;

use Aheadworks\Affiliate\Api\AccountRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterfaceFactory;
use Aheadworks\Affiliate\Api\Data\AccountSearchResultsInterface;
use Aheadworks\Affiliate\Api\Data\AccountSearchResultsInterfaceFactory;
use Aheadworks\Affiliate\Model\Account as AccountModel;
use Aheadworks\Affiliate\Model\ResourceModel\Account as AccountResourceModel;
use Aheadworks\Affiliate\Model\ResourceModel\Account\Collection as AccountCollection;
use Aheadworks\Affiliate\Model\ResourceModel\Account\CollectionFactory as AccountCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;

/**
 * Class AccountRepository
 *
 * @package Aheadworks\Affiliate\Model
 */
class AccountRepository implements AccountRepositoryInterface
{
    /**
     * @var AccountResourceModel
     */
    private $resource;

    /**
     * @var AccountInterfaceFactory
     */
    private $accountInterfaceFactory;

    /**
     * @var AccountCollectionFactory
     */
    private $accountCollectionFactory;

    /**
     * @var AccountSearchResultsInterfaceFactory
     */
    private $searchResultsFactory;

    /**
     * @var JoinProcessorInterface
     */
    private $extensionAttributesJoinProcessor;

    /**
     * @var CollectionProcessorInterface
     */
    private $collectionProcessor;

    /**
     * @var DataObjectHelper
     */
    private $dataObjectHelper;

    /**
     * @var DataObjectProcessor
     */
    private $dataObjectProcessor;

    /**
     * @var array
     */
    private $accounts = [];

    /**
     * @param AccountResourceModel $resource
     * @param AccountInterfaceFactory $accountInterfaceFactory
     * @param AccountCollectionFactory $accountCollectionFactory
     * @param AccountSearchResultsInterfaceFactory $searchResultsFactory
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param CollectionProcessorInterface $collectionProcessor
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     */
    public function __construct(
        AccountResourceModel $resource,
        AccountInterfaceFactory $accountInterfaceFactory,
        AccountCollectionFactory $accountCollectionFactory,
        AccountSearchResultsInterfaceFactory $searchResultsFactory,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        CollectionProcessorInterface $collectionProcessor,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor
    ) {
        $this->resource = $resource;
        $this->accountInterfaceFactory = $accountInterfaceFactory;
        $this->accountCollectionFactory = $accountCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->collectionProcessor = $collectionProcessor;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataObjectProcessor = $dataObjectProcessor;
    }

    /**
     * {@inheritdoc}
     */
    public function save(AccountInterface $account)
    {
        try {
            $this->resource->save($account);
            $this->accounts[$account->getAccountId()] = $account;
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__($exception->getMessage()));
        }

        return $account;
    }

    /**
     * {@inheritdoc}
     */
    public function getById($accountId)
    {
        if (!isset($this->accounts[$accountId])) {
            /** @var AccountInterface $account */
            $account = $this->accountInterfaceFactory->create();
            $this->resource->load($account, $accountId);
            if (!$account->getAccountId()) {
                throw NoSuchEntityException::singleField(AccountInterface::ID, $accountId);
            }
            $this->accounts[$accountId] = $account;
        }
        return $this->accounts[$accountId];
    }

    /**
     * {@inheritdoc}
     */
    public function getByCustomerId($customerId, $websiteId)
    {
        $accountId = $this->resource->getAccountIdByCustomerId($customerId, $websiteId);
        try {
            /** @var AccountInterface $account */
            $account = $this->getById($accountId);
        } catch (NoSuchEntityException $e) {
            throw NoSuchEntityException::singleField(AccountInterface::CUSTOMER_ID, $customerId);
        }
        return $account;
    }

    /**
     * {@inheritdoc}
     */
    public function getList(SearchCriteriaInterface $searchCriteria)
    {
        /** @var AccountCollection $collection */
        $collection = $this->accountCollectionFactory->create();

        $this->extensionAttributesJoinProcessor->process($collection, AccountInterface::class);
        $this->collectionProcessor->process($searchCriteria, $collection);

        /** @var AccountSearchResultsInterface $searchResults */
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($searchCriteria);
        $searchResults->setTotalCount($collection->getSize());

        $objects = [];
        /** @var AccountModel $item */
        foreach ($collection->getItems() as $item) {
            $objects[] = $this->getDataObject($item);
        }
        $searchResults->setItems($objects);

        return $searchResults;
    }

    /**
     * {@inheritdoc}
     */
    public function getAffiliateIdsToPayout()
    {
        return $this->resource->getAffiliateIdsToPayout();
    }

    /**
     * Retrieves data object using model
     *
     * @param AccountModel $model
     * @return AccountInterface
     */
    private function getDataObject($model)
    {
        /** @var AccountInterface $object */
        $object = $this->accountInterfaceFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $object,
            $this->dataObjectProcessor->buildOutputDataArray($model, AccountInterface::class),
            AccountInterface::class
        );
        return $object;
    }
}
