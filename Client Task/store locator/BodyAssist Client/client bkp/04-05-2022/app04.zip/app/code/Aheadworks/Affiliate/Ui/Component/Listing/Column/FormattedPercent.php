<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Ui\Component\Listing\Column;

use Magento\Ui\Component\Listing\Columns\Column;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Framework\Stdlib\ArrayManager;

/**
 * Class FormattedPercent
 * @package Aheadworks\Affiliate\Ui\Component\Listing\Column
 */
class FormattedPercent extends Column
{
    /**
     * @var ArrayManager
     */
    private $arrayManager;

    /**
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param ArrayManager $arrayManager
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        ArrayManager $arrayManager,
        array $components = [],
        array $data = []
    ) {
        $this->arrayManager = $arrayManager;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * {@inheritdoc}
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$item) {
                $item[$this->getData('name')] = $this->getFormattedPercentValue(
                    $this->arrayManager->get($this->getData('name'), $item)
                );
            }
        }
        return $dataSource;
    }

    /**
     * Retrieve formatted percent value
     *
     * @param float $value
     * @return string
     */
    private function getFormattedPercentValue($value)
    {
        $value = round($value, 2);

        return __('%1%', $value);
    }
}
