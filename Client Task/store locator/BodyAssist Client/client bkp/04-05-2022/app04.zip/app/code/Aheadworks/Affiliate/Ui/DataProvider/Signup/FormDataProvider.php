<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Ui\DataProvider\Signup;

use Aheadworks\Affiliate\Model\Source\Signup\Status;
use Magento\Ui\DataProvider\AbstractDataProvider;
use Aheadworks\Affiliate\Model\ResourceModel\Signup\CollectionFactory;
use Aheadworks\Affiliate\Model\ResourceModel\Signup\Collection;
use Aheadworks\Affiliate\Model\Signup;
use Aheadworks\Affiliate\Api\Data\SignupInterface;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\App\RequestInterface;

/**
 * Class FormDataProvider
 * @package Aheadworks\Affiliate\Ui\DataProvider\Signup
 */
class FormDataProvider extends AbstractDataProvider
{
    /**
     * @var Collection
     */
    protected $collection;

    /**
     * @var RequestInterface
     */
    private $request;

    /**
     * @var DataPersistorInterface
     */
    private $dataPersistor;

    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param RequestInterface $request
     * @param DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        RequestInterface $request,
        DataPersistorInterface $dataPersistor,
        array $meta = [],
        array $data = []
    ) {
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
        $this->collection = $collectionFactory->create();
        $this->request = $request;
        $this->dataPersistor = $dataPersistor;
    }

    /**
     * Get data
     *
     * @return array
     */
    public function getData()
    {
        $data = [];
        $dataFromForm = $this->dataPersistor->get('aw_affiliate_signup_form');
        $signupId = $this->request->getParam($this->getRequestFieldName());
        if (!empty($dataFromForm)) {
            $data[$signupId] = $dataFromForm;
            $this->dataPersistor->clear('aw_affiliate_signup_form');
        } elseif (!empty($signupId)) {
            $signups = $this->getCollection()
                ->addFieldToFilter(SignupInterface::ID, $signupId)
                ->getItems();
            /** @var Signup $signup */
            foreach ($signups as $signup) {
                if ($signupId == $signup->getId()) {
                    $signupData = $signup->getData();
                    $data[$signupId] = $this->populateFlags($signupData);
                    break;
                }
            }
        }

        return $data;
    }

    /**
     * Populate flags
     *
     * @param array $data
     * @return array
     */
    private function populateFlags($data)
    {
        $data['isReasonVisible'] =
            isset($data[SignupInterface::STATUS]) && $data[SignupInterface::STATUS] != Status::APPROVED;

        return $data;
    }
}
