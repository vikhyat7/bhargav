<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Transaction\HoldingPeriod;

use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Aheadworks\Affiliate\Api\Data\TransactionInterface;
use Aheadworks\Affiliate\Api\Data\TransactionEntityInterface;
use Aheadworks\Affiliate\Api\TransactionRepositoryInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Api\SearchCriteria;
use Aheadworks\Affiliate\Model\Source\Transaction\Status as TransactionStatus;
use Aheadworks\Affiliate\Model\Source\Transaction\Type as TransactionType;
use Magento\Framework\Stdlib\DateTime;
use Magento\Sales\Model\Order\Item as OrderItem;
use Aheadworks\Affiliate\Model\Source\Transaction\EntityType as TransactionEntityType;

/**
 * Class DataProvider
 * @package Aheadworks\Affiliate\Model\Transaction\HoldingPeriod
 */
class DataProvider
{
    /**
     * @var TransactionRepositoryInterface
     */
    private $transactionRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    private $searchCriteriaBuilder;

    /**
     * @var DateTime
     */
    private $dateTime;

    /**
     * @param TransactionRepositoryInterface $transactionRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param DateTime $dateTime
     */
    public function __construct(
        TransactionRepositoryInterface $transactionRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        DateTime $dateTime
    ) {
        $this->transactionRepository = $transactionRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->dateTime = $dateTime;
    }

    /**
     * Find pending commission transactions with expired holding period
     *
     * @return TransactionInterface[]
     */
    public function getExpiredTransactionsToProcess()
    {
        $this->searchCriteriaBuilder
            ->addFilter(TransactionInterface::TYPE, TransactionType::COMMISSION)
            ->addFilter(TransactionInterface::STATUS, TransactionStatus::PENDING)
            ->addFilter(
                TransactionInterface::HOLDING_PERIOD_EXPIRATION,
                $this->getCurrentDatetime(),
                'to'
            )
        ;
        /** @var SearchCriteria $searchCriteria */
        $searchCriteria = $this->searchCriteriaBuilder->create();
        return $this->transactionRepository->getList($searchCriteria)->getItems();
    }

    /**
     * Find pending commission transactions with unexpired holding period by related order item
     *
     * @param OrderItem $orderItem
     * @return TransactionInterface[]
     */
    public function getUnexpiredTransactionsByOrderItem($orderItem)
    {
        $this->searchCriteriaBuilder
            ->addFilter(TransactionInterface::TYPE, TransactionType::COMMISSION)
            ->addFilter(TransactionInterface::STATUS, TransactionStatus::PENDING)
            ->addFilter(TransactionEntityInterface::ENTITY_TYPE, TransactionEntityType::ORDER_ITEM)
            ->addFilter(TransactionEntityInterface::ENTITY_ID, $orderItem->getItemId())
            ->addFilter(
                TransactionInterface::HOLDING_PERIOD_EXPIRATION,
                $this->getCurrentDatetime(),
                'from'
            )
        ;
        /** @var SearchCriteria $searchCriteria */
        $searchCriteria = $this->searchCriteriaBuilder->create();
        return $this->transactionRepository->getList($searchCriteria)->getItems();
    }

    /**
     * Find pending commission transactions with unexpired holding period by affiliate
     *
     * @param AccountInterface $account
     * @return TransactionInterface[]
     */
    public function getUnexpiredTransactionsByAffiliate($account)
    {
        $searchCriteria = $this->searchCriteriaBuilder
            ->addFilter(TransactionInterface::TYPE, TransactionType::COMMISSION)
            ->addFilter(TransactionInterface::STATUS, TransactionStatus::PENDING)
            ->addFilter(TransactionInterface::AFFILIATE_ID, $account->getAccountId())
            ->create();

        return $this->transactionRepository->getList($searchCriteria)->getItems();
    }

    /**
     * Retrieve current datetime
     *
     * @return null|string
     */
    private function getCurrentDatetime()
    {
        return $this->dateTime->formatDate(true);
    }
}
