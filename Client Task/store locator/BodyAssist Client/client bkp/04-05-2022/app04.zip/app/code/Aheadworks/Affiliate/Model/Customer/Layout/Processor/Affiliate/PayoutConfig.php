<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Customer\Layout\Processor\Affiliate;

use Aheadworks\Affiliate\Api\AccountRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Aheadworks\Affiliate\Model\Layout\LayoutProcessorInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Stdlib\ArrayManager;
use Aheadworks\Affiliate\Model\Config;
use Aheadworks\Affiliate\Model\ValueFormatter\Price as PriceValueFormatter;
use Aheadworks\Affiliate\Model\Account\Balance\Calculator;

/**
 * Class PayoutConfig
 * @package Aheadworks\Affiliate\Model\Customer\Layout\Processor\Affiliate
 */
class PayoutConfig implements LayoutProcessorInterface
{
    /**
     * @var ArrayManager
     */
    private $arrayManager;

    /**
     * @var Config
     */
    private $config;

    /**
     * @var PriceValueFormatter
     */
    private $priceValueFormatter;

    /**
     * @var AccountRepositoryInterface
     */
    private $accountRepository;

    /**
     * @var Calculator
     */
    private $balanceCalculator;

    /**
     * @param ArrayManager $arrayManager
     * @param Config $config
     * @param PriceValueFormatter $priceValueFormatter
     * @param AccountRepositoryInterface $accountRepository
     * @param Calculator $balanceCalculator
     */
    public function __construct(
        ArrayManager $arrayManager,
        Config $config,
        PriceValueFormatter $priceValueFormatter,
        AccountRepositoryInterface $accountRepository,
        Calculator $balanceCalculator
    ) {
        $this->arrayManager = $arrayManager;
        $this->config = $config;
        $this->priceValueFormatter = $priceValueFormatter;
        $this->accountRepository = $accountRepository;
        $this->balanceCalculator = $balanceCalculator;
    }

    /**
     * {@inheritdoc}
     */
    public function process($jsLayout, $customerId, $websiteId)
    {
        $signupConfigProviderPath = 'components/awAffPayoutConfigProvider';
        $account = $this->getAccount($customerId, $websiteId);
        $remainingBalance = $this->balanceCalculator->getRemainingBalance($account);
        $jsLayout = $this->arrayManager->merge(
            $signupConfigProviderPath,
            $jsLayout,
            [
                'data' => [
                    'payout_request_enabled' => $this->config->isPayoutRequestAllowed($websiteId),
                    'balance_for_payout' => $this->balanceCalculator->getBalanceForPayout($account),
                    'remaining_balance_for_payout' => $remainingBalance,
                    'remaining_balance_for_payout_formatted' => $this->priceValueFormatter->getFormattedValue(
                        $remainingBalance,
                        $websiteId
                    ),
                    'is_notice_visible' => $remainingBalance > 0.00
                ]
            ]
        );

        return $jsLayout;
    }

    /**
     * Get affiliate account
     *
     * @param int|null $customerId
     * @param int|null $websiteId
     * @return AccountInterface|null
     */
    private function getAccount($customerId, $websiteId)
    {
        try {
            return $this->accountRepository->getByCustomerId($customerId, $websiteId);
        } catch (NoSuchEntityException $e) {
            return null;
        }
    }
}
