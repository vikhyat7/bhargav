<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\BoundCustomer;

use Aheadworks\Affiliate\Model\ResourceModel\BoundCustomer as BoundCustomerResourceModel;

/**
 * Class DataProvider
 * @package Aheadworks\Affiliate\Model\BoundCustomer
 */
class DataProvider
{
    /**
     * @var BoundCustomerResourceModel
     */
    private $resource;

    /**
     * @param BoundCustomerResourceModel $resource
     */
    public function __construct(
        BoundCustomerResourceModel $resource
    ) {
        $this->resource = $resource;
    }

    /**
     * Retrieve bound customers commission amount
     *
     * @param int $accountId
     * @return float
     */
    public function getBoundCustomersCommissionAmount($accountId)
    {
        return $this->resource->getBoundCustomersCommissionAmount($accountId);
    }

    /**
     * Retrieve bound customers order ids
     *
     * @param int $accountId
     * @return array
     */
    public function getBoundCustomerOrderIds($accountId)
    {
        return $this->resource->getBoundCustomerOrderIds($accountId);
    }
}
