<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Customer\Layout\Processor\Affiliate;

use Aheadworks\Affiliate\Model\Layout\LayoutProcessorInterface;
use Magento\Framework\Stdlib\ArrayManager;
use Aheadworks\Affiliate\Model\Customer\Checker as CustomerChecker;
use Aheadworks\Affiliate\Model\Config;
use Magento\Framework\UrlInterface;

/**
 * Class GlobalConfig
 * @package Aheadworks\Affiliate\Model\Customer\Layout\Processor\Affiliate
 */
class GlobalConfig implements LayoutProcessorInterface
{
    /**
     * @var ArrayManager
     */
    private $arrayManager;

    /**
     * @var CustomerChecker
     */
    private $customerChecker;

    /**
     * @var Config
     */
    private $config;

    /**
     * @var UrlInterface
     */
    private $urlBuilder;

    /**
     * @param ArrayManager $arrayManager
     * @param CustomerChecker $customerChecker
     * @param Config $config
     * @param UrlInterface $urlBuilder
     */
    public function __construct(
        ArrayManager $arrayManager,
        CustomerChecker $customerChecker,
        Config $config,
        UrlInterface $urlBuilder
    ) {
        $this->arrayManager = $arrayManager;
        $this->customerChecker = $customerChecker;
        $this->config = $config;
        $this->urlBuilder = $urlBuilder;
    }

    /**
     * {@inheritdoc}
     */
    public function process($jsLayout, $customerId, $websiteId)
    {
        $globalConfigProviderPath = 'components/awAffGlobalConfigProvider';
        $jsLayout = $this->arrayManager->merge(
            $globalConfigProviderPath,
            $jsLayout,
            [
                'data' => [
                    'is_customer_has_account' => $this->customerChecker->isCustomerHasAffiliateAccount(
                        $customerId,
                        $websiteId
                    ),
                    'is_account_active' => $this->customerChecker->isAffiliateAccountActive($customerId, $websiteId),
                    'is_account_payment_info_specified' => $this->customerChecker->isAffiliatePaymentInfoSpecified(
                        $customerId,
                        $websiteId
                    ),
                    'terms_and_conditions_page_url' => $this->getTermsAndConditionsPageUrl()
                ]
            ]
        );

        return $jsLayout;
    }

    /**
     * Retrieve url for affiliate terms and conditions page
     *
     * @return string
     */
    private function getTermsAndConditionsPageUrl()
    {
        $termsConditionsCmsPageIdentifier = $this->config->getTermsConditionsCmsPageId();
        return $this->urlBuilder->getUrl('', ['_direct' => $termsConditionsCmsPageIdentifier]);
    }
}
