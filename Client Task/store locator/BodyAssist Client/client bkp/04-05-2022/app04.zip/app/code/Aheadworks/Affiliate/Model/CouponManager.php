<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model;

use Aheadworks\Affiliate\Api\CouponRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Aheadworks\Affiliate\Api\Data\CouponInterface;
use Aheadworks\Affiliate\Model\Coupon\Generator;
use Aheadworks\Affiliate\Model\Coupon\SalesRuleManager;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Aheadworks\Affiliate\Model\Coupon\Resolver as CouponResolver;

/**
 * Class CouponManager
 * @package Aheadworks\Affiliate\Model
 */
class CouponManager
{
    /**
     * @var Generator
     */
    private $generator;

    /**
     * @var SalesRuleManager
     */
    private $salesRuleManager;

    /**
     * @var CouponResolver
     */
    private $couponResolver;

    /**
     * @var CouponRepositoryInterface
     */
    private $couponRepository;

    /**
     * @param Generator $generator
     * @param SalesRuleManager $salesRuleManager
     * @param CouponResolver $resolver
     * @param CouponRepositoryInterface $couponRepository
     */
    public function __construct(
        Generator $generator,
        SalesRuleManager $salesRuleManager,
        CouponResolver $resolver,
        CouponRepositoryInterface $couponRepository
    ) {
        $this->generator = $generator;
        $this->salesRuleManager = $salesRuleManager;
        $this->couponResolver = $resolver;
        $this->couponRepository = $couponRepository;
    }

    /**
     * Update coupons
     *
     * @param CampaignInterface $campaign
     * @throws InputException
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function updateCoupons($campaign)
    {
        $salesRuleId = $this->couponResolver->getSalesRuleIdByCampaignId($campaign->getCampaignId());

        if ($salesRuleId) {
            $this->salesRuleManager->saveSalesRule($campaign, $salesRuleId);
        }
    }

    /**
     * Delete coupons by campaign
     *
     * @param CampaignInterface $campaign
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function deleteCouponsByCampaign($campaign)
    {
        $salesRuleId = $this->couponResolver->getSalesRuleIdByCampaignId($campaign->getCampaignId());

        if ($salesRuleId) {
            $this->salesRuleManager->deleteSalesRule($salesRuleId);
        }
    }

    /**
     * Delete coupons by account
     *
     * @param AccountInterface $account
     * @throws LocalizedException
     */
    public function deleteCouponsByAccount($account)
    {
        $coupons = $this->couponResolver->getCouponsByAffiliateId($account->getAccountId());

        foreach ($coupons as $coupon) {
            $this->couponRepository->delete($coupon);
        }
    }

    /**
     * Generate coupon
     *
     * @param AccountInterface $account
     * @param CampaignInterface $campaign
     * @return CouponInterface
     * @throws InputException
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function generateCoupon($account, $campaign)
    {
        $salesRuleId = $this->couponResolver->getSalesRuleIdByCampaignId($campaign->getCampaignId());

        return $this->generator->generateCoupon($account, $campaign, $salesRuleId);
    }
}
