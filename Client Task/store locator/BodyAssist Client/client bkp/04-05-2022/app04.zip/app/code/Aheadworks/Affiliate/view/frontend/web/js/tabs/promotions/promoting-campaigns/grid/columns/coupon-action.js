define([
    'jquery',
    'underscore',
    'Magento_Ui/js/grid/columns/column',
    'mage/storage'
], function ($, _, Component, storage) {
    'use strict';

    return Component.extend({
        defaults: {
            isSetCouponPrefix: false,
            generateCouponUrl: 'aw_affiliate/promo/generateCoupon',
            reloadGridAction: '',
            ignoreTmpls: {
                reloadGridAction: true
            }
        },

        /**
         * @inheritdoc
         */
        initObservable: function () {
            this._super()
                .observe({
                    isSetCouponPrefix: false
                });

            return this;
        },

        /**
         * Coupon action
         *
         * @param record
         * @return {*|void}
         */
        getCouponAction: function (record) {
            this.generateCoupon(record.campaign_id);
        },

        /**
         * Check is disabled
         *
         * @param record
         * @return {Boolean}
         */
        isDisabled: function (record) {
            return Number(record.coupon_usage_mode) === 1
                || !_.isEmpty(record.coupon_code)
                || !this.isSetCouponPrefix();
        },

        /**
         * Generate coupon
         *
         * @param campaign_id
         */
        generateCoupon: function (campaign_id) {
            var payload = {
                    form_key: this.getFormKey(),
                    campaign_id: campaign_id
                },
                serviceUrl = this.generateCouponUrl,
                me = this;

            $('body').trigger('processStart');
            return storage.post(
                serviceUrl,
                JSON.stringify(payload),
                true
            ).done(
                function (response) {
                    if (response.success) {
                        me.reloadGrid();
                    }
                }
            ).always(
                function () {
                    $('body').trigger('processStop');
                }
            );
        },

        /**
         * Reload grid
         */
        reloadGrid: function () {
            this.applySingleAction(null, this.reloadGridAction);
        },

        /**
         * Retrieve form key
         *
         * @return {string}
         */
        getFormKey: function () {
            var formKey = window.FORM_KEY;

            if (!formKey) {
                window.FORM_KEY = $.mage.cookies.get('form_key');
            }

            return formKey;
        }
    });
});
