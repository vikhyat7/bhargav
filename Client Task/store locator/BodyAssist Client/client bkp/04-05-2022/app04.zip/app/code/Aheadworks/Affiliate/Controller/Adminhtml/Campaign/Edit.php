<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Campaign;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Backend\Model\View\Result\Page;
use Magento\Framework\View\Result\PageFactory;
use Aheadworks\Affiliate\Api\CampaignRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Registry;

/**
 * Class Edit
 *
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Campaign
 */
class Edit extends Action
{
    /**
     * {@inheritdoc}
     */
    const ADMIN_RESOURCE = 'Aheadworks_Affiliate::campaigns';

    /**
     * Key used for registry to store campaign data
     */
    const CAMPAIGN_DATA_KEY = 'campaign_data';

    /**
     * @var PageFactory
     */
    private $resultPageFactory;

    /**
     * @var CampaignRepositoryInterface
     */
    private $campaignRepository;

    /**
     * @var Registry
     */
    private $coreRegistry;

    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     * @param CampaignRepositoryInterface $campaignRepository
     * @param Registry $coreRegistry
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        CampaignRepositoryInterface $campaignRepository,
        Registry $coreRegistry
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->campaignRepository = $campaignRepository;
        $this->coreRegistry = $coreRegistry;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        $campaignId = (int)$this->getRequest()->getParam(CampaignInterface::ID);
        if ($campaignId) {
            try {
                /** @var CampaignInterface $campaign */
                $campaign = $this->campaignRepository->getById($campaignId);
                $this->coreRegistry->register(self::CAMPAIGN_DATA_KEY, $campaign);
            } catch (NoSuchEntityException $exception) {
                $this->messageManager->addErrorMessage(
                    __('This campaign no longer exists.')
                );
                $resultRedirect = $this->resultRedirectFactory->create();
                $resultRedirect->setPath('*/*/');
                return $resultRedirect;
            }
        }

        /** @var Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage
            ->setActiveMenu('Aheadworks_Affiliate::campaigns')
            ->getConfig()->getTitle()->prepend(
                $campaignId ? __('Edit Campaign') : __('New Campaign')
            );
        return $resultPage;
    }
}
