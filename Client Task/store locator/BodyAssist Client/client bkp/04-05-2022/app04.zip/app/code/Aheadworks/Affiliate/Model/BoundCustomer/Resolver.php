<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\BoundCustomer;

use Aheadworks\Affiliate\Api\BoundCustomerRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\BoundCustomerInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Quote\Model\Quote\Item;

/**
 * Class Resolver
 * @package Aheadworks\Affiliate\Model\BoundCustomer
 */
class Resolver
{
    /**
     * @var BoundCustomerRepositoryInterface
     */
    private $boundCustomerRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    private $searchCriteriaBuilder;

    /**
     * @param BoundCustomerRepositoryInterface $boundCustomerRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     */
    public function __construct(
        BoundCustomerRepositoryInterface $boundCustomerRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder
    ) {
        $this->boundCustomerRepository = $boundCustomerRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
    }

    /**
     * Retrieve bound customer by email
     *
     * @param string $email
     * @return BoundCustomerInterface|null
     */
    public function getBoundCustomerByEmail($email)
    {
        $boundCustomer = null;
        $searchCriteria = $this->searchCriteriaBuilder
            ->addFilter(BoundCustomerInterface::CUSTOMER_EMAIL, $email)
            ->setPageSize(1)
            ->create();
        $searchResult = $this->boundCustomerRepository->getList($searchCriteria)->getItems();

        if (count($searchResult)) {
            $boundCustomer = array_shift($searchResult);
        }

        return $boundCustomer;
    }

    /**
     * Retrieve bound customer by customer ID
     *
     * @param int $id
     * @return BoundCustomerInterface|null
     */
    public function getBoundCustomerByCustomerId($id)
    {
        $boundCustomer = null;
        $searchCriteria = $this->searchCriteriaBuilder
            ->addFilter(BoundCustomerInterface::CUSTOMER_ID, $id)
            ->setPageSize(1)
            ->create();
        $searchResult = $this->boundCustomerRepository->getList($searchCriteria)->getItems();

        if (count($searchResult)) {
            $boundCustomer = array_shift($searchResult);
        }

        return $boundCustomer;
    }

    /**
     * Retrieve bound customer by customer ID
     *
     * @param Item $item
     * @return BoundCustomerInterface|null
     */
    public function getBoundCustomerByQuoteItem($item)
    {
        $boundCustomer = null;

        if ($item->getQuote()->getCustomerId()) {
            $boundCustomer = $this->getBoundCustomerByCustomerId($item->getQuote()->getCustomerId());
        }
        if (!$boundCustomer){
            $boundCustomer = $this->getBoundCustomerByEmail($item->getQuote()->getCustomerEmail());
        }

        return $boundCustomer;
    }
}
