<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model;

use Aheadworks\Affiliate\Api\SignupRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\SignupInterface;
use Aheadworks\Affiliate\Api\Data\SignupInterfaceFactory;
use Aheadworks\Affiliate\Api\Data\SignupSearchResultsInterface;
use Aheadworks\Affiliate\Api\Data\SignupSearchResultsInterfaceFactory;
use Aheadworks\Affiliate\Model\Signup as SignupModel;
use Aheadworks\Affiliate\Model\ResourceModel\Signup as SignupResourceModel;
use Aheadworks\Affiliate\Model\ResourceModel\Signup\Collection as SignupCollection;
use Aheadworks\Affiliate\Model\ResourceModel\Signup\CollectionFactory as SignupCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Reflection\DataObjectProcessor;

/**
 * Class SignupRepository
 *
 * @package Aheadworks\Affiliate\Model
 */
class SignupRepository implements SignupRepositoryInterface
{
    /**
     * @var SignupResourceModel
     */
    private $resource;

    /**
     * @var SignupInterfaceFactory
     */
    private $signupInterfaceFactory;

    /**
     * @var SignupCollectionFactory
     */
    private $signupCollectionFactory;

    /**
     * @var SignupSearchResultsInterfaceFactory
     */
    private $searchResultsFactory;

    /**
     * @var JoinProcessorInterface
     */
    private $extensionAttributesJoinProcessor;

    /**
     * @var CollectionProcessorInterface
     */
    private $collectionProcessor;

    /**
     * @var DataObjectHelper
     */
    private $dataObjectHelper;

    /**
     * @var DataObjectProcessor
     */
    private $dataObjectProcessor;

    /**
     * @var array
     */
    private $signups = [];

    /**
     * @param SignupResourceModel $resource
     * @param SignupInterfaceFactory $signupInterfaceFactory
     * @param SignupCollectionFactory $signupCollectionFactory
     * @param SignupSearchResultsInterfaceFactory $searchResultsFactory
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param CollectionProcessorInterface $collectionProcessor
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     */
    public function __construct(
        SignupResourceModel $resource,
        SignupInterfaceFactory $signupInterfaceFactory,
        SignupCollectionFactory $signupCollectionFactory,
        SignupSearchResultsInterfaceFactory $searchResultsFactory,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        CollectionProcessorInterface $collectionProcessor,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor
    ) {
        $this->resource = $resource;
        $this->signupInterfaceFactory = $signupInterfaceFactory;
        $this->signupCollectionFactory = $signupCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->collectionProcessor = $collectionProcessor;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataObjectProcessor = $dataObjectProcessor;
    }

    /**
     * {@inheritdoc}
     */
    public function save(SignupInterface $signup)
    {
        try {
            $this->resource->save($signup);
            $this->signups[$signup->getSignupId()] = $signup;
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__($exception->getMessage()));
        }

        return $signup;
    }

    /**
     * {@inheritdoc}
     */
    public function delete(SignupInterface $signup)
    {
        try {
            $this->resource->delete($signup);
            unset($this->signups[$signup->getSignupId()]);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__($exception->getMessage()));
        }

        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function getById($signupId)
    {
        if (!isset($this->signups[$signupId])) {
            /** @var SignupInterface $signup */
            $signup = $this->signupInterfaceFactory->create();
            $this->resource->load($signup, $signupId);
            if (!$signup->getSignupId()) {
                throw NoSuchEntityException::singleField(SignupInterface::ID, $signupId);
            }
            $this->signups[$signupId] = $signup;
        }
        return $this->signups[$signupId];
    }

    /**
     * {@inheritdoc}
     */
    public function getList(SearchCriteriaInterface $searchCriteria)
    {
        /** @var SignupCollection $collection */
        $collection = $this->signupCollectionFactory->create();

        $this->extensionAttributesJoinProcessor->process($collection, SignupInterface::class);
        $this->collectionProcessor->process($searchCriteria, $collection);

        /** @var SignupSearchResultsInterface $searchResults */
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($searchCriteria);
        $searchResults->setTotalCount($collection->getSize());

        $objects = [];
        /** @var SignupModel $item */
        foreach ($collection->getItems() as $item) {
            $objects[] = $this->getDataObject($item);
        }
        $searchResults->setItems($objects);

        return $searchResults;
    }

    /**
     * Retrieves data object using model
     *
     * @param SignupModel $model
     * @return SignupInterface
     */
    private function getDataObject($model)
    {
        /** @var SignupInterface $object */
        $object = $this->signupInterfaceFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $object,
            $this->dataObjectProcessor->buildOutputDataArray($model, SignupInterface::class),
            SignupInterface::class
        );
        return $object;
    }
}
