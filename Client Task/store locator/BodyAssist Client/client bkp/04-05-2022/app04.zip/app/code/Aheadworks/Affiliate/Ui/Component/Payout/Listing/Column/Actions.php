<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Ui\Component\Payout\Listing\Column;

use Aheadworks\Affiliate\Ui\Component\Listing\Column\AbstractActions;
use Aheadworks\Affiliate\Model\Source\Payout\Status;
use Aheadworks\Affiliate\Model\Payout\StatusResolver;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Aheadworks\Affiliate\Api\Data\PayoutInterface;

/**
 * Class Actions
 *
 * @package Aheadworks\Affiliate\Ui\Component\Payout\Listing\Column
 */
class Actions extends AbstractActions
{
    /**
     * @var StatusResolver
     */
    protected $statusResolver;

    /**
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param UrlInterface $urlBuilder
     * @param StatusResolver $statusResolver
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        UrlInterface $urlBuilder,
        StatusResolver $statusResolver,
        array $components = [],
        array $data = []
    ) {
        $this->statusResolver = $statusResolver;
        parent::__construct($context, $uiComponentFactory, $urlBuilder, $components, $data);
    }

    /**
     * {@inheritdoc}
     */
    protected function getActionsDataForItem($item)
    {
        $actionsData = parent::getActionsDataForItem($item);

        $additionalActionsConfig = $this->getPayoutSpecificActions();
        foreach ($additionalActionsConfig as $actionName => $actionConfigData) {
            if ($this->isNeedToAddActionForItem($actionConfigData, $item)) {
                $currentActionData = $this->getDataForAction($actionConfigData, $item);
                if (!empty($currentActionData)) {
                    $actionsData[$actionName] = $currentActionData;
                }
            }
        }

        return $actionsData;
    }

    /**
     * Retrieve config data for actions, that are specific for the payout
     *
     * @return array
     */
    private function getPayoutSpecificActions()
    {
        return [
            'process' => [
                'url_route'     => 'aw_affiliate/payout/process',
                'id_key'        => PayoutInterface::ID,
                'label'         => __('Process'),
                'status_to_set' => Status::PROCESSING
            ],
            'complete' => [
                'url_route'     => 'aw_affiliate/payout/complete',
                'id_key'        => PayoutInterface::ID,
                'label'         => __('Complete'),
                'status_to_set' => Status::COMPLETE
            ],
            'cancel' => [
                'url_route'     => 'aw_affiliate/payout/cancel',
                'id_key'        => PayoutInterface::ID,
                'label'         => __('Cancel'),
                'status_to_set' => Status::CANCELED
            ]
        ];
    }

    /**
     * Check if need to add specific status-change action for the current item
     *
     * @param array $actionConfigData
     * @param array $itemData
     * @return bool
     */
    private function isNeedToAddActionForItem($actionConfigData, $itemData)
    {
        return (isset($actionConfigData['status_to_set'])
            && $this->statusResolver->isStatusAllowedForPayout(
                $actionConfigData['status_to_set'],
                $itemData[PayoutInterface::STATUS]
            )
        );
    }
}
