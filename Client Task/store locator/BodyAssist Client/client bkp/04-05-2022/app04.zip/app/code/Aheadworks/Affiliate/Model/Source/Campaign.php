<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Source;

use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Aheadworks\Affiliate\Api\CampaignRepositoryInterface;
use Aheadworks\Affiliate\Model\Source\Campaign\Status as CampaignStatus;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Convert\DataObject as DataObjectConverter;

/**
 * Class Campaign
 *
 * @package Aheadworks\Affiliate\Model\Source
 */
class Campaign
{
    /**
     * @var CampaignRepositoryInterface
     */
    private $campaignRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    private $searchCriteriaBuilder;

    /**
     * @var DataObjectConverter
     */
    private $dataObjectConverter;

    /**
     * @param CampaignRepositoryInterface $campaignRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param DataObjectConverter $dataObjectConverter
     */
    public function __construct(
        CampaignRepositoryInterface $campaignRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        DataObjectConverter $dataObjectConverter
    ) {
        $this->campaignRepository = $campaignRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->dataObjectConverter = $dataObjectConverter;
    }

    /**
     * Retrieve options array of campaigns, available for recommendations
     *
     * @param int $affiliateGroupId
     * @param int $websiteId
     * @return array
     */
    public function getAvailableForRecommendationsOptions($affiliateGroupId, $websiteId)
    {
        $searchCriteria = $this->searchCriteriaBuilder
            ->addFilter(CampaignInterface::STATUS, CampaignStatus::ACTIVE, 'eq')
            ->addFilter(CampaignInterface::IS_LINK_GENERATION_ALLOWED, true, 'eq')
            ->addFilter(CampaignInterface::AFFILIATE_GROUP_IDS, $affiliateGroupId, 'eq')
            ->addFilter(CampaignInterface::WEBSITE_ID, $websiteId, 'eq')
            ->create();
        $campaigns = $this->campaignRepository->getList($searchCriteria)->getItems();
        $optionsArray = $this->dataObjectConverter->toOptionArray(
            $campaigns,
            CampaignInterface::ID,
            CampaignInterface::NAME
        );
        return $optionsArray;
    }
}
