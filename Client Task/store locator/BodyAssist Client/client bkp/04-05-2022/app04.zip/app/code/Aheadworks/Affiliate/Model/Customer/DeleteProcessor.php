<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Customer;

use Aheadworks\Affiliate\Model\CouponManager;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Aheadworks\Affiliate\Model\Transaction\HoldingPeriod\DataProvider as TransactionHoldingPeriodDataProvider;
use Aheadworks\Affiliate\Model\Service\TransactionService;
use Aheadworks\Affiliate\Model\Service\AccountService;
use Aheadworks\Affiliate\Model\Source\Account\Status as AccountStatus;
use Aheadworks\Affiliate\Model\Source\Transaction\Status as TransactionStatus;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Aheadworks\Affiliate\Model\Customer\Data\EmailUpdater;

/**
 * Class DeleteProcessor
 * @package Aheadworks\Affiliate\Model\Customer
 */
class DeleteProcessor
{
    /**
     * @var AccountService
     */
    private $accountService;

    /**
     * @var TransactionHoldingPeriodDataProvider
     */
    private $transactionHoldingPeriodDataProvider;

    /**
     * @var CouponManager
     */
    private $couponManager;

    /**
     * @var TransactionService
     */
    private $transactionService;

    /**
     * @var EmailUpdater
     */
    private $emailUpdater;

    /**
     * @param AccountService $accountService
     * @param CouponManager $couponManager
     * @param TransactionService $transactionService
     * @param TransactionHoldingPeriodDataProvider $transactionHoldingPeriodDataProvider
     * @param EmailUpdater $emailUpdater
     */
    public function __construct(
        AccountService $accountService,
        CouponManager $couponManager,
        TransactionService $transactionService,
        TransactionHoldingPeriodDataProvider $transactionHoldingPeriodDataProvider,
        EmailUpdater $emailUpdater
    ) {
        $this->accountService = $accountService;
        $this->couponManager = $couponManager;
        $this->transactionService = $transactionService;
        $this->transactionHoldingPeriodDataProvider = $transactionHoldingPeriodDataProvider;
        $this->emailUpdater = $emailUpdater;
    }

    /**
     * Process customer deletion related actions
     *
     * @param AccountInterface $account
     * phpcs:disable Magento2.CodeAnalysis.EmptyBlock.DetectedCatch
     */
    public function process(AccountInterface $account)
    {
        try {
            $this->changeAccountData($account);
            $this->couponManager->deleteCouponsByAccount($account);
            $this->cancelUnexpiredTransactions($account);
        } catch (LocalizedException $e) {
        }
    }

    /**
     * Change account status
     *
     * @param AccountInterface $account
     * @throws CouldNotSaveException
     * @throws NoSuchEntityException
     */
    private function changeAccountData(AccountInterface $account)
    {
        $account->setStatus(AccountStatus::DELETED);
        $account->setEmail($this->emailUpdater->getConcatenatedEmail($account->getEmail()));
        $this->accountService->updateAccount($account);
    }

    /**
     * Cancel unexpired transactions
     *
     * @param AccountInterface $account
     * @throws CouldNotSaveException
     */
    private function cancelUnexpiredTransactions(AccountInterface $account)
    {
        $transactions = $this->transactionHoldingPeriodDataProvider->getUnexpiredTransactionsByAffiliate($account);
        foreach ($transactions as $transaction) {
            $this->transactionService->updateTransactionStatus(
                $transaction->getTransactionId(),
                TransactionStatus::CANCELED
            );
        }
    }
}
