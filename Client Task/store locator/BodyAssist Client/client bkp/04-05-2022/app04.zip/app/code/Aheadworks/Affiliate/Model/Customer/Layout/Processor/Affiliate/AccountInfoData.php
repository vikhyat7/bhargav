<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Customer\Layout\Processor\Affiliate;

use Aheadworks\Affiliate\Model\Layout\LayoutProcessorInterface;
use Magento\Framework\Stdlib\ArrayManager;
use Aheadworks\Affiliate\Api\AccountRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Magento\Framework\Reflection\DataObjectProcessor;
use Aheadworks\Affiliate\Model\Account\Data\Extractor as AccountDataExtractor;

/**
 * Class AccountInfoData
 *
 * @package Aheadworks\Affiliate\Model\Customer\Layout\Processor\Affiliate
 */
class AccountInfoData implements LayoutProcessorInterface
{
    /**
     * @var ArrayManager
     */
    private $arrayManager;

    /**
     * @var AccountRepositoryInterface
     */
    private $accountRepository;

    /**
     * @var DataObjectProcessor
     */
    private $dataObjectProcessor;

    /**
     * @var AccountDataExtractor
     */
    private $accountDataExtractor;

    /**
     * @param ArrayManager $arrayManager
     * @param AccountRepositoryInterface $accountRepository
     * @param DataObjectProcessor $dataObjectProcessor
     * @param AccountDataExtractor $accountDataExtractor
     */
    public function __construct(
        ArrayManager $arrayManager,
        AccountRepositoryInterface $accountRepository,
        DataObjectProcessor $dataObjectProcessor,
        AccountDataExtractor $accountDataExtractor
    ) {
        $this->arrayManager = $arrayManager;
        $this->accountRepository = $accountRepository;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->accountDataExtractor = $accountDataExtractor;
    }

    /**
     * {@inheritdoc}
     */
    public function process($jsLayout, $customerId, $websiteId)
    {
        $accountInfoConfigProviderPath = 'components/awAffAccountInfoFormProvider';
        $jsLayout = $this->arrayManager->merge(
            $accountInfoConfigProviderPath,
            $jsLayout,
            [
                'data' => $this->getAffiliateAccountInfo($customerId, $websiteId)
            ]
        );

        return $jsLayout;
    }

    /**
     * Retrieve affiliate account info fields data for the current customer
     *
     * @param int|null $customerId
     * @param int|null $websiteId
     * @return array
     */
    private function getAffiliateAccountInfo($customerId, $websiteId)
    {
        try {
            /** @var AccountInterface $account */
            $account = $this->accountRepository->getByCustomerId($customerId, $websiteId);
            $accountData = $this->dataObjectProcessor->buildOutputDataArray($account, AccountInterface::class);
            $accountInfo = $this->accountDataExtractor->extractInfoFields($accountData);
        } catch (\Exception $exception) {
            $accountInfo = [];
        }
        return $accountInfo;
    }
}
