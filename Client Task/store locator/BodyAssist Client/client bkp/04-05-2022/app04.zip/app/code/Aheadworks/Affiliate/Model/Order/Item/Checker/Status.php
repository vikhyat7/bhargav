<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Order\Item\Checker;

use Magento\Sales\Model\Order\Item as OrderItem;
use Magento\Catalog\Model\Product\Type\AbstractType as AbstractProductType;

/**
 * Class Status
 *
 * @package Aheadworks\Affiliate\Model\Order\Item\Checker
 */
class Status
{
    /**
     * @var array
     */
    private $statusesToCheckByChildrenItems = [];

    /**
     * @param array $statusesToCheckByChildrenItems
     */
    public function __construct(
        $statusesToCheckByChildrenItems = []
    ) {
        $this->statusesToCheckByChildrenItems = $statusesToCheckByChildrenItems;
    }

    /**
     * @param OrderItem $orderItem
     * @param int $statusId
     * @return bool
     */
    public function isItemInStatus($orderItem, $statusId)
    {
        $isItemInStatus = false;

        if ($this->isNeedToCheckChildrenItems($orderItem, $statusId)) {
            $childrenItems = $orderItem->getChildrenItems();
            if (is_array($childrenItems)) {
                $isAllChildrenItemsInStatus = true;
                /** @var OrderItem $childrenOrderItem */
                foreach ($childrenItems as $childrenOrderItem) {
                    if ($childrenOrderItem->getStatusId() != $statusId) {
                        $isAllChildrenItemsInStatus = false;
                        break;
                    }
                }
                $isItemInStatus = $isAllChildrenItemsInStatus;
            }
        } else {
            $isItemInStatus = $orderItem->getStatusId() == $statusId;
        }

        return $isItemInStatus;
    }

    /**
     * @param OrderItem $orderItem
     * @param int $statusId
     * @return bool
     */
    private function isNeedToCheckChildrenItems($orderItem, $statusId)
    {
        $calculationType = $orderItem->isChildrenCalculated()
            ? AbstractProductType::CALCULATE_CHILD
            : AbstractProductType::CALCULATE_PARENT
        ;
        $shipmentType = $orderItem->isShipSeparately()
            ? AbstractProductType::SHIPMENT_SEPARATELY
            : AbstractProductType::SHIPMENT_TOGETHER
        ;
        return isset($this->statusesToCheckByChildrenItems[$calculationType])
            && isset($this->statusesToCheckByChildrenItems[$calculationType][$shipmentType])
            && in_array($statusId, $this->statusesToCheckByChildrenItems[$calculationType][$shipmentType]);
    }
}
