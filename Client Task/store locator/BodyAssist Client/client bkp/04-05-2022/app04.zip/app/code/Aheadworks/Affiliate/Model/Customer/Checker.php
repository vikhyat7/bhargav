<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Customer;

use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Aheadworks\Affiliate\Model\Source\Account\Status;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Store\Api\StoreWebsiteRelationInterface;
use Aheadworks\Affiliate\Api\Data\SignupInterface;
use Aheadworks\Affiliate\Api\SignupRepositoryInterface;
use Aheadworks\Affiliate\Model\Source\Signup\Status as SignupStatusSource;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Api\SearchCriteria;
use Aheadworks\Affiliate\Api\AccountRepositoryInterface;

/**
 * Class Checker
 *
 * @package Aheadworks\Affiliate\Model\Customer
 */
class Checker
{
    /**
     * @var AccountRepositoryInterface
     */
    private $accountRepository;

    /**
     * @var StoreWebsiteRelationInterface
     */
    private $storeWebsiteRelation;

    /**
     * @var SignupRepositoryInterface
     */
    private $signupRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    private $searchCriteriaBuilder;

    /**
     * @param AccountRepositoryInterface $accountRepository
     * @param StoreWebsiteRelationInterface $storeWebsiteRelation
     * @param SignupRepositoryInterface $signupRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     */
    public function __construct(
        AccountRepositoryInterface $accountRepository,
        StoreWebsiteRelationInterface $storeWebsiteRelation,
        SignupRepositoryInterface $signupRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder
    ) {
        $this->accountRepository = $accountRepository;
        $this->storeWebsiteRelation = $storeWebsiteRelation;
        $this->signupRepository = $signupRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
    }

    /**
     * Check if customer already has affiliate account
     *
     * @param int|null $customerId
     * @param int|null $websiteId
     * @return bool
     */
    public function isCustomerHasAffiliateAccount($customerId, $websiteId)
    {
        $isCustomerHasAffiliateAccount = false;
        if (!empty($customerId) && !empty($websiteId)) {
            try {
                /** @var AccountInterface $affiliateAccount */
                $affiliateAccount = $this->accountRepository->getByCustomerId($customerId, $websiteId);
                if (!empty($affiliateAccount)) {
                    $isCustomerHasAffiliateAccount = true;
                }
            } catch (NoSuchEntityException $e) {
                $isCustomerHasAffiliateAccount = false;
            }
        }
        return $isCustomerHasAffiliateAccount;
    }

    /**
     * Check if customer has active affiliate signup request
     *
     * @param int|null $customerId
     * @param int|null $websiteId
     * @return bool
     */
    public function isCustomerHasActiveSignupRequest($customerId, $websiteId)
    {
        $isCustomerHasActiveSignupRequest = false;
        if (!empty($customerId) && !empty($websiteId)) {
            /** @var SignupInterface[] $activeSignupRequests */
            $activeSignupRequests = $this->getActiveSignupRequests($customerId, $websiteId);
            $isCustomerHasActiveSignupRequest = (count($activeSignupRequests) > 0);
        }
        return $isCustomerHasActiveSignupRequest;
    }

    /**
     * Check if affiliate account is active
     *
     * @param int|null $customerId
     * @param int|null $websiteId
     * @return bool
     */
    public function isAffiliateAccountActive($customerId, $websiteId)
    {
        $isActive = false;

        try {
            $affiliateAccount = $this->accountRepository->getByCustomerId($customerId, $websiteId);
            $isActive = $affiliateAccount->getStatus() == Status::ACTIVE;
        } catch (NoSuchEntityException $e) {
            $isActive = false;
        }

        return $isActive;
    }

    /**
     * Check if affiliate account has all necessary payment information
     *
     * @param int|null $customerId
     * @param int|null $websiteId
     * @return bool
     */
    public function isAffiliatePaymentInfoSpecified($customerId, $websiteId)
    {
        $isPaymentInfoSpecified = false;

        try {
            $affiliateAccount = $this->accountRepository->getByCustomerId($customerId, $websiteId);
            $isPaymentInfoSpecified =
                !empty($affiliateAccount->getPaymentType())
                && !empty($affiliateAccount->getPaymentInfo())
            ;
        } catch (NoSuchEntityException $e) {
            $isPaymentInfoSpecified = false;
        }

        return $isPaymentInfoSpecified;
    }

    /**
     * Retrieve array of active signup requests for definite customer within specific website
     *
     * @param int $customerId
     * @param int $websiteId
     * @return SignupInterface[]
     */
    private function getActiveSignupRequests($customerId, $websiteId)
    {
        /** @var array $websiteStoreIds */
        $websiteStoreIds = $this->storeWebsiteRelation->getStoreByWebsiteId($websiteId);
        /** @var SearchCriteria $searchCriteria */
        $searchCriteria = $this->searchCriteriaBuilder
            ->addFilter(SignupInterface::CUSTOMER_ID, $customerId)
            ->addFilter(SignupInterface::STORE_ID, $websiteStoreIds, 'in')
            ->addFilter(SignupInterface::STATUS, SignupStatusSource::getActiveStatuses(), 'in')
            ->create();
        return $this->signupRepository->getList($searchCriteria)->getItems();
    }
}
