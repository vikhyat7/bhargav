define([
    'underscore',
    'Magento_Ui/js/grid/columns/column'
], function (_, Component) {
    'use strict';

    return Component.extend({
        defaults: {
            linkActions: [],
            ignoreTmpls: {
                linkActions: true
            }
        },

        /**
         * Link action
         *
         * @param record
         * @return {*|void}
         */
        getLinkAction: function (record) {
            var me = this;

            _.each(this.linkActions, function (action) {
                var fieldName = action.field ? action.field : '',
                    fieldValue = me._getFieldValue(record, fieldName);

                me.applySingleAction(fieldValue, action);
            });

            return this;
        },

        /**
         * Check is disabled
         *
         * @param record
         * @return {Boolean}
         */
        isDisabled: function (record) {
            return Number(record.is_link_generation_allowed) === 0;
        },

        /**
         * Retrieve field value
         *
         * @param {Object} source
         * @param {String} pathStr
         * @return {*}
         * @private
         */
        _getFieldValue: function (source, pathStr) {
            var path = pathStr.split('/'),
                value = null;

            _.each(path, function (prop) {
                if (_.has(source, prop)) {
                    value = source[prop];
                    source = _.isObject(value) ? value : {}
                }
            });

            return value;
        }
    });
});
