<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Transaction;

use Aheadworks\Affiliate\Model\Source\Transaction\Status;

/**
 * Class StatusResolver
 * @package Aheadworks\Affiliate\Model\Transaction
 */
class StatusResolver
{
    /**
     * @var array
     */
    private $statusTransformationMap = [
        Status::PENDING => [Status::COMPLETE, Status::CANCELED],
        Status::COMPLETE => [],
        Status::CANCELED => []
    ];

    /**
     * Check if transaction status can be changed
     *
     * @param string $newStatus
     * @param string $currentStatus
     * @return bool
     */
    public function isStatusAllowedForTransaction($newStatus, $currentStatus)
    {
        return ($newStatus != $currentStatus)
            && isset($this->statusTransformationMap[$currentStatus])
            && in_array($newStatus, $this->statusTransformationMap[$currentStatus]);
    }
}
