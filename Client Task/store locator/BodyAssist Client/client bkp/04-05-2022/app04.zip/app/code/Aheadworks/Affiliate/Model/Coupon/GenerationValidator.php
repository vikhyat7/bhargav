<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Model\Coupon;

use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Aheadworks\Affiliate\Model\Campaign\Validator\Account as CampaignAccountValidator;
use Aheadworks\Affiliate\Model\Source\Campaign\CouponUsageMode;
use Magento\Framework\Exception\LocalizedException;

/**
 * Class GenerationValidator
 * @package Aheadworks\Affiliate\Model\Coupon
 */
class GenerationValidator
{
    /**
     * @var CampaignAccountValidator
     */
    private $campaignAccountValidator;

    /**
     * @param CampaignAccountValidator $campaignAccountValidator
     */
    public function __construct(
        CampaignAccountValidator $campaignAccountValidator
    ) {
        $this->campaignAccountValidator = $campaignAccountValidator;
    }

    /**
     * Can generate coupon
     *
     * @param AccountInterface $account
     * @param CampaignInterface $campaign
     * @return bool
     * @throws LocalizedException
     */
    public function validate($account, $campaign)
    {
        if ($campaign->getCouponUsageMode() == CouponUsageMode::NO_COUPON) {
            throw new LocalizedException(__('This campaign doesn\'t allow coupon generation.'));
        }
        if (!$this->campaignAccountValidator->validate($account, $campaign, $campaign->getWebsiteId())) {
            throw new LocalizedException(__('This campaign isn\'t available for affiliate.'));
        }
        if (empty($campaign->getCouponCodeTemplate())) {
            throw new LocalizedException(__('Campaign coupon code template isn\'t set.'));
        }
        if (empty($account->getUniqueCouponPrefix())) {
            throw new LocalizedException(__('Affiliate coupon prefix isn\'t set.'));
        }

        return true;
    }
}
