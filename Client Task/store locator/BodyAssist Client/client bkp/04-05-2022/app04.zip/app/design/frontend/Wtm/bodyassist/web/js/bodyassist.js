require(['jquery','slick', 'jquery/ui'], function ($) {
$( document ).ready(function() {
// Remove title from product page in tab
		jQuery(".data.item.content").each(function(){
			var athis = jQuery(this); 
			if(jQuery(athis.find(".value")).html().trim().length == 0 ){
    				athis.prev().remove();
    				athis.remove();
		}
		});
		jQuery(".data.item.title").first().click();
		
});
});
