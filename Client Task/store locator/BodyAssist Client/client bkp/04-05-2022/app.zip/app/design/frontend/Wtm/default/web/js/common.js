require(['jquery','slick', 'jquery/ui'], function ($) {
	$(document).ready(function () {
		// Remove title from product page in tab
		jQuery(".data.item.content").each(function(){
			var athis = jQuery(this); 
			if(jQuery(athis.find(".value")).html().trim().length == 0 ){
    				athis.prev().remove();
    				athis.remove();
		}
		});
		jQuery(".data.item.title").first().click();
		
		


		// Add class in parent
 		$(".pages .pages-items:has(.pages-item-previous)").addClass("pages-items-previous"); 
 		$(".category-des-wrapper:has(.category-image)").addClass("has-cat-image");
		
		// Category Accordion  
		$(".cat-design > ul > li.first-cat-nav a .arrow").click(function(e) { 
			e.preventDefault(); 
			e.stopPropagation();
			if( $(this).closest(".cat-design > ul > li.first-cat-nav").find(".sub-cat-nav").hasClass("open")){
				$(this).closest(".cat-design > ul > li.first-cat-nav").find(".sub-cat-nav").removeClass("open");
			}
			else {
				$(this).closest(".cat-design > ul").find(".sub-cat-nav").removeClass("open");
				$(this).closest(".cat-design > ul > li.first-cat-nav").find(".sub-cat-nav").addClass("open"); 
			}
		});
		jQuery(".product.attribute.description:not(:first)").remove();
		// Add class in image for active Circle
		jQuery(".cat-design > ul > li.first-cat-nav a .arrow").click(function(e) {
			e.preventDefault(); 
			e.stopPropagation();
			if( jQuery(this).closest(".first-cat-nav").find(".cat-image").hasClass("open")){
				jQuery(this).closest(".first-cat-nav").find(".cat-image").removeClass("open");
			}
			else {
				jQuery(this).closest(".cat-design > ul").find(".cat-image").removeClass("open");
				jQuery(this).closest(".first-cat-nav").find(".cat-image").addClass("open"); 
			}
		});
		 
		// Category Accordion Arrow
		$(".cat-design > ul > li.first-cat-nav a .arrow").click(function(e){ 
			e.preventDefault(); 
			e.stopPropagation();
			if( $(this).closest(".cat-design > ul > li.first-cat-nav").find(".arrow").hasClass("open")){
				$(this).closest(".cat-design > ul > li.first-cat-nav").find(".arrow").removeClass("open");
				}else{
				$(this).closest(".cat-design > ul").find(".arrow").removeClass("open");
				$(this).closest(".cat-design > ul > li.first-cat-nav").find(".arrow").addClass("open"); 
			}   
		});
		
		$("li.level-0:not(:has(.submenu))").removeClass("is-submenu");
 		$("li.level-1:has(.level-3-row)").addClass("level-3-submenu"); 
 		// Mobile Menu Start
		if (window.matchMedia('(max-width: 767px)').matches) { 
			$(".nav-sections-row ul.nav li.level-0.is-submenu > a").click(function(e){ 
				e.preventDefault(); 
				e.stopPropagation();
				if( $(this).closest("ul.nav li.level-0").find(".submenu").hasClass("open")){
					$(this).closest("ul.nav li.level-0").find(".submenu").removeClass("open");
					}else{
					$(this).closest("ul.nav").find(".submenu").removeClass("open");
					$(this).closest("ul.nav li.level-0").find(".submenu").addClass("open");
				}
			}); 
			$(".nav-sections-row ul.nav li.level-0.is-submenu > a").click(function(e){ 
				e.preventDefault(); 
				e.stopPropagation();
				if( $(this).closest("ul.nav li.level-0").find(".level-link").hasClass("open")){
					$(this).closest("ul.nav li.level-0").find(".level-link").removeClass("open");
					}else{
					$(this).closest("ul.nav").find(".level-link").removeClass("open");
					$(this).closest("ul.nav li.level-0").find(".level-link").addClass("open"); 
				}
			});
			$("ul.level-2-row li.level-1 > a").click(function(e){ 
				e.preventDefault(); 
				e.stopPropagation();
				if( $(this).closest(".level-1").hasClass("open")){
					$(this).closest(".level-1").removeClass("open");
					}else{
					$(this).closest(".level-2-row").removeClass("open");
					$(this).closest(".level-1").addClass("open"); 
				}
			});  
		} 
	}); 
});
   
