<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Ui\Component\Transaction\Frontend\Listing\Column;

use Aheadworks\Affiliate\Ui\Component\Listing\Column\FormattedPrice;

/**
 * Class Amount
 *
 * @package Aheadworks\Affiliate\Ui\Component\Transaction\Frontend\Listing\Column
 */
class Amount extends FormattedPrice
{
    /**
     * {@inheritdoc}
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$item) {
                $originalValue = $this->arrayManager->get($this->getData('name'), $item);
                $item[$this->getData('name')] = $this->getFormattedValue(
                    $originalValue,
                    $this->arrayManager->get(self::WEBSITE_ID, $item)
                );
                $item[$this->getData('name') . '_field_class'] = $this->getAdditionalFieldClass($originalValue);
            }
        }
        return $dataSource;
    }

    /**
     * {@inheritdoc}
     */
    protected function getFormattedValue($value, $websiteId)
    {
        $formattedValue = (($value >= 0) ? '+' : '') . parent::getFormattedValue($value, $websiteId);
        return $formattedValue;
    }

    /**
     * Retrieve additional CSS class for field
     *
     * @param float $value
     * @return string
     */
    protected function getAdditionalFieldClass($value)
    {
        if ($value >= 0) {
            $fieldClass = 'positive';
        } else {
            $fieldClass = 'negative';
        }
        return $fieldClass;
    }
}
