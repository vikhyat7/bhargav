<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Campaign;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Aheadworks\Affiliate\Api\CampaignRepositoryInterface;
use Aheadworks\Affiliate\Api\CampaignManagementInterface;
use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Magento\Framework\Exception\CouldNotSaveException;

/**
 * Class AbstractChangeStatusAction
 *
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Campaign
 */
abstract class AbstractChangeStatusAction extends Action
{
    /**
     * {@inheritdoc}
     */
    const ADMIN_RESOURCE = 'Aheadworks_Affiliate::campaigns';

    /**
     * @var CampaignRepositoryInterface
     */
    protected $campaignRepository;

    /**
     * @var CampaignManagementInterface
     */
    protected $campaignService;

    /**
     * @param Context $context
     * @param CampaignRepositoryInterface $campaignRepository
     * @param CampaignManagementInterface $campaignService
     */
    public function __construct(
        Context $context,
        CampaignRepositoryInterface $campaignRepository,
        CampaignManagementInterface $campaignService
    ) {
        parent::__construct($context);
        $this->campaignRepository = $campaignRepository;
        $this->campaignService = $campaignService;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($campaignId = $this->getRequest()->getParam(CampaignInterface::ID, false)) {
            try {
                /** @var CampaignInterface $campaign */
                $campaign = $this->campaignRepository->getById($campaignId);
                $campaign->setStatus($this->getStatusToSet());
                $this->campaignService->updateCampaign($campaign);
                $this->messageManager->addSuccessMessage($this->getSuccessMessage());
                return $resultRedirect->setPath('*/*/');
            } catch (CouldNotSaveException $exception) {
                $this->messageManager->addErrorMessage($exception->getMessage());
            } catch (\Exception $exception) {
                $this->messageManager->addExceptionMessage(
                    $exception,
                    $this->getErrorMessage()
                );
            }
            return $resultRedirect->setPath('*/*/edit', [CampaignInterface::ID => $campaignId]);
        }
        return $resultRedirect->setPath('*/*/');
    }

    /**
     * Retrieve status id to set
     *
     * @return int
     */
    abstract protected function getStatusToSet();

    /**
     * Retrieve success message
     *
     * @return string
     */
    abstract protected function getSuccessMessage();

    /**
     * Retrieve error message
     *
     * @return string
     */
    abstract protected function getErrorMessage();
}
