define([
    'jquery',
    'underscore',
    'Magento_Ui/js/form/element/abstract',
    'Magento_Ui/js/lib/validation/rules',
    'mage/translate'
], function ($, _, Input, rules, $t) {
    'use strict';

    return Input.extend({

        /**
         * {@inheritdoc}
         */
        initialize: function () {
            this._super()
                ._addValidationRule();

            return this;
        },

        /**
         * Add validation rule
         *
         * @private
         */
        _addValidationRule: function () {
            _.extend(rules, {
                'validate-not-zero': {
                    handler: function (value) {
                        return Number(value) !== 0 && $.validator.methods['validate-number'](value);
                    },
                    message: $t('Please enter a number except 0 in this field.')
                }
            });
        }
    });
});
