<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Signup;

use Magento\Backend\App\Action;
use Aheadworks\Affiliate\Api\SignupManagementInterface;
use Aheadworks\Affiliate\Api\Data\SignupInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Backend\App\Action\Context;

/**
 * Class Delete
 *
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Signup
 */
class Delete extends Action
{
    /**
     * {@inheritdoc}
     */
    const ADMIN_RESOURCE = 'Aheadworks_Affiliate::signups';

    /**
     * @var SignupManagementInterface
     */
    private $signupService;

    /**
     * @param Context $context
     * @param SignupManagementInterface $signupService
     */
    public function __construct(
        Context $context,
        SignupManagementInterface $signupService
    ) {
        parent::__construct($context);
        $this->signupService = $signupService;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();

        if ($signupId = $this->getRequest()->getParam(SignupInterface::ID, false)) {
            try {
                $this->signupService->deleteSignupById($signupId);
                $this->messageManager->addSuccessMessage(__('The signup request was successfully deleted.'));
                return $resultRedirect->setPath('*/*/');
            } catch (CouldNotDeleteException $exception) {
                $this->messageManager->addErrorMessage($exception->getMessage());
            } catch (\Exception $exception) {
                $this->messageManager->addExceptionMessage(
                    $exception,
                    __('Something went wrong while deleting the signup request.')
                );
            }
            return $resultRedirect->setPath('*/*/edit', [SignupInterface::ID => $signupId]);
        }
        return $resultRedirect->setPath('*/*/');
    }
}
