<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Setup;

use Aheadworks\Affiliate\Model\Customer\Data\EmailUpdater;
use Aheadworks\Affiliate\Model\ResourceModel\Account as AffiliateAccountResource;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Aheadworks\Affiliate\Model\Source\Account\Status;
use Magento\Framework\Setup\UpgradeDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;

/**
 * Class UpgradeData
 * @package Aheadworks\Affiliate\Setup
 */
class UpgradeData implements UpgradeDataInterface
{
    /**
     * @var EmailUpdater
     */
    private $emailUpdater;

    /**
     * @param EmailUpdater $emailUpdater
     */
    public function __construct(
        EmailUpdater $emailUpdater
    ) {
        $this->emailUpdater = $emailUpdater;
    }
    /**
     * {@inheritdoc}
     */
    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        if (version_compare($context->getVersion(), '1.0.1', '<')) {
            $this->editDeletedAccountEmail101($setup);
        }

        $setup->endSetup();
    }

    /**
     * Update email of deleted customers
     *
     * @param ModuleDataSetupInterface $setup
     */
    private function editDeletedAccountEmail101(ModuleDataSetupInterface $setup)
    {
        $connection = $setup->getConnection();
        $table = $setup->getTable(AffiliateAccountResource::MAIN_TABLE_NAME);
        $select = $connection->select()->from(
            $table,
            [
                AccountInterface::ID,
                AccountInterface::STATUS,
                AccountInterface::EMAIL
            ]
        )->where(AccountInterface::STATUS . ' = ?', Status::DELETED);
        $accounts = $connection->fetchAssoc($select);
        foreach ($accounts as $account) {
            $updatedEmail = $this->emailUpdater->getSimplyConcatenatedEmail($account[AccountInterface::EMAIL]);

            $connection->update(
                $table,
                [
                    AccountInterface::EMAIL => $updatedEmail
                ],
                AccountInterface::ID . ' = ' . $account[AccountInterface::ID]
            );
        }
    }
}
