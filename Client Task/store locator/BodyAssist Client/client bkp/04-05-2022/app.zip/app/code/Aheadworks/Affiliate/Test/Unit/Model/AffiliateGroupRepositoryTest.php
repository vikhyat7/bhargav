<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Model;

use Aheadworks\Affiliate\Api\Data\AffiliateGroupInterface;
use Aheadworks\Affiliate\Api\Data\AffiliateGroupInterfaceFactory;
use Aheadworks\Affiliate\Api\Data\AffiliateGroupSearchResultsInterface;
use Aheadworks\Affiliate\Api\Data\AffiliateGroupSearchResultsInterfaceFactory;
use Aheadworks\Affiliate\Model\AffiliateGroup as AffiliateGroupModel;
use Aheadworks\Affiliate\Model\ResourceModel\AffiliateGroup as AffiliateGroupResourceModel;
use Aheadworks\Affiliate\Model\ResourceModel\AffiliateGroup\Collection as AffiliateGroupCollection;
use Aheadworks\Affiliate\Model\ResourceModel\AffiliateGroup\CollectionFactory as AffiliateGroupCollectionFactory;
use Aheadworks\Affiliate\Model\AffiliateGroup;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Aheadworks\Affiliate\Model\AffiliateGroupRepository;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;

/**
 * Class AffiliateGroupRepositoryTest
 *
 * @package Aheadworks\Affiliate\Test\Unit\Model
 */
class AffiliateGroupRepositoryTest extends TestCase
{
    /**
     * @var AffiliateGroupResourceModel|\PHPUnit_Framework_MockObject_MockObject
     */
    private $resourceMock;

    /**
     * @var AffiliateGroupInterfaceFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $affiliateGroupInterfaceFactoryMock;

    /**
     * @var AffiliateGroupCollectionFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $affiliateGroupCollectionFactoryMock;

    /**
     * @var AffiliateGroupSearchResultsInterfaceFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $searchResultsFactoryMock;

    /**
     * @var JoinProcessorInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $extensionAttributesJoinProcessorMock;

    /**
     * @var CollectionProcessorInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $collectionProcessorMock;

    /**
     * @var DataObjectHelper|\PHPUnit_Framework_MockObject_MockObject
     */
    private $dataObjectHelperMock;

    /**
     * @var DataObjectProcessor|\PHPUnit_Framework_MockObject_MockObject
     */
    private $dataObjectProcessorMock;

    /**
     * @var AffiliateGroupRepository
     */
    private $affiliateGroupRepository;

    /**#@+
     * Constants used for tests
     */
    const DEFAULT_ID = 2;
    const DELETING_DEFAULT_GROUP_EXC_CODE = 1;
    /**#@-*/

    /**
     * Init mocks for tests
     *
     * @return void
     */
    protected function setUp() : void
    {
        $objectManager = new ObjectManager($this);
        $this->resourceMock = $this->createMock(AffiliateGroupResourceModel::class);
        $this->affiliateGroupInterfaceFactoryMock = $this->createMock(AffiliateGroupInterfaceFactory::class);
        $this->affiliateGroupCollectionFactoryMock = $this->createMock(AffiliateGroupCollectionFactory::class);
        $this->searchResultsFactoryMock = $this->createMock(AffiliateGroupSearchResultsInterfaceFactory::class);
        $this->extensionAttributesJoinProcessorMock = $this->createMock(JoinProcessorInterface::class);
        $this->collectionProcessorMock = $this->createMock(CollectionProcessorInterface::class);
        $this->dataObjectHelperMock = $this->createMock(DataObjectHelper::class);
        $this->dataObjectProcessorMock = $this->createMock(DataObjectProcessor::class);
        $this->affiliateGroupRepository = $objectManager->getObject(
            AffiliateGroupRepository::class,
            [
                'resource' => $this->resourceMock,
                'affiliateGroupInterfaceFactory' => $this->affiliateGroupInterfaceFactoryMock,
                'affiliateGroupCollectionFactory' => $this->affiliateGroupCollectionFactoryMock,
                'searchResultsFactory' => $this->searchResultsFactoryMock,
                'extensionAttributesJoinProcessor' => $this->extensionAttributesJoinProcessorMock,
                'collectionProcessor' => $this->collectionProcessorMock,
                'dataObjectHelper' => $this->dataObjectHelperMock,
                'dataObjectProcessor' => $this->dataObjectProcessorMock
            ]
        );
    }

    /**
     * Test save method
     *
     * @throws CouldNotSaveException
     */
    public function testSave()
    {
        $affiliateGroupMock = $this->getAffiliateGroupMock(AffiliateGroupInterface::class);

        $this->resourceMock->expects($this->once())
            ->method('save')
            ->willReturnSelf();

        $this->assertSame($affiliateGroupMock, $this->affiliateGroupRepository->save($affiliateGroupMock));
    }

    /**
     * Test save method with exception
     *
     * @expectedException \Magento\Framework\Exception\CouldNotSaveException
     * @expectedExceptionMessage Test message
     * @throws CouldNotSaveException
     */
    public function testSaveWithException()
    {
        $exception = new \Exception('Test message');
        $affiliateGroupMock = $this->getAffiliateGroupMock();
        $this->resourceMock->expects($this->once())
            ->method('save')
            ->with($affiliateGroupMock)
            ->willThrowException($exception);
        $this->expectException(CouldNotSaveException::class);
        $this->affiliateGroupRepository->save($affiliateGroupMock);
    }

    /**
     * Test delete method
     *
     * @throws CouldNotDeleteException
     */
    public function testDelete()
    {
        $affiliateGroupMock = $this->getAffiliateGroupMock();

        $this->resourceMock->expects($this->once())
            ->method('delete')
            ->with($affiliateGroupMock);

        $this->assertTrue($this->affiliateGroupRepository->delete($affiliateGroupMock));
    }

    /**
     * Test delete method with exception
     *
     * @param AffiliateGroupInterface|\PHPUnit_Framework_MockObject_MockObject
     * @param CouldNotDeleteException $exception
     * @param string $exceptionMsg
     * @dataProvider testDeleteWithExceptionProvider
     * @expectedException \Magento\Framework\Exception\CouldNotDeleteException
     * @throws CouldNotDeleteException
     */
    public function testDeleteWithException($affiliateGroupMock, $exception, $exceptionMsg)
    {
        if ($exception->getCode() != self::DELETING_DEFAULT_GROUP_EXC_CODE) {
            $this->resourceMock->expects($this->once())
                ->method('delete')
                ->willThrowException($exception);
        }
        $this->expectExceptionMessage($exceptionMsg);

        $this->assertTrue($this->affiliateGroupRepository->delete($affiliateGroupMock));
    }

    /**
     * Test getById method
     *
     * @throws NoSuchEntityException
     */
    public function testGetById()
    {
        $affiliateGroupMock = $this->getAffiliateGroupMock();

        $this->affiliateGroupInterfaceFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($affiliateGroupMock);
        $this->resourceMock->expects($this->once())
            ->method('load')
            ->with($affiliateGroupMock, self::DEFAULT_ID)
            ->willReturnSelf();

        $this->assertSame($affiliateGroupMock, $this->affiliateGroupRepository->getById(self::DEFAULT_ID));
    }

    /**
     * Test getById method with exception
     *
     * @throws NoSuchEntityException
     * @expectedException \Magento\Framework\Exception\NoSuchEntityException
     * @expectedExceptionMessage No such entity with affiliate_group_id = 2
     */
    public function testGetByIdWithException()
    {
        $affiliateGroupMock = $this->getAffiliateGroupMock(null);

        $this->affiliateGroupInterfaceFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($affiliateGroupMock);
        $this->resourceMock->expects($this->once())
            ->method('load')
            ->with($affiliateGroupMock, self::DEFAULT_ID)
            ->willReturnSelf();
        $this->expectException(NoSuchEntityException::class);
        $this->assertSame($affiliateGroupMock, $this->affiliateGroupRepository->getById(self::DEFAULT_ID));
    }

    /**
     * Test getList method
     *
     * @param array $collectionItems
     * @param array $searchResultItems
     * @param AffiliateGroupModel|null|\PHPUnit_Framework_MockObject_MockObject $affiliateGroupModelMock
     * @dataProvider testGetListProvider
     */
    public function testGetList($collectionItems, $searchResultItems, $affiliateGroupModelMock = null)
    {
        /** @var SearchCriteriaInterface|\PHPUnit_Framework_MockObject_MockObject $searchCriteriaMock */
        $searchCriteriaMock = $this->createMock(SearchCriteriaInterface::class);
        $collectionSize = count($collectionItems);
        $affiliateGroupCollectionMock = $this->createMock(AffiliateGroupCollection::class);
        $searchResultsMock = $this->createMock(AffiliateGroupSearchResultsInterface::class);
        $affiliateGroupData = [AffiliateGroupInterface::ID => self::DEFAULT_ID];

        $this->affiliateGroupCollectionFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($affiliateGroupCollectionMock);
        $this->extensionAttributesJoinProcessorMock->expects($this->once())
            ->method('process')
            ->with($affiliateGroupCollectionMock, AffiliateGroupInterface::class);
        $this->collectionProcessorMock->expects($this->once())
            ->method('process')
            ->with($searchCriteriaMock, $affiliateGroupCollectionMock);
        $this->searchResultsFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($searchResultsMock);
        $searchResultsMock->expects($this->once())
            ->method('setSearchCriteria')
            ->with($searchCriteriaMock);
        $affiliateGroupCollectionMock->expects($this->once())
            ->method('getSize')
            ->willReturn($collectionSize);
        $searchResultsMock->expects($this->once())
            ->method('setTotalCount')
            ->with($collectionSize);
        $affiliateGroupCollectionMock->expects($this->once())
            ->method('getItems')
            ->willReturn($collectionItems);
        $this->affiliateGroupInterfaceFactoryMock->expects($this->exactly($collectionSize))
            ->method('create')
            ->willReturn($affiliateGroupModelMock);
        $this->dataObjectProcessorMock->expects($this->exactly($collectionSize))
            ->method('buildOutputDataArray')
            ->with($affiliateGroupModelMock, AffiliateGroupInterface::class)
            ->willReturn($affiliateGroupData);
        $this->dataObjectHelperMock->expects($this->exactly($collectionSize))
            ->method('populateWithArray')
            ->with($affiliateGroupModelMock, $affiliateGroupData, AffiliateGroupInterface::class);
        $searchResultsMock->expects($this->once())
            ->method('setItems')
            ->with($searchResultItems)
            ->willReturnSelf();

        $this->assertSame($searchResultsMock, $this->affiliateGroupRepository->getList($searchCriteriaMock));
    }

    /**
     * Get affiliateGroup mock
     *
     * @param int|null $affiliateGroupId
     * @return AffiliateGroupModel|\PHPUnit_Framework_MockObject_MockObject
     */
    private function getAffiliateGroupMock($affiliateGroupId = self::DEFAULT_ID)
    {
        $affiliateGroupMock = $this->createMock(AffiliateGroupModel::class);

        $affiliateGroupMock->expects($this->atMost(2))
            ->method('getAffiliateGroupId')
            ->willReturn($affiliateGroupId);

        return $affiliateGroupMock;
    }

    /**
     * @return array
     */
    public function testGetListProvider()
    {
        $affiliateGroupModelMock = $this->getAffiliateGroupMock();

        return [
            [[$affiliateGroupModelMock], [$affiliateGroupModelMock], $affiliateGroupModelMock],
            [[],[]]
        ];
    }

    /**
     * @return array
     */
    public function testDeleteWithExceptionProvider()
    {
        return [
            [
                $this->getAffiliateGroupMock(AffiliateGroupInterface::DEFAULT_GROUP_ID),
                new CouldNotDeleteException(
                    __('You cannot delete default affiliate group.'),
                    null,
                    self::DELETING_DEFAULT_GROUP_EXC_CODE
                ),
                'You cannot delete default affiliate group.'
            ],
            [
                $this->getAffiliateGroupMock(),
                new CouldNotDeleteException(__('Can\'t delete exception message.')),
                'Can\'t delete exception message.'
            ]
        ];
    }
}
