<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Ui\Component\Transaction\Frontend\Listing\Column;

use Magento\Ui\Component\Listing\Columns\Column;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Aheadworks\Affiliate\Api\Data\TransactionInterface;
use Aheadworks\Affiliate\Model\Source\Transaction\Type as TransactionType;
use Magento\Framework\Stdlib\ArrayManager;

/**
 * Class Comment
 *
 * @package Aheadworks\Affiliate\Ui\Component\Transaction\Frontend\Listing\Column
 */
class Comment extends Column
{
    /**
     * @var ArrayManager
     */
    private $arrayManager;

    /**
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param ArrayManager $arrayManager
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        ArrayManager $arrayManager,
        array $components = [],
        array $data = []
    ) {
        $this->arrayManager = $arrayManager;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * @inheritdoc
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as & $item) {
                $originalComment = $this->arrayManager->get(
                    $this->getData('name'),
                    $item,
                    ''
                );
                $transactionType = $this->arrayManager->get(
                    TransactionInterface::TYPE,
                    $item,
                    ''
                );
                $item[$this->getData('name')] = $this->getCommentLabel(
                    $transactionType,
                    $originalComment
                );
            }
        }

        return $dataSource;
    }

    /**
     * Retrieve comment label
     *
     * @param string $transactionType
     * @param $originalComment
     * @return \Magento\Framework\Phrase
     */
    private function getCommentLabel($transactionType, $originalComment)
    {
        $commentLabel = $originalComment;
        if ($transactionType == TransactionType::ADMIN_CHANGES) {
            $commentLabel = __("Transaction created by admin.");
        }
        return $commentLabel;
    }
}
