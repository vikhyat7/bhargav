<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Model;

use Aheadworks\Affiliate\Api\Data\SignupInterface;
use Aheadworks\Affiliate\Api\Data\SignupInterfaceFactory;
use Aheadworks\Affiliate\Api\Data\SignupSearchResultsInterface;
use Aheadworks\Affiliate\Api\Data\SignupSearchResultsInterfaceFactory;
use Aheadworks\Affiliate\Model\Signup as SignupModel;
use Aheadworks\Affiliate\Model\ResourceModel\Signup as SignupResourceModel;
use Aheadworks\Affiliate\Model\ResourceModel\Signup\Collection as SignupCollection;
use Aheadworks\Affiliate\Model\ResourceModel\Signup\CollectionFactory as SignupCollectionFactory;
use Aheadworks\Affiliate\Model\Signup;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Aheadworks\Affiliate\Model\SignupRepository;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;

/**
 * Class SignupRepositoryTest
 *
 * @package Aheadworks\Affiliate\Test\Unit\Model
 */
class SignupRepositoryTest extends TestCase
{
    /**
     * @var SignupResourceModel|\PHPUnit_Framework_MockObject_MockObject
     */
    private $resourceMock;

    /**
     * @var SignupInterfaceFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $signupInterfaceFactoryMock;

    /**
     * @var SignupCollectionFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $signupCollectionFactoryMock;

    /**
     * @var SignupSearchResultsInterfaceFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $searchResultsFactoryMock;

    /**
     * @var JoinProcessorInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $extensionAttributesJoinProcessorMock;

    /**
     * @var CollectionProcessorInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $collectionProcessorMock;

    /**
     * @var DataObjectHelper|\PHPUnit_Framework_MockObject_MockObject
     */
    private $dataObjectHelperMock;

    /**
     * @var DataObjectProcessor|\PHPUnit_Framework_MockObject_MockObject
     */
    private $dataObjectProcessorMock;

    /**
     * @var SignupRepository
     */
    private $signupRepository;

    /**#@+
     * Constants used for tests
     */
    const DEFAULT_ID = 1;
    /**#@-*/

    /**
     * Init mocks for tests
     *
     * @return void
     */
    protected function setUp() : void
    {
        $objectManager = new ObjectManager($this);
        $this->resourceMock = $this->createMock(SignupResourceModel::class);
        $this->signupInterfaceFactoryMock = $this->createMock(SignupInterfaceFactory::class);
        $this->signupCollectionFactoryMock = $this->createMock(SignupCollectionFactory::class);
        $this->searchResultsFactoryMock = $this->createMock(SignupSearchResultsInterfaceFactory::class);
        $this->extensionAttributesJoinProcessorMock = $this->createMock(JoinProcessorInterface::class);
        $this->collectionProcessorMock = $this->createMock(CollectionProcessorInterface::class);
        $this->dataObjectHelperMock = $this->createMock(DataObjectHelper::class);
        $this->dataObjectProcessorMock = $this->createMock(DataObjectProcessor::class);
        $this->signupRepository = $objectManager->getObject(
            SignupRepository::class,
            [
                'resource' => $this->resourceMock,
                'signupInterfaceFactory' => $this->signupInterfaceFactoryMock,
                'signupCollectionFactory' => $this->signupCollectionFactoryMock,
                'searchResultsFactory' => $this->searchResultsFactoryMock,
                'extensionAttributesJoinProcessor' => $this->extensionAttributesJoinProcessorMock,
                'collectionProcessor' => $this->collectionProcessorMock,
                'dataObjectHelper' => $this->dataObjectHelperMock,
                'dataObjectProcessor' => $this->dataObjectProcessorMock
            ]
        );
    }

    /**
     * Test save method
     *
     * @throws CouldNotSaveException
     */
    public function testSave()
    {
        $signupMock = $this->getSignupMock(SignupInterface::class);

        $this->resourceMock->expects($this->once())
            ->method('save')
            ->willReturnSelf();

        $this->assertSame($signupMock, $this->signupRepository->save($signupMock));
    }

    /**
     * Test save method with exception
     *
     * @expectedException \Magento\Framework\Exception\CouldNotSaveException
     * @expectedExceptionMessage Test message
     * @throws CouldNotSaveException
     */
    public function testSaveWithException()
    {
        $exception = new \Exception('Test message');
        $signupMock = $this->getSignupMock();
        $this->resourceMock->expects($this->once())
            ->method('save')
            ->with($signupMock)
            ->willThrowException($exception);
        $this->expectException(CouldNotSaveException::class);
        $this->signupRepository->save($signupMock);
    }

    /**
     * Test delete method
     *
     * @throws CouldNotDeleteException
     */
    public function testDelete()
    {
        $signupMock = $this->getSignupMock();

        $this->resourceMock->expects($this->once())
            ->method('delete')
            ->with($signupMock);

        $this->assertTrue($this->signupRepository->delete($signupMock));
    }

    /**
     * Test delete method with exception
     *
     * @expectedException \Magento\Framework\Exception\CouldNotDeleteException
     * @expectedExceptionMessage Can't delete exception message.
     * @throws CouldNotDeleteException
     */
    public function testDeleteWithException()
    {
        $signupMock = $this->getSignupMock();
        $exception = new CouldNotDeleteException(__('Can\'t delete exception message.'));
        $this->resourceMock->expects($this->once())
            ->method('delete')
            ->willThrowException($exception);
        $this->expectException(CouldNotDeleteException::class);
        $this->assertTrue($this->signupRepository->delete($signupMock));
    }

    /**
     * Test getById method
     *
     * @throws NoSuchEntityException
     */
    public function testGetById()
    {
        $signupMock = $this->getSignupMock();

        $this->signupInterfaceFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($signupMock);
        $this->resourceMock->expects($this->once())
            ->method('load')
            ->with($signupMock, self::DEFAULT_ID)
            ->willReturnSelf();

        $this->assertSame($signupMock, $this->signupRepository->getById(self::DEFAULT_ID));
    }

    /**
     * Test getById method with exception
     *
     * @throws NoSuchEntityException
     * @expectedException \Magento\Framework\Exception\NoSuchEntityException
     * @expectedExceptionMessage No such entity with signup_id = 1
     */
    public function testGetByIdWithException()
    {
        $signupMock = $this->getSignupMock(null);

        $this->signupInterfaceFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($signupMock);
        $this->resourceMock->expects($this->once())
            ->method('load')
            ->with($signupMock, self::DEFAULT_ID)
            ->willReturnSelf();
        $this->expectException(NoSuchEntityException::class);
        $this->assertSame($signupMock, $this->signupRepository->getById(self::DEFAULT_ID));
    }

    /**
     * Test getList method
     *
     * @param array $collectionItems
     * @param array $searchResultItems
     * @param SignupModel|null|\PHPUnit_Framework_MockObject_MockObject $signupModelMock
     * @dataProvider testGetListProvider
     */
    public function testGetList($collectionItems, $searchResultItems, $signupModelMock = null)
    {
        /** @var SearchCriteriaInterface|\PHPUnit_Framework_MockObject_MockObject $searchCriteriaMock */
        $searchCriteriaMock = $this->createMock(SearchCriteriaInterface::class);
        $collectionSize = count($collectionItems);
        $signupCollectionMock = $this->createMock(SignupCollection::class);
        $searchResultsMock = $this->createMock(SignupSearchResultsInterface::class);
        $signupData = [SignupInterface::ID => self::DEFAULT_ID];

        $this->signupCollectionFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($signupCollectionMock);
        $this->extensionAttributesJoinProcessorMock->expects($this->once())
            ->method('process')
            ->with($signupCollectionMock, SignupInterface::class);
        $this->collectionProcessorMock->expects($this->once())
            ->method('process')
            ->with($searchCriteriaMock, $signupCollectionMock);
        $this->searchResultsFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($searchResultsMock);
        $searchResultsMock->expects($this->once())
            ->method('setSearchCriteria')
            ->with($searchCriteriaMock);
        $signupCollectionMock->expects($this->once())
            ->method('getSize')
            ->willReturn($collectionSize);
        $searchResultsMock->expects($this->once())
            ->method('setTotalCount')
            ->with($collectionSize);
        $signupCollectionMock->expects($this->once())
            ->method('getItems')
            ->willReturn($collectionItems);
        $this->signupInterfaceFactoryMock->expects($this->exactly($collectionSize))
            ->method('create')
            ->willReturn($signupModelMock);
        $this->dataObjectProcessorMock->expects($this->exactly($collectionSize))
            ->method('buildOutputDataArray')
            ->with($signupModelMock, SignupInterface::class)
            ->willReturn($signupData);
        $this->dataObjectHelperMock->expects($this->exactly($collectionSize))
            ->method('populateWithArray')
            ->with($signupModelMock, $signupData, SignupInterface::class);
        $searchResultsMock->expects($this->once())
            ->method('setItems')
            ->with($searchResultItems)
            ->willReturnSelf();

        $this->assertSame($searchResultsMock, $this->signupRepository->getList($searchCriteriaMock));
    }

    /**
     * Get signup mock
     *
     * @param int|null $signupId
     * @return SignupModel|\PHPUnit_Framework_MockObject_MockObject
     */
    private function getSignupMock($signupId = self::DEFAULT_ID)
    {
        $signupMock = $this->createMock(SignupModel::class);

        $signupMock->expects($this->atMost(2))
            ->method('getSignupId')
            ->willReturn($signupId);

        return $signupMock;
    }

    /**
     * @return array
     */
    public function testGetListProvider()
    {
        $signupModelMock = $this->getSignupMock();

        return [
            [[$signupModelMock], [$signupModelMock], $signupModelMock],
            [[],[]]
        ];
    }
}
