<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Model\Service;

use PHPUnit\Framework\TestCase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Aheadworks\Affiliate\Model\Service\OrderItemService;
use Aheadworks\Affiliate\Model\PromoData\Validator as PromoDataValidator;
use Aheadworks\Affiliate\Model\PromoData\Quote\Item\Validator\Composite as QuoteItemValidator;
use Magento\Sales\Api\Data\OrderItemInterface;
use Magento\Sales\Model\Order\Item as OrderItem;
use Magento\Quote\Model\Quote\Item as QuoteItem;
use Aheadworks\Affiliate\Api\Data\PromoDataInterface;

/**
 * Test for \Aheadworks\Affiliate\Model\Service\OrderItemService
 */
class OrderItemServiceTest extends TestCase
{
    /**
     * @var OrderItemService
     */
    private $model;

    /**
     * @var PromoDataValidator|\PHPUnit_Framework_MockObject_MockObject
     */
    private $promoDataValidatorMock;

    /**
     * @var QuoteItemValidator|\PHPUnit_Framework_MockObject_MockObject
     */
    private $quoteItemValidatorMock;

    /**
     * Init mocks for tests
     *
     * @return void
     */
    public function setUp() : void
    {
        $objectManager = new ObjectManager($this);

        $this->promoDataValidatorMock = $this->createMock(PromoDataValidator::class);
        $this->quoteItemValidatorMock = $this->createMock(QuoteItemValidator::class);

        $this->model = $objectManager->getObject(
            OrderItemService::class,
            [
                'promoDataValidator' => $this->promoDataValidatorMock,
                'quoteItemValidator' => $this->quoteItemValidatorMock
            ]
        );
    }

    /**
     * Test addPromoData with invalid promo data
     */
    public function testAddPromoDataInvalidPromoData()
    {
        $storeId = 1;
        $isPromoDataValid = false;
        $result = false;

        $orderItemMock = $this->createMock(OrderItemInterface::class);
        $quoteItemMock = $this->createMock(QuoteItem::class);
        $quoteItemMock->expects($this->once())
            ->method('__call')
            ->with('getStoreId')
            ->willReturn($storeId);
        $promoDataMock = $this->createMock(PromoDataInterface::class);

        $this->promoDataValidatorMock->expects($this->once())
            ->method('validate')
            ->with($promoDataMock, $storeId)
            ->willReturn($isPromoDataValid);

        $this->quoteItemValidatorMock->expects($this->never())
            ->method('isValidItem');

        $this->assertEquals($result, $this->model->addPromoData($orderItemMock, $quoteItemMock, $promoDataMock));
    }

    /**
     * Test addPromoData with invalid quote item
     */
    public function testAddPromoDataInvalidQuoteItem()
    {
        $storeId = 1;
        $isPromoDataValid = true;
        $isQuoteItemValid = false;
        $result = false;

        $orderItemMock = $this->createMock(OrderItemInterface::class);
        $quoteItemMock = $this->createMock(QuoteItem::class);
        $quoteItemMock->expects($this->once())
            ->method('__call')
            ->with('getStoreId')
            ->willReturn($storeId);
        $promoDataMock = $this->createMock(PromoDataInterface::class);

        $this->promoDataValidatorMock->expects($this->once())
            ->method('validate')
            ->with($promoDataMock, $storeId)
            ->willReturn($isPromoDataValid);

        $this->quoteItemValidatorMock->expects($this->once())
            ->method('isValidItem')
            ->with($promoDataMock, $quoteItemMock)
            ->willReturn($isQuoteItemValid);

        $this->assertEquals($result, $this->model->addPromoData($orderItemMock, $quoteItemMock, $promoDataMock));
    }

    /**
     * Test addPromoData
     */
    public function testAddPromo()
    {
        $storeId = 1;
        $isPromoDataValid = true;
        $isQuoteItemValid = true;
        $campaignId = 1;
        $accountId = 1;
        $trafficSource = 'test';
        $result = true;

        $orderItemMock = $this->createMock(OrderItem::class);
        $quoteItemMock = $this->createMock(QuoteItem::class);
        $quoteItemMock->expects($this->once())
            ->method('__call')
            ->with('getStoreId')
            ->willReturn($storeId);
        $promoDataMock = $this->createMock(PromoDataInterface::class);

        $this->promoDataValidatorMock->expects($this->once())
            ->method('validate')
            ->with($promoDataMock, $storeId)
            ->willReturn($isPromoDataValid);

        $this->quoteItemValidatorMock->expects($this->once())
            ->method('isValidItem')
            ->with($promoDataMock, $quoteItemMock)
            ->willReturn($isQuoteItemValid);

        $promoDataMock->expects($this->once())
            ->method('getCampaignId')
            ->willReturn($campaignId);
        $promoDataMock->expects($this->once())
            ->method('getAccountId')
            ->willReturn($accountId);
        $promoDataMock->expects($this->once())
            ->method('getTrafficSource')
            ->willReturn($trafficSource);

        $orderItemMock->expects($this->any())
            ->method('__call')
            ->willReturnSelf();

        $this->assertEquals($result, $this->model->addPromoData($orderItemMock, $quoteItemMock, $promoDataMock));
    }
}
