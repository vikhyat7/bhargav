<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Plugin\Sales\Model;

use PHPUnit\Framework\TestCase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Aheadworks\Affiliate\Plugin\Sales\Model\OrderPlugin;
use Magento\Sales\Model\Order;
use Aheadworks\Affiliate\Model\LinkStatistic\Manager as LinkStatisticManager;

/**
 * Test for \Aheadworks\Affiliate\Plugin\Sales\Model\OrderPlugin
 */
class OrderPluginTest extends TestCase
{
    /**
     * @var OrderPlugin
     */
    private $model;

    /**
     * @var LinkStatisticManager|\PHPUnit_Framework_MockObject_MockObject
     */
    private $linkStatisticManagerMock;

    /**
     * Init mocks for tests
     *
     * @return void
     */
    public function setUp() : void
    {
        $objectManager = new ObjectManager($this);

        $this->linkStatisticManagerMock = $this->createMock(LinkStatisticManager::class);

        $this->model = $objectManager->getObject(
            OrderPlugin::class,
            [
                'linkStatisticManager' => $this->linkStatisticManagerMock
            ]
        );
    }

    /**
     * Test for afterPlace
     */
    public function testAfterPlace()
    {
        $subjectMock = $this->createMock(Order::class);
        $resultMock = $this->createMock(Order::class);

        $this->linkStatisticManagerMock->expects($this->once())
            ->method('registerOrderPlacement');

        $this->assertSame($resultMock, $this->model->afterPlace($subjectMock, $resultMock));
    }
}
