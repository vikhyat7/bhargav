<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Model\Coupon;

use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Aheadworks\Affiliate\Model\Coupon\SalesRule\DataPreparer;
use Aheadworks\Affiliate\Model\Coupon\SalesRuleManager;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\SalesRule\Api\Data\ConditionInterface;
use Magento\SalesRule\Api\Data\RuleInterfaceFactory;
use Magento\SalesRule\Api\RuleRepositoryInterface;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\SalesRule\Model\Data\Rule;
use PHPUnit\Framework\TestCase;

/**
 * Class SalesRuleManagerTest
 * @package Aheadworks\Affiliate\Test\Unit\Model\Coupon
 */
class SalesRuleManagerTest extends TestCase
{
    /**
     * @var RuleInterfaceFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $ruleFactoryMock;

    /**
     * @var RuleRepositoryInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $ruleRepositoryMock;

    /**
     * @var DataPreparer|\PHPUnit_Framework_MockObject_MockObject
     */
    private $dataPreparerMock;
    
    /**
     * @var SalesRuleManager
     */
    private $manager;

    /**
     * Init mocks for tests
     *
     * @return void
     */
    protected function setUp() : void
    {
        $objectManager = new ObjectManager($this);
        $this->ruleFactoryMock = $this->createMock(RuleInterfaceFactory::class);
        $this->ruleRepositoryMock = $this->createMock(RuleRepositoryInterface::class);
        $this->dataPreparerMock = $this->createMock(DataPreparer::class);
        $this->manager = $objectManager->getObject(
            SalesRuleManager::class,
            [
                'ruleFactory' => $this->ruleFactoryMock,
                'ruleRepository' => $this->ruleRepositoryMock,
                'dataPreparer' => $this->dataPreparerMock
            ]
        );
    }

    /**
     * Test saveSalesRule method
     *
     * @throws LocalizedException
     */
    public function testSaveSalesRule()
    {
        /** @var CampaignInterface|\PHPUnit_Framework_MockObject_MockObject $campaignMock */
        $campaignMock = $this->createMock(CampaignInterface::class);
        $ruleMock = $this->createMock(Rule::class);
        $conditionMock = $this->createMock(ConditionInterface::class);

        $customerGroupIds = [0, 1, 2];

        $ruleMock->expects($this->once())
            ->method('setCustomerGroupIds')
            ->with($customerGroupIds)
            ->willReturnSelf();
        $ruleMock->expects($this->once())
            ->method('setWebsiteIds')
            ->willReturnSelf();
        $ruleMock->expects($this->once())
            ->method('setCouponType')
            ->willReturnSelf();
        $ruleMock->expects($this->once())
            ->method('setName')
            ->willReturnSelf();
        $ruleMock->expects($this->once())
            ->method('setDescription')
            ->willReturnSelf();
        $ruleMock->expects($this->once())
            ->method('setDiscountAmount')
            ->willReturnSelf();
        $ruleMock->expects($this->once())
            ->method('setUsesPerCoupon')
            ->willReturnSelf();
        $ruleMock->expects($this->once())
            ->method('setActionCondition')
            ->willReturnSelf();
        $ruleMock->expects($this->once())
            ->method('setSortOrder')
            ->willReturnSelf();
        $ruleMock->expects($this->once())
            ->method('setUseAutoGeneration')
            ->willReturnSelf();
        $ruleMock->expects($this->once())
            ->method('setStopRulesProcessing')
            ->willReturnSelf();
        $ruleMock->expects($this->once())
            ->method('setSimpleAction')
            ->willReturnSelf();



        $this->ruleFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($ruleMock);
        $ruleMock->expects($this->any())
            ->method('setData')
            ->withAnyParameters()
            ->willReturnSelf();
        $this->dataPreparerMock->expects($this->once())
            ->method('isSalesRuleActive')
            ->with($campaignMock)
            ->willReturn(true);
        $this->dataPreparerMock->expects($this->once())
            ->method('getCustomerGroupIds')
            ->willReturn($customerGroupIds);
        $this->dataPreparerMock->expects($this->once())
            ->method('getWebsiteIds')
            ->with($campaignMock)
            ->willReturn([1, 2, 3]);
        $this->dataPreparerMock->expects($this->once())
            ->method('getPreparedDescription')
            ->with($campaignMock)
            ->willReturn('Prepared description');
        $this->dataPreparerMock->expects($this->once())
            ->method('getCouponActionCondition')
            ->with($campaignMock)
            ->willReturn($conditionMock);
        $this->dataPreparerMock->expects($this->once())
            ->method('getCouponDiscountAction')
            ->with($campaignMock)
            ->willReturn($conditionMock);
        $this->ruleRepositoryMock->expects($this->once())
            ->method('save')
            ->with($ruleMock)
            ->willReturn($ruleMock);

        $this->assertSame($ruleMock, $this->manager->saveSalesRule($campaignMock));
    }

    /**
     * Test saveSalesRule method with exception
     *
     * @param LocalizedException|InputException|NoSuchEntityException $exception
     * @param string $exceptionClass
     * @param string $exceptionMsg
     * @throws LocalizedException
     * @dataProvider testSaveSalesRuleWithExceptionDataProvider
     */
    public function testSaveSalesRuleWithException($exception, $exceptionClass, $exceptionMsg)
    {
        /** @var CampaignInterface|\PHPUnit_Framework_MockObject_MockObject $campaignMock */
        $campaignMock = $this->createMock(CampaignInterface::class);
        $ruleMock = $this->createMock(Rule::class);
        $conditionMock = $this->createMock(ConditionInterface::class);

        $this->ruleFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($ruleMock);
        $ruleMock->expects($this->any())
            ->method('setData')
            ->withAnyParameters()
            ->willReturnSelf();
        $ruleMock->expects($this->once())
                 ->method('setCustomerGroupIds')
                 ->willReturnSelf();
        $ruleMock->expects($this->once())
                 ->method('setWebsiteIds')
                 ->willReturnSelf();
        $ruleMock->expects($this->once())
                 ->method('setCouponType')
                 ->willReturnSelf();
        $ruleMock->expects($this->once())
                 ->method('setName')
                 ->willReturnSelf();
        $ruleMock->expects($this->once())
                 ->method('setDescription')
                 ->willReturnSelf();
        $ruleMock->expects($this->once())
                 ->method('setDiscountAmount')
                 ->willReturnSelf();
        $ruleMock->expects($this->once())
                 ->method('setUsesPerCoupon')
                 ->willReturnSelf();
        $ruleMock->expects($this->once())
                 ->method('setActionCondition')
                 ->willReturnSelf();
        $ruleMock->expects($this->once())
                 ->method('setSortOrder')
                 ->willReturnSelf();
        $ruleMock->expects($this->once())
                 ->method('setUseAutoGeneration')
                 ->willReturnSelf();
        $ruleMock->expects($this->once())
                 ->method('setStopRulesProcessing')
                 ->willReturnSelf();
        $ruleMock->expects($this->once())
                 ->method('setSimpleAction')
                 ->willReturnSelf();

        $this->dataPreparerMock->expects($this->once())
            ->method('isSalesRuleActive')
            ->with($campaignMock)
            ->willReturn(true);
        $this->dataPreparerMock->expects($this->once())
            ->method('getCustomerGroupIds')
            ->willReturn([0, 1, 2]);
        $this->dataPreparerMock->expects($this->once())
            ->method('getWebsiteIds')
            ->with($campaignMock)
            ->willReturn([1, 2, 3]);
        $this->dataPreparerMock->expects($this->once())
            ->method('getPreparedDescription')
            ->with($campaignMock)
            ->willReturn('Prepared description');
        $this->dataPreparerMock->expects($this->once())
            ->method('getCouponActionCondition')
            ->with($campaignMock)
            ->willReturn($conditionMock);
        $this->dataPreparerMock->expects($this->once())
            ->method('getCouponDiscountAction')
            ->with($campaignMock)
            ->willReturn($conditionMock);
        $this->ruleRepositoryMock->expects($this->once())
            ->method('save')
            ->with($ruleMock)
            ->willThrowException($exception);

        $this->expectException($exceptionClass);
        $this->expectExceptionMessage($exceptionMsg);

        $this->manager->saveSalesRule($campaignMock);
    }

    /**
     * @return array
     */
    public function testSaveSalesRuleWithExceptionDataProvider()
    {
        return [
            [
                new InputException(__('Input exception message.')),
                InputException::class,
                'Input exception message.'
            ],
            [
                new LocalizedException(__('Localized exception message.')),
                LocalizedException::class,
                'Localized exception message.'
            ],
            [
                new NoSuchEntityException(__('No such exception message.')),
                NoSuchEntityException::class,
                'No such exception message.'
            ]
        ];
    }
}
