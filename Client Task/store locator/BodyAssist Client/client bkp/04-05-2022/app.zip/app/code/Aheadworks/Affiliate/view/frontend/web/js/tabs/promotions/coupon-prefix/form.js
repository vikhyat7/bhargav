define([
    'underscore',
    'Aheadworks_Affiliate/js/ui/form/form',
    'uiRegistry'
], function (_, Component, registry) {
    'use strict';

    return Component.extend({
        defaults: {
            imports: {
                couponPrefix: '${ $.provider }:data.unique_coupon_prefix'
            },
            template: 'Aheadworks_Affiliate/tabs/promotions/coupon-prefix/form',
            listens: {
                responseData: 'onResponseData'
            },
            couponPrefixComponentName: '${ $.name }.unique_coupon_prefix'
        },

        /** @inheritdoc */
        initialize: function () {
            this._super()
                .resolveCouponPrefixValueFlag();

            return this;
        },

        /**
         * @inheritdoc
         */
        initObservable: function () {
            this._super()
                .observe({
                    isSetCouponPrefix: false
                });

            return this;
        },

        /**
         * {@inheritDoc}
         */
        onResponseData: function (response) {
            var couponPrefixComponent = this.getCouponPrefixComponent();

            if (response.error && couponPrefixComponent) {
                couponPrefixComponent.error(response.error);
                this.isSetCouponPrefix(false);
            } else {
                this.isSetCouponPrefix(true);
            }

            return this;
        },

        /**
         * @return {Object}|null
         */
        getCouponPrefixComponent: function () {
            return registry.get(this.couponPrefixComponentName);
        },

        /**
         * Resolve coupon prefix value flag
         */
        resolveCouponPrefixValueFlag: function () {
            this.isSetCouponPrefix(!_.isEmpty(this.couponPrefix));
        }
    });
});
