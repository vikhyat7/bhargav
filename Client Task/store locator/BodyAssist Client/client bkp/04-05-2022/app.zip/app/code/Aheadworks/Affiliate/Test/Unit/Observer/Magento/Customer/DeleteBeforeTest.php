<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Observer\Magento\Customer;

use PHPUnit\Framework\TestCase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Aheadworks\Affiliate\Observer\Magento\Customer\DeleteBefore;
use Magento\Framework\Event;
use Aheadworks\Affiliate\Api\AccountRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Api\SearchCriteria;
use Aheadworks\Affiliate\Model\Customer\DeleteProcessor as CustomerDeleteProcessor;
use Magento\Framework\Event\Observer;
use Aheadworks\Affiliate\Api\Data\AccountSearchResultsInterface;
use Magento\Customer\Model\Backend\Customer as BackendCustomer;

/**
 * Test for \Aheadworks\Affiliate\Observer\Magento\Customer\DeleteBefore
 */
class DeleteBeforeTest extends TestCase
{
    /**
     * @var DeleteBefore
     */
    private $model;

    /**
     * @var AccountRepositoryInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $accountRepositoryMock;

    /**
     * @var SearchCriteriaBuilder|\PHPUnit_Framework_MockObject_MockObject
     */
    private $searchCriteriaBuilderMock;

    /**
     * @var CustomerDeleteProcessor|\PHPUnit_Framework_MockObject_MockObject
     */
    private $customerDeleteProcessorMock;

    /**
     * Init mocks for tests
     *
     * @return void
     */
    public function setUp() : void
    {
        $objectManager = new ObjectManager($this);

        $this->accountRepositoryMock = $this->createMock(AccountRepositoryInterface::class);
        $this->searchCriteriaBuilderMock = $this->createMock(SearchCriteriaBuilder::class);
        $this->customerDeleteProcessorMock = $this->createMock(CustomerDeleteProcessor::class);

        $this->model = $objectManager->getObject(
            DeleteBefore::class,
            [
                'accountRepository' => $this->accountRepositoryMock,
                'searchCriteriaBuilder' => $this->searchCriteriaBuilderMock,
                'customerDeleteProcessor' => $this->customerDeleteProcessorMock
            ]
        );
    }

    /**
     * Test for execute() when no customer specified
     */
    public function testExecuteNoCustomer()
    {
        $customerId = 0;
        $customerMock = null;
        $accountsArray = [];
        $eventMock = $this->createMock(Event::class);
        $eventMock->expects($this->once())
            ->method('__call')
            ->with('getCustomer')
            ->willReturn($customerMock);

        $observerMock = $this->createMock(Observer::class);
        $observerMock->expects($this->once())
            ->method('getEvent')
            ->willReturn($eventMock);

        $searchCriteriaMock = $this->createMock(SearchCriteria::class);
        $this->searchCriteriaBuilderMock->expects($this->once())
            ->method('addFilter')
            ->with(AccountInterface::CUSTOMER_ID, $customerId)
            ->willReturnSelf();
        $this->searchCriteriaBuilderMock->expects($this->once())
            ->method('create')
            ->willReturn($searchCriteriaMock);

        $accountSearchResultsMock = $this->createMock(AccountSearchResultsInterface::class);
        $accountSearchResultsMock->expects($this->once())
            ->method('getItems')
            ->willReturn($accountsArray);

        $this->accountRepositoryMock->expects($this->once())
            ->method('getList')
            ->willReturn($accountSearchResultsMock);

        $this->customerDeleteProcessorMock->expects($this->never())
            ->method('process');

        $this->model->execute($observerMock);
    }

    /**
     * Test for execute() when customer has no affiliate account
     */
    public function testExecuteCustomerNoAccount()
    {
        $customerId = 1;
        $customerMock = $this->createMock(BackendCustomer::class);
        $customerMock->expects($this->once())
            ->method('getEntityId')
            ->willReturn($customerId);
        
        $accountsArray = [];
        $eventMock = $this->createMock(Event::class);
        $eventMock->expects($this->once())
            ->method('__call')
            ->with('getCustomer')
            ->willReturn($customerMock);

        $observerMock = $this->createMock(Observer::class);
        $observerMock->expects($this->once())
            ->method('getEvent')
            ->willReturn($eventMock);

        $searchCriteriaMock = $this->createMock(SearchCriteria::class);
        $this->searchCriteriaBuilderMock->expects($this->once())
            ->method('addFilter')
            ->with(AccountInterface::CUSTOMER_ID, $customerId)
            ->willReturnSelf();
        $this->searchCriteriaBuilderMock->expects($this->once())
            ->method('create')
            ->willReturn($searchCriteriaMock);

        $accountSearchResultsMock = $this->createMock(AccountSearchResultsInterface::class);
        $accountSearchResultsMock->expects($this->once())
            ->method('getItems')
            ->willReturn($accountsArray);

        $this->accountRepositoryMock->expects($this->once())
            ->method('getList')
            ->willReturn($accountSearchResultsMock);

        $this->customerDeleteProcessorMock->expects($this->never())
            ->method('process');

        $this->model->execute($observerMock);
    }

    /**
     * Test for execute() when customer has affiliate account
     */
    public function testExecuteCustomerWithAccount()
    {
        $customerId = 1;
        $customerMock = $this->createMock(BackendCustomer::class);
        $customerMock->expects($this->once())
            ->method('getEntityId')
            ->willReturn($customerId);

        $accountMock = $this->createMock(AccountInterface::class);
        $accountsArray = [$accountMock];
        $eventMock = $this->createMock(Event::class);
        $eventMock->expects($this->once())
            ->method('__call')
            ->with('getCustomer')
            ->willReturn($customerMock);

        $observerMock = $this->createMock(Observer::class);
        $observerMock->expects($this->once())
            ->method('getEvent')
            ->willReturn($eventMock);

        $searchCriteriaMock = $this->createMock(SearchCriteria::class);
        $this->searchCriteriaBuilderMock->expects($this->once())
            ->method('addFilter')
            ->with(AccountInterface::CUSTOMER_ID, $customerId)
            ->willReturnSelf();
        $this->searchCriteriaBuilderMock->expects($this->once())
            ->method('create')
            ->willReturn($searchCriteriaMock);

        $accountSearchResultsMock = $this->createMock(AccountSearchResultsInterface::class);
        $accountSearchResultsMock->expects($this->once())
            ->method('getItems')
            ->willReturn($accountsArray);

        $this->accountRepositoryMock->expects($this->once())
            ->method('getList')
            ->willReturn($accountSearchResultsMock);

        $this->customerDeleteProcessorMock->expects($this->once())
            ->method('process')
            ->with($accountMock);

        $this->model->execute($observerMock);
    }
}
