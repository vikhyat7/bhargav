<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Model;

use Aheadworks\Affiliate\Api\Data\CouponInterface;
use Aheadworks\Affiliate\Api\Data\CouponInterfaceFactory;
use Aheadworks\Affiliate\Api\Data\CouponSearchResultsInterface;
use Aheadworks\Affiliate\Api\Data\CouponSearchResultsInterfaceFactory;
use Aheadworks\Affiliate\Model\Coupon as CouponModel;
use Aheadworks\Affiliate\Model\ResourceModel\Coupon as CouponResourceModel;
use Aheadworks\Affiliate\Model\ResourceModel\Coupon\Collection as CouponCollection;
use Aheadworks\Affiliate\Model\ResourceModel\Coupon\CollectionFactory as CouponCollectionFactory;
use Magento\SalesRule\Api\CouponRepositoryInterface as SalesCouponRepositoryInterface;
use Aheadworks\Affiliate\Model\Coupon;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Aheadworks\Affiliate\Model\CouponRepository;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;

/**
 * Class CouponRepositoryTest
 *
 * @package Aheadworks\Affiliate\Test\Unit\Model
 */
class CouponRepositoryTest extends TestCase
{
    /**
     * @var CouponResourceModel|\PHPUnit_Framework_MockObject_MockObject
     */
    private $resourceMock;

    /**
     * @var CouponInterfaceFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $couponInterfaceFactoryMock;

    /**
     * @var CouponCollectionFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $couponCollectionFactoryMock;

    /**
     * @var CouponSearchResultsInterfaceFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $searchResultsFactoryMock;

    /**
     * @var JoinProcessorInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $extensionAttributesJoinProcessorMock;

    /**
     * @var CollectionProcessorInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $collectionProcessorMock;

    /**
     * @var DataObjectHelper|\PHPUnit_Framework_MockObject_MockObject
     */
    private $dataObjectHelperMock;

    /**
     * @var DataObjectProcessor|\PHPUnit_Framework_MockObject_MockObject
     */
    private $dataObjectProcessorMock;

    /**
     * @var SalesCouponRepositoryInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $salesCouponRepositoryMock;

    /**
     * @var CouponRepository
     */
    private $couponRepository;

    /**#@+
     * Constants used for tests
     */
    const DEFAULT_ID = 1;
    /**#@-*/

    /**
     * Init mocks for tests
     *
     * @return void
     */
    protected function setUp() : void
    {
        $objectManager = new ObjectManager($this);
        $this->resourceMock = $this->createMock(CouponResourceModel::class);
        $this->couponInterfaceFactoryMock = $this->createMock(CouponInterfaceFactory::class);
        $this->couponCollectionFactoryMock = $this->createMock(CouponCollectionFactory::class);
        $this->searchResultsFactoryMock = $this->createMock(CouponSearchResultsInterfaceFactory::class);
        $this->extensionAttributesJoinProcessorMock = $this->createMock(JoinProcessorInterface::class);
        $this->collectionProcessorMock = $this->createMock(CollectionProcessorInterface::class);
        $this->dataObjectHelperMock = $this->createMock(DataObjectHelper::class);
        $this->dataObjectProcessorMock = $this->createMock(DataObjectProcessor::class);
        $this->salesCouponRepositoryMock = $this->createMock(SalesCouponRepositoryInterface::class);
        $this->couponRepository = $objectManager->getObject(
            CouponRepository::class,
            [
                'resource' => $this->resourceMock,
                'couponInterfaceFactory' => $this->couponInterfaceFactoryMock,
                'couponCollectionFactory' => $this->couponCollectionFactoryMock,
                'searchResultsFactory' => $this->searchResultsFactoryMock,
                'extensionAttributesJoinProcessor' => $this->extensionAttributesJoinProcessorMock,
                'collectionProcessor' => $this->collectionProcessorMock,
                'dataObjectHelper' => $this->dataObjectHelperMock,
                'dataObjectProcessor' => $this->dataObjectProcessorMock,
                'salesCouponRepository' => $this->salesCouponRepositoryMock
            ]
        );
    }

    /**
     * Test save method
     *
     * @throws CouldNotSaveException
     */
    public function testSave()
    {
        $couponMock = $this->getCouponMock(CouponInterface::class);

        $this->resourceMock->expects($this->once())
            ->method('save')
            ->willReturnSelf();

        $this->assertSame($couponMock, $this->couponRepository->save($couponMock));
    }

    /**
     * Test save method with exception
     *
     * @expectedException \Magento\Framework\Exception\CouldNotSaveException
     * @expectedExceptionMessage Test message
     * @throws CouldNotSaveException
     */
    public function testSaveWithException()
    {
        $exception = new \Exception('Test message');
        $couponMock = $this->getCouponMock();
        $this->resourceMock->expects($this->once())
            ->method('save')
            ->with($couponMock)
            ->willThrowException($exception);
        $this->expectException(CouldNotSaveException::class);
        $this->couponRepository->save($couponMock);
    }

    /**
     * Test delete method
     *
     * @throws CouldNotDeleteException
     */
    public function testDelete()
    {
        $couponMock = $this->getCouponMock();

        $this->salesCouponRepositoryMock->expects($this->once())
            ->method('deleteById')
            ->with(self::DEFAULT_ID);

        $this->assertTrue($this->couponRepository->delete($couponMock));
    }

    /**
     * Test delete method with exception
     *
     * @param CouldNotDeleteException|NoSuchEntityException $exception
     * @param string $exceptionMsg
     * @dataProvider testDeleteWithExceptionProvider
     * @expectedException \Magento\Framework\Exception\CouldNotDeleteException
     * @throws CouldNotDeleteException
     */
    public function testDeleteWithException($exception, $exceptionMsg)
    {
        $couponMock = $this->getCouponMock();

        $this->salesCouponRepositoryMock->expects($this->once())
            ->method('deleteById')
            ->with(self::DEFAULT_ID)
            ->willThrowException($exception);
        $this->expectExceptionMessage($exceptionMsg);

        $this->assertTrue($this->couponRepository->delete($couponMock));
    }

    /**
     * Test getById method
     *
     * @throws NoSuchEntityException
     */
    public function testGetById()
    {
        $couponMock = $this->getCouponMock();

        $this->couponInterfaceFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($couponMock);
        $this->resourceMock->expects($this->once())
            ->method('load')
            ->with($couponMock, self::DEFAULT_ID)
            ->willReturnSelf();

        $this->assertSame($couponMock, $this->couponRepository->getById(self::DEFAULT_ID));
    }

    /**
     * Test getById method with exception
     *
     * @throws NoSuchEntityException
     * @expectedException \Magento\Framework\Exception\NoSuchEntityException
     * @expectedExceptionMessage No such entity with coupon_id = 1
     */
    public function testGetByIdWithException()
    {
        $couponMock = $this->getCouponMock(null);

        $this->couponInterfaceFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($couponMock);
        $this->resourceMock->expects($this->once())
            ->method('load')
            ->with($couponMock, self::DEFAULT_ID)
            ->willReturnSelf();
        $this->expectException(NoSuchEntityException::class);
        $this->assertSame($couponMock, $this->couponRepository->getById(self::DEFAULT_ID));
    }

    /**
     * Test getList method
     *
     * @param array $collectionItems
     * @param array $searchResultItems
     * @param CouponModel|null|\PHPUnit_Framework_MockObject_MockObject $couponModelMock
     * @dataProvider testGetListProvider
     */
    public function testGetList($collectionItems, $searchResultItems, $couponModelMock = null)
    {
        /** @var SearchCriteriaInterface|\PHPUnit_Framework_MockObject_MockObject $searchCriteriaMock */
        $searchCriteriaMock = $this->createMock(SearchCriteriaInterface::class);
        $collectionSize = count($collectionItems);
        $couponCollectionMock = $this->createMock(CouponCollection::class);
        $searchResultsMock = $this->createMock(CouponSearchResultsInterface::class);
        $couponData = [CouponInterface::COUPON_ID => self::DEFAULT_ID];

        $this->couponCollectionFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($couponCollectionMock);
        $this->extensionAttributesJoinProcessorMock->expects($this->once())
            ->method('process')
            ->with($couponCollectionMock, CouponInterface::class);
        $this->collectionProcessorMock->expects($this->once())
            ->method('process')
            ->with($searchCriteriaMock, $couponCollectionMock);
        $this->searchResultsFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($searchResultsMock);
        $searchResultsMock->expects($this->once())
            ->method('setSearchCriteria')
            ->with($searchCriteriaMock);
        $couponCollectionMock->expects($this->once())
            ->method('getSize')
            ->willReturn($collectionSize);
        $searchResultsMock->expects($this->once())
            ->method('setTotalCount')
            ->with($collectionSize);
        $couponCollectionMock->expects($this->once())
            ->method('getItems')
            ->willReturn($collectionItems);
        $this->couponInterfaceFactoryMock->expects($this->exactly($collectionSize))
            ->method('create')
            ->willReturn($couponModelMock);
        $this->dataObjectProcessorMock->expects($this->exactly($collectionSize))
            ->method('buildOutputDataArray')
            ->with($couponModelMock, CouponInterface::class)
            ->willReturn($couponData);
        $this->dataObjectHelperMock->expects($this->exactly($collectionSize))
            ->method('populateWithArray')
            ->with($couponModelMock, $couponData, CouponInterface::class);
        $searchResultsMock->expects($this->once())
            ->method('setItems')
            ->with($searchResultItems)
            ->willReturnSelf();

        $this->assertSame($searchResultsMock, $this->couponRepository->getList($searchCriteriaMock));
    }

    /**
     * Get coupon mock
     *
     * @param int|null $couponId
     * @return CouponModel|\PHPUnit_Framework_MockObject_MockObject
     */
    private function getCouponMock($couponId = self::DEFAULT_ID)
    {
        $couponMock = $this->createMock(CouponModel::class);

        $couponMock->expects($this->atMost(2))
            ->method('getCouponId')
            ->willReturn($couponId);

        return $couponMock;
    }

    /**
     * @return array
     */
    public function testGetListProvider()
    {
        $couponModelMock = $this->getCouponMock();

        return [
            [[$couponModelMock], [$couponModelMock], $couponModelMock],
            [[],[]]
        ];
    }

    /**
     * @return array
     */
    public function testDeleteWithExceptionProvider()
    {
        return [
            [
                new NoSuchEntityException(__('No such coupon exception message.')),
                'No such coupon exception message.'
            ],
            [
                new CouldNotDeleteException(__('Can\'t delete exception message.')),
                'Can\'t delete exception message.'
            ]
        ];
    }
}
