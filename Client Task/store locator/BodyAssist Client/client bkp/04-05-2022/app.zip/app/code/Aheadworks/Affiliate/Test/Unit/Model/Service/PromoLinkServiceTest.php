<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Model\Service;

use Aheadworks\Affiliate\Api\Data\PromoLinkDataInterface;
use Magento\Framework\Exception\LocalizedException;
use PHPUnit\Framework\TestCase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Aheadworks\Affiliate\Model\Service\PromoLinkService;
use Aheadworks\Affiliate\Model\Account\Promo\Link\Generator as PromoLinkGenerator;
use Aheadworks\Affiliate\Model\PromoData\Resolver as PromoDataResolver;
use Aheadworks\Affiliate\Model\PromoData\Validator as PromoDataValidator;
use Aheadworks\Affiliate\Model\Cookie\Management as CookieManagement;
use Aheadworks\Affiliate\Api\Data\PromoDataInterface;
use Aheadworks\Affiliate\Model\LinkStatistic\Manager as LinkStatisticManager;
use Magento\Framework\App\RequestInterface;

/**
 * Test for \Aheadworks\Affiliate\Model\Service\PromoLinkService
 */
class PromoLinkServiceTest extends TestCase
{
    /**
     * @var PromoLinkService
     */
    private $model;

    /**
     * @var PromoLinkGenerator|\PHPUnit_Framework_MockObject_MockObject
     */
    private $promoLinkGeneratorMock;

    /**
     * @var PromoDataResolver|\PHPUnit_Framework_MockObject_MockObject
     */
    private $promoDataResolverMock;

    /**
     * @var PromoDataValidator|\PHPUnit_Framework_MockObject_MockObject
     */
    private $promoDataValidatorMock;

    /**
     * @var CookieManagement|\PHPUnit_Framework_MockObject_MockObject
     */
    private $cookieManagementMock;

    /**
     * @var LinkStatisticManager|\PHPUnit_Framework_MockObject_MockObject
     */
    private $linkStatisticManagerMock;

    /**
     * Init mocks for tests
     *
     * @return void
     */
    public function setUp() : void
    {
        $objectManager = new ObjectManager($this);

        $this->promoLinkGeneratorMock = $this->createMock(PromoLinkGenerator::class);
        $this->promoDataResolverMock = $this->createMock(PromoDataResolver::class);
        $this->promoDataValidatorMock = $this->createMock(PromoDataValidator::class);
        $this->cookieManagementMock = $this->createMock(CookieManagement::class);
        $this->linkStatisticManagerMock = $this->createMock(LinkStatisticManager::class);

        $this->model = $objectManager->getObject(
            PromoLinkService::class,
            [
                'promoLinkGenerator' => $this->promoLinkGeneratorMock,
                'promoDataResolver' => $this->promoDataResolverMock,
                'promoDataValidator' => $this->promoDataValidatorMock,
                'cookieManagement' => $this->cookieManagementMock,
                'linkStatisticManager' => $this->linkStatisticManagerMock
            ]
        );
    }

    /**
     * Test generateLink with invalid promo link data
     *
     * @expectedException \Magento\Framework\Exception\LocalizedException
     * @expectedExceptionMessage Provided data is not valid to generate a promo link.
     */
    public function testGenerateLinkInvalidPromoLinkData()
    {
        $storeId = 1;
        $currentTrafficSource = 'test';
        $isPromoDataValid = false;

        $promoLinkDataMock = $this->createMock(PromoLinkDataInterface::class);
        $promoLinkDataMock->expects($this->once())
            ->method('getTrafficSource')
            ->willReturn($currentTrafficSource);
        $promoLinkDataMock->expects($this->never())
            ->method('setTrafficSource');

        $this->promoDataValidatorMock->expects($this->once())
            ->method('validate')
            ->with($promoLinkDataMock, $storeId)
            ->willReturn($isPromoDataValid);
        $this->expectException(LocalizedException::class);
        $this->model->generateLink($promoLinkDataMock, $storeId);
    }

    /**
     * Test generateLink with invalid promo link data
     *
     * @expectedException \Magento\Framework\Exception\LocalizedException
     * @expectedExceptionMessage Provided data is not valid to generate a promo link.
     */
    public function testGenerateLinkInvalidPromoLinkDataAddDefaultTrafficSource()
    {
        $storeId = 1;
        $currentTrafficSource = '';
        $isPromoDataValid = false;

        $promoLinkDataMock = $this->createMock(PromoLinkDataInterface::class);
        $promoLinkDataMock->expects($this->once())
            ->method('getTrafficSource')
            ->willReturn($currentTrafficSource);
        $promoLinkDataMock->expects($this->once())
            ->method('setTrafficSource')
            ->with(PromoLinkService::DEFAULT_TRAFFIC_SOURCE_VALUE)
            ->willReturnSelf();

        $this->promoDataValidatorMock->expects($this->once())
            ->method('validate')
            ->with($promoLinkDataMock, $storeId)
            ->willReturn($isPromoDataValid);
        $this->expectException(LocalizedException::class);
        $this->model->generateLink($promoLinkDataMock, $storeId);
    }

    /**
     * Test generateLink
     */
    public function testGenerateLink()
    {
        $storeId = 1;
        $isPromoDataValid = true;
        $currentTrafficSource = 'test';
        $promoLink = 'http://test.com/path.html?aw_affiliate=eyJjYW1wYWlnbl9pZCI6IvdXJjZSIsImFjY291bnRfaWQiOjF9';

        $promoLinkDataMock = $this->createMock(PromoLinkDataInterface::class);
        $promoLinkDataMock->expects($this->once())
            ->method('getTrafficSource')
            ->willReturn($currentTrafficSource);
        $promoLinkDataMock->expects($this->never())
            ->method('setTrafficSource');

        $this->promoDataValidatorMock->expects($this->once())
            ->method('validate')
            ->with($promoLinkDataMock, $storeId)
            ->willReturn($isPromoDataValid);

        $this->promoLinkGeneratorMock->expects($this->once())
            ->method('generate')
            ->with($promoLinkDataMock)
            ->willReturn($promoLink);

        $this->assertEquals($promoLink, $this->model->generateLink($promoLinkDataMock, $storeId));
    }

    /**
     * Test generateLink with adding default traffic source param
     */
    public function testGenerateLinkAddDefaultTrafficSource()
    {
        $storeId = 1;
        $isPromoDataValid = true;
        $currentTrafficSource = '';
        $promoLink = 'http://test.com/path.html?aw_affiliate=eyJjYW1wYWlnbl9pZCI6IvdXJjZSIsImFjY291bnRfaWQiOjF9';

        $promoLinkDataMock = $this->createMock(PromoLinkDataInterface::class);
        $promoLinkDataMock->expects($this->once())
            ->method('getTrafficSource')
            ->willReturn($currentTrafficSource);
        $promoLinkDataMock->expects($this->once())
            ->method('setTrafficSource')
            ->with(PromoLinkService::DEFAULT_TRAFFIC_SOURCE_VALUE)
            ->willReturnSelf();

        $this->promoDataValidatorMock->expects($this->once())
            ->method('validate')
            ->with($promoLinkDataMock, $storeId)
            ->willReturn($isPromoDataValid);

        $this->promoLinkGeneratorMock->expects($this->once())
            ->method('generate')
            ->with($promoLinkDataMock)
            ->willReturn($promoLink);

        $this->assertEquals($promoLink, $this->model->generateLink($promoLinkDataMock, $storeId));
    }

    /**
     * Test processRequest when promo data from request is invalid
     */
    public function testProcessRequestInvalidPromoData()
    {
        $requestMock = $this->createMock(RequestInterface::class);
        $promoDataMock = $this->createMock(PromoDataInterface::class);

        $this->promoDataResolverMock->expects($this->once())
            ->method('resolveByRequest')
            ->with($requestMock)
            ->willReturn($promoDataMock);

        $this->promoDataValidatorMock->expects($this->any())
            ->method('validate')
            ->willReturnMap(
                [
                    [
                        $promoDataMock,
                        null,
                        false
                    ],
                ]
            )
        ;

        $this->linkStatisticManagerMock->expects($this->never())
            ->method('registerNewHit');

        $this->cookieManagementMock->expects($this->never())
            ->method('setVisitorPromoData');

        $this->model->processRequest($requestMock);
    }

    /**
     * Test processRequest when promo data from request is valid
     */
    public function testProcessRequestValidPromoData()
    {
        $requestMock = $this->createMock(RequestInterface::class);
        $promoDataMock = $this->createMock(PromoDataInterface::class);

        $this->promoDataResolverMock->expects($this->once())
            ->method('resolveByRequest')
            ->with($requestMock)
            ->willReturn($promoDataMock);

        $this->promoDataValidatorMock->expects($this->any())
            ->method('validate')
            ->willReturnMap(
                [
                    [
                        $promoDataMock,
                        null,
                        true
                    ],
                ]
            )
        ;

        $this->linkStatisticManagerMock->expects($this->once())
            ->method('registerNewHit')
            ->with($promoDataMock);

        $this->cookieManagementMock->expects($this->once())
            ->method('setVisitorPromoData')
            ->with($promoDataMock);

        $this->model->processRequest($requestMock);
    }
}
