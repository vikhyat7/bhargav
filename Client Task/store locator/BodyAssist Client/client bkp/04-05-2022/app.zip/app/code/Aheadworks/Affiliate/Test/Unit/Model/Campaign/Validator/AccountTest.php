<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Model\Campaign\Validator;

use PHPUnit\Framework\TestCase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Aheadworks\Affiliate\Model\Campaign\Validator\Account;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Aheadworks\Affiliate\Model\Source\Account\Status as AccountStatus;
use Aheadworks\Affiliate\Model\Source\Campaign\Status as CampaignStatus;
use Aheadworks\Affiliate\Model\Source\AffiliateGroup as AffiliateGroupSource;

/**
 * Test for \Aheadworks\Affiliate\Model\Campaign\Validator\Account
 */
class AccountTest extends TestCase
{
    /**
     * @var Account
     */
    private $model;

    /**
     * Init mocks for tests
     *
     * @return void
     */
    public function setUp() : void
    {
        $objectManager = new ObjectManager($this);

        $this->model = $objectManager->getObject(Account::class);
    }

    /**
     * Test for validate()
     *
     * @param AccountInterface|\PHPUnit\Framework\MockObject\MockObject $account
     * @param CampaignInterface|\PHPUnit\Framework\MockObject\MockObject $campaign
     * @param int $websiteId
     * @param bool $isValid
     * @dataProvider validateDataProvider
     */
    public function testValidate(
        $account,
        $campaign,
        $websiteId,
        $isValid
    ) {
        $this->assertEquals(
            $isValid,
            $this->model->validate($account, $campaign, $websiteId)
        );
    }

    /**
     * @return array
     */
    public function validateDataProvider()
    {
        return [
            // valid combinations start
            [
                'account' => $this->getAccountMock(
                    AccountStatus::ACTIVE,
                    1,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::ACTIVE,
                    1,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => true
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::ACTIVE,
                    1,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::ACTIVE,
                    1,
                    [AffiliateGroupSource::ALL_GROUPS_VALUE]
                ),
                'websiteId' => 1,
                'isValid' => true
            ],
            // valid combinations end
            //invalid combinations - status - start
            [
                'account' => $this->getAccountMock(
                    AccountStatus::INACTIVE,
                    1,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::ACTIVE,
                    1,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::ACTIVE,
                    1,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::INACTIVE,
                    1,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::INACTIVE,
                    1,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::INACTIVE,
                    1,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::INACTIVE,
                    1,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::ACTIVE,
                    1,
                    [AffiliateGroupSource::ALL_GROUPS_VALUE]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::ACTIVE,
                    1,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::INACTIVE,
                    1,
                    [AffiliateGroupSource::ALL_GROUPS_VALUE]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::INACTIVE,
                    1,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::INACTIVE,
                    1,
                    [AffiliateGroupSource::ALL_GROUPS_VALUE]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            //invalid combinations - status - end
            //invalid combinations - website - start
            [
                'account' => $this->getAccountMock(
                    AccountStatus::ACTIVE,
                    1,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::ACTIVE,
                    2,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::ACTIVE,
                    1,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::ACTIVE,
                    2,
                    [AffiliateGroupSource::ALL_GROUPS_VALUE]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::INACTIVE,
                    1,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::ACTIVE,
                    2,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::ACTIVE,
                    1,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::INACTIVE,
                    2,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::INACTIVE,
                    1,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::INACTIVE,
                    2,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::INACTIVE,
                    1,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::ACTIVE,
                    2,
                    [AffiliateGroupSource::ALL_GROUPS_VALUE]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::ACTIVE,
                    1,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::INACTIVE,
                    2,
                    [AffiliateGroupSource::ALL_GROUPS_VALUE]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::INACTIVE,
                    1,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::INACTIVE,
                    2,
                    [AffiliateGroupSource::ALL_GROUPS_VALUE]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::ACTIVE,
                    2,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::ACTIVE,
                    1,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::ACTIVE,
                    2,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::ACTIVE,
                    1,
                    [AffiliateGroupSource::ALL_GROUPS_VALUE]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::INACTIVE,
                    2,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::ACTIVE,
                    1,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::ACTIVE,
                    2,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::INACTIVE,
                    1,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::INACTIVE,
                    2,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::INACTIVE,
                    1,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::INACTIVE,
                    2,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::ACTIVE,
                    1,
                    [AffiliateGroupSource::ALL_GROUPS_VALUE]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::ACTIVE,
                    2,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::INACTIVE,
                    1,
                    [AffiliateGroupSource::ALL_GROUPS_VALUE]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::INACTIVE,
                    2,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::INACTIVE,
                    1,
                    [AffiliateGroupSource::ALL_GROUPS_VALUE]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::ACTIVE,
                    2,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::ACTIVE,
                    2,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::ACTIVE,
                    2,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::ACTIVE,
                    2,
                    [AffiliateGroupSource::ALL_GROUPS_VALUE]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::INACTIVE,
                    2,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::ACTIVE,
                    2,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::ACTIVE,
                    2,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::INACTIVE,
                    2,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::INACTIVE,
                    2,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::INACTIVE,
                    2,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::INACTIVE,
                    2,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::ACTIVE,
                    2,
                    [AffiliateGroupSource::ALL_GROUPS_VALUE]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::ACTIVE,
                    2,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::INACTIVE,
                    2,
                    [AffiliateGroupSource::ALL_GROUPS_VALUE]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::INACTIVE,
                    2,
                    1
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::INACTIVE,
                    2,
                    [AffiliateGroupSource::ALL_GROUPS_VALUE]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            //invalid combinations - website - end
            //invalid combinations - affiliate groups - start
            [
                'account' => $this->getAccountMock(
                    AccountStatus::ACTIVE,
                    1,
                    3
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::ACTIVE,
                    2,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::INACTIVE,
                    1,
                    3
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::ACTIVE,
                    2,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::ACTIVE,
                    1,
                    3
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::INACTIVE,
                    2,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::INACTIVE,
                    1,
                    3
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::INACTIVE,
                    2,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::ACTIVE,
                    2,
                    3
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::ACTIVE,
                    1,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::INACTIVE,
                    2,
                    3
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::ACTIVE,
                    1,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::ACTIVE,
                    2,
                    3
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::INACTIVE,
                    1,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::INACTIVE,
                    2,
                    3
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::INACTIVE,
                    1,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::ACTIVE,
                    2,
                    3
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::ACTIVE,
                    2,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::INACTIVE,
                    2,
                    3
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::ACTIVE,
                    2,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::ACTIVE,
                    2,
                    3
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::INACTIVE,
                    2,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            [
                'account' => $this->getAccountMock(
                    AccountStatus::INACTIVE,
                    2,
                    3
                ),
                'campaign' => $this->getCampaignMock(
                    CampaignStatus::INACTIVE,
                    2,
                    [1, 2]
                ),
                'websiteId' => 1,
                'isValid' => false
            ],
            //invalid combinations - affiliate groups - end
        ];
    }

    /**
     * @param int $status
     * @param int $websiteId
     * @param int $affiliateGroupId
     * @return AccountInterface|\PHPUnit\Framework\MockObject\MockObject
     */
    private function getAccountMock($status, $websiteId, $affiliateGroupId)
    {
        $accountMock = $this->createMock(AccountInterface::class);
        $accountMock->expects($this->once())
            ->method('getStatus')
            ->willReturn($status);
        $accountMock->expects($this->once())
            ->method('getWebsiteId')
            ->willReturn($websiteId);
        $accountMock->expects($this->once())
            ->method('getAffiliateGroupId')
            ->willReturn($affiliateGroupId);
        return $accountMock;
    }

    /**
     * @param int $status
     * @param int $websiteId
     * @param array $affiliateGroupIds
     * @return CampaignInterface|\PHPUnit\Framework\MockObject\MockObject
     */
    private function getCampaignMock($status, $websiteId, $affiliateGroupIds)
    {
        $campaignMock = $this->createMock(CampaignInterface::class);
        $campaignMock->expects($this->once())
            ->method('getStatus')
            ->willReturn($status);
        $campaignMock->expects($this->once())
            ->method('getWebsiteId')
            ->willReturn($websiteId);
        $campaignMock->expects($this->once())
            ->method('getAffiliateGroupIds')
            ->willReturn($affiliateGroupIds);
        return $campaignMock;
    }
}
