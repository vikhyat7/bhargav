<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Api\Data;

use Magento\Framework\Api\ExtensibleDataInterface;

/**
 * Interface CouponInterface
 * @package Aheadworks\Affiliate\Api\Data
 */
interface CouponInterface extends ExtensibleDataInterface
{
    /**#@+
     * Constants defined for keys of the data array.
     * Identical to the name of the getter in snake case
     */
    const COUPON_ID = 'coupon_id';
    const COUPON_CODE = 'coupon_code';
    const SALES_RULE_ID = 'sales_rule_id';
    const CAMPAIGN_ID = 'campaign_id';
    const AFFILIATE_ID = 'affiliate_id';
    /**#@-*/

    /**
     * Get coupon id
     *
     * @return int
     */
    public function getCouponId();

    /**
     * Set coupon id
     *
     * @param int $couponId
     * @return $this
     */
    public function setCouponId($couponId);

    /**
     * Get coupon code
     *
     * @return string
     */
    public function getCouponCode();

    /**
     * Set coupon code
     *
     * @param string $couponCode
     * @return $this
     */
    public function setCouponCode($couponCode);

    /**
     * Get sales rule id
     *
     * @return int
     */
    public function getSalesRuleId();

    /**
     * Set sales rule id
     *
     * @param int $ruleId
     * @return $this
     */
    public function setSalesRuleId($ruleId);

    /**
     * Get campaign id
     *
     * @return int
     */
    public function getCampaignId();

    /**
     * Set campaign id
     *
     * @param int $campaignId
     * @return $this
     */
    public function setCampaignId($campaignId);

    /**
     * Get affiliate id
     *
     * @return int
     */
    public function getAffiliateId();

    /**
     * Set affiliate id
     *
     * @param int $affiliateId
     * @return $this
     */
    public function setAffiliateId($affiliateId);

    /**
     * Retrieve existing extension attributes object or create a new one
     *
     * @return \Aheadworks\Affiliate\Api\Data\CouponExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object
     *
     * @param \Aheadworks\Affiliate\Api\Data\CouponExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aheadworks\Affiliate\Api\Data\CouponExtensionInterface $extensionAttributes
    );
}
