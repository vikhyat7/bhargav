<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Block\Adminhtml\Signup\Edit\Button;

use Aheadworks\Affiliate\Api\Data\SignupInterface;
use Aheadworks\Affiliate\Api\SignupRepositoryInterface;
use Aheadworks\Affiliate\Model\Signup\StatusResolver;
use Magento\Framework\App\Request\Http as HttpRequest;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Class Save
 * @package Aheadworks\Affiliate\Block\Adminhtml\Signup\Edit\Button
 */
abstract class AbstractChangeStatusButton
{
    /**
     * @var SignupRepositoryInterface
     */
    private $signupRepository;

    /**
     * @var HttpRequest;
     */
    private $request;

    /**
     * @var StatusResolver
     */
    private $statusResolver;

    /**
     * @param SignupRepositoryInterface $signupRepository
     * @param HttpRequest $request
     * @param StatusResolver $statusResolver
     */
    public function __construct(
        SignupRepositoryInterface $signupRepository,
        HttpRequest $request,
        StatusResolver $statusResolver
    ) {
        $this->signupRepository = $signupRepository;
        $this->request = $request;
        $this->statusResolver = $statusResolver;
    }

    protected function isNeedToShow()
    {
        $signupId = $this->request->getParam(SignupInterface::ID, null);
        $result = false;

        if ($signupId) {
            try {
                $signup = $this->signupRepository->getById($signupId);
                $result = $this->statusResolver->isStatusAllowedForSignup(
                    $this->getStatusToSet(),
                    $signup->getStatus()
                );
            } catch (NoSuchEntityException $e) {
                $result = false;
            }
        }

        return $result;
    }

    /**
     * Get status to set
     *
     * @return int
     */
    abstract protected function getStatusToSet();
}
