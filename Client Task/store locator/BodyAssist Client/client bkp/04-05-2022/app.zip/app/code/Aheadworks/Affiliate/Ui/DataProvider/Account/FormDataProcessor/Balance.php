<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Ui\DataProvider\Account\FormDataProcessor;

use Aheadworks\Affiliate\Ui\DataProvider\FormDataProcessor\ProcessorInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Aheadworks\Affiliate\Api\Data\Account\BalanceInterface;
use Aheadworks\Affiliate\Api\AccountBalanceManagementInterface;
use Magento\Framework\Reflection\DataObjectProcessor;

/**
 * Class Balance
 *
 * @package Aheadworks\Affiliate\Ui\DataProvider\Account\FormDataProcessor
 */
class Balance implements ProcessorInterface
{
    /**
     * Name of the field with account balance data
     */
    const ACCOUNT_BALANCE_DATA_FIELD_NAME = 'balance';

    /**
     * @var AccountBalanceManagementInterface
     */
    private $accountBalanceManagement;

    /**
     * @var DataObjectProcessor
     */
    private $dataObjectProcessor;

    /**
     * @param AccountBalanceManagementInterface $accountBalanceManagement
     * @param DataObjectProcessor $dataObjectProcessor
     */
    public function __construct(
        AccountBalanceManagementInterface $accountBalanceManagement,
        DataObjectProcessor $dataObjectProcessor
    ) {
        $this->accountBalanceManagement = $accountBalanceManagement;
        $this->dataObjectProcessor = $dataObjectProcessor;
    }

    /**
     * {@inheritdoc}
     */
    public function process($data)
    {
        if (isset($data[AccountInterface::ID]) && !empty($data[AccountInterface::ID])) {
            $balance = $this->accountBalanceManagement->getBalance($data[AccountInterface::ID]);
            $data[self::ACCOUNT_BALANCE_DATA_FIELD_NAME] = $this->dataObjectProcessor->buildOutputDataArray(
                $balance,
                BalanceInterface::class
            );
        }
        return $data;
    }
}
