<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Ui\DataProvider\Frontend\PromotingCampaigns;

use Aheadworks\Affiliate\Api\AccountRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Aheadworks\Affiliate\Api\Data\CouponInterface;
use Aheadworks\Affiliate\Ui\DataProvider\Frontend\AbstractDataProvider;
use Aheadworks\Affiliate\Model\ResourceModel\Account\Frontend\PromotingCampaigns\Collection;
use Aheadworks\Affiliate\Model\ResourceModel\Account\Frontend\PromotingCampaigns\CollectionFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Customer\Model\Session as CustomerSession;

/**
 * Class ListingDataProvider
 * @package Aheadworks\Affiliate\Ui\DataProvider\Frontend\PromotingCampaigns
 */
class ListingDataProvider extends AbstractDataProvider
{
    /**
     * @var Collection
     */
    protected $collection;

    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param StoreManagerInterface $storeManager
     * @param CustomerSession $customerSession
     * @param AccountRepositoryInterface $accountRepository
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        StoreManagerInterface $storeManager,
        CustomerSession $customerSession,
        CollectionFactory $collectionFactory,
        AccountRepositoryInterface $accountRepository,
        array $meta = [],
        array $data = []
    ) {
        parent::__construct(
            $name,
            $primaryFieldName,
            $requestFieldName,
            $storeManager,
            $customerSession,
            $accountRepository,
            $meta,
            $data
        );
        $this->collection = $collectionFactory->create();
    }

    /**
     * {@inheritdoc}
     */
    protected function applyDefaultFilters()
    {
        $this->getCollection()
            ->addFieldToFilter(CampaignInterface::WEBSITE_ID, $this->getCurrentWebsiteId())
            ->addAffiliateGroupFilter($this->getAffiliateGroupId());
    }

    /**
     * Retrieve affiliate group id
     *
     * @return int
     */
    protected function getAffiliateGroupId()
    {
        $account = $this->getAffiliateAccount();

        return $account
            ? $account->getAffiliateGroupId()
            : 0;
    }

    /**
     * {@inheritdoc}
     */
    public function addField($field, $alias = null)
    {
        $fieldsToAdd = (is_string($field)) ? [$field] : $field;

        if (in_array(CouponInterface::COUPON_CODE, $fieldsToAdd)) {
            $this->getCollection()->addAffiliateCoupon($this->getAffiliateAccountId());
        } else {
            parent::addField($field, $alias);
        }
    }
}
