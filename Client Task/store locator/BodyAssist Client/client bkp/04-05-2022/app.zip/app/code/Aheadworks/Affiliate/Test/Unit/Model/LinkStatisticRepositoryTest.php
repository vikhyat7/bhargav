<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Model;

use Aheadworks\Affiliate\Api\Data\LinkStatisticInterface;
use Aheadworks\Affiliate\Api\Data\LinkStatisticInterfaceFactory;
use Aheadworks\Affiliate\Api\Data\LinkStatisticSearchResultsInterface;
use Aheadworks\Affiliate\Api\Data\LinkStatisticSearchResultsInterfaceFactory;
use Aheadworks\Affiliate\Model\LinkStatistic as LinkStatisticModel;
use Aheadworks\Affiliate\Model\ResourceModel\LinkStatistic as LinkStatisticResourceModel;
use Aheadworks\Affiliate\Model\ResourceModel\LinkStatistic\Collection as LinkStatisticCollection;
use Aheadworks\Affiliate\Model\ResourceModel\LinkStatistic\CollectionFactory as LinkStatisticCollectionFactory;
use Aheadworks\Affiliate\Model\LinkStatistic;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Aheadworks\Affiliate\Model\LinkStatisticRepository;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;

/**
 * Class LinkStatisticRepositoryTest
 *
 * @package Aheadworks\Affiliate\Test\Unit\Model
 */
class LinkStatisticRepositoryTest extends TestCase
{
    /**
     * @var LinkStatisticResourceModel|\PHPUnit_Framework_MockObject_MockObject
     */
    private $resourceMock;

    /**
     * @var LinkStatisticInterfaceFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $linkStatisticInterfaceFactoryMock;

    /**
     * @var LinkStatisticCollectionFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $linkStatisticCollectionFactoryMock;

    /**
     * @var LinkStatisticSearchResultsInterfaceFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $searchResultsFactoryMock;

    /**
     * @var JoinProcessorInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $extensionAttributesJoinProcessorMock;

    /**
     * @var CollectionProcessorInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $collectionProcessorMock;

    /**
     * @var DataObjectHelper|\PHPUnit_Framework_MockObject_MockObject
     */
    private $dataObjectHelperMock;

    /**
     * @var DataObjectProcessor|\PHPUnit_Framework_MockObject_MockObject
     */
    private $dataObjectProcessorMock;

    /**
     * @var LinkStatisticRepository
     */
    private $linkStatisticRepository;

    /**#@+
     * Constants used for tests
     */
    const DEFAULT_ID = 1;
    /**#@-*/

    /**
     * Init mocks for tests
     *
     * @return void
     */
    protected function setUp() : void
    {
        $objectManager = new ObjectManager($this);
        $this->resourceMock = $this->createMock(LinkStatisticResourceModel::class);
        $this->linkStatisticInterfaceFactoryMock = $this->createMock(LinkStatisticInterfaceFactory::class);
        $this->linkStatisticCollectionFactoryMock = $this->createMock(LinkStatisticCollectionFactory::class);
        $this->searchResultsFactoryMock = $this->createMock(LinkStatisticSearchResultsInterfaceFactory::class);
        $this->extensionAttributesJoinProcessorMock = $this->createMock(JoinProcessorInterface::class);
        $this->collectionProcessorMock = $this->createMock(CollectionProcessorInterface::class);
        $this->dataObjectHelperMock = $this->createMock(DataObjectHelper::class);
        $this->dataObjectProcessorMock = $this->createMock(DataObjectProcessor::class);
        $this->linkStatisticRepository = $objectManager->getObject(
            LinkStatisticRepository::class,
            [
                'resource' => $this->resourceMock,
                'linkStatisticInterfaceFactory' => $this->linkStatisticInterfaceFactoryMock,
                'linkStatisticCollectionFactory' => $this->linkStatisticCollectionFactoryMock,
                'searchResultsFactory' => $this->searchResultsFactoryMock,
                'extensionAttributesJoinProcessor' => $this->extensionAttributesJoinProcessorMock,
                'collectionProcessor' => $this->collectionProcessorMock,
                'dataObjectHelper' => $this->dataObjectHelperMock,
                'dataObjectProcessor' => $this->dataObjectProcessorMock
            ]
        );
    }

    /**
     * Test save method
     *
     * @throws CouldNotSaveException
     */
    public function testSave()
    {
        $linkStatisticMock = $this->getLinkStatisticMock(LinkStatisticInterface::class);

        $this->resourceMock->expects($this->once())
            ->method('save')
            ->willReturnSelf();

        $this->assertSame($linkStatisticMock, $this->linkStatisticRepository->save($linkStatisticMock));
    }

    /**
     * Test save method with exception
     *
     * @expectedException \Magento\Framework\Exception\CouldNotSaveException
     * @expectedExceptionMessage Test message
     * @throws CouldNotSaveException
     */
    public function testSaveWithException()
    {
        $exception = new \Exception('Test message');
        $linkStatisticMock = $this->getLinkStatisticMock();
        $this->resourceMock->expects($this->once())
            ->method('save')
            ->with($linkStatisticMock)
            ->willThrowException($exception);
        $this->expectException(CouldNotSaveException::class);
        $this->linkStatisticRepository->save($linkStatisticMock);
    }

    /**
     * Test getById method
     *
     * @throws NoSuchEntityException
     */
    public function testGetById()
    {
        $linkStatisticMock = $this->getLinkStatisticMock();

        $this->linkStatisticInterfaceFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($linkStatisticMock);
        $this->resourceMock->expects($this->once())
            ->method('load')
            ->with($linkStatisticMock, self::DEFAULT_ID)
            ->willReturnSelf();

        $this->assertSame($linkStatisticMock, $this->linkStatisticRepository->getById(self::DEFAULT_ID));
    }

    /**
     * Test getById method with exception
     *
     * @throws NoSuchEntityException
     * @expectedException \Magento\Framework\Exception\NoSuchEntityException
     * @expectedExceptionMessage No such entity with hit_id = 1
     */
    public function testGetByIdWithException()
    {
        $linkStatisticMock = $this->getLinkStatisticMock(null);

        $this->linkStatisticInterfaceFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($linkStatisticMock);
        $this->resourceMock->expects($this->once())
            ->method('load')
            ->with($linkStatisticMock, self::DEFAULT_ID)
            ->willReturnSelf();
        $this->expectException(NoSuchEntityException::class);
        $this->assertSame($linkStatisticMock, $this->linkStatisticRepository->getById(self::DEFAULT_ID));
    }

    /**
     * Test getList method
     *
     * @param array $collectionItems
     * @param array $searchResultItems
     * @param LinkStatisticModel|null|\PHPUnit_Framework_MockObject_MockObject $linkStatisticModelMock
     * @dataProvider testGetListProvider
     */
    public function testGetList($collectionItems, $searchResultItems, $linkStatisticModelMock = null)
    {
        /** @var SearchCriteriaInterface|\PHPUnit_Framework_MockObject_MockObject $searchCriteriaMock */
        $searchCriteriaMock = $this->createMock(SearchCriteriaInterface::class);
        $collectionSize = count($collectionItems);
        $linkStatisticCollectionMock = $this->createMock(LinkStatisticCollection::class);
        $searchResultsMock = $this->createMock(LinkStatisticSearchResultsInterface::class);
        $linkStatisticData = [LinkStatisticInterface::HIT_ID => self::DEFAULT_ID];

        $this->linkStatisticCollectionFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($linkStatisticCollectionMock);
        $this->extensionAttributesJoinProcessorMock->expects($this->once())
            ->method('process')
            ->with($linkStatisticCollectionMock, LinkStatisticInterface::class);
        $this->collectionProcessorMock->expects($this->once())
            ->method('process')
            ->with($searchCriteriaMock, $linkStatisticCollectionMock);
        $this->searchResultsFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($searchResultsMock);
        $searchResultsMock->expects($this->once())
            ->method('setSearchCriteria')
            ->with($searchCriteriaMock);
        $linkStatisticCollectionMock->expects($this->once())
            ->method('getSize')
            ->willReturn($collectionSize);
        $searchResultsMock->expects($this->once())
            ->method('setTotalCount')
            ->with($collectionSize);
        $linkStatisticCollectionMock->expects($this->once())
            ->method('getItems')
            ->willReturn($collectionItems);
        $this->linkStatisticInterfaceFactoryMock->expects($this->exactly($collectionSize))
            ->method('create')
            ->willReturn($linkStatisticModelMock);
        $this->dataObjectProcessorMock->expects($this->exactly($collectionSize))
            ->method('buildOutputDataArray')
            ->with($linkStatisticModelMock, LinkStatisticInterface::class)
            ->willReturn($linkStatisticData);
        $this->dataObjectHelperMock->expects($this->exactly($collectionSize))
            ->method('populateWithArray')
            ->with($linkStatisticModelMock, $linkStatisticData, LinkStatisticInterface::class);
        $searchResultsMock->expects($this->once())
            ->method('setItems')
            ->with($searchResultItems)
            ->willReturnSelf();

        $this->assertSame($searchResultsMock, $this->linkStatisticRepository->getList($searchCriteriaMock));
    }

    /**
     * Get linkStatistic mock
     *
     * @param int|null $linkStatisticId
     * @return LinkStatisticModel|\PHPUnit_Framework_MockObject_MockObject
     */
    private function getLinkStatisticMock($linkStatisticId = self::DEFAULT_ID)
    {
        $linkStatisticMock = $this->createMock(LinkStatisticModel::class);

        $linkStatisticMock->expects($this->atMost(1))
            ->method('getHitId')
            ->willReturn($linkStatisticId);

        return $linkStatisticMock;
    }

    /**
     * @return array
     */
    public function testGetListProvider()
    {
        $linkStatisticModelMock = $this->createMock(LinkStatisticModel::class);

        return [
            [[$linkStatisticModelMock], [$linkStatisticModelMock], $linkStatisticModelMock],
            [[],[]]
        ];
    }
}
