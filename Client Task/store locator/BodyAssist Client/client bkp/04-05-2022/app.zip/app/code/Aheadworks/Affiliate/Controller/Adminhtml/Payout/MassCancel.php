<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Payout;

use Aheadworks\Affiliate\Model\Source\Payout\Status;

/**
 * Class MassCancel
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Payout
 */
class MassCancel extends AbstractMassChangeStatus
{
    /**
     * {@inheritdoc}
     */
    protected function updateStatus($payoutId)
    {
        $this->payoutManagement->cancelPayout($payoutId);
    }

    /**
     * {@inheritdoc}
     */
    protected function getStatusToSet()
    {
        return Status::CANCELED;
    }

    /**
     * {@inheritdoc}
     */
    protected function getSuccessMessage($changedRecordsCounter)
    {
        return __('A total of %1 payout(s) were changed status to "Canceled".', $changedRecordsCounter);
    }
}
