<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Account\PostDataProcessor\MassCreate;

use Aheadworks\Affiliate\Model\PostData\ProcessorInterface as PostDataProcessorInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Aheadworks\Affiliate\Model\Customer\Provider as CustomerProvider;
use Aheadworks\Affiliate\Model\Account\Data\Collector as AccountDataCollector;

/**
 * Class CustomerData
 *
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Account\PostDataProcessor\MassCreate
 */
class CustomerData implements PostDataProcessorInterface
{
    /**
     * Name of the field with selected customers data
     */
    const CUSTOMER_SELECTION_DATA_FIELD_NAME = 'customer_selection';

    /**
     * @var CustomerProvider
     */
    private $customerProvider;

    /**
     * @var AccountDataCollector
     */
    private $customerDataAccountCollector;

    /**
     * @param CustomerProvider $customerProvider
     * @param AccountDataCollector $customerDataAccountCollector
     */
    public function __construct(
        CustomerProvider $customerProvider,
        AccountDataCollector $customerDataAccountCollector
    ) {
        $this->customerProvider = $customerProvider;
        $this->customerDataAccountCollector = $customerDataAccountCollector;
    }

    /**
     * {@inheritdoc}
     */
    public function process($data)
    {
        $preparedData = [];
        $websiteId = $data[AccountInterface::WEBSITE_ID] ?? null;
        $affiliateGroupId = $data[AccountInterface::AFFILIATE_GROUP_ID] ?? null;

        if (isset($data[self::CUSTOMER_SELECTION_DATA_FIELD_NAME])
            && is_array($data[self::CUSTOMER_SELECTION_DATA_FIELD_NAME])
        ) {
            foreach ($data[self::CUSTOMER_SELECTION_DATA_FIELD_NAME] as $customerDataRow) {
                $customerId = $customerDataRow[AccountInterface::CUSTOMER_ID] ?? null;
                if ($customerId) {
                    $affiliateAccountData = $this->getAffiliateAccountDataByCustomerId($customerId);
                    $affiliateAccountData[AccountInterface::WEBSITE_ID] = $websiteId;
                    $affiliateAccountData[AccountInterface::AFFILIATE_GROUP_ID] = $affiliateGroupId;
                    $preparedData[$customerId] = $affiliateAccountData;
                }
            }
        }

        return $preparedData;
    }

    /**
     * Get affiliate account data, collected by related customer
     *
     * @param int $customerId
     * @return array
     */
    private function getAffiliateAccountDataByCustomerId($customerId)
    {
        $customerData = $this->customerProvider->getData($customerId);
        return $this->customerDataAccountCollector->collect($customerData);
    }
}
