<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Campaign\PostDataProcessor;

use Aheadworks\Affiliate\Model\PostData\ProcessorInterface as PostDataProcessorInterface;
use Aheadworks\Affiliate\Api\Data\CampaignInterface;

/**
 * Class RecommendedProducts
 *
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Campaign\PostDataProcessor
 */
class RecommendedProducts implements PostDataProcessorInterface
{
    /**
     * Name of the field with recommeded products data
     */
    const RECOMMENDED_PRODUCTS_DATA_FIELD_NAME = 'recommended_products_selection';

    /**
     * {@inheritdoc}
     */
    public function process($data)
    {
        $data[CampaignInterface::RECOMMENDED_PRODUCT_IDS] = $this->getRecommendedProductIds($data);
        return $data;
    }

    /**
     * Retrieve from data array prepared recommended product ids array
     *
     * @param $data
     * @return array
     */
    private function getRecommendedProductIds($data)
    {
        $recommendedProductIds = [];
        if (isset($data[self::RECOMMENDED_PRODUCTS_DATA_FIELD_NAME])) {
            foreach ($data[self::RECOMMENDED_PRODUCTS_DATA_FIELD_NAME] as $recommendedProductData) {
                if (is_array($recommendedProductData) && isset($recommendedProductData['id'])) {
                    $recommendedProductIds[] = $recommendedProductData['id'];
                }
            }
        }
        return $recommendedProductIds;
    }
}
