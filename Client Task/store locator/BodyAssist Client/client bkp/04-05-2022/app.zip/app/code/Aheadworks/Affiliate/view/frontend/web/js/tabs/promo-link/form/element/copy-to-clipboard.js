define([
    'jquery',
    'Magento_Ui/js/form/components/button'
], function ($, Component) {
    'use strict';

    return Component.extend({
        defaults: {
            fieldSelector: '[name="generated_link"]'
        },

        /**
         * Copy text to clipboard
         */
        copyTextToClipboard: function () {
            $(this.fieldSelector).select();
            document.execCommand('Copy');
        }
    });
});
