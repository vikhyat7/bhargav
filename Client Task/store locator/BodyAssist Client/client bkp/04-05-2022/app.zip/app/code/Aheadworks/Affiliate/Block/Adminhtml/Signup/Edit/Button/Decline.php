<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Block\Adminhtml\Signup\Edit\Button;

use Aheadworks\Affiliate\Model\Source\Signup\Status;
use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;

/**
 * Class Save
 * @package Aheadworks\Affiliate\Block\Adminhtml\Signup\Edit\Button
 */
class Decline extends AbstractChangeStatusButton implements ButtonProviderInterface
{
    /**
     * {@inheritdoc}
     */
    public function getButtonData()
    {
        if ($this->isNeedToShow()) {
            return [
                'label' => __('Decline'),
                'class' => 'save primary',
                'data_attribute' => [
                    'mage-init' => ['button' => ['event' => 'save']],
                    'form-role' => 'save'
                ],
                'sort_order' => 60,
            ];
        } else {
            return [];
        }
    }

    /**
     * {@inheritdoc}
     */
    protected function getStatusToSet()
    {
        return Status::DECLINED;
    }
}
