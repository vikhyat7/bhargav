<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Plugin\Quote\Model\Quote\Item;

use PHPUnit\Framework\TestCase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Aheadworks\Affiliate\Plugin\Quote\Model\Quote\Item\ToOrderItemPlugin;
use Psr\Log\LoggerInterface;
use Magento\Quote\Model\Quote\Item\ToOrderItem;
use Magento\Quote\Model\Quote\Item;
use Magento\Quote\Model\Quote\Address\Item as AddressItem;
use Magento\Sales\Api\Data\OrderItemInterface;
use Aheadworks\Affiliate\Api\Data\PromoDataInterface;
use Aheadworks\Affiliate\Model\PromoData\Resolver as PromoDataResolver;
use Aheadworks\Affiliate\Api\OrderItemManagementInterface;

/**
 * Test for \Aheadworks\Affiliate\Plugin\Quote\Model\Quote\Item\ToOrderItemPlugin
 */
class ToOrderItemPluginTest extends TestCase
{
    /**
     * @var ToOrderItemPlugin
     */
    private $model;

    /**
     * @var LoggerInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $loggerMock;

    /**
     * @var PromoDataResolver|\PHPUnit_Framework_MockObject_MockObject
     */
    private $promoDataResolverMock;

    /**
     * @var OrderItemManagementInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $orderItemManagementMock;

    /**
     * Init mocks for tests
     *
     * @return void
     */
    public function setUp() : void
    {
        $objectManager = new ObjectManager($this);

        $this->loggerMock = $this->createMock(LoggerInterface::class);
        $this->promoDataResolverMock = $this->createMock(PromoDataResolver::class);
        $this->orderItemManagementMock = $this->createMock(OrderItemManagementInterface::class);

        $this->model = $objectManager->getObject(
            ToOrderItemPlugin::class,
            [
                'logger' => $this->loggerMock,
                'promoDataResolver' => $this->promoDataResolverMock,
                'orderItemManagement' => $this->orderItemManagementMock
            ]
        );
    }

    /**
     * Test afterConvert for quote item
     *
     * @param bool $isPromoDataAddedSuccessfully
     * @dataProvider promoDataAddedFlagDataProvider
     */
    public function testAfterConvertForQuoteItem($isPromoDataAddedSuccessfully)
    {
        $subjectMock = $this->createMock(ToOrderItem::class);
        $orderItemMock = $this->createMock(OrderItemInterface::class);
        $quoteItemMock = $this->createMock(Item::class);
        $additional = [];

        $promoDataMock = $this->createMock(PromoDataInterface::class);

        $this->promoDataResolverMock->expects($this->any())
            ->method('resolveByQuoteItem')
            ->with($quoteItemMock)
            ->willReturn($promoDataMock);

        $this->orderItemManagementMock->expects($this->any())
            ->method('addPromoData')
            ->with($orderItemMock, $quoteItemMock, $promoDataMock)
            ->willReturn($isPromoDataAddedSuccessfully);

        $this->loggerMock->expects($this->never())
            ->method('error');

        $this->assertSame(
            $orderItemMock,
            $this->model->afterConvert($subjectMock, $orderItemMock, $quoteItemMock, $additional)
        );
    }

    /**
     * @return array
     */
    public function promoDataAddedFlagDataProvider()
    {
        return [
            [
                'isPromoDataAddedSuccessfully' => true,
            ],
            [
                'isPromoDataAddedSuccessfully' => false,
            ],
        ];
    }

    /**
     * Test afterConvert for address item
     *
     * @param bool $isPromoDataAddedSuccessfully
     * @dataProvider promoDataAddedFlagDataProvider
     */
    public function testAfterConvertForAddressItem($isPromoDataAddedSuccessfully)
    {
        $subjectMock = $this->createMock(ToOrderItem::class);
        $orderItemMock = $this->createMock(OrderItemInterface::class);
        $quoteItemMock = $this->createMock(Item::class);
        $addressItem = $this->createMock(AddressItem::class);
        $addressItem->expects($this->any())
            ->method('__call')
            ->with('getQuoteItem')
            ->willReturn($orderItemMock);
        $additional = [];

        $promoDataMock = $this->createMock(PromoDataInterface::class);

        $this->promoDataResolverMock->expects($this->any())
            ->method('resolveByQuoteItem')
            ->with($quoteItemMock)
            ->willReturn($promoDataMock);

        $this->orderItemManagementMock->expects($this->any())
            ->method('addPromoData')
            ->with($orderItemMock, $quoteItemMock, $promoDataMock)
            ->willReturn($isPromoDataAddedSuccessfully);

        $this->loggerMock->expects($this->never())
            ->method('error');

        $this->assertSame(
            $orderItemMock,
            $this->model->afterConvert($subjectMock, $orderItemMock, $addressItem, $additional)
        );
    }

    /**
     * Test afterConvert for item of incorrect class
     */
    public function testAfterConvertForIncorrectItem()
    {
        $subjectMock = $this->createMock(ToOrderItem::class);
        $orderItemMock = $this->createMock(OrderItemInterface::class);
        $additional = [];

        $this->promoDataResolverMock->expects($this->any())
            ->method('resolveByQuoteItem');

        $this->orderItemManagementMock->expects($this->any())
            ->method('addPromoData');

        $this->loggerMock->expects($this->never())
            ->method('error');

        $this->assertSame(
            $orderItemMock,
            $this->model->afterConvert($subjectMock, $orderItemMock, $orderItemMock, $additional)
        );
    }

    /**
     * Test afterConvert for address with item of incorrect class
     */
    public function testAfterConvertForAddressWithIncorrectItem()
    {
        $subjectMock = $this->createMock(ToOrderItem::class);
        $orderItemMock = $this->createMock(OrderItemInterface::class);
        $addressItem = $this->createMock(AddressItem::class);
        $addressItem->expects($this->any())
            ->method('__call')
            ->with('getQuoteItem')
            ->willReturn($orderItemMock);
        $additional = [];

        $this->promoDataResolverMock->expects($this->any())
            ->method('resolveByQuoteItem');

        $this->orderItemManagementMock->expects($this->any())
            ->method('addPromoData');

        $this->loggerMock->expects($this->never())
            ->method('error');

        $this->assertSame(
            $orderItemMock,
            $this->model->afterConvert($subjectMock, $orderItemMock, $addressItem, $additional)
        );
    }
}
