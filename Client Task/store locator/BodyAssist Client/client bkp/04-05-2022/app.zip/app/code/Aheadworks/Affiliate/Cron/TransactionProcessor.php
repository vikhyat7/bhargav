<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Cron;

use Aheadworks\Affiliate\Model\Config;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Aheadworks\Affiliate\Api\TransactionHoldingPeriodManagementInterface;

/**
 * Class TransactionProcessor
 *
 * @package Aheadworks\Affiliate\Cron
 */
class TransactionProcessor extends CronAbstract
{
    /**
     * Cron run interval in seconds
     */
    const RUN_INTERVAL = 23 * 60 * 60;

    /**
     * @var TransactionHoldingPeriodManagementInterface
     */
    private $transactionHoldingPeriodService;

    /**
     * @param Config $config
     * @param DateTime $dateTime
     * @param TransactionHoldingPeriodManagementInterface $transactionHoldingPeriodService
     */
    public function __construct(
        Config $config,
        DateTime $dateTime,
        TransactionHoldingPeriodManagementInterface $transactionHoldingPeriodService
    ) {
        parent::__construct($config, $dateTime);
        $this->transactionHoldingPeriodService = $transactionHoldingPeriodService;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        if ($this->isLocked($this->config->getCronTransactionProcessorLastExecTime(), self::RUN_INTERVAL)) {
            return $this;
        }

        $this->transactionHoldingPeriodService->processExpiredTransactions();

        $this->config->setCronTransactionProcessorLastExecTime($this->getCurrentTime());

        return $this;
    }
}
