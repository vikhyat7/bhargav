<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Model\Service;

use Aheadworks\Affiliate\Api\CampaignRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Aheadworks\Affiliate\Api\Data\CouponInterface;
use Aheadworks\Affiliate\Model\CouponManager;
use Aheadworks\Affiliate\Model\Service\CouponService;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Phrase;
use PHPUnit\Framework\TestCase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Aheadworks\Affiliate\Api\AccountRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Magento\Framework\Exception\CouldNotSaveException;

/**
 * Class CouponServiceTest
 * @package Aheadworks\Affiliate\Test\Unit\Model\Service
 */
class CouponServiceTest extends TestCase
{
    /**
     * @var AccountRepositoryInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $accountRepositoryMock;

    /**
     * @var CampaignRepositoryInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $campaignRepositoryMock;

    /**
     * @var CouponManager|\PHPUnit_Framework_MockObject_MockObject
     */
    private $couponManagerMock;

    /**
     * @var CouponService
     */
    private $testedClass;

    /**#@+
     * Constants used for tests
     */
    const NO_SUCH_ACCOUNT_EXC_CODE = 1;
    const NO_SUCH_CAMPAIGN_EXC_CODE = 2;
    /**#@-*/

    /**
     * Init mocks for tests
     *
     * @return void
     */
    public function setUp() : void
    {
        $objectManager = new ObjectManager($this);
        $this->accountRepositoryMock = $this->createMock(AccountRepositoryInterface::class);
        $this->campaignRepositoryMock = $this->createMock(CampaignRepositoryInterface::class);
        $this->couponManagerMock = $this->createMock(CouponManager::class);
        $this->testedClass = $objectManager->getObject(
            CouponService::class,
            [
                'accountRepository' => $this->accountRepositoryMock,
                'campaignRepository' => $this->campaignRepositoryMock,
                'couponManager' => $this->couponManagerMock
            ]
        );
    }

    /**
     * Test generateCouponCode method
     *
     * @throws LocalizedException
     */
    public function testGenerateCouponCode()
    {
        $accountId = 1;
        $campaignId = 1;
        $accountMock = $this->createMock(AccountInterface::class);
        $campaignMock = $this->createMock(CampaignInterface::class);
        $couponMock = $this->createMock(CouponInterface::class);
        $couponCode = 'AFFPREFIX-CAMPAIGNBASE';

        $this->accountRepositoryMock->expects($this->once())
            ->method('getById')
            ->with($accountId)
            ->willReturn($accountMock);
        $this->campaignRepositoryMock->expects($this->once())
            ->method('getById')
            ->with($campaignId)
            ->willReturn($campaignMock);
        $this->couponManagerMock->expects($this->once())
            ->method('generateCoupon')
            ->with($accountMock, $campaignMock)
            ->willReturn($couponMock);
        $couponMock->expects($this->once())
            ->method('getCouponCode')
            ->willReturn($couponCode);

        $this->assertEquals($couponCode, $this->testedClass->generateCouponCode($accountId, $campaignId));
    }

    /**
     * Test generateCouponCode method with exception
     *
     * @param CouldNotSaveException|NoSuchEntityException $exception
     * @param Phrase $excMessage
     * @dataProvider testGenerateCouponCodeWithExceptionProvider
     * @expectedException \Magento\Framework\Exception\LocalizedException
     * @throws LocalizedException
     */
    public function testGenerateCouponCodeWithException($exception, $excMessage)
    {
        $accountId = 1;
        $campaignId = 1;
        $accountMock = $this->createMock(AccountInterface::class);
        $campaignMock = $this->createMock(CampaignInterface::class);

        if ($exception->getCode() == self::NO_SUCH_ACCOUNT_EXC_CODE) {
            $this->accountRepositoryMock->expects($this->once())
                ->method('getById')
                ->with($accountId)
                ->willThrowException($exception);
        } elseif ($exception->getCode() == self::NO_SUCH_CAMPAIGN_EXC_CODE) {
            $this->campaignRepositoryMock->expects($this->once())
                ->method('getById')
                ->with($campaignId)
                ->willThrowException($exception);
        } else {
            $this->accountRepositoryMock->expects($this->once())
                ->method('getById')
                ->with($accountId)
                ->willReturn($accountMock);
            $this->campaignRepositoryMock->expects($this->once())
                ->method('getById')
                ->with($campaignId)
                ->willReturn($campaignMock);
            $this->couponManagerMock->expects($this->once())
                ->method('generateCoupon')
                ->with($accountMock, $campaignMock)
                ->willThrowException($exception);
        }
        $this->expectExceptionMessage($excMessage);

        $this->testedClass->generateCouponCode($accountId, $campaignId);
    }

    /**
     * @return array
     */
    public function testGenerateCouponCodeWithExceptionProvider()
    {
        return [
            [
                new NoSuchEntityException(__('No such account message.', null, self::NO_SUCH_ACCOUNT_EXC_CODE)),
                'No such account message.'
            ],
            [
                new NoSuchEntityException(__('No such campaign message.', null, self::NO_SUCH_CAMPAIGN_EXC_CODE)),
                'No such campaign message.'
            ],
            [
                new NoSuchEntityException(__('No such rule for coupon generation.')),
                'No such rule for coupon generation.'
            ],
            [
                new InputException(__('Error input message.')),
                'Error input message.'
            ],
            [
                new LocalizedException(__('Error while generation coupon.')),
                'Error while generation coupon.'
            ]
        ];
    }
}
