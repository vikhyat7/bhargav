<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Group;

use Aheadworks\Affiliate\Model\AffiliateGroup;
use Magento\Backend\App\Action\Context;
use Aheadworks\Affiliate\Model\ResourceModel\AffiliateGroup\CollectionFactory;
use Aheadworks\Affiliate\Model\ResourceModel\AffiliateGroup\Collection;
use Aheadworks\Affiliate\Api\AffiliateGroupRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\AffiliateGroupInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Ui\Component\MassAction\Filter;
use Magento\Backend\App\Action;
use Magento\Framework\Exception\LocalizedException;

/**
 * Class MassDelete
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Group
 */
class MassDelete extends Action
{
    /**
     * {@inheritdoc}
     */
    const ADMIN_RESOURCE = 'Aheadworks_Affiliate::affiliate_groups';

    /**
     * @var CollectionFactory
     */
    private $collectionFactory;

    /**
     * @var Filter
     */
    private $filter;

    /**
     * @var AffiliateGroupRepositoryInterface
     */
    protected $affiliateGroupRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * @param Context $context
     * @param CollectionFactory $collectionFactory
     * @param AffiliateGroupRepositoryInterface $affiliateGroupRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param Filter $filter
     */
    public function __construct(
        Context $context,
        CollectionFactory $collectionFactory,
        AffiliateGroupRepositoryInterface $affiliateGroupRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        Filter $filter
    ) {
        parent::__construct($context);
        $this->collectionFactory = $collectionFactory;
        $this->filter = $filter;
        $this->affiliateGroupRepository = $affiliateGroupRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        try {
            $affiliateGroupsArray = $this->getAffiliateGroupsToDelete();
            $this->deleteAffiliateGroups($affiliateGroupsArray);
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        }

        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $resultRedirect->setPath('*/*/index');
        return $resultRedirect;
    }

    /**
     * Retrieve array of affiliate groups for mass action
     *
     * @return AffiliateGroupInterface[]
     */
    private function getAffiliateGroupsToDelete()
    {
        $affiliateGroupsToDelete = [];
        try {
            /** @var Collection $collection */
            $collection = $this->filter->getCollection($this->collectionFactory->create());
            $searchCriteria = $this->searchCriteriaBuilder
                ->addFilter(AffiliateGroupInterface::ID, $collection->getAllIds(), 'in')
                ->create();
            $affiliateGroupsToDelete = $this->affiliateGroupRepository->getList($searchCriteria)->getItems();
        } catch (LocalizedException $exception) {
            $affiliateGroupsToDelete = [];
        }

        return $affiliateGroupsToDelete;
    }

    /**
     * Delete affiliate groups
     *
     * @param AffiliateGroupInterface[] $affiliateGroupsArray
     */
    private function deleteAffiliateGroups($affiliateGroupsArray)
    {
        $deletedRecords = 0;
        /** @var AffiliateGroup $item */
        foreach ($affiliateGroupsArray as $item) {
            try {
                $this->affiliateGroupRepository->delete($item);
                $deletedRecords++;
            } catch (CouldNotDeleteException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            }
        }
        if ($deletedRecords) {
            $this->messageManager->addSuccessMessage(__('A total of %1 record(s) were deleted.', $deletedRecords));
        } else {
            $this->messageManager->addSuccessMessage(__('No records were deleted.'));
        }
    }
}
