<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Ui\Component\RecommendedProduct\Listing\Column;

use Magento\Ui\Component\Listing\Columns\Column;

/**
 * Class AbstractLabel
 *
 * @package Aheadworks\Affiliate\Ui\Component\RecommendedProduct\Listing\Column
 */
abstract class AbstractLabel extends Column
{
    /**
     * {@inheritdoc}
     */
    public function prepareDataSource(array $dataSource)
    {
        $fieldName = $this->getData('name');
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$item) {
                $fieldValue = $this->getFieldValue($item);
                if (!empty($fieldValue)) {
                    $item[$fieldName] = $this->resolveFieldLabel($fieldValue);
                }
            }
        }
        return $dataSource;
    }

    /**
     * Retrieve field value from item data array
     *
     * @param array $itemData
     * @return string|null
     */
    abstract protected function getFieldValue($itemData);

    /**
     * Resolve field label by its value
     *
     * @param string $fieldValue
     * @return null|string
     */
    abstract protected function resolveFieldLabel($fieldValue);
}
