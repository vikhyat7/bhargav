<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Model;

use Aheadworks\Affiliate\Api\Data\TransactionInterface;
use Aheadworks\Affiliate\Api\Data\TransactionInterfaceFactory;
use Aheadworks\Affiliate\Api\Data\TransactionSearchResultsInterface;
use Aheadworks\Affiliate\Api\Data\TransactionSearchResultsInterfaceFactory;
use Aheadworks\Affiliate\Model\Source\Transaction\EntityType;
use Aheadworks\Affiliate\Model\Transaction as TransactionModel;
use Aheadworks\Affiliate\Model\ResourceModel\Transaction as TransactionResourceModel;
use Aheadworks\Affiliate\Model\ResourceModel\Transaction\Collection as TransactionCollection;
use Aheadworks\Affiliate\Model\ResourceModel\Transaction\CollectionFactory as TransactionCollectionFactory;
use Aheadworks\Affiliate\Model\Transaction;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Aheadworks\Affiliate\Model\TransactionRepository;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;

/**
 * Class TransactionRepositoryTest
 *
 * @package Aheadworks\Affiliate\Test\Unit\Model
 */
class TransactionRepositoryTest extends TestCase
{
    /**
     * @var TransactionResourceModel|\PHPUnit_Framework_MockObject_MockObject
     */
    private $resourceMock;

    /**
     * @var TransactionInterfaceFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $transactionInterfaceFactoryMock;

    /**
     * @var TransactionCollectionFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $transactionCollectionFactoryMock;

    /**
     * @var TransactionSearchResultsInterfaceFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $searchResultsFactoryMock;

    /**
     * @var JoinProcessorInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $extensionAttributesJoinProcessorMock;

    /**
     * @var CollectionProcessorInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $collectionProcessorMock;

    /**
     * @var DataObjectHelper|\PHPUnit_Framework_MockObject_MockObject
     */
    private $dataObjectHelperMock;

    /**
     * @var DataObjectProcessor|\PHPUnit_Framework_MockObject_MockObject
     */
    private $dataObjectProcessorMock;

    /**
     * @var TransactionRepository
     */
    private $transactionRepository;

    /**#@+
     * Constants used for tests
     */
    const DEFAULT_ID = 1;
    /**#@-*/

    /**
     * Init mocks for tests
     *
     * @return void
     */
    protected function setUp() : void
    {
        $objectManager = new ObjectManager($this);
        $this->resourceMock = $this->createMock(TransactionResourceModel::class);
        $this->transactionInterfaceFactoryMock = $this->createMock(TransactionInterfaceFactory::class);
        $this->transactionCollectionFactoryMock = $this->createMock(TransactionCollectionFactory::class);
        $this->searchResultsFactoryMock = $this->createMock(TransactionSearchResultsInterfaceFactory::class);
        $this->extensionAttributesJoinProcessorMock = $this->createMock(JoinProcessorInterface::class);
        $this->collectionProcessorMock = $this->createMock(CollectionProcessorInterface::class);
        $this->dataObjectHelperMock = $this->createMock(DataObjectHelper::class);
        $this->dataObjectProcessorMock = $this->createMock(DataObjectProcessor::class);
        $this->transactionRepository = $objectManager->getObject(
            TransactionRepository::class,
            [
                'resource' => $this->resourceMock,
                'transactionInterfaceFactory' => $this->transactionInterfaceFactoryMock,
                'transactionCollectionFactory' => $this->transactionCollectionFactoryMock,
                'searchResultsFactory' => $this->searchResultsFactoryMock,
                'extensionAttributesJoinProcessor' => $this->extensionAttributesJoinProcessorMock,
                'collectionProcessor' => $this->collectionProcessorMock,
                'dataObjectHelper' => $this->dataObjectHelperMock,
                'dataObjectProcessor' => $this->dataObjectProcessorMock
            ]
        );
    }

    /**
     * Test save method
     *
     * @throws CouldNotSaveException
     */
    public function testSave()
    {
        $transactionMock = $this->getTransactionMock(TransactionInterface::class);

        $this->resourceMock->expects($this->once())
            ->method('save')
            ->willReturnSelf();

        $this->assertSame($transactionMock, $this->transactionRepository->save($transactionMock));
    }

    /**
     * Test save method with exception
     *
     * @expectedException \Magento\Framework\Exception\CouldNotSaveException
     * @expectedExceptionMessage Test message
     * @throws CouldNotSaveException
     */
    public function testSaveWithException()
    {
        $exception = new \Exception('Test message');
        $transactionMock = $this->getTransactionMock();
        $this->resourceMock->expects($this->once())
            ->method('save')
            ->with($transactionMock)
            ->willThrowException($exception);
        $this->expectException(CouldNotSaveException::class);
        $this->transactionRepository->save($transactionMock);
    }

    /**
     * Test getById method
     *
     * @throws NoSuchEntityException
     */
    public function testGetById()
    {
        $transactionMock = $this->getTransactionMock();

        $this->transactionInterfaceFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($transactionMock);
        $this->resourceMock->expects($this->once())
            ->method('load')
            ->with($transactionMock, self::DEFAULT_ID)
            ->willReturnSelf();

        $this->assertSame($transactionMock, $this->transactionRepository->getById(self::DEFAULT_ID));
    }

    /**
     * Test getById method with exception
     *
     * @throws NoSuchEntityException
     * @expectedException \Magento\Framework\Exception\NoSuchEntityException
     * @expectedExceptionMessage No such entity with transaction_id = 1
     */
    public function testGetByIdWithException()
    {
        $transactionMock = $this->getTransactionMock(null);

        $this->transactionInterfaceFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($transactionMock);
        $this->resourceMock->expects($this->once())
            ->method('load')
            ->with($transactionMock, self::DEFAULT_ID)
            ->willReturnSelf();
        $this->expectException(NoSuchEntityException::class);
        $this->assertSame($transactionMock, $this->transactionRepository->getById(self::DEFAULT_ID));
    }

    /**
     * Test getList method
     *
     * @param array $collectionItems
     * @param array $searchResultItems
     * @param TransactionModel|null|\PHPUnit_Framework_MockObject_MockObject $transactionModelMock
     * @dataProvider testGetListProvider
     */
    public function testGetList($collectionItems, $searchResultItems, $transactionModelMock = null)
    {
        /** @var SearchCriteriaInterface|\PHPUnit_Framework_MockObject_MockObject $searchCriteriaMock */
        $searchCriteriaMock = $this->createMock(SearchCriteriaInterface::class);
        $collectionSize = count($collectionItems);
        $transactionCollectionMock = $this->createMock(TransactionCollection::class);
        $searchResultsMock = $this->createMock(TransactionSearchResultsInterface::class);
        $transactionData = [TransactionInterface::ID => self::DEFAULT_ID];

        $this->transactionCollectionFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($transactionCollectionMock);
        $this->extensionAttributesJoinProcessorMock->expects($this->once())
            ->method('process')
            ->with($transactionCollectionMock, TransactionInterface::class);
        $this->collectionProcessorMock->expects($this->once())
            ->method('process')
            ->with($searchCriteriaMock, $transactionCollectionMock);
        $this->searchResultsFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($searchResultsMock);
        $searchResultsMock->expects($this->once())
            ->method('setSearchCriteria')
            ->with($searchCriteriaMock);
        $transactionCollectionMock->expects($this->once())
            ->method('getSize')
            ->willReturn($collectionSize);
        $searchResultsMock->expects($this->once())
            ->method('setTotalCount')
            ->with($collectionSize);
        $transactionCollectionMock->expects($this->once())
            ->method('getItems')
            ->willReturn($collectionItems);
        $this->transactionInterfaceFactoryMock->expects($this->exactly($collectionSize))
            ->method('create')
            ->willReturn($transactionModelMock);
        $this->dataObjectProcessorMock->expects($this->exactly($collectionSize))
            ->method('buildOutputDataArray')
            ->with($transactionModelMock, TransactionInterface::class)
            ->willReturn($transactionData);
        $this->dataObjectHelperMock->expects($this->exactly($collectionSize))
            ->method('populateWithArray')
            ->with($transactionModelMock, $transactionData, TransactionInterface::class);
        $searchResultsMock->expects($this->once())
            ->method('setItems')
            ->with($searchResultItems)
            ->willReturnSelf();

        $this->assertSame($searchResultsMock, $this->transactionRepository->getList($searchCriteriaMock));
    }

    /**
     * Test getTransactionIdForEntity method
     *
     * @param string $entityType
     * @param int $entityId
     * @param string $transactionId
     * @dataProvider testGetTransactionIdForEntityProvider
     */
    public function testGetTransactionIdForEntity($entityType, $entityId, $transactionId = '')
    {
        $this->resourceMock->expects($this->once())
            ->method('getTransactionIdForEntity')
            ->with($entityType, $entityId)
            ->willReturn($transactionId);

        $this->assertEquals(
            $transactionId,
            $this->transactionRepository->getTransactionIdForEntity($entityType, $entityId)
        );
    }

    /**
     * Get transaction mock
     *
     * @param int|null $transactionId
     * @return TransactionModel|\PHPUnit_Framework_MockObject_MockObject
     */
    private function getTransactionMock($transactionId = self::DEFAULT_ID)
    {
        $transactionMock = $this->createMock(TransactionModel::class);

        $transactionMock->expects($this->atMost(1))
            ->method('getTransactionId')
            ->willReturn($transactionId);

        return $transactionMock;
    }

    /**
     * @return array
     */
    public function testGetListProvider()
    {
        $transactionModelMock = $this->createMock(TransactionModel::class);

        return [
            [[$transactionModelMock], [$transactionModelMock], $transactionModelMock],
            [[],[]]
        ];
    }

    /**
     * @return array
     */
    public function testGetTransactionIdForEntityProvider()
    {
        return [
            [EntityType::PAYOUT, 1, (string)self::DEFAULT_ID],
            [EntityType::ORDER_ITEM, 1, (string)self::DEFAULT_ID],
            [EntityType::PAYOUT, 1],
            [EntityType::ORDER_ITEM, 1]
        ];
    }
}
