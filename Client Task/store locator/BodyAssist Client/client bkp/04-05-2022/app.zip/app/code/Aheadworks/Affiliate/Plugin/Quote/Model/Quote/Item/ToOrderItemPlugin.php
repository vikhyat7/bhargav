<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Plugin\Quote\Model\Quote\Item;

use Psr\Log\LoggerInterface;
use Magento\Quote\Model\Quote\Item\ToOrderItem;
use Magento\Quote\Model\Quote\Item;
use Magento\Quote\Model\Quote\Address\Item as AddressItem;
use Magento\Sales\Api\Data\OrderItemInterface;
use Aheadworks\Affiliate\Api\Data\PromoDataInterface;
use Aheadworks\Affiliate\Model\PromoData\Resolver as PromoDataResolver;
use Aheadworks\Affiliate\Api\OrderItemManagementInterface;
use Magento\Quote\Api\Data\CartItemInterface;

/**
 * Class ToOrderItemPlugin
 *
 * @package Aheadworks\Affiliate\Plugin\Quote\Model\Quote\Item
 */
class ToOrderItemPlugin
{
    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var PromoDataResolver
     */
    private $promoDataResolver;

    /**
     * @var OrderItemManagementInterface
     */
    private $orderItemManagement;

    /**
     * @param LoggerInterface $logger
     * @param PromoDataResolver $promoDataResolver
     * @param OrderItemManagementInterface $orderItemManagement
     */
    public function __construct(
        LoggerInterface $logger,
        PromoDataResolver $promoDataResolver,
        OrderItemManagementInterface $orderItemManagement
    ) {
        $this->logger = $logger;
        $this->promoDataResolver = $promoDataResolver;
        $this->orderItemManagement = $orderItemManagement;
    }

    /**
     * @param ToOrderItem $subject
     * @param OrderItemInterface $orderItem
     * @param Item|AddressItem $item
     * @param array $additional
     * @return OrderItemInterface
     */
    public function afterConvert(
        ToOrderItem $subject,
        OrderItemInterface $orderItem,
        $item,
        $additional = []
    ) {
        $item = $item instanceof AddressItem
            ? $item->getQuoteItem()
            : $item;

        if ($item instanceof CartItemInterface) {
            try {
                /** @var PromoDataInterface $promoData */
                $promoData = $this->promoDataResolver->resolveByQuoteItem($item);
                $this->orderItemManagement->addPromoData($orderItem, $item, $promoData);
            } catch (\Exception $e) {
                $this->logger->error($e);
            }
        }

        return $orderItem;
    }
}
