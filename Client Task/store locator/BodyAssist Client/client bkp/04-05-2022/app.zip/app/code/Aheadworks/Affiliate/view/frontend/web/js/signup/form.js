define([
    'jquery',
    'Aheadworks_Affiliate/js/ui/form/form'
], function ($, Component) {
    'use strict';

    return Component.extend({
        defaults: {
            imports: {
                isCustomerHasAccount: '${ $.globalConfigProvider }:data.is_customer_has_account',
                isCustomerHasActiveSignup: '${ $.configProvider }:data.is_customer_has_active_signup'
            },
            template: 'Aheadworks_Affiliate/signup/form',
            formMessage: 'Your request has been registered. We\'ll review it in 2-3 business '
                + 'days and notify you about our decision via email. Thanks for your patience.'
        },

        /**
         * Check if need to render signup form
         *
         * @returns {boolean}
         */
        isNeedToRenderForm: function () {
            return !this.isCustomerHasAccount
                && !this.isCustomerHasActiveSignup;
        },

        /**
         * Retrieve information message for the form
         *
         * @returns {String}
         */
        getMessage: function () {
            return !this.isCustomerHasAccount && this.isCustomerHasActiveSignup
                ? this.formMessage
                : '';
        }
    });
});
