<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller;

use Aheadworks\Affiliate\Api\AccountRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Magento\Framework\App\Action\Context;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Data\Form\FormKey\Validator as FormKeyValidator;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Class AbstractPostCustomerAction
 * @package Aheadworks\Affiliate\Controller
 */
abstract class AbstractPostCustomerAction extends AbstractCustomerAction
{
    /**
     * @var FormKeyValidator
     */
    private $formKeyValidator;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * @var AccountRepositoryInterface
     */
    private $accountRepository;

    /**
     * @param Context $context
     * @param CustomerSession $customerSession
     * @param FormKeyValidator $formKeyValidator
     * @param StoreManagerInterface $storeManager
     * @param AccountRepositoryInterface $accountRepository
     */
    public function __construct(
        Context $context,
        CustomerSession $customerSession,
        FormKeyValidator $formKeyValidator,
        StoreManagerInterface $storeManager,
        AccountRepositoryInterface $accountRepository
    ) {
        parent::__construct($context, $customerSession);
        $this->formKeyValidator = $formKeyValidator;
        $this->storeManager = $storeManager;
        $this->accountRepository = $accountRepository;
    }

    /**
     * Validate form
     *
     * @throws LocalizedException
     */
    protected function validate()
    {
        if (!$this->formKeyValidator->validate($this->getRequest())) {
            throw new LocalizedException(__('Invalid Form Key. Please refresh the page.'));
        }
    }

    /**
     * Get affiliate account
     *
     * @return AccountInterface
     * @throws NoSuchEntityException
     */
    protected function getAffiliateAccount()
    {
        return $this->accountRepository->getByCustomerId(
            $this->customerSession->getCustomerId(),
            $this->storeManager->getStore()->getWebsiteId()
        );
    }
}
