<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Ui\DataProvider\Frontend;

use Aheadworks\Affiliate\Api\AccountRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Ui\DataProvider\AbstractDataProvider as UiAbstractDataProvider;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Customer\Model\Session as CustomerSession;

/**
 * Class AbstractDataProvider
 * @package Aheadworks\AdvancedReviews\Ui\DataProvider\Frontend
 */
abstract class AbstractDataProvider extends UiAbstractDataProvider
{
    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * @var CustomerSession
     */
    private $customerSession;

    /**
     * @var AccountRepositoryInterface
     */
    private $accountRepository;

    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param StoreManagerInterface $storeManager
     * @param CustomerSession $customerSession
     * @param AccountRepositoryInterface $accountRepository
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        StoreManagerInterface $storeManager,
        CustomerSession $customerSession,
        AccountRepositoryInterface $accountRepository,
        array $meta = [],
        array $data = []
    ) {
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
        $this->storeManager = $storeManager;
        $this->customerSession = $customerSession;
        $this->accountRepository = $accountRepository;
    }

    /**
     * Get data
     *
     * @return array
     */
    public function getData()
    {
        $this->prepareCollectionForLoading();

        return $this->getCollection()->toArray();
    }

    /**
     * Perform all necessary operations to prepare collection for loading
     *
     * @return $this
     */
    private function prepareCollectionForLoading()
    {
        $this->applyDefaultFilters();
        $this->applyDefaultSorting();

        return $this;
    }

    /**
     * Apply default filters to the collection
     *
     * @return void
     */
    abstract protected function applyDefaultFilters();

    /**
     * Apply default sorting to the collection
     * phpcs:disable Magento2.CodeAnalysis.EmptyBlock.DetectedFunction
     */
    protected function applyDefaultSorting()
    {
    }

    /**
     * Retrieve current website id
     *
     * @return int
     */
    protected function getCurrentWebsiteId()
    {
        try {
            $websiteId = $this->storeManager->getStore()->getWebsiteId();
        } catch (NoSuchEntityException $e) {
            $websiteId = 0;
        }

        return $websiteId;
    }

    /**
     * Retrieve current customer id
     *
     * @return int|null
     */
    protected function getCurrentCustomerId()
    {
        return $this->customerSession->getCustomerId();
    }

    /**
     * Retrieve affiliate account id
     *
     * @return int
     */
    protected function getAffiliateAccountId()
    {
        $account = $this->getAffiliateAccount();

        return $account
            ? $account->getAccountId()
            : 0;
    }

    /**
     * Retrieve affiliate account
     *
     * @return AccountInterface|null
     */
    protected function getAffiliateAccount()
    {
        try {
            $account = $this->accountRepository->getByCustomerId(
                $this->getCurrentCustomerId(),
                $this->getCurrentWebsiteId()
            );
        } catch (NoSuchEntityException $e) {
            $account = null;
        }

        return $account;
    }
}
