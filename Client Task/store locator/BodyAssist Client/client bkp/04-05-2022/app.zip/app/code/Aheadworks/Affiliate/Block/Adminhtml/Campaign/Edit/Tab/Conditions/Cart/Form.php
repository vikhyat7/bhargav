<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Block\Adminhtml\Campaign\Edit\Tab\Conditions\Cart;

use Aheadworks\Affiliate\Block\Adminhtml\Campaign\Edit\Tab\Conditions\AbstractForm;
use Magento\Rule\Block\Conditions as ConditionsBlock;
use Magento\Backend\Block\Widget\Form\Renderer\FieldsetFactory as RendererFieldsetFactory;
use Magento\Framework\UrlInterface;
use Aheadworks\Affiliate\Model\Campaign\Condition\Cart\Rule as CartConditionRule;
use Aheadworks\Affiliate\Model\Campaign\Condition\Cart\RuleFactory as CartConditionRuleFactory;
use Aheadworks\Affiliate\Model\Campaign\Condition\Cart\Form\DataProvider as CartConditionFormDataProvider;

/**
 * Class Form
 *
 * @package Aheadworks\Affiliate\Block\Adminhtml\Campaign\Edit\Tab\Conditions\Cart
 */
class Form extends AbstractForm
{
    /**
     * @var RendererFieldsetFactory
     */
    protected $rendererFieldsetFactory;

    /**
     * @var UrlInterface
     */
    protected $urlBuilder;

    /**
     * @var CartConditionRuleFactory
     */
    protected $cartConditionRuleFactory;

    /**
     * @param ConditionsBlock $conditionsBlock
     * @param CartConditionFormDataProvider $conditionFormDataProvider
     * @param RendererFieldsetFactory $rendererFieldsetFactory
     * @param UrlInterface $urlBuilder
     * @param CartConditionRuleFactory $cartConditionRuleFactory
     */
    public function __construct(
        ConditionsBlock $conditionsBlock,
        CartConditionFormDataProvider $conditionFormDataProvider,
        RendererFieldsetFactory $rendererFieldsetFactory,
        UrlInterface $urlBuilder,
        CartConditionRuleFactory $cartConditionRuleFactory
    ) {
        parent::__construct($conditionsBlock, $conditionFormDataProvider);
        $this->rendererFieldsetFactory = $rendererFieldsetFactory;
        $this->urlBuilder = $urlBuilder;
        $this->cartConditionRuleFactory = $cartConditionRuleFactory;
    }

    /**
     * {@inheritdoc}
     */
    public function getFormIdPrefix()
    {
        return 'rule_';
    }

    /**
     * {@inheritdoc}
     */
    public function getFormFieldsetName()
    {
        return 'campaign_conditions_fieldset';
    }

    /**
     * {@inheritdoc}
     */
    public function getConditionFieldName()
    {
        return CartConditionRule::CONDITIONS_PREFIX;
    }

    /**
     * {@inheritdoc}
     */
    protected function getRuleModelInstance()
    {
        return $this->cartConditionRuleFactory->create();
    }

    /**
     * {@inheritdoc}
     */
    protected function getFieldsetRenderer()
    {
        return $this->rendererFieldsetFactory->create()
            ->setTemplate($this->getFieldsetTemplate())
            ->setNewChildUrl(
                $this->urlBuilder->getUrl(
                    $this->getNewChildUrlRoute(),
                    [
                        'form'   => $this->getJsFormObjectName(),
                        'prefix' => CartConditionRule::CONDITIONS_PREFIX,
                        'rule'   => base64_encode(CartConditionRule::class),
                        'form_namespace' => $this->getFormNamespace()
                    ]
                )
            );
    }

    /**
     * Retrieve fieldset template
     *
     * @return string
     */
    protected function getFieldsetTemplate()
    {
        return 'Magento_CatalogRule::promo/fieldset.phtml';
    }
}
