<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Promo;

use Aheadworks\Affiliate\Api\CouponManagementInterface;
use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Aheadworks\Affiliate\Controller\AbstractPostCustomerAction;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Data\Form\FormKey\Validator as FormKeyValidator;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Store\Model\StoreManagerInterface;
use Aheadworks\Affiliate\Api\AccountRepositoryInterface;
use Magento\Framework\Serialize\Serializer\Json as JsonSerializer;

/**
 * Class GenerateCoupon
 * @package Aheadworks\Affiliate\Controller\Promo
 */
class GenerateCoupon extends AbstractPostCustomerAction
{
    /**
     * @var JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var CouponManagementInterface
     */
    private $couponService;

    /**
     * @var JsonSerializer
     */
    private $jsonSerializer;

    /**
     * @param Context $context
     * @param CustomerSession $customerSession
     * @param JsonFactory $resultJsonFactory
     * @param FormKeyValidator $formKeyValidator
     * @param CouponManagementInterface $couponService
     * @param StoreManagerInterface $storeManager
     * @param AccountRepositoryInterface $accountRepository
     * @param JsonSerializer $jsonSerializer
     */
    public function __construct(
        Context $context,
        CustomerSession $customerSession,
        JsonFactory $resultJsonFactory,
        FormKeyValidator $formKeyValidator,
        CouponManagementInterface $couponService,
        StoreManagerInterface $storeManager,
        AccountRepositoryInterface $accountRepository,
        JsonSerializer $jsonSerializer
    ) {
        parent::__construct($context, $customerSession, $formKeyValidator, $storeManager, $accountRepository);
        $this->resultJsonFactory = $resultJsonFactory;
        $this->couponService = $couponService;
        $this->jsonSerializer = $jsonSerializer;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        $data = [];
        $this->prepareRequest();
        $campaignId = $this->getRequest()->getParam(CampaignInterface::ID, false);
        if ($campaignId) {
            try {
                $this->validate();
                $data = [
                    'success' => $this->generateCoupon($campaignId)
                ];
                $this->messageManager->addSuccessMessage(__('Coupon was successfully generated.'));
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addExceptionMessage($e, __('Something went wrong while coupon generation.'));
            }
        } else {
            $this->messageManager->addErrorMessage(__('No data provided to coupon generation.'));
        }

        return $this->resultJsonFactory->create()->setData($data);
    }

    /**
     * Generate promo link
     *
     * @param int $campaignId
     * @return string
     * @throws LocalizedException
     */
    private function generateCoupon($campaignId)
    {
        $account = $this->getAffiliateAccount();

        return !empty($this->couponService->generateCouponCode(
            $account->getAccountId(),
            $campaignId
        ));
    }

    /**
     * Prepare request
     */
    private function prepareRequest()
    {
        try {
            $params = $this->jsonSerializer->unserialize($this->getRequest()->getContent());
        } catch (\Exception $e) {
            $params = [];
        }
        $this->getRequest()->setParams($params);
    }
}
