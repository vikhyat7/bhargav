<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Api\Data;

/**
 * Interface PromoLinkDataInterface
 *
 * @package Aheadworks\Affiliate\Api\Data
 */
interface PromoLinkDataInterface extends PromoDataInterface
{
    /**#@+
     * Constants defined for keys of the data array.
     * Identical to the name of the getter in snake case
     */
    const BASIC_URL = 'basic_url';
    /**#@-*/

    /**
     * Get basic url
     *
     * @return string
     */
    public function getBasicUrl();

    /**
     * Set basic url
     *
     * @param string $basicUrl
     * @return $this
     */
    public function setBasicUrl($basicUrl);
}
