define([
    'Magento_Ui/js/form/components/button',
    'mageUtils',
    'mage/translate'
], function (Component, utils, $t) {
    'use strict';

    return Component.extend({
        defaults: {
            imports: {
                payoutRequestEnabled: '${ $.configProvider }:data.payout_request_enabled',
                balanceForPayout: '${ $.configProvider }:data.balance_for_payout',
                remainingBalanceForPayout: '${ $.configProvider }:data.remaining_balance_for_payout',
                remainingBalanceFormatted: '${ $.configProvider }:data.remaining_balance_for_payout_formatted'
            },
            submitUrl: '${ $.submit_url }',
            noticeText: ''
        },

        /**
         * {@inheritdoc}
         */
        initialize: function () {
            this._super()
                .prepareNotice();

            return this;
        },

        /**
         * {@inheritdoc}
         */
        action: function () {
            utils.submit({
                url: this.submitUrl,
                data: {}
            });

            return this;
        },

        /**
         * Can make payout request
         *
         * @return {boolean}
         */
        canMakePayoutRequest: function () {
            return this.payoutRequestEnabled
                && this.balanceForPayout > 0
                && this.remainingBalanceForPayout <= 0
        },

        /**
         * Prepare notice
         *
         * @return {exports}
         */
        prepareNotice: function () {
            this.noticeText = $t(this.noticeText).replace('{remaining_balance}', this.remainingBalanceFormatted);

            return this;
        }
    });
});
