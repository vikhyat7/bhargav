<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface CampaignSearchResultsInterface
 *
 * @package Aheadworks\Affiliate\Api\Data
 */
interface CampaignSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get campaigns list
     *
     * @return \Aheadworks\Affiliate\Api\Data\CampaignInterface[]
     */
    public function getItems();

    /**
     * Set campaigns list
     *
     * @param \Aheadworks\Affiliate\Api\Data\CampaignInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
