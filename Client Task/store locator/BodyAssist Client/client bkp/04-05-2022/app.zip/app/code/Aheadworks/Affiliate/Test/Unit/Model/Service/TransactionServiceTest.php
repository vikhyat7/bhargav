<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Model\Service;

use Aheadworks\Affiliate\Api\Data\PayoutInterface;
use Aheadworks\Affiliate\Model\Source\Transaction\Type;
use Aheadworks\Affiliate\Model\Transaction\Processor\ProcessorInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Sales\Api\Data\OrderItemInterface;
use PHPUnit\Framework\TestCase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Aheadworks\Affiliate\Model\Service\TransactionService;
use Aheadworks\Affiliate\Api\TransactionRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\TransactionInterface;
use Aheadworks\Affiliate\Model\Source\Transaction\Status;
use Aheadworks\Affiliate\Api\AccountBalanceManagementInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Aheadworks\Affiliate\Model\Transaction\ProcessorsPool as TransactionProcessorsPool;
use Aheadworks\Affiliate\Model\ResourceModel\Transaction as TransactionResource;
use Aheadworks\Affiliate\Model\Transaction\StatusResolver;

/**
 * Class TransactionServiceTest
 * @package Aheadworks\Affiliate\Test\Unit\Model\Service
 */
class TransactionServiceTest extends TestCase
{
    /**
     * @var TransactionRepositoryInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $transactionRepositoryMock;
    
    /**
     * @var TransactionProcessorsPool|\PHPUnit_Framework_MockObject_MockObject
     */
    private $transactionProcessorPoolMock;
    
    /**
     * @var AccountBalanceManagementInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $accountBalanceManagementMock;
    
    /**
     * @var TransactionResource|\PHPUnit_Framework_MockObject_MockObject
     */
    private $transactionResourceMock;
    
    /**
     * @var StatusResolver|\PHPUnit_Framework_MockObject_MockObject
     */
    private $statusResolverMock;

    /**
     * @var TransactionService
     */
    private $testedClass;

    /**#@+
     * Constants used for tests
     */
    const DEFAULT_ID = 1;
    const DEFAULT_STATUS = Status::PENDING;
    const AFFILIATE_ID = 1;
    const COULD_SAVE_TRANSACTION_EXC_CODE = 1;
    const NO_SUCH_TRANSACTION_EXC_CODE = 2;
    const INVALID_STATUS_EXC_CODE = 3;
    /**#@-*/

    /**
     * Init mocks for tests
     *
     * @return void
     */
    public function setUp() : void
    {
        $objectManager = new ObjectManager($this);
        $this->transactionRepositoryMock = $this->createMock(TransactionRepositoryInterface::class);
        $this->transactionProcessorPoolMock = $this->createMock(TransactionProcessorsPool::class);
        $this->accountBalanceManagementMock = $this->createMock(AccountBalanceManagementInterface::class);
        $this->transactionResourceMock = $this->createMock(TransactionResource::class);
        $this->statusResolverMock = $this->createMock(StatusResolver::class);
        $this->testedClass = $objectManager->getObject(
            TransactionService::class,
            [
                'transactionRepository' => $this->transactionRepositoryMock,
                'transactionProcessorPool' => $this->transactionProcessorPoolMock,
                'accountBalanceManagement' => $this->accountBalanceManagementMock,
                'transactionResource' => $this->transactionResourceMock,
                'statusResolver' => $this->statusResolverMock
            ]
        );
    }

    /**
     * Test addTransaction method
     *
     * @param string $type
     * @param int $status
     * @param PayoutInterface|OrderItemInterface|null $entity
     * @param float $amount
     * @param string $comment
     * @dataProvider testAddTransactionProvider
     */
    public function testAddTransaction($type, $status, $entity = null, $amount = 0.00, $comment = '')
    {
        $transactionMock = $this->getTransactionMock();
        $processorMock = $this->createMock(ProcessorInterface::class);

        $this->transactionProcessorPoolMock->expects($this->once())
            ->method('getByType')
            ->with($type)
            ->willReturn($processorMock);
        $processorMock->expects($this->once())
            ->method('process')
            ->with(self::AFFILIATE_ID, $type, $status, $entity, $amount, $comment)
            ->willReturn($transactionMock);
        $this->mockObjectsSaveAndUpdateBalance($transactionMock);

        $this->assertSame(
            $transactionMock,
            $this->testedClass->addTransaction(self::AFFILIATE_ID, $type, $status, $entity, $amount, $comment)
        );
    }

    /**
     * Test addTransaction method with exception
     *
     * @param CouldNotSaveException|NoSuchEntityException $exception
     * @param string $exceptionMsg
     * @dataProvider testAddTransactionWithExceptionProvider
     * @expectedException \Magento\Framework\Exception\CouldNotSaveException
     */
    public function testAddTransactionWithException($exception, $exceptionMsg)
    {
        $type = Type::COMMISSION;
        $status = Status::PENDING;
        $entity = $this->createMock(OrderItemInterface::class);
        $transactionMock = $this->getTransactionMock();
        $processorMock = $this->createMock(ProcessorInterface::class);

        $this->transactionProcessorPoolMock->expects($this->once())
            ->method('getByType')
            ->with($type)
            ->willReturn($processorMock);
        $processorMock->expects($this->once())
            ->method('process')
            ->with(self::AFFILIATE_ID, $type, $status, $entity)
            ->willReturn($transactionMock);
        $this->mockObjectsSaveAndUpdateBalanceWithException($transactionMock, $exception);
        $this->expectExceptionMessage($exceptionMsg);

        $this->testedClass->addTransaction(self::AFFILIATE_ID, $type, $status, $entity);
    }

    /**
     * Test updateTransactionStatus method
     *
     * @param TransactionInterface|\PHPUnit_Framework_MockObject_MockObject $transactionMock
     * @param string $currentStatus
     * @param string $statusToSet
     * @dataProvider testUpdateTransactionStatusProvider
     * @throws CouldNotSaveException
     */
    public function testUpdateTransactionStatus($transactionMock, $currentStatus, $statusToSet)
    {
        $this->transactionRepositoryMock->expects($this->once())
            ->method('getById')
            ->with(self::DEFAULT_ID)
            ->willReturn($transactionMock);
        $this->statusResolverMock->expects($this->once())
            ->method('isStatusAllowedForTransaction')
            ->with($statusToSet, $currentStatus)
            ->willReturn(true);
        $transactionMock->expects($this->once())
            ->method('setStatus')
            ->with($statusToSet)
            ->willReturnSelf();
        $transactionMock->expects($this->once())
            ->method('getAffiliateId')
            ->willReturn(self::AFFILIATE_ID);
        $this->mockObjectsSaveAndUpdateBalance($transactionMock);

        $this->assertSame(
            $transactionMock,
            $this->testedClass->updateTransactionStatus(self::DEFAULT_ID, $statusToSet)
        );
    }

    /**
     * Test updateTransactionStatus method with exception
     *
     * @param TransactionInterface|\PHPUnit_Framework_MockObject_MockObject $transactionMock
     * @param string $currentStatus
     * @param string $statusToSet
     * @param CouldNotSaveException|NoSuchEntityException $exception
     * @param string $exceptionMsg
     * @dataProvider testUpdateTransactionStatusWithExceptionProvider
     * @throws CouldNotSaveException
     */
    public function testUpdateTransactionStatusWithException(
        $transactionMock,
        $currentStatus,
        $statusToSet,
        $exception,
        $exceptionMsg
    ) {
        if ($exception->getCode() == self::NO_SUCH_TRANSACTION_EXC_CODE) {
            $this->transactionRepositoryMock->expects($this->once())
                ->method('getById')
                ->with(self::DEFAULT_ID)
                ->willThrowException($exception);
        } elseif ($exception->getCode() == self::INVALID_STATUS_EXC_CODE) {
            $this->transactionRepositoryMock->expects($this->once())
                ->method('getById')
                ->with(self::DEFAULT_ID)
                ->willReturn($transactionMock);
            $this->statusResolverMock->expects($this->once())
                ->method('isStatusAllowedForTransaction')
                ->with($statusToSet, $currentStatus)
                ->willReturn(false);
        } else {
            $this->transactionRepositoryMock->expects($this->once())
                ->method('getById')
                ->with(self::DEFAULT_ID)
                ->willReturn($transactionMock);
            $this->statusResolverMock->expects($this->once())
                ->method('isStatusAllowedForTransaction')
                ->with($statusToSet, $currentStatus)
                ->willReturn(true);
            $transactionMock->expects($this->once())
                ->method('setStatus')
                ->with($statusToSet)
                ->willReturnSelf();
            $transactionMock->expects($this->once())
                ->method('getAffiliateId')
                ->willReturn(self::AFFILIATE_ID);
            $this->mockObjectsSaveAndUpdateBalanceWithException($transactionMock, $exception);
        }
        $this->expectExceptionMessage($exceptionMsg);

        $this->testedClass->updateTransactionStatus(self::DEFAULT_ID, $statusToSet);
    }

    /**
     * @return array
     */
    public function testAddTransactionProvider()
    {
        return [
            [
                Type::COMMISSION,
                Status::PENDING,
                $this->createMock(OrderItemInterface::class)
            ],
            [
                Type::PAYOUT,
                Status::PENDING,
                $this->createMock(PayoutInterface::class)
            ],
            [
                Type::ADMIN_CHANGES,
                Status::COMPLETE,
                null,
                10.00,
                'Test comment for admin transaction.'
            ]
        ];
    }

    /**
     * @return array
     */
    public function testAddTransactionWithExceptionProvider()
    {
        return [
            [
                new CouldNotSaveException(
                    __('Could not save transaction message.'),
                    null,
                    self::COULD_SAVE_TRANSACTION_EXC_CODE
                ),
                'Could not save transaction message.'
            ],
            [
                new NoSuchEntityException(__('No such account message.')),
                'No such account message.'
            ]
        ];
    }

    /**
     * @return array
     */
    public function testUpdateTransactionStatusProvider()
    {
        return [
            [$this->getTransactionMock(), Status::PENDING, Status::COMPLETE],
            [$this->getTransactionMock(), Status::PENDING, Status::CANCELED]
        ];
    }

    /**
     * @return array
     */
    public function testUpdateTransactionStatusWithExceptionProvider()
    {
        return [
            [
                $this->getTransactionMock(),
                Status::PENDING,
                Status::COMPLETE,
                new CouldNotSaveException(
                    __('Transaction with ID = %1 does not exist.', self::DEFAULT_ID),
                    null,
                    self::NO_SUCH_TRANSACTION_EXC_CODE
                ),
                'Transaction with ID = 1 does not exist.'
            ],
            [
                $this->getTransactionMock(Status::COMPLETE),
                Status::COMPLETE,
                Status::COMPLETE,
                new CouldNotSaveException(
                    __('This status can\'t be set to transaction.'),
                    null,
                    self::INVALID_STATUS_EXC_CODE
                ),
                'This status can\'t be set to transaction.'
            ],
            [
                $this->getTransactionMock(),
                Status::PENDING,
                Status::COMPLETE,
                new CouldNotSaveException(
                    __('Could not save transaction message.'),
                    null,
                    self::COULD_SAVE_TRANSACTION_EXC_CODE
                ),
                'Could not save transaction message.'
            ],
            [
                $this->getTransactionMock(),
                Status::PENDING,
                Status::COMPLETE,
                new NoSuchEntityException(__('No such account message.')),
                'No such account message.'
            ]
        ];
    }

    /**
     * Get transaction mock
     *
     * @param string $status
     * @param int $transactionId
     * @return TransactionInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private function getTransactionMock($status = self::DEFAULT_STATUS, $transactionId = self::DEFAULT_ID)
    {
        $transactionMock = $this->createMock(TransactionInterface::class);

        $transactionMock->expects($this->atMost(1))
            ->method('getTransactionId')
            ->willReturn($transactionId);
        $transactionMock->expects($this->atMost(1))
            ->method('getStatus')
            ->willReturn($status);

        return $transactionMock;
    }
    
    /**
     * Mock objects for saveTransactionAndUpdateBalance method
     *
     * @param TransactionInterface|\PHPUnit_Framework_MockObject_MockObject $transactionMock
     */
    private function mockObjectsSaveAndUpdateBalance($transactionMock)
    {
        $this->transactionResourceMock->expects($this->once())
            ->method('beginTransaction')
            ->willReturnSelf();
        $this->transactionRepositoryMock->expects($this->once())
            ->method('save')
            ->with($transactionMock)
            ->willReturn($transactionMock);
        $this->accountBalanceManagementMock->expects($this->once())
            ->method('updateBalance')
            ->with(self::AFFILIATE_ID, $transactionMock);
        $this->transactionResourceMock->expects($this->once())
            ->method('commit')
            ->willReturnSelf();
    }

    /**
     * Mock objects for saveTransactionAndUpdateBalance method with exception
     *
     * @param TransactionInterface|\PHPUnit_Framework_MockObject_MockObject $transactionMock
     * @param CouldNotSaveException|NoSuchEntityException $exception
     */
    private function mockObjectsSaveAndUpdateBalanceWithException($transactionMock, $exception)
    {
        $this->transactionResourceMock->expects($this->once())
            ->method('beginTransaction')
            ->willReturnSelf();
        if ($exception->getCode() == self::COULD_SAVE_TRANSACTION_EXC_CODE) {
            $this->transactionRepositoryMock->expects($this->once())
                ->method('save')
                ->with($transactionMock)
                ->willThrowException($exception);
        } else {
            $this->transactionRepositoryMock->expects($this->once())
                ->method('save')
                ->with($transactionMock)
                ->willReturn($transactionMock);
            $this->accountBalanceManagementMock->expects($this->once())
                ->method('updateBalance')
                ->with(self::AFFILIATE_ID, $transactionMock)
                ->willThrowException($exception);
        }
        $this->transactionResourceMock->expects($this->once())
            ->method('rollBack')
            ->willReturnSelf();
    }
}
