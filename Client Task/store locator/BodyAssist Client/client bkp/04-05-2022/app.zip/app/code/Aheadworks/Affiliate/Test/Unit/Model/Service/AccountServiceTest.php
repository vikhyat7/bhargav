<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Model\Service;

use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Phrase;
use PHPUnit\Framework\TestCase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Aheadworks\Affiliate\Model\Service\AccountService;
use Aheadworks\Affiliate\Api\AccountRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Aheadworks\Affiliate\Model\Source\Account\Status;
use Aheadworks\Affiliate\Api\AccountBalanceManagementInterface;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Exception\CouldNotSaveException;

/**
 * Class AccountServiceTest
 * @package Aheadworks\Affiliate\Test\Unit\Model\Service
 */
class AccountServiceTest extends TestCase
{
    /**
     * @var AccountRepositoryInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $accountRepositoryMock;

    /**
     * @var DataObjectHelper|\PHPUnit_Framework_MockObject_MockObject
     */
    private $dataObjectHelperMock;

    /**
     * @var AccountBalanceManagementInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $accountBalanceManagementMock;

    /**
     * @var AccountService
     */
    private $testedClass;

    /**#@+
     * Default values
     */
    const DEFAULT_ACCOUNT_ID = 1;
    const DEFAULT_STATUS = 1;
    /**#@-*/

    /**
     * Init mocks for tests
     *
     * @return void
     */
    public function setUp() : void
    {
        $objectManager = new ObjectManager($this);
        $this->accountRepositoryMock = $this->createMock(AccountRepositoryInterface::class);
        $this->dataObjectHelperMock = $this->createMock(DataObjectHelper::class);
        $this->accountBalanceManagementMock = $this->createMock(AccountBalanceManagementInterface::class);
        $this->testedClass = $objectManager->getObject(
            AccountService::class,
            [
                'accountRepository' => $this->accountRepositoryMock,
                'dataObjectHelper' => $this->dataObjectHelperMock,
                'accountBalanceManagement' => $this->accountBalanceManagementMock
            ]
        );
    }

    /**
     * Test createAccount method
     */
    public function testCreateAccount()
    {
        $accountMock = $this->getAccountMock();

        $this->accountRepositoryMock->expects($this->once())
            ->method('save')
            ->with($accountMock)
            ->willReturn($accountMock);
        $this->accountBalanceManagementMock->expects($this->once())
            ->method('initializeBalance')
            ->with(self::DEFAULT_ACCOUNT_ID);

        $this->assertSame($accountMock, $this->testedClass->createAccount($accountMock));
    }

    /**
     * Test createAccount method with exception
     *
     * @expectedException \Magento\Framework\Exception\CouldNotSaveException
     * @expectedExceptionMessage Test message.
     */
    public function testCreateAccountWithException()
    {
        $accountMock = $this->getAccountMock();
        $exception = new CouldNotSaveException(__('Test message.'));
        $this->expectException(CouldNotSaveException::class);
        $this->accountRepositoryMock->expects($this->once())
            ->method('save')
            ->with($accountMock)
            ->willThrowException($exception);
        $this->accountBalanceManagementMock->expects($this->never())
            ->method('initializeBalance');

        $this->testedClass->createAccount($accountMock);
    }

    /**
     * Test updateAccount method
     */
    public function testUpdateAccount()
    {
        $accountMock = $this->getAccountMock();
        $accountToMergeMock = $this->getAccountMock();

        $this->accountRepositoryMock->expects($this->once())
            ->method('getById')
            ->with(self::DEFAULT_ACCOUNT_ID)
            ->willReturn($accountToMergeMock);
        $this->dataObjectHelperMock->expects($this->once())
            ->method('mergeDataObjects')
            ->with(AccountInterface::class, $accountMock, $accountToMergeMock)
            ->willReturn($accountToMergeMock);
        $this->accountRepositoryMock->expects($this->once())
            ->method('save')
            ->with($accountToMergeMock)
            ->willReturn($accountToMergeMock);

        $this->assertSame($accountToMergeMock, $this->testedClass->updateAccount($accountMock));
    }

    /**
     * Test updateAccount method with exception
     *
     * @param AccountInterface|\PHPUnit_Framework_MockObject_MockObject $accountMock
     * @param CouldNotSaveException|NoSuchEntityException $exception
     * @param string $excClass
     * @param Phrase $excMessage
     * @dataProvider testUpdateAccountWithExceptionProvider
     */
    public function testUpdateAccountWithException($accountMock, $exception, $excClass, $excMessage)
    {
        $accountToMergeMock = $this->getAccountMock();

        if ($exception instanceof NoSuchEntityException) {
            $this->accountRepositoryMock->expects($this->once())
                ->method('getById')
                ->with(self::DEFAULT_ACCOUNT_ID)
                ->willThrowException($exception);
        } else {
            $this->accountRepositoryMock->expects($this->once())
                ->method('getById')
                ->with(self::DEFAULT_ACCOUNT_ID)
                ->willReturn($accountToMergeMock);
            $this->dataObjectHelperMock->expects($this->once())
                ->method('mergeDataObjects')
                ->with(AccountInterface::class, $accountMock, $accountToMergeMock)
                ->willReturn($accountToMergeMock);
            $this->accountRepositoryMock->expects($this->once())
                ->method('save')
                ->with($accountToMergeMock)
                ->willThrowException($exception);
        }
        $this->expectException($excClass);
        $this->expectExceptionMessage($excMessage);

        $this->testedClass->updateAccount($accountMock);
    }

    /**
     * @return array
     */
    public function testUpdateAccountWithExceptionProvider()
    {
        return [
            [
                $this->getAccountMock(),
                new NoSuchEntityException(__('No such entity message.')),
                NoSuchEntityException::class,
                'No such entity message.'
            ],
            [
                $this->getAccountMock(),
                new CouldNotSaveException(__('Can\'t save message.')),
                CouldNotSaveException::class,
                'Can\'t save message.'
            ],
            [
                $this->getAccountMock(self::DEFAULT_ACCOUNT_ID, Status::DELETED),
                new CouldNotSaveException(
                    __('Account status cannot be changed due to customer account has been deleted.')
                ),
                CouldNotSaveException::class,
                'Account status cannot be changed due to customer account has been deleted.'
            ]
        ];
    }

    /**
     * @param int $accountId
     * @param int $status
     * @return AccountInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private function getAccountMock($accountId = self::DEFAULT_ACCOUNT_ID, $status = self::DEFAULT_STATUS)
    {
        $accountMock = $this->createMock(AccountInterface::class);

        $accountMock->expects($this->atMost(1))
            ->method('getAccountId')
            ->willReturn($accountId);
        $accountMock->expects($this->atMost(1))
            ->method('getStatus')
            ->willReturn($status);

        return $accountMock;
    }
}
