<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Api\Data;

/**
 * Interface LinkStatisticInterface
 * @package Aheadworks\Affiliate\Api\Data
 */
interface LinkStatisticInterface extends PromoDataInterface
{
    /**#@+
     * Constants defined for keys of the data array.
     * Identical to the name of the getter in snake case
     */
    const HIT_ID = 'hit_id';
    const CREATED_AT = 'created_at';
    const ORDERS_COUNT = 'orders_count';
    /**#@-*/

    /**
     * Get hit id
     *
     * @return int
     */
    public function getHitId();

    /**
     * Set hit id
     *
     * @param int $hit
     * @return $this
     */
    public function setHitId($hit);

    /**
     * Get created at
     *
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created at
     *
     * @param string $createdAt
     * @return $this
     */
    public function setCreatedAt($createdAt);
    
    /**
     * Get orders count
     *
     * @return int
     */
    public function getOrdersCount();

    /**
     * Set orders count
     *
     * @param int $ordersCount
     * @return $this
     */
    public function setOrdersCount($ordersCount);
}
