<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Ui\DataProvider\Frontend\RecommendedProduct;

use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Catalog\Ui\DataProvider\Product\ProductRenderCollectorComposite;
use Magento\Catalog\Ui\DataProvider\Product\ProductRenderCollectorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Data\CollectionModifier;
use Magento\Framework\Data\CollectionModifierInterface;
use Magento\Framework\Api\Search\SearchResultInterface;
use Magento\Framework\Api\Search\SearchResultFactory;
use Magento\Catalog\Model\ProductRenderFactory;
use Magento\Catalog\Api\Data\ProductRenderExtensionFactory;
use Magento\Catalog\Model\Config;
use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * Class ProductRenderList
 *
 * @package Aheadworks\Affiliate\Ui\DataProvider\Frontend\RecommendedProduct
 */
class ProductRenderList
{
    /**
     * @var CollectionFactory
     */
    private $collectionFactory;

    /**
     * @var CollectionModifierInterface
     */
    private $collectionModifier;

    /**
     * @var CollectionProcessorInterface
     */
    private $collectionProcessor;

    /**
     * @var ProductRenderFactory
     */
    private $productRenderFactory;

    /**
     * @var ProductRenderExtensionFactory
     */
    private $productRenderExtensionFactory;

    /**
     * @var ProductRenderCollectorInterface
     */
    private $productRenderCollectorComposite;

    /**
     * @var SearchResultFactory
     */
    private $searchResultFactory;

    /**
     * @var array
     */
    private $productAttributes;

    /**
     * @param CollectionFactory $collectionFactory
     * @param CollectionModifier $collectionModifier
     * @param CollectionProcessorInterface $collectionProcessor
     * @param ProductRenderFactory $productRenderFactory
     * @param ProductRenderExtensionFactory $productRenderExtensionFactory
     * @param ProductRenderCollectorComposite $productRenderCollectorComposite
     * @param SearchResultFactory $searchResultFactory
     * @param Config $config
     * @param array $productAttributes
     */
    public function __construct(
        CollectionFactory $collectionFactory,
        CollectionModifier $collectionModifier,
        CollectionProcessorInterface $collectionProcessor,
        ProductRenderFactory $productRenderFactory,
        ProductRenderExtensionFactory $productRenderExtensionFactory,
        ProductRenderCollectorComposite $productRenderCollectorComposite,
        SearchResultFactory $searchResultFactory,
        Config $config,
        array $productAttributes = []
    ) {
        $this->collectionFactory = $collectionFactory;
        $this->collectionModifier = $collectionModifier;
        $this->collectionProcessor = $collectionProcessor;
        $this->productRenderFactory = $productRenderFactory;
        $this->productRenderExtensionFactory = $productRenderExtensionFactory;
        $this->productRenderCollectorComposite = $productRenderCollectorComposite;
        $this->searchResultFactory = $searchResultFactory;
        $this->productAttributes = array_merge($productAttributes, $config->getProductAttributes());
    }

    /**
     * Collect and retrieve the list of product render info
     *
     * @param SearchCriteriaInterface $searchCriteria
     * @param int $storeId
     * @param string $currencyCode
     * @param int $campaignId
     * @return SearchResultInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria, $storeId, $currencyCode, $campaignId)
    {
        $searchResult = $this->searchResultFactory->create();
        try {
            $productCollection = $this->collectionFactory->create();
            $productCollection
                ->addAttributeToSelect($this->productAttributes)
                ->setStoreId($storeId)
                ->addMinimalPrice()
                ->addFinalPrice()
                ->addTaxPercents();

            $this->collectionModifier->apply($productCollection);
            $this->collectionProcessor->process($searchCriteria, $productCollection);

            $renderedItems = [];
            foreach ($productCollection as $item) {
                $productRenderInfo = $this->productRenderFactory->create();
                $productRenderInfo->setStoreId($storeId);
                $productRenderInfo->setCurrencyCode($currencyCode);
                $extensionAttributes = $this->productRenderExtensionFactory->create();
                $extensionAttributes->setAwAffCampaignId($campaignId);
                $productRenderInfo->setExtensionAttributes($extensionAttributes);
                $this->productRenderCollectorComposite->collect($item, $productRenderInfo);
                $renderedItems[$item->getId()] = $productRenderInfo;
            }

            $searchResult->setItems($renderedItems);
            $searchResult->setTotalCount($productCollection->getSize());
            $searchResult->setSearchCriteria($searchCriteria);
        } catch (\Exception $exception) {
            $searchResult->setItems([]);
            $searchResult->setTotalCount(0);
            $searchResult->setSearchCriteria($searchCriteria);
        }

        return $searchResult;
    }
}
