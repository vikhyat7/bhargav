<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Model\Coupon;

use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Aheadworks\Affiliate\Model\Campaign\Validator\Account as CampaignAccountValidator;
use Aheadworks\Affiliate\Model\Coupon\GenerationValidator;
use Aheadworks\Affiliate\Model\Source\Campaign\CouponUsageMode;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;

/**
 * Class GenerationValidatorTest
 * @package Aheadworks\Affiliate\Test\Unit\Model\Coupon
 */
class GenerationValidatorTest extends TestCase
{
    /**
     * @var CampaignAccountValidator|\PHPUnit_Framework_MockObject_MockObject
     */
    private $campaignAccountValidatorMock;
    
    /**
     * @var GenerationValidator
     */
    private $validator;
    
    /**#@+
     * Constants used for tests
     */
    const COUPON_GENERATION_DOESNT_ALLOW_EXC_CODE = 1;
    const CAMPAIGN_NOT_AVAILABLE_FOR_AFFILIATE_EXC_CODE = 2;
    const IS_NOT_SET_COUPON_CODE_EXC_CODE = 3;
    const IS_NOT_SET_COUPON_PREFIX_CODE_EXC_CODE = 4;
    /**#@-*/

    /**
     * Init mocks for tests
     *
     * @return void
     */
    protected function setUp() : void
    {
        $objectManager = new ObjectManager($this);
        $this->campaignAccountValidatorMock = $this->createMock(CampaignAccountValidator::class);
        $this->validator = $objectManager->getObject(
            GenerationValidator::class,
            [
                'campaignAccountValidator' => $this->campaignAccountValidatorMock
            ]
        );
    }

    /**
     * Test validate method
     *
     * @throws LocalizedException
     */
    public function testValidate()
    {
        /** @var CampaignInterface|\PHPUnit_Framework_MockObject_MockObject $campaignMock */
        $campaignMock = $this->createMock(CampaignInterface::class);
        /** @var AccountInterface|\PHPUnit_Framework_MockObject_MockObject $accountMock */
        $accountMock = $this->createMock(AccountInterface::class);
        $websiteId = 1;
        $couponCode = 'TEST';
        $couponPrefix = 'PREFIX';

        $campaignMock->expects($this->atMost(1))
            ->method('getCouponUsageMode')
            ->willReturn(CouponUsageMode::SPECIFIC_COUPON);
        $campaignMock->expects($this->atMost(1))
            ->method('getWebsiteId')
            ->willReturn($websiteId);
        $campaignMock->expects($this->atMost(1))
            ->method('getCouponCodeTemplate')
            ->willReturn($couponCode);
        $accountMock->expects($this->atMost(1))
            ->method('getUniqueCouponPrefix')
            ->willReturn($couponPrefix);
        $this->campaignAccountValidatorMock->expects($this->atMost(1))
            ->method('validate')
            ->with($accountMock, $campaignMock, $websiteId)
            ->willReturn(true);

        $this->assertTrue($this->validator->validate($accountMock, $campaignMock));
    }

    /**
     * Test validate method with exception
     *
     * @param LocalizedException $exception
     * @param string $exceptionMsg
     * @throws LocalizedException
     * @dataProvider testValidateWithExceptionProvider
     * @expectedException \Magento\Framework\Exception\LocalizedException
     */
    public function testValidateWithException($exception, $exceptionMsg)
    {
        /** @var CampaignInterface|\PHPUnit_Framework_MockObject_MockObject $campaignMock */
        $campaignMock = $this->createMock(CampaignInterface::class);
        /** @var AccountInterface|\PHPUnit_Framework_MockObject_MockObject $accountMock */
        $accountMock = $this->createMock(AccountInterface::class);
        $websiteId = 1;
        $couponUsageMode = $exception->getCode() == self::COUPON_GENERATION_DOESNT_ALLOW_EXC_CODE
            ? CouponUsageMode::NO_COUPON
            : CouponUsageMode::SPECIFIC_COUPON;
        $campaignValidForAffiliate = $exception->getCode() == self::CAMPAIGN_NOT_AVAILABLE_FOR_AFFILIATE_EXC_CODE
            ? false
            : true;
        $couponCode = $exception->getCode() == self::IS_NOT_SET_COUPON_CODE_EXC_CODE
            ? null
            : 'TEST';
        $couponPrefix = $exception->getCode() == self::IS_NOT_SET_COUPON_PREFIX_CODE_EXC_CODE
            ? null
            : 'PREFIX';

        $campaignMock->expects($this->atMost(1))
            ->method('getCouponUsageMode')
            ->willReturn($couponUsageMode);
        $campaignMock->expects($this->atMost(1))
            ->method('getWebsiteId')
            ->willReturn($websiteId);
        $campaignMock->expects($this->atMost(1))
            ->method('getCouponCodeTemplate')
            ->willReturn($couponCode);
        $accountMock->expects($this->atMost(1))
            ->method('getUniqueCouponPrefix')
            ->willReturn($couponPrefix);
        $this->campaignAccountValidatorMock->expects($this->any())
            ->method('validate')
            ->with($accountMock, $campaignMock, $websiteId)
            ->willReturn($campaignValidForAffiliate);

        $this->expectExceptionMessage($exceptionMsg);

        $this->validator->validate($accountMock, $campaignMock);
    }

    /**
     * @return array
     */
    public function testValidateWithExceptionProvider()
    {
        return [
            [
                new LocalizedException(
                    __('This campaign doesn\'t allow coupon generation.'),
                    null,
                    self::COUPON_GENERATION_DOESNT_ALLOW_EXC_CODE
                ),
                'This campaign doesn\'t allow coupon generation.'
            ],
            [
                new LocalizedException(
                    __('This campaign isn\'t available for affiliate.'),
                    null,
                    self::CAMPAIGN_NOT_AVAILABLE_FOR_AFFILIATE_EXC_CODE
                ),
                'This campaign isn\'t available for affiliate.'
            ],
            [
                new LocalizedException(
                    __('Campaign coupon code template isn\'t set.'),
                    null,
                    self::IS_NOT_SET_COUPON_CODE_EXC_CODE
                ),
                'Campaign coupon code template isn\'t set.'
            ],
            [
                new LocalizedException(
                    __('Affiliate coupon prefix isn\'t set.'),
                    null,
                    self::IS_NOT_SET_COUPON_PREFIX_CODE_EXC_CODE
                ),
                'Affiliate coupon prefix isn\'t set.'
            ]
        ];
    }
}
