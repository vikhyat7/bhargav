<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Api\Data;

/**
 * Interface PromoDataInterface
 *
 * @package Aheadworks\Affiliate\Api\Data
 */
interface PromoDataInterface
{
    /**#@+
     * Constants defined for keys of the data array.
     * Identical to the name of the getter in snake case
     */
    const ACCOUNT_ID = 'account_id';
    const CAMPAIGN_ID = 'campaign_id';
    const TRAFFIC_SOURCE = 'traffic_source';
    /**#@-*/

    /**
     * Get account id
     *
     * @return int
     */
    public function getAccountId();

    /**
     * Set account id
     *
     * @param int $accountId
     * @return $this
     */
    public function setAccountId($accountId);

    /**
     * Get campaign id
     *
     * @return int|null
     */
    public function getCampaignId();

    /**
     * Set campaign id
     *
     * @param int|null $campaignId
     * @return $this
     */
    public function setCampaignId($campaignId);

    /**
     * Get traffic source description
     *
     * @return string
     */
    public function getTrafficSource();

    /**
     * Set traffic source description
     *
     * @param string $trafficSource
     * @return $this
     */
    public function setTrafficSource($trafficSource);
}
