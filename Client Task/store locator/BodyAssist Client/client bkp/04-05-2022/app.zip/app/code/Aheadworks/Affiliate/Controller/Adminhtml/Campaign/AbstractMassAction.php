<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Campaign;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Aheadworks\Affiliate\Api\CampaignRepositoryInterface;
use Aheadworks\Affiliate\Api\CampaignManagementInterface;
use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Aheadworks\Affiliate\Model\ResourceModel\Campaign\CollectionFactory;
use Aheadworks\Affiliate\Model\ResourceModel\Campaign\Collection;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Ui\Component\MassAction\Filter;
use Magento\Framework\Exception\LocalizedException;

/**
 * Class AbstractMassAction
 *
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Campaign
 */
abstract class AbstractMassAction extends Action
{
    /**
     * {@inheritdoc}
     */
    const ADMIN_RESOURCE = 'Aheadworks_Affiliate::campaigns';

    /**
     * @var CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @var Filter
     */
    protected $filter;

    /**
     * @var CampaignManagementInterface
     */
    protected $campaignManagement;

    /**
     * @var CampaignRepositoryInterface
     */
    protected $campaignRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * @param Context $context
     * @param CollectionFactory $collectionFactory
     * @param CampaignManagementInterface $campaignManagement
     * @param CampaignRepositoryInterface $campaignRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param Filter $filter
     */
    public function __construct(
        Context $context,
        CollectionFactory $collectionFactory,
        CampaignManagementInterface $campaignManagement,
        CampaignRepositoryInterface $campaignRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        Filter $filter
    ) {
        parent::__construct($context);
        $this->collectionFactory = $collectionFactory;
        $this->filter = $filter;
        $this->campaignManagement = $campaignManagement;
        $this->campaignRepository = $campaignRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        try {
            $campaignsArray = $this->getCampaignsForMassAction();
            $this->massAction($campaignsArray);
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        }

        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $resultRedirect->setPath('*/*/index');
        return $resultRedirect;
    }

    /**
     * Retrieve array of campaigns for mass action
     *
     * @return CampaignInterface[]
     */
    protected function getCampaignsForMassAction()
    {
        $campaignsForMassAction = [];
        try {
            /** @var Collection $collection */
            $collection = $this->filter->getCollection($this->collectionFactory->create());
            $searchCriteria = $this->searchCriteriaBuilder
                ->addFilter(CampaignInterface::ID, $collection->getAllIds(), 'in')
                ->create();
            $campaignsForMassAction = $this->campaignRepository->getList($searchCriteria)->getItems();
        } catch (LocalizedException $exception) {
            $campaignsForMassAction = [];
        }

        return $campaignsForMassAction;
    }

    /**
     * Perform mass action
     *
     * @param CampaignInterface[] $campaigns
     */
    abstract protected function massAction($campaigns);
}
