<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Model;

use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Aheadworks\Affiliate\Api\Data\CampaignInterfaceFactory;
use Aheadworks\Affiliate\Api\Data\CampaignSearchResultsInterface;
use Aheadworks\Affiliate\Api\Data\CampaignSearchResultsInterfaceFactory;
use Aheadworks\Affiliate\Model\Campaign as CampaignModel;
use Aheadworks\Affiliate\Model\ResourceModel\Campaign as CampaignResourceModel;
use Aheadworks\Affiliate\Model\ResourceModel\Campaign\Collection as CampaignCollection;
use Aheadworks\Affiliate\Model\ResourceModel\Campaign\CollectionFactory as CampaignCollectionFactory;
use Aheadworks\Affiliate\Model\Campaign;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Aheadworks\Affiliate\Model\CampaignRepository;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;

/**
 * Class CampaignRepositoryTest
 *
 * @package Aheadworks\Affiliate\Test\Unit\Model
 */
class CampaignRepositoryTest extends TestCase
{
    /**
     * @var CampaignResourceModel|\PHPUnit_Framework_MockObject_MockObject
     */
    private $resourceMock;

    /**
     * @var CampaignInterfaceFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $campaignInterfaceFactoryMock;

    /**
     * @var CampaignCollectionFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $campaignCollectionFactoryMock;

    /**
     * @var CampaignSearchResultsInterfaceFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $searchResultsFactoryMock;

    /**
     * @var JoinProcessorInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $extensionAttributesJoinProcessorMock;

    /**
     * @var CollectionProcessorInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $collectionProcessorMock;

    /**
     * @var DataObjectHelper|\PHPUnit_Framework_MockObject_MockObject
     */
    private $dataObjectHelperMock;

    /**
     * @var DataObjectProcessor|\PHPUnit_Framework_MockObject_MockObject
     */
    private $dataObjectProcessorMock;

    /**
     * @var CampaignRepository
     */
    private $campaignRepository;

    /**#@+
     * Constants used for tests
     */
    const DEFAULT_ID = 1;
    /**#@-*/

    /**
     * Init mocks for tests
     *
     * @return void
     */
    protected function setUp() : void
    {
        $objectManager = new ObjectManager($this);
        $this->resourceMock = $this->createMock(CampaignResourceModel::class);
        $this->campaignInterfaceFactoryMock = $this->createMock(CampaignInterfaceFactory::class);
        $this->campaignCollectionFactoryMock = $this->createMock(CampaignCollectionFactory::class);
        $this->searchResultsFactoryMock = $this->createMock(CampaignSearchResultsInterfaceFactory::class);
        $this->extensionAttributesJoinProcessorMock = $this->createMock(JoinProcessorInterface::class);
        $this->collectionProcessorMock = $this->createMock(CollectionProcessorInterface::class);
        $this->dataObjectHelperMock = $this->createMock(DataObjectHelper::class);
        $this->dataObjectProcessorMock = $this->createMock(DataObjectProcessor::class);
        $this->campaignRepository = $objectManager->getObject(
            CampaignRepository::class,
            [
                'resource' => $this->resourceMock,
                'campaignInterfaceFactory' => $this->campaignInterfaceFactoryMock,
                'campaignCollectionFactory' => $this->campaignCollectionFactoryMock,
                'searchResultsFactory' => $this->searchResultsFactoryMock,
                'extensionAttributesJoinProcessor' => $this->extensionAttributesJoinProcessorMock,
                'collectionProcessor' => $this->collectionProcessorMock,
                'dataObjectHelper' => $this->dataObjectHelperMock,
                'dataObjectProcessor' => $this->dataObjectProcessorMock
            ]
        );
    }

    /**
     * Test save method
     *
     * @throws CouldNotSaveException
     */
    public function testSave()
    {
        $campaignMock = $this->getCampaignMock(CampaignInterface::class);

        $this->resourceMock->expects($this->once())
            ->method('save')
            ->willReturnSelf();

        $this->assertSame($campaignMock, $this->campaignRepository->save($campaignMock));
    }

    /**
     * Test save method with exception
     *
     * @expectedException \Magento\Framework\Exception\CouldNotSaveException
     * @expectedExceptionMessage Test message
     * @throws CouldNotSaveException
     */
    public function testSaveWithException()
    {
        $exception = new \Exception('Test message');
        $campaignMock = $this->getCampaignMock();
        $this->resourceMock->expects($this->once())
            ->method('save')
            ->with($campaignMock)
            ->willThrowException($exception);
        $this->expectException(CouldNotSaveException::class);
        $this->campaignRepository->save($campaignMock);
    }

    /**
     * Test delete method
     *
     * @throws CouldNotDeleteException
     */
    public function testDelete()
    {
        $campaignMock = $this->getCampaignMock();

        $this->resourceMock->expects($this->once())
            ->method('delete')
            ->with($campaignMock);

        $this->assertTrue($this->campaignRepository->delete($campaignMock));
    }

    /**
     * Test delete method with exception
     *
     * @expectedException \Magento\Framework\Exception\CouldNotDeleteException
     * @expectedExceptionMessage Can't delete exception message.
     * @throws CouldNotDeleteException
     */
    public function testDeleteWithException()
    {
        $campaignMock = $this->getCampaignMock();
        $exception = new CouldNotDeleteException(__('Can\'t delete exception message.'));
        $this->resourceMock->expects($this->once())
            ->method('delete')
            ->willThrowException($exception);
        $this->expectException(CouldNotDeleteException::class);
        $this->assertTrue($this->campaignRepository->delete($campaignMock));
    }

    /**
     * Test getById method
     *
     * @throws NoSuchEntityException
     */
    public function testGetById()
    {
        $campaignMock = $this->getCampaignMock();

        $this->campaignInterfaceFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($campaignMock);
        $this->resourceMock->expects($this->once())
            ->method('load')
            ->with($campaignMock, self::DEFAULT_ID)
            ->willReturnSelf();

        $this->assertSame($campaignMock, $this->campaignRepository->getById(self::DEFAULT_ID));
    }

    /**
     * Test getById method with exception
     *
     * @throws NoSuchEntityException
     * @expectedException \Magento\Framework\Exception\NoSuchEntityException
     * @expectedExceptionMessage No such entity with campaign_id = 1
     */
    public function testGetByIdWithException()
    {
        $campaignMock = $this->getCampaignMock(null);

        $this->campaignInterfaceFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($campaignMock);
        $this->resourceMock->expects($this->once())
            ->method('load')
            ->with($campaignMock, self::DEFAULT_ID)
            ->willReturnSelf();
        $this->expectException(NoSuchEntityException::class);
        $this->assertSame($campaignMock, $this->campaignRepository->getById(self::DEFAULT_ID));
    }

    /**
     * Test getList method
     *
     * @param array $collectionItems
     * @param array $searchResultItems
     * @param CampaignModel|null|\PHPUnit_Framework_MockObject_MockObject $campaignModelMock
     * @dataProvider testGetListProvider
     */
    public function testGetList($collectionItems, $searchResultItems, $campaignModelMock = null)
    {
        /** @var SearchCriteriaInterface|\PHPUnit_Framework_MockObject_MockObject $searchCriteriaMock */
        $searchCriteriaMock = $this->createMock(SearchCriteriaInterface::class);
        $collectionSize = count($collectionItems);
        $campaignCollectionMock = $this->createMock(CampaignCollection::class);
        $searchResultsMock = $this->createMock(CampaignSearchResultsInterface::class);
        $campaignData = [CampaignInterface::ID => self::DEFAULT_ID];

        $this->campaignCollectionFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($campaignCollectionMock);
        $this->extensionAttributesJoinProcessorMock->expects($this->once())
            ->method('process')
            ->with($campaignCollectionMock, CampaignInterface::class);
        $this->collectionProcessorMock->expects($this->once())
            ->method('process')
            ->with($searchCriteriaMock, $campaignCollectionMock);
        $this->searchResultsFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($searchResultsMock);
        $searchResultsMock->expects($this->once())
            ->method('setSearchCriteria')
            ->with($searchCriteriaMock);
        $campaignCollectionMock->expects($this->once())
            ->method('getSize')
            ->willReturn($collectionSize);
        $searchResultsMock->expects($this->once())
            ->method('setTotalCount')
            ->with($collectionSize);
        $campaignCollectionMock->expects($this->once())
            ->method('getItems')
            ->willReturn($collectionItems);
        $this->campaignInterfaceFactoryMock->expects($this->exactly($collectionSize))
            ->method('create')
            ->willReturn($campaignModelMock);
        $this->dataObjectProcessorMock->expects($this->exactly($collectionSize))
            ->method('buildOutputDataArray')
            ->with($campaignModelMock, CampaignInterface::class)
            ->willReturn($campaignData);
        $this->dataObjectHelperMock->expects($this->exactly($collectionSize))
            ->method('populateWithArray')
            ->with($campaignModelMock, $campaignData, CampaignInterface::class);
        $searchResultsMock->expects($this->once())
            ->method('setItems')
            ->with($searchResultItems)
            ->willReturnSelf();

        $this->assertSame($searchResultsMock, $this->campaignRepository->getList($searchCriteriaMock));
    }

    /**
     * Get campaign mock
     *
     * @param int|null $campaignId
     * @return CampaignModel|\PHPUnit_Framework_MockObject_MockObject
     */
    private function getCampaignMock($campaignId = self::DEFAULT_ID)
    {
        $campaignMock = $this->createMock(CampaignModel::class);

        $campaignMock->expects($this->atMost(2))
            ->method('getCampaignId')
            ->willReturn($campaignId);

        return $campaignMock;
    }

    /**
     * @return array
     */
    public function testGetListProvider()
    {
        $campaignModelMock = $this->getCampaignMock();

        return [
            [[$campaignModelMock], [$campaignModelMock], $campaignModelMock],
            [[],[]]
        ];
    }
}
