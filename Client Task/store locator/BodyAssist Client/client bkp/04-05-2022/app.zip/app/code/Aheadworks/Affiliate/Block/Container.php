<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Aheadworks\Affiliate\Model\Layout\ProcessorProvider as LayoutProcessorProvider;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\Serialize\Serializer\Json as JsonSerializer;

/**
 * Class Container
 *
 * @package Aheadworks\Affiliate\Block
 */
class Container extends Template
{
    /**
     * {@inheritdoc}
     */
    protected $_template = 'Aheadworks_Affiliate::container.phtml';

    /**
     * @var LayoutProcessorProvider
     */
    private $layoutProcessorProvider;

    /**
     * @var CustomerSession
     */
    private $customerSession;

    /**
     * @var JsonSerializer
     */
    private $jsonSerializer;

    /**
     * @param Context $context
     * @param LayoutProcessorProvider $layoutProcessorProvider
     * @param CustomerSession $customerSession
     * @param JsonSerializer $jsonSerializer
     * @param array $data
     */
    public function __construct(
        Context $context,
        LayoutProcessorProvider $layoutProcessorProvider,
        CustomerSession $customerSession,
        JsonSerializer $jsonSerializer,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->layoutProcessorProvider = $layoutProcessorProvider;
        $this->customerSession = $customerSession;
        $this->jsonSerializer = $jsonSerializer;
        $this->jsLayout = isset($data['jsLayout']) && is_array($data['jsLayout'])
            ? $data['jsLayout']
            : [];
    }

    /**
     * {@inheritdoc}
     */
    public function getJsLayout()
    {
        foreach ($this->layoutProcessorProvider->getLayoutProcessors() as $layoutProcessor) {
            $this->jsLayout = $layoutProcessor->process(
                $this->jsLayout,
                $this->customerSession->getCustomerId(),
                $this->_storeManager->getStore()->getWebsiteId()
            );
        }

        return $this->jsonSerializer->serialize($this->jsLayout);
    }
}
