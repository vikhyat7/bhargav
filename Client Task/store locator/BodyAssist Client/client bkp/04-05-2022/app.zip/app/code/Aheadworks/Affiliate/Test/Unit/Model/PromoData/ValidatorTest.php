<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Model\PromoData;

use PHPUnit\Framework\TestCase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Aheadworks\Affiliate\Model\PromoData\Validator;
use Aheadworks\Affiliate\Api\AccountRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Aheadworks\Affiliate\Api\CampaignRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Store\Api\Data\StoreInterface;
use Aheadworks\Affiliate\Api\Data\PromoDataInterface;
use Aheadworks\Affiliate\Model\Campaign\Validator\Account as CampaignAccountValidator;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Test for \Aheadworks\Affiliate\Model\PromoData\Validator
 */
class ValidatorTest extends TestCase
{
    /**
     * Entity ID for throwing NoSuchEntityException by repository
     */
    const ID_FOR_THROWING_EXCEPTION = -1;

    /**
     * @var Validator
     */
    private $model;

    /**
     * @var AccountRepositoryInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $accountRepositoryMock;

    /**
     * @var CampaignRepositoryInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $campaignRepositoryMock;

    /**
     * @var StoreManagerInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $storeManagerMock;

    /**
     * @var CampaignAccountValidator|\PHPUnit_Framework_MockObject_MockObject
     */
    private $campaignAccountValidatorMock;

    /**
     * Init mocks for tests
     *
     * @return void
     */
    public function setUp() : void
    {
        $objectManager = new ObjectManager($this);

        $this->accountRepositoryMock = $this->createMock(AccountRepositoryInterface::class);
        $this->campaignRepositoryMock = $this->createMock(CampaignRepositoryInterface::class);
        $this->storeManagerMock = $this->createMock(StoreManagerInterface::class);
        $this->campaignAccountValidatorMock = $this->createMock(CampaignAccountValidator::class);

        $this->model = $objectManager->getObject(
            Validator::class,
            [
                'accountRepository' => $this->accountRepositoryMock,
                'campaignRepository' => $this->campaignRepositoryMock,
                'storeManager' => $this->storeManagerMock,
                'campaignAccountValidator' => $this->campaignAccountValidatorMock
            ]
        );
    }

    /**
     * Test for validate()
     *
     * @param int $accountId
     * @param int $campaignId
     * @param int|null $storeId
     * @param int $websiteId
     * @param bool $isCampaignAccountValid
     * @param bool $isValid
     * @dataProvider validateDataProvider
     */
    public function testValidate(
        $accountId,
        $campaignId,
        $storeId,
        $websiteId,
        $isCampaignAccountValid,
        $isValid
    ) {
        $promoDataMock = $this->createMock(PromoDataInterface::class);
        $promoDataMock->expects($this->any())
            ->method('getAccountId')
            ->willReturn($accountId);
        $promoDataMock->expects($this->any())
            ->method('getCampaignId')
            ->willReturn($campaignId);

        $accountMock = $this->createMock(AccountInterface::class);
        if ($accountId === self::ID_FOR_THROWING_EXCEPTION) {
            $this->accountRepositoryMock->expects($this->any())
                ->method('getById')
                ->with($accountId)
                ->willThrowException(new NoSuchEntityException());
        } else {
            $this->accountRepositoryMock->expects($this->any())
                ->method('getById')
                ->with($accountId)
                ->willReturn($accountMock);
        }

        $campaignMock = $this->createMock(CampaignInterface::class);

        if ($campaignId === self::ID_FOR_THROWING_EXCEPTION) {
            $this->campaignRepositoryMock->expects($this->any())
                ->method('getById')
                ->with($campaignId)
                ->willThrowException(new NoSuchEntityException());
        } else {
            $this->campaignRepositoryMock->expects($this->any())
                ->method('getById')
                ->with($campaignId)
                ->willReturn($campaignMock);
        }

        $storeMock = $this->createMock(StoreInterface::class);
        $storeMock->expects($this->any())
            ->method('getWebsiteId')
            ->willReturn($websiteId);
        if ($storeId === self::ID_FOR_THROWING_EXCEPTION) {
            $this->storeManagerMock->expects($this->any())
                ->method('getStore')
                ->with($storeId)
                ->willThrowException(new NoSuchEntityException());
        } else {
            $this->storeManagerMock->expects($this->any())
                ->method('getStore')
                ->with($storeId)
                ->willReturn($storeMock);
        }

        $this->campaignAccountValidatorMock->expects($this->any())
            ->method('validate')
            ->with($accountMock, $campaignMock, $websiteId)
            ->willReturn($isCampaignAccountValid);

        $this->assertEquals(
            $isValid,
            $this->model->validate($promoDataMock, $storeId)
        );
    }

    /**
     * @return array
     */
    public function validateDataProvider()
    {
        return [
            [
                'accountId'                 => 1,
                'campaignId'                => 1,
                'storeId'                   => 1,
                'websiteId'                 => 1,
                'isCampaignAccountValid'    => true,
                'isValid'                   => true
            ],
            [
                'accountId'                 => self::ID_FOR_THROWING_EXCEPTION,
                'campaignId'                => 1,
                'storeId'                   => 1,
                'websiteId'                 => 1,
                'isCampaignAccountValid'    => true,
                'isValid'                   => false
            ],
            [
                'accountId'                 => 1,
                'campaignId'                => self::ID_FOR_THROWING_EXCEPTION,
                'storeId'                   => 1,
                'websiteId'                 => 1,
                'isCampaignAccountValid'    => true,
                'isValid'                   => false
            ],
            [
                'accountId'                 => 1,
                'campaignId'                => 1,
                'storeId'                   => self::ID_FOR_THROWING_EXCEPTION,
                'websiteId'                 => 1,
                'isCampaignAccountValid'    => true,
                'isValid'                   => false
            ],
            [
                'accountId'                 => self::ID_FOR_THROWING_EXCEPTION,
                'campaignId'                => self::ID_FOR_THROWING_EXCEPTION,
                'storeId'                   => 1,
                'websiteId'                 => 1,
                'isCampaignAccountValid'    => true,
                'isValid'                   => false
            ],
            [
                'accountId'                 => self::ID_FOR_THROWING_EXCEPTION,
                'campaignId'                => 1,
                'storeId'                   => self::ID_FOR_THROWING_EXCEPTION,
                'websiteId'                 => 1,
                'isCampaignAccountValid'    => true,
                'isValid'                   => false
            ],
            [
                'accountId'                 => 1,
                'campaignId'                => self::ID_FOR_THROWING_EXCEPTION,
                'storeId'                   => self::ID_FOR_THROWING_EXCEPTION,
                'websiteId'                 => 1,
                'isCampaignAccountValid'    => true,
                'isValid'                   => false
            ],
            [
                'accountId'                 => self::ID_FOR_THROWING_EXCEPTION,
                'campaignId'                => self::ID_FOR_THROWING_EXCEPTION,
                'storeId'                   => self::ID_FOR_THROWING_EXCEPTION,
                'websiteId'                 => 1,
                'isCampaignAccountValid'    => true,
                'isValid'                   => false
            ],
            [
                'accountId'                 => 1,
                'campaignId'                => 2,
                'storeId'                   => 1,
                'websiteId'                 => 1,
                'isCampaignAccountValid'    => false,
                'isValid'                   => false
            ],
        ];
    }
}
