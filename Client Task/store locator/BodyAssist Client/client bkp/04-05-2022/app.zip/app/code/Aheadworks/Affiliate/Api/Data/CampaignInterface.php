<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Api\Data;

use Magento\Framework\Api\ExtensibleDataInterface;

/**
 * Interface CampaignInterface
 *
 * @package Aheadworks\Affiliate\Api\Data
 */
interface CampaignInterface extends ExtensibleDataInterface
{
    /**#@+
     * Constants defined for keys of the data array.
     * Identical to the name of the getter in snake case
     */
    const ID = 'campaign_id';
    const NAME = 'name';
    const DESCRIPTION = 'description';
    const STATUS = 'status';
    const WEBSITE_ID = 'website_id';
    const AFFILIATE_GROUP_IDS = 'affiliate_group_ids';
    const COMMISSION_TYPE = 'commission_type';
    const COMMISSION_VALUE = 'commission_value';
    const IS_LINK_GENERATION_ALLOWED = 'is_link_generation_allowed';
    const TRACKING_GAP = 'tracking_gap';
    const COUPON_USAGE_MODE = 'coupon_usage_mode';
    const COUPON_CODE_TEMPLATE = 'coupon_code_template';
    const COUPON_USES_PER_AFFILIATE = 'coupon_uses_per_affiliate';
    const COUPON_DISCOUNT_TYPE = 'coupon_discount_type';
    const COUPON_DISCOUNT_AMOUNT = 'coupon_discount_amount';
    const IS_COUPON_CODE_SEPARATOR_ALLOWED = 'is_coupon_code_separator_allowed';
    const CART_CONDITION = 'cart_condition';
    const RECOMMENDED_PRODUCT_IDS = 'recommended_product_ids';
    /**#@-*/

    /**
     * Get campaign id
     *
     * @return int
     */
    public function getCampaignId();

    /**
     * Set campaign id
     *
     * @param int $id
     * @return $this
     */
    public function setCampaignId($id);

    /**
     * Get name
     *
     * @return string
     */
    public function getName();

    /**
     * Set name
     *
     * @param string $name
     * @return $this
     */
    public function setName($name);

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription();

    /**
     * Set description
     *
     * @param string $description
     * @return $this
     */
    public function setDescription($description);

    /**
     * Get status
     *
     * @return int
     */
    public function getStatus();

    /**
     * Set status
     *
     * @param int $status
     * @return $this
     */
    public function setStatus($status);

    /**
     * Get website id
     *
     * @return int
     */
    public function getWebsiteId();

    /**
     * Set website id
     *
     * @param int $websiteId
     * @return $this
     */
    public function setWebsiteId($websiteId);

    /**
     * Get affiliate group ids
     *
     * @return int[]
     */
    public function getAffiliateGroupIds();

    /**
     * Set affiliate group ids
     *
     * @param int[] $affiliateGroupIds
     * @return $this
     */
    public function setAffiliateGroupIds($affiliateGroupIds);

    /**
     * Get commission type
     *
     * @return int
     */
    public function getCommissionType();

    /**
     * Set commission type
     *
     * @param int $commissionType
     * @return $this
     */
    public function setCommissionType($commissionType);

    /**
     * Get commission value
     *
     * @return float
     */
    public function getCommissionValue();

    /**
     * Set commission value
     *
     * @param float $commissionValue
     * @return $this
     */
    public function setCommissionValue($commissionValue);

    /**
     * Get is link generation allowed
     *
     * @return bool
     */
    public function getIsLinkGenerationAllowed();

    /**
     * Set is link generation allowed
     *
     * @param bool $isLinkGenerationAllowed
     * @return $this
     */
    public function setIsLinkGenerationAllowed($isLinkGenerationAllowed);

    /**
     * Get tracking gap
     *
     * @return int
     */
    public function getTrackingGap();

    /**
     * Set tracking gap
     *
     * @param int $trackingGap
     * @return $this
     */
    public function setTrackingGap($trackingGap);

    /**
     * Get coupon usage mode
     *
     * @return int
     */
    public function getCouponUsageMode();

    /**
     * Set coupon usage mode
     *
     * @param int $couponUsageMode
     * @return $this
     */
    public function setCouponUsageMode($couponUsageMode);

    /**
     * Get coupon code template
     *
     * @return string|null
     */
    public function getCouponCodeTemplate();

    /**
     * Set coupon code template
     *
     * @param string $couponCodeTemplate
     * @return $this
     */
    public function setCouponCodeTemplate($couponCodeTemplate);

    /**
     * Get coupon uses per affiliate
     *
     * @return int|null
     */
    public function getCouponUsesPerAffiliate();

    /**
     * Set coupon uses per affiliate
     *
     * @param int $couponUsesPerAffiliate
     * @return $this
     */
    public function setCouponUsesPerAffiliate($couponUsesPerAffiliate);

    /**
     * Get coupon discount type
     *
     * @return int
     */
    public function getCouponDiscountType();

    /**
     * Set coupon discount type
     *
     * @param int $discountType
     * @return $this
     */
    public function setCouponDiscountType($discountType);

    /**
     * Get coupon discount amount
     *
     * @return float
     */
    public function getCouponDiscountAmount();

    /**
     * Set coupon discount amount
     *
     * @param float $discountAmount
     * @return $this
     */
    public function setCouponDiscountAmount($discountAmount);

    /**
     * Get is coupon code separator allowed
     *
     * @return bool
     */
    public function getIsCouponCodeSeparatorAllowed();

    /**
     * Set is coupon code separator allowed
     *
     * @param bool $isCouponCodeSeparatorAllowed
     * @return $this
     */
    public function setIsCouponCodeSeparatorAllowed($isCouponCodeSeparatorAllowed);

    /**
     * Get cart condition
     *
     * @return \Aheadworks\Affiliate\Api\Data\ConditionInterface
     */
    public function getCartCondition();

    /**
     * Set cart condition
     *
     * @param \Aheadworks\Affiliate\Api\Data\ConditionInterface $cartCondition
     * @return $this
     */
    public function setCartCondition($cartCondition);

    /**
     * Get recommended product ids
     *
     * @return int[]
     */
    public function getRecommendedProductIds();

    /**
     * Set recommended product ids
     *
     * @param int[] $recommendedProductIds
     * @return $this
     */
    public function setRecommendedProductIds($recommendedProductIds);
    
    /**
     * Retrieve existing extension attributes object or create a new one
     *
     * @return \Aheadworks\Affiliate\Api\Data\CampaignExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object
     *
     * @param \Aheadworks\Affiliate\Api\Data\CampaignExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aheadworks\Affiliate\Api\Data\CampaignExtensionInterface $extensionAttributes
    );
}
