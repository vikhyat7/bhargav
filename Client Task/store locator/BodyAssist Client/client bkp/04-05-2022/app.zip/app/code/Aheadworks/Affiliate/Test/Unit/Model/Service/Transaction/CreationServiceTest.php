<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Model\Service\Transaction;

use PHPUnit\Framework\TestCase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Aheadworks\Affiliate\Model\Service\Transaction\CreationService;
use Magento\Sales\Model\Order\Item as OrderItem;
use Aheadworks\Affiliate\Model\Order\Item\Checker as OrderItemChecker;
use Aheadworks\Affiliate\Api\TransactionManagementInterface;
use Aheadworks\Affiliate\Model\Source\Transaction\Status as TransactionStatus;
use Aheadworks\Affiliate\Model\Source\Transaction\Type as TransactionType;
use Magento\Framework\Exception\CouldNotSaveException;

/**
 * Test for \Aheadworks\Affiliate\Model\Service\Transaction\CreationService
 */
class CreationServiceTest extends TestCase
{
    /**
     * @var CreationService
     */
    private $model;

    /**
     * @var TransactionManagementInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $transactionServiceMock;

    /**
     * @var OrderItemChecker|\PHPUnit_Framework_MockObject_MockObject
     */
    private $orderItemCheckerMock;

    /**
     * Init mocks for tests
     *
     * @return void
     */
    public function setUp() : void
    {
        $objectManager = new ObjectManager($this);

        $this->transactionServiceMock = $this->createMock(TransactionManagementInterface::class);
        $this->orderItemCheckerMock = $this->createMock(OrderItemChecker::class);

        $this->model = $objectManager->getObject(
            CreationService::class,
            [
                'transactionService' => $this->transactionServiceMock,
                'orderItemChecker' => $this->orderItemCheckerMock
            ]
        );
    }

    /**
     * Test createTransactionByOrderItem
     *
     * @param int $awAffAccountId
     * @param OrderItem $orderItem
     * @param bool $isPromoDataValid
     * @param bool $isTransactionCreated
     * @param bool $isTransactionCreationAllowed
     * @param bool $isAddTransactionCalled
     * @param bool $isExceptionThrown
     * @dataProvider createTransactionByOrderItemProvider
     * phpcs:disable Magento2.CodeAnalysis.EmptyBlock.DetectedCatch
     */
    public function testCreateTransactionByOrderItem(
        $awAffAccountId,
        $orderItem,
        $isPromoDataValid,
        $isTransactionCreated,
        $isTransactionCreationAllowed,
        $isAddTransactionCalled,
        $isExceptionThrown
    ) {
        $this->orderItemCheckerMock->expects($this->any())
            ->method('hasValidPromoData')
            ->with($orderItem)
            ->willReturn($isPromoDataValid);
        $this->orderItemCheckerMock->expects($this->any())
            ->method('isTransactionCreated')
            ->with($orderItem)
            ->willReturn($isTransactionCreated);
        $this->orderItemCheckerMock->expects($this->any())
            ->method('isTransactionCreationAllowed')
            ->with($orderItem)
            ->willReturn($isTransactionCreationAllowed);

        if ($isAddTransactionCalled) {
            if ($isExceptionThrown) {
                $this->transactionServiceMock->expects($this->once())
                    ->method('addTransaction')
                    ->with(
                        $awAffAccountId,
                        TransactionType::COMMISSION,
                        TransactionStatus::getDefaultStatus(),
                        $orderItem
                    )->willThrowException(new CouldNotSaveException(__('')));
            } else {
                $this->transactionServiceMock->expects($this->once())
                    ->method('addTransaction')
                    ->with(
                        $awAffAccountId,
                        TransactionType::COMMISSION,
                        TransactionStatus::getDefaultStatus(),
                        $orderItem
                    );
            }
        } else {
            $this->transactionServiceMock->expects($this->never())
                ->method('addTransaction')
                ->with(
                    $awAffAccountId,
                    TransactionType::COMMISSION,
                    TransactionStatus::getDefaultStatus(),
                    $orderItem
                );
        }

        if ($isExceptionThrown) {
            try {
                $this->model->createTransactionByOrderItem($orderItem);
            } catch (CouldNotSaveException $exception) {
            }
        } else {
            $this->model->createTransactionByOrderItem($orderItem);
        }
    }

    /**
     * @return array
     */
    public function createTransactionByOrderItemProvider()
    {
        $awAffAccountId = 1;
        $orderItemMock = $this->createMock(OrderItem::class);
        $orderItemMock->expects($this->any())
            ->method('__call')
            ->with('getAwAffAccountId')
            ->willReturn($awAffAccountId);
        return [
            [
                'awAffAccountId' => $awAffAccountId,
                'orderItem' => $orderItemMock,
                'isPromoDataValid' => false,
                'isTransactionCreated' => false,
                'isTransactionCreationAllowed' => false,
                'isAddTransactionCalled' => false,
                'isExceptionThrown' => false
            ],
            [
                'awAffAccountId' => $awAffAccountId,
                'orderItem' => $orderItemMock,
                'isPromoDataValid' => true,
                'isTransactionCreated' => false,
                'isTransactionCreationAllowed' => false,
                'isAddTransactionCalled' => false,
                'isExceptionThrown' => false
            ],
            [
                'awAffAccountId' => $awAffAccountId,
                'orderItem' => $orderItemMock,
                'isPromoDataValid' => false,
                'isTransactionCreated' => true,
                'isTransactionCreationAllowed' => false,
                'isAddTransactionCalled' => false,
                'isExceptionThrown' => false
            ],
            [
                'awAffAccountId' => $awAffAccountId,
                'orderItem' => $orderItemMock,
                'isPromoDataValid' => true,
                'isTransactionCreated' => true,
                'isTransactionCreationAllowed' => false,
                'isAddTransactionCalled' => false,
                'isExceptionThrown' => false
            ],
            [
                'awAffAccountId' => $awAffAccountId,
                'orderItem' => $orderItemMock,
                'isPromoDataValid' => false,
                'isTransactionCreated' => false,
                'isTransactionCreationAllowed' => true,
                'isAddTransactionCalled' => false,
                'isExceptionThrown' => false
            ],
            [
                'awAffAccountId' => $awAffAccountId,
                'orderItem' => $orderItemMock,
                'isPromoDataValid' => true,
                'isTransactionCreated' => false,
                'isTransactionCreationAllowed' => true,
                'isAddTransactionCalled' => true,
                'isExceptionThrown' => false
            ],
            [
                'awAffAccountId' => $awAffAccountId,
                'orderItem' => $orderItemMock,
                'isPromoDataValid' => false,
                'isTransactionCreated' => true,
                'isTransactionCreationAllowed' => true,
                'isAddTransactionCalled' => false,
                'isExceptionThrown' => false
            ],
            [
                'awAffAccountId' => $awAffAccountId,
                'orderItem' => $orderItemMock,
                'isPromoDataValid' => true,
                'isTransactionCreated' => true,
                'isTransactionCreationAllowed' => true,
                'isAddTransactionCalled' => false,
                'isExceptionThrown' => false
            ],
            [
                'awAffAccountId' => $awAffAccountId,
                'orderItem' => $orderItemMock,
                'isPromoDataValid' => true,
                'isTransactionCreated' => false,
                'isTransactionCreationAllowed' => true,
                'isAddTransactionCalled' => true,
                'isExceptionThrown' => true
            ],
        ];
    }
}
