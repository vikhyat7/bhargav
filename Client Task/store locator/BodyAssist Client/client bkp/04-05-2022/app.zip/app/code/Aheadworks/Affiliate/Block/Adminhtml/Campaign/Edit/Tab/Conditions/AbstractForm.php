<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Block\Adminhtml\Campaign\Edit\Tab\Conditions;

use Magento\Framework\Data\Form as DataForm;
use Magento\Framework\Data\Form\Element\Fieldset;
use Magento\Rule\Model\AbstractModel;
use Magento\Rule\Model\Condition\Combine as ConditionCombine;
use Magento\Framework\Data\Form\Element\Renderer\RendererInterface;
use Magento\Rule\Block\Conditions as ConditionsBlock;
use Aheadworks\Affiliate\Model\Campaign\Condition\Form\DataProviderInterface as ConditionFormDataProviderInterface;

/**
 * Class AbstractForm
 *
 * @package Aheadworks\Affiliate\Block\Adminhtml\Campaign\Edit\Tab\Conditions
 */
abstract class AbstractForm
{
    /**
     * @var ConditionsBlock
     */
    protected $conditionsBlock;

    /**
     * @var ConditionFormDataProviderInterface
     */
    protected $conditionFormDataProvider;

    /**
     * @param ConditionsBlock $conditionsBlock
     * @param ConditionFormDataProviderInterface $conditionFormDataProvider
     */
    public function __construct(
        ConditionsBlock $conditionsBlock,
        ConditionFormDataProviderInterface $conditionFormDataProvider
    ) {
        $this->conditionsBlock = $conditionsBlock;
        $this->conditionFormDataProvider = $conditionFormDataProvider;
    }

    /**
     * Retrieve form namespace
     *
     * @return string
     */
    public function getFormNamespace()
    {
        return 'aw_affiliate_campaign_form';
    }

    /**
     * Retrieve form id prefix
     *
     * @return string
     */
    abstract public function getFormIdPrefix();

    /**
     * Retrieve new child url route
     *
     * @return string
     */
    public function getNewChildUrlRoute()
    {
        return '*/*/newConditionHtml';
    }

    /**
     * Retrieve form fieldset name
     *
     * @return string
     */
    abstract public function getFormFieldsetName();

    /**
     * Retrieve condition field name
     *
     * @return string
     */
    abstract public function getConditionFieldName();

    /**
     * Retrieve js form object name
     *
     * @return string
     */
    public function getJsFormObjectName()
    {
        return $this->getFormIdPrefix() . $this->getFormFieldsetName();
    }

    /**
     * Prepare form
     *
     * @param DataForm $form
     */
    public function prepareForm($form)
    {
        $fieldset = $this->addFieldsetToForm($form);
        $this->prepareFieldset($fieldset);
    }

    /**
     * Add fieldset to specified form
     *
     * @param DataForm $form
     * @return Fieldset
     */
    protected function addFieldsetToForm($form)
    {
        return $form->addFieldset($this->getFormFieldsetName(), []);
    }

    /**
     * Prepare field set for form
     *
     * @param Fieldset $fieldset
     */
    protected function prepareFieldset($fieldset)
    {
        $conditionData = $this->conditionFormDataProvider->getConditionData();
        $conditionRule = $this->getConditionRule($conditionData);
        $fieldset->setRenderer($this->getFieldsetRenderer());
        $conditionRule->setJsFormObject($this->getJsFormObjectName());
        $this->addFieldsToFieldset($fieldset, $conditionRule);
        $this->setFormNameToRuleConditions($conditionRule->getConditions());
    }

    /**
     * Retrieve condition rule object from condition array
     *
     * @param array $conditionData
     * @return AbstractModel
     */
    protected function getConditionRule($conditionData)
    {
        $rule = $this->getRuleModelInstance();
        if (isset($conditionData) && (is_array($conditionData))) {
            $rule->setConditions([])
                ->getConditions()
                ->loadArray($conditionData);
        }
        return $rule;
    }

    /**
     * Retrieve rule model instance
     *
     * @return \Magento\Rule\Model\AbstractModel
     */
    abstract protected function getRuleModelInstance();

    /**
     * Retrieve renderer for form fieldset
     *
     * @return RendererInterface
     */
    abstract protected function getFieldsetRenderer();

    /**
     * Add necessary fields to form fieldset
     *
     * @param Fieldset $fieldset
     * @param AbstractModel $conditionRule
     */
    protected function addFieldsToFieldset($fieldset, $conditionRule)
    {
        $fieldset
            ->addField(
                $this->getConditionFieldName(),
                'text',
                [
                    'name' => $this->getConditionFieldName(),
                    'label' => __('Conditions'),
                    'title' => __('Conditions'),
                    'data-form-part' => $this->getFormNamespace()
                ]
            )
            ->setRule($conditionRule)
            ->setRenderer($this->conditionsBlock);
    }

    /**
     * Handles addition of form name to combine condition and its child conditions
     *
     * @param ConditionCombine $conditions
     * @return void
     */
    protected function setFormNameToRuleConditions($conditions)
    {
        $conditions->setFormName($this->getFormNamespace());
        $conditions->setJsFormObject($this->getJsFormObjectName());
        if ($conditions->getConditions() && is_array($conditions->getConditions())) {
            foreach ($conditions->getConditions() as $conditionsArrayItem) {
                $this->setFormNameToRuleConditions($conditionsArrayItem);
            }
        }
    }
}
