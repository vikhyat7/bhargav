<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Ui\DataProvider\Frontend\RecommendedProduct\Listing\Collector;

use Magento\Catalog\Ui\DataProvider\Product\ProductRenderCollectorInterface;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Catalog\Api\Data\ProductRenderInterface;
use Magento\Catalog\Api\Data\ProductRenderExtensionFactory;
use Aheadworks\Affiliate\Model\ValueFormatter\Price as PriceValueFormatter;
use Aheadworks\Affiliate\Model\Commission\Calculator\Campaign as CampaignCommissionCalculator;

/**
 * Class Commission
 *
 * @package Aheadworks\Affiliate\Ui\DataProvider\Frontend\RecommendedProduct\Listing\Collector
 */
class Commission implements ProductRenderCollectorInterface
{
    /**
     * Product qty to calculate commission
     */
    const QTY_TO_CALCULATE_COMMISSION = 1;

    /**
     * @var PriceValueFormatter
     */
    private $priceValueFormatter;

    /**
     * @var ProductRenderExtensionFactory
     */
    private $productRenderExtensionFactory;

    /**
     * @var CampaignCommissionCalculator
     */
    private $campaignCommissionCalculator;

    /**
     * @param PriceValueFormatter $priceValueFormatter
     * @param ProductRenderExtensionFactory $productRenderExtensionFactory
     * @param CampaignCommissionCalculator $campaignCommissionCalculator
     */
    public function __construct(
        PriceValueFormatter $priceValueFormatter,
        ProductRenderExtensionFactory $productRenderExtensionFactory,
        CampaignCommissionCalculator $campaignCommissionCalculator
    ) {
        $this->priceValueFormatter = $priceValueFormatter;
        $this->productRenderExtensionFactory = $productRenderExtensionFactory;
        $this->campaignCommissionCalculator = $campaignCommissionCalculator;
    }

    /**
     * @inheritdoc
     */
    public function collect(ProductInterface $product, ProductRenderInterface $productRender)
    {
        $extensionAttributes = $productRender->getExtensionAttributes();
        if (empty($extensionAttributes)) {
            $extensionAttributes = $this->productRenderExtensionFactory->create();
        }

        $campaignId = $extensionAttributes->getAwAffCampaignId();
        $productPrice = $this->getProductPrice($product);
        $amount = self::QTY_TO_CALCULATE_COMMISSION * $productPrice;
        $commissionValue = $this->campaignCommissionCalculator->calculateCommissionAmount(
            $campaignId,
            self::QTY_TO_CALCULATE_COMMISSION,
            $amount
        );

        $formattedCommissionValue = $this->priceValueFormatter->getFormattedValueByCurrencyCode(
            $commissionValue,
            $productRender->getCurrencyCode()
        );

        $extensionAttributes->setAwAffFormattedCommissionValue($formattedCommissionValue);
        $productRender->setExtensionAttributes($extensionAttributes);
    }

    /**
     * Retrieve product price for commission calculation
     *
     * @param ProductInterface $product
     * @return float
     */
    private function getProductPrice($product)
    {
        try {
            $productPrice = $product
                ->getPriceInfo()
                ->getPrice('final_price')
                ->getMinimalPrice()
                ->getValue();
        } catch (\Exception $exception) {
            $productPrice = 0.0;
        }
        return $productPrice;
    }
}
