<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Account;

use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterfaceFactory;
use Aheadworks\Affiliate\Api\AccountManagementInterface;
use Aheadworks\Affiliate\Model\Source\Account\Status;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Backend\App\Action;

/**
 * Class Save
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Account
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Save extends Action
{
    /**
     * {@inheritdoc}
     */
    const ADMIN_RESOURCE = 'Aheadworks_Affiliate::accounts';

    /**
     * @var AccountInterfaceFactory
     */
    private $accountDataFactory;

    /**
     * @var DataObjectHelper
     */
    private $dataObjectHelper;

    /**
     * @var DataPersistorInterface
     */
    private $dataPersistor;

    /**
     * @var AccountManagementInterface
     */
    private $accountService;

    /**
     * @param Context $context
     * @param AccountInterfaceFactory $accountDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataPersistorInterface $dataPersistor
     * @param AccountManagementInterface $accountService
     */
    public function __construct(
        Context $context,
        AccountInterfaceFactory $accountDataFactory,
        DataObjectHelper $dataObjectHelper,
        DataPersistorInterface $dataPersistor,
        AccountManagementInterface $accountService
    ) {
        parent::__construct($context);
        $this->accountDataFactory = $accountDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataPersistor = $dataPersistor;
        $this->accountService = $accountService;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($postData = $this->getRequest()->getPostValue()) {
            try {
                $this->validate($postData);
                $account = $this->performSave($postData);
                $this->dataPersistor->clear('aw_affiliate_account_form');
                $this->messageManager->addSuccessMessage(__('The affiliate account was successfully saved.'));
                $back = $this->getRequest()->getParam('back');
                if ($back == 'edit') {
                    return $resultRedirect->setPath(
                        '*/*/' . $back,
                        [
                            AccountInterface::ID => $account->getId(),
                            '_current' => true
                        ]
                    );
                }
                return $resultRedirect->setPath('*/*/');
            } catch (CouldNotSaveException $exception) {
                $this->messageManager->addErrorMessage($exception->getMessage());
            } catch (\Exception $exception) {
                $this->messageManager->addExceptionMessage(
                    $exception,
                    __('Something went wrong while saving the affiliate account.')
                );
            }
            $this->dataPersistor->set('aw_affiliate_account_form', $postData);
            if ($this->isAccountAlreadyExist($postData)) {
                return $resultRedirect->setPath(
                    '*/*/edit',
                    [AccountInterface::ID => $postData[AccountInterface::ID], '_current' => true]
                );
            }
            return $resultRedirect->setPath('*/*/new', ['_current' => true]);
        }
        return $resultRedirect->setPath('*/*/');
    }

    /**
     * Perform account save
     *
     * @param $postData
     * @return AccountInterface
     * @throws CouldNotSaveException
     * @throws NoSuchEntityException
     */
    private function performSave($postData)
    {
        $accountObject = $this->accountDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $accountObject,
            $postData,
            AccountInterface::class
        );

        if ($this->isAccountAlreadyExist($postData)) {
            $savedAccount = $this->accountService->updateAccount($accountObject);
        } else {
            $savedAccount = $this->accountService->createAccount($accountObject);
        }

        return $savedAccount;
    }

    /**
     * Check if account already exists
     *
     * @param array $accountData
     * @return bool
     */
    private function isAccountAlreadyExist($accountData)
    {
        return isset($accountData[AccountInterface::ID])
            && !empty($accountData[AccountInterface::ID]);
    }

    /**
     * Validate
     *
     * @param array $postData
     * @throws CouldNotSaveException
     */
    private function validate($postData)
    {
        if (isset($postData[AccountInterface::STATUS])
            && $postData[AccountInterface::STATUS] == Status::DELETED
        ) {
            throw new CouldNotSaveException(
                __('Account data cannot be changed due to customer account has been deleted.')
            );
        }
    }
}
