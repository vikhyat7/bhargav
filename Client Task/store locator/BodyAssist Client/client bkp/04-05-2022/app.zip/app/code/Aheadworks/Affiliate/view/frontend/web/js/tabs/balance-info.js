define([
    'jquery',
    'uiComponent'
], function ($, Component) {
    'use strict';

    return Component.extend({
        defaults: {
            template: 'Aheadworks_Affiliate/tabs/balance-info',
            imports: {
                balanceInfo: '${ $.balanceProvider }:data'
            }
        }
    });
});