<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Account;

use Aheadworks\Affiliate\Api\AccountRepositoryInterface;
use Aheadworks\Affiliate\Controller\AbstractPostCustomerAction;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Data\Form\FormKey\Validator as FormKeyValidator;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Store\Model\StoreManagerInterface;
use Aheadworks\Affiliate\Api\AccountManagementInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterface;

/**
 * Class SaveCouponPrefix
 * @package Aheadworks\Affiliate\Controller\Account
 */
class SaveCouponPrefix extends AbstractPostCustomerAction
{
    /**
     * @var JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var AccountManagementInterface
     */
    private $accountService;

    /**
     * @param Context $context
     * @param CustomerSession $customerSession
     * @param JsonFactory $resultJsonFactory
     * @param FormKeyValidator $formKeyValidator
     * @param StoreManagerInterface $storeManager
     * @param AccountRepositoryInterface $accountRepository
     * @param AccountManagementInterface $accountService
     */
    public function __construct(
        Context $context,
        CustomerSession $customerSession,
        JsonFactory $resultJsonFactory,
        FormKeyValidator $formKeyValidator,
        StoreManagerInterface $storeManager,
        AccountRepositoryInterface $accountRepository,
        AccountManagementInterface $accountService
    ) {
        parent::__construct($context, $customerSession, $formKeyValidator, $storeManager, $accountRepository);
        $this->resultJsonFactory = $resultJsonFactory;
        $this->accountService = $accountService;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        $data = [];
        $couponPrefix = $this->getCouponPrefix();
        if (!empty($couponPrefix)) {
            try {
                $this->validate();
                $account = $this->getAffiliateAccount();
                $account->setUniqueCouponPrefix($couponPrefix);
                $this->accountService->updateAccount($account);
                $this->messageManager->addSuccessMessage(__('Identifier was successfully saved.'));
            } catch (LocalizedException $e) {
                $data['error'] = $e->getMessage();
            } catch (\Exception $e) {
                $data['error'] = $e->getMessage();
            }
        } else {
            $data['error'] = __('No data provided to save.');
        }

        return $this->resultJsonFactory->create()->setData($data);
    }

    /**
     * Retrieve coupon prefix
     *
     * @return string
     */
    private function getCouponPrefix()
    {
        return trim($this->getRequest()->getParam(AccountInterface::UNIQUE_COUPON_PREFIX, ''));
    }
}
