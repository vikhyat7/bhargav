<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Cron;

use Aheadworks\Affiliate\Model\Config;
use Aheadworks\Affiliate\Model\Payout\AutoGenerator as PayoutAutoGenerator;
use Magento\Framework\Stdlib\DateTime\DateTime;

/**
 * Class PayoutGeneration
 * @package Aheadworks\Affiliate\Cron
 */
class PayoutGeneration extends CronAbstract
{
    const SECONDS_IN_DAY = 86400;

    /**
     * @var PayoutAutoGenerator
     */
    private $payoutAutoGenerator;

    /**
     * @param Config $config
     * @param DateTime $dateTime
     * @param PayoutAutoGenerator $payoutAutoGenerator
     */
    public function __construct(
        Config $config,
        DateTime $dateTime,
        PayoutAutoGenerator $payoutAutoGenerator
    ) {
        parent::__construct($config, $dateTime);
        $this->payoutAutoGenerator = $payoutAutoGenerator;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        if (!$this->isNeedToGeneratePayouts()) {
            return $this;
        }

        $this->payoutAutoGenerator->generatePayoutsForAffiliates();
        $this->config->setCronPayoutGenerationLastExecTime($this->getCurrentTime());

        return $this;
    }

    /**
     * Check is need to generate payouts
     *
     * @return bool
     */
    private function isNeedToGeneratePayouts()
    {
        return $this->config->isPayoutAutoGenerationEnabled()
            && !$this->isLocked($this->config->getCronPayoutGenerationLastExecTime(), $this->getRunInterval());
    }

    /**
     * Get run interval
     *
     * @return int
     */
    private function getRunInterval()
    {
        $configIntervalDays = $this->config->getPayoutCreationPeriodInDays();

        return $configIntervalDays * self::SECONDS_IN_DAY - self::INTERVAL_BETWEEN_JOBS;
    }
}
