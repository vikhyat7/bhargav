<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Observer\Magento\SalesRule;

use PHPUnit\Framework\TestCase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Aheadworks\Affiliate\Observer\Magento\SalesRule\DeleteCoupons;
use Magento\Framework\Event;
use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Magento\Framework\Event\Observer;
use Aheadworks\Affiliate\Model\CouponManager;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Test for \Aheadworks\Affiliate\Observer\Magento\SalesRule\DeleteCoupons
 */
class DeleteCouponsTest extends TestCase
{
    /**
     * @var DeleteCoupons
     */
    private $model;

    /**
     * @var CouponManager|\PHPUnit_Framework_MockObject_MockObject
     */
    private $couponManagerMock;

    /**
     * Init mocks for tests
     *
     * @return void
     */
    public function setUp() : void
    {
        $objectManager = new ObjectManager($this);

        $this->couponManagerMock = $this->createMock(CouponManager::class);

        $this->model = $objectManager->getObject(
            DeleteCoupons::class,
            [
                'couponManager' => $this->couponManagerMock
            ]
        );
    }

    /**
     * Test for execute() with wrong entity
     */
    public function testExecuteWrongEntity()
    {
        $campaignMock = null;
        $eventMock = $this->createMock(Event::class);
        $eventMock->expects($this->once())
            ->method('__call')
            ->with('getEntity')
            ->willReturn($campaignMock);

        $observerMock = $this->createMock(Observer::class);
        $observerMock->expects($this->once())
            ->method('getEvent')
            ->willReturn($eventMock);

        $this->couponManagerMock->expects($this->never())
            ->method('deleteCouponsByCampaign');

        $this->model->execute($observerMock);
    }

    /**
     * Test for execute()
     */
    public function testExecute()
    {
        $campaignMock = $this->createMock(CampaignInterface::class);
        $eventMock = $this->createMock(Event::class);
        $eventMock->expects($this->once())
            ->method('__call')
            ->with('getEntity')
            ->willReturn($campaignMock);

        $observerMock = $this->createMock(Observer::class);
        $observerMock->expects($this->once())
            ->method('getEvent')
            ->willReturn($eventMock);

        $this->couponManagerMock->expects($this->once())
            ->method('deleteCouponsByCampaign')
            ->with($campaignMock);

        $this->model->execute($observerMock);
    }

    /**
     * Test for execute() with localized exception
     *
     * @expectedException \Magento\Framework\Exception\LocalizedException
     * @expectedExceptionMessage Error!
     */
    public function testExecuteLocalizedException()
    {
        $campaignMock = $this->createMock(CampaignInterface::class);
        $eventMock = $this->createMock(Event::class);
        $eventMock->expects($this->once())
            ->method('__call')
            ->with('getEntity')
            ->willReturn($campaignMock);

        $observerMock = $this->createMock(Observer::class);
        $observerMock->expects($this->once())
            ->method('getEvent')
            ->willReturn($eventMock);

        $this->couponManagerMock->expects($this->once())
            ->method('deleteCouponsByCampaign')
            ->with($campaignMock)
            ->willThrowException(new LocalizedException(__('Error!')));
        $this->expectException(LocalizedException::class);
        $this->model->execute($observerMock);
    }

    /**
     * Test for execute() with localized exception
     *
     * @expectedException \Magento\Framework\Exception\NoSuchEntityException
     * @expectedExceptionMessage Error!
     */
    public function testExecuteNoSuchEntityException()
    {
        $campaignMock = $this->createMock(CampaignInterface::class);
        $eventMock = $this->createMock(Event::class);
        $eventMock->expects($this->once())
            ->method('__call')
            ->with('getEntity')
            ->willReturn($campaignMock);

        $observerMock = $this->createMock(Observer::class);
        $observerMock->expects($this->once())
            ->method('getEvent')
            ->willReturn($eventMock);

        $this->couponManagerMock->expects($this->once())
            ->method('deleteCouponsByCampaign')
            ->with($campaignMock)
            ->willThrowException(new NoSuchEntityException(__('Error!')));
        $this->expectException(LocalizedException::class);
        $this->model->execute($observerMock);
    }
}
