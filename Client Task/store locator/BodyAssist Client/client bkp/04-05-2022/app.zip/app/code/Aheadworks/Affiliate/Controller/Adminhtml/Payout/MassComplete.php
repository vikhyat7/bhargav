<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Payout;

use Aheadworks\Affiliate\Model\Source\Payout\Status;

/**
 * Class MassComplete
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Payout
 */
class MassComplete extends AbstractMassChangeStatus
{
    /**
     * {@inheritdoc}
     */
    protected function updateStatus($payoutId)
    {
        $this->payoutManagement->completePayout($payoutId);
    }

    /**
     * {@inheritdoc}
     */
    protected function getStatusToSet()
    {
        return Status::COMPLETE;
    }

    /**
     * {@inheritdoc}
     */
    protected function getSuccessMessage($changedRecordsCounter)
    {
        return __('A total of %1 payout(s) were changed status to "Complete".', $changedRecordsCounter);
    }
}
