<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Model;

use Aheadworks\Affiliate\Api\Data\PayoutInterface;
use Aheadworks\Affiliate\Api\Data\PayoutInterfaceFactory;
use Aheadworks\Affiliate\Api\Data\PayoutSearchResultsInterface;
use Aheadworks\Affiliate\Api\Data\PayoutSearchResultsInterfaceFactory;
use Aheadworks\Affiliate\Model\Payout as PayoutModel;
use Aheadworks\Affiliate\Model\ResourceModel\Payout as PayoutResourceModel;
use Aheadworks\Affiliate\Model\ResourceModel\Payout\Collection as PayoutCollection;
use Aheadworks\Affiliate\Model\ResourceModel\Payout\CollectionFactory as PayoutCollectionFactory;
use Aheadworks\Affiliate\Model\Payout;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Aheadworks\Affiliate\Model\PayoutRepository;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;

/**
 * Class PayoutRepositoryTest
 *
 * @package Aheadworks\Affiliate\Test\Unit\Model
 */
class PayoutRepositoryTest extends TestCase
{
    /**
     * @var PayoutResourceModel|\PHPUnit_Framework_MockObject_MockObject
     */
    private $resourceMock;

    /**
     * @var PayoutInterfaceFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $payoutInterfaceFactoryMock;

    /**
     * @var PayoutCollectionFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $payoutCollectionFactoryMock;

    /**
     * @var PayoutSearchResultsInterfaceFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $searchResultsFactoryMock;

    /**
     * @var JoinProcessorInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $extensionAttributesJoinProcessorMock;

    /**
     * @var CollectionProcessorInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $collectionProcessorMock;

    /**
     * @var DataObjectHelper|\PHPUnit_Framework_MockObject_MockObject
     */
    private $dataObjectHelperMock;

    /**
     * @var DataObjectProcessor|\PHPUnit_Framework_MockObject_MockObject
     */
    private $dataObjectProcessorMock;

    /**
     * @var PayoutRepository
     */
    private $payoutRepository;

    /**#@+
     * Constants used for tests
     */
    const DEFAULT_ID = 1;
    /**#@-*/

    /**
     * Init mocks for tests
     *
     * @return void
     */
    protected function setUp() : void
    {
        $objectManager = new ObjectManager($this);
        $this->resourceMock = $this->createMock(PayoutResourceModel::class);
        $this->payoutInterfaceFactoryMock = $this->createMock(PayoutInterfaceFactory::class);
        $this->payoutCollectionFactoryMock = $this->createMock(PayoutCollectionFactory::class);
        $this->searchResultsFactoryMock = $this->createMock(PayoutSearchResultsInterfaceFactory::class);
        $this->extensionAttributesJoinProcessorMock = $this->createMock(JoinProcessorInterface::class);
        $this->collectionProcessorMock = $this->createMock(CollectionProcessorInterface::class);
        $this->dataObjectHelperMock = $this->createMock(DataObjectHelper::class);
        $this->dataObjectProcessorMock = $this->createMock(DataObjectProcessor::class);
        $this->payoutRepository = $objectManager->getObject(
            PayoutRepository::class,
            [
                'resource' => $this->resourceMock,
                'payoutInterfaceFactory' => $this->payoutInterfaceFactoryMock,
                'payoutCollectionFactory' => $this->payoutCollectionFactoryMock,
                'searchResultsFactory' => $this->searchResultsFactoryMock,
                'extensionAttributesJoinProcessor' => $this->extensionAttributesJoinProcessorMock,
                'collectionProcessor' => $this->collectionProcessorMock,
                'dataObjectHelper' => $this->dataObjectHelperMock,
                'dataObjectProcessor' => $this->dataObjectProcessorMock
            ]
        );
    }

    /**
     * Test save method
     *
     * @throws CouldNotSaveException
     */
    public function testSave()
    {
        $payoutMock = $this->getPayoutMock(PayoutInterface::class);

        $this->resourceMock->expects($this->once())
            ->method('save')
            ->willReturnSelf();

        $this->assertSame($payoutMock, $this->payoutRepository->save($payoutMock));
    }

    /**
     * Test save method with exception
     *
     * @expectedException \Magento\Framework\Exception\CouldNotSaveException
     * @expectedExceptionMessage Test message
     * @throws CouldNotSaveException
     */
    public function testSaveWithException()
    {
        $exception = new \Exception('Test message');
        $payoutMock = $this->getPayoutMock();
        $this->resourceMock->expects($this->once())
            ->method('save')
            ->with($payoutMock)
            ->willThrowException($exception);
        $this->expectException(CouldNotSaveException::class);
        $this->payoutRepository->save($payoutMock);
    }

    /**
     * Test getById method
     *
     * @throws NoSuchEntityException
     */
    public function testGetById()
    {
        $payoutMock = $this->getPayoutMock();

        $this->payoutInterfaceFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($payoutMock);
        $this->resourceMock->expects($this->once())
            ->method('load')
            ->with($payoutMock, self::DEFAULT_ID)
            ->willReturnSelf();

        $this->assertSame($payoutMock, $this->payoutRepository->getById(self::DEFAULT_ID));
    }

    /**
     * Test getById method with exception
     *
     * @throws NoSuchEntityException
     * @expectedException \Magento\Framework\Exception\NoSuchEntityException
     * @expectedExceptionMessage No such entity with payout_id = 1
     */
    public function testGetByIdWithException()
    {
        $payoutMock = $this->getPayoutMock(null);

        $this->payoutInterfaceFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($payoutMock);
        $this->resourceMock->expects($this->once())
            ->method('load')
            ->with($payoutMock, self::DEFAULT_ID)
            ->willReturnSelf();
        $this->expectException(NoSuchEntityException::class);
        $this->assertSame($payoutMock, $this->payoutRepository->getById(self::DEFAULT_ID));
    }

    /**
     * Test getList method
     *
     * @param array $collectionItems
     * @param array $searchResultItems
     * @param PayoutModel|null|\PHPUnit_Framework_MockObject_MockObject $payoutModelMock
     * @dataProvider testGetListProvider
     */
    public function testGetList($collectionItems, $searchResultItems, $payoutModelMock = null)
    {
        /** @var SearchCriteriaInterface|\PHPUnit_Framework_MockObject_MockObject $searchCriteriaMock */
        $searchCriteriaMock = $this->createMock(SearchCriteriaInterface::class);
        $collectionSize = count($collectionItems);
        $payoutCollectionMock = $this->createMock(PayoutCollection::class);
        $searchResultsMock = $this->createMock(PayoutSearchResultsInterface::class);
        $payoutData = [PayoutInterface::ID => self::DEFAULT_ID];

        $this->payoutCollectionFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($payoutCollectionMock);
        $this->extensionAttributesJoinProcessorMock->expects($this->once())
            ->method('process')
            ->with($payoutCollectionMock, PayoutInterface::class);
        $this->collectionProcessorMock->expects($this->once())
            ->method('process')
            ->with($searchCriteriaMock, $payoutCollectionMock);
        $this->searchResultsFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($searchResultsMock);
        $searchResultsMock->expects($this->once())
            ->method('setSearchCriteria')
            ->with($searchCriteriaMock);
        $payoutCollectionMock->expects($this->once())
            ->method('getSize')
            ->willReturn($collectionSize);
        $searchResultsMock->expects($this->once())
            ->method('setTotalCount')
            ->with($collectionSize);
        $payoutCollectionMock->expects($this->once())
            ->method('getItems')
            ->willReturn($collectionItems);
        $this->payoutInterfaceFactoryMock->expects($this->exactly($collectionSize))
            ->method('create')
            ->willReturn($payoutModelMock);
        $this->dataObjectProcessorMock->expects($this->exactly($collectionSize))
            ->method('buildOutputDataArray')
            ->with($payoutModelMock, PayoutInterface::class)
            ->willReturn($payoutData);
        $this->dataObjectHelperMock->expects($this->exactly($collectionSize))
            ->method('populateWithArray')
            ->with($payoutModelMock, $payoutData, PayoutInterface::class);
        $searchResultsMock->expects($this->once())
            ->method('setItems')
            ->with($searchResultItems)
            ->willReturnSelf();

        $this->assertSame($searchResultsMock, $this->payoutRepository->getList($searchCriteriaMock));
    }

    /**
     * Get payout mock
     *
     * @param int|null $payoutId
     * @return PayoutModel|\PHPUnit_Framework_MockObject_MockObject
     */
    private function getPayoutMock($payoutId = self::DEFAULT_ID)
    {
        $payoutMock = $this->createMock(PayoutModel::class);

        $payoutMock->expects($this->atMost(1))
            ->method('getPayoutId')
            ->willReturn($payoutId);

        return $payoutMock;
    }

    /**
     * @return array
     */
    public function testGetListProvider()
    {
        $payoutModelMock = $this->createMock(PayoutModel::class);

        return [
            [[$payoutModelMock], [$payoutModelMock], $payoutModelMock],
            [[],[]]
        ];
    }
}
