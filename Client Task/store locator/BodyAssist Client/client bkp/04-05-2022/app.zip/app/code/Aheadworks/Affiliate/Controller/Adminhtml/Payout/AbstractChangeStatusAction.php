<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Payout;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Aheadworks\Affiliate\Api\PayoutManagementInterface;
use Aheadworks\Affiliate\Api\Data\PayoutInterface;
use Magento\Framework\Exception\LocalizedException;

/**
 * Class AbstractChangeStatusAction
 *
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Payout
 */
abstract class AbstractChangeStatusAction extends Action
{
    /**
     * {@inheritdoc}
     */
    const ADMIN_RESOURCE = 'Aheadworks_Affiliate::payouts';

    /**
     * @var PayoutManagementInterface
     */
    protected $payoutService;

    /**
     * @param Context $context
     * @param PayoutManagementInterface $payoutService
     */
    public function __construct(
        Context $context,
        PayoutManagementInterface $payoutService
    ) {
        parent::__construct($context);
        $this->payoutService = $payoutService;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($payoutId = $this->getRequest()->getParam(PayoutInterface::ID, false)) {
            try {
                /** @var PayoutInterface $payout */
                $this->updateStatus($payoutId);
                $this->messageManager->addSuccessMessage($this->getSuccessMessage());
                return $resultRedirect->setPath('*/*/');
            } catch (LocalizedException $exception) {
                $this->messageManager->addErrorMessage($exception->getMessage());
            } catch (\Exception $exception) {
                $this->messageManager->addExceptionMessage(
                    $exception,
                    $this->getErrorMessage()
                );
            }
        }
        return $resultRedirect->setPath('*/*/');
    }

    /**
     * Retrieve error message
     *
     * @return string
     */
    private function getErrorMessage()
    {
        return __('Something went wrong while changing status.');
    }

    /**
     * Update status
     *
     * @param int $payoutId
     * @throws LocalizedException
     */
    abstract protected function updateStatus($payoutId);

    /**
     * Retrieve success message
     *
     * @return string
     */
    abstract protected function getSuccessMessage();
}
