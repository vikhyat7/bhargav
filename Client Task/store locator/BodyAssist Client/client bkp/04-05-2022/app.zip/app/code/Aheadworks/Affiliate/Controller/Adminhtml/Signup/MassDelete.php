<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Signup;

use Aheadworks\Affiliate\Api\Data\SignupInterface;
use Magento\Framework\Exception\CouldNotDeleteException;

/**
 * Class MassDelete
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Signup
 */
class MassDelete extends AbstractMassAction
{
    /**
     * Delete signup requests
     *
     * @param SignupInterface[] $signups
     */
    protected function massAction($signups)
    {
        $deletedRecords = 0;
        /** @var SignupInterface $item */
        foreach ($signups as $item) {
            try {
                $this->signupManagement->deleteSignup($item);
                $deletedRecords++;
            } catch (CouldNotDeleteException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            }
        }
        if ($deletedRecords) {
            $this->messageManager->addSuccessMessage(__('A total of %1 record(s) were deleted.', $deletedRecords));
        } else {
            $this->messageManager->addSuccessMessage(__('No records were deleted.'));
        }
    }
}
