<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Model;

use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterfaceFactory;
use Aheadworks\Affiliate\Api\Data\AccountSearchResultsInterface;
use Aheadworks\Affiliate\Api\Data\AccountSearchResultsInterfaceFactory;
use Aheadworks\Affiliate\Model\Account as AccountModel;
use Aheadworks\Affiliate\Model\ResourceModel\Account as AccountResourceModel;
use Aheadworks\Affiliate\Model\ResourceModel\Account\Collection as AccountCollection;
use Aheadworks\Affiliate\Model\ResourceModel\Account\CollectionFactory as AccountCollectionFactory;
use Aheadworks\Affiliate\Model\Account;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Aheadworks\Affiliate\Model\AccountRepository;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;

/**
 * Class AccountRepositoryTest
 *
 * @package Aheadworks\Affiliate\Test\Unit\Model
 */
class AccountRepositoryTest extends TestCase
{
    /**
     * @var AccountResourceModel|\PHPUnit_Framework_MockObject_MockObject
     */
    private $resourceMock;

    /**
     * @var AccountInterfaceFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $accountInterfaceFactoryMock;

    /**
     * @var AccountCollectionFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $accountCollectionFactoryMock;

    /**
     * @var AccountSearchResultsInterfaceFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $searchResultsFactoryMock;

    /**
     * @var JoinProcessorInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $extensionAttributesJoinProcessorMock;

    /**
     * @var CollectionProcessorInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $collectionProcessorMock;

    /**
     * @var DataObjectHelper|\PHPUnit_Framework_MockObject_MockObject
     */
    private $dataObjectHelperMock;

    /**
     * @var DataObjectProcessor|\PHPUnit_Framework_MockObject_MockObject
     */
    private $dataObjectProcessorMock;

    /**
     * @var AccountRepository
     */
    private $accountRepository;

    /**#@+
     * Constants used for tests
     */
    const DEFAULT_ID = 1;
    /**#@-*/

    /**
     * Init mocks for tests
     *
     * @return void
     */
    protected function setUp() : void
    {
        $objectManager = new ObjectManager($this);
        $this->resourceMock = $this->createMock(AccountResourceModel::class);
        $this->accountInterfaceFactoryMock = $this->createMock(AccountInterfaceFactory::class);
        $this->accountCollectionFactoryMock = $this->createMock(AccountCollectionFactory::class);
        $this->searchResultsFactoryMock = $this->createMock(AccountSearchResultsInterfaceFactory::class);
        $this->extensionAttributesJoinProcessorMock = $this->createMock(JoinProcessorInterface::class);
        $this->collectionProcessorMock = $this->createMock(CollectionProcessorInterface::class);
        $this->dataObjectHelperMock = $this->createMock(DataObjectHelper::class);
        $this->dataObjectProcessorMock = $this->createMock(DataObjectProcessor::class);
        $this->accountRepository = $objectManager->getObject(
            AccountRepository::class,
            [
                'resource' => $this->resourceMock,
                'accountInterfaceFactory' => $this->accountInterfaceFactoryMock,
                'accountCollectionFactory' => $this->accountCollectionFactoryMock,
                'searchResultsFactory' => $this->searchResultsFactoryMock,
                'extensionAttributesJoinProcessor' => $this->extensionAttributesJoinProcessorMock,
                'collectionProcessor' => $this->collectionProcessorMock,
                'dataObjectHelper' => $this->dataObjectHelperMock,
                'dataObjectProcessor' => $this->dataObjectProcessorMock
            ]
        );
    }

    /**
     * Test save method
     *
     * @throws CouldNotSaveException
     */
    public function testSave()
    {
        $accountMock = $this->getAccountMock(AccountInterface::class);

        $this->resourceMock->expects($this->once())
            ->method('save')
            ->willReturnSelf();

        $this->assertSame($accountMock, $this->accountRepository->save($accountMock));
    }

    /**
     * Test save method with exception
     *
     * @expectedException \Magento\Framework\Exception\CouldNotSaveException
     * @expectedExceptionMessage Test message
     * @throws CouldNotSaveException
     */
    public function testSaveWithException()
    {
        $exception = new \Exception('Test message');
        $accountMock = $this->getAccountMock();
        $this->resourceMock->expects($this->once())
            ->method('save')
            ->with($accountMock)
            ->willThrowException($exception);
        $this->expectException(CouldNotSaveException::class);
        $this->accountRepository->save($accountMock);
    }

    /**
     * Test getById method
     *
     * @throws NoSuchEntityException
     */
    public function testGetById()
    {
        $accountMock = $this->getAccountMock();

        $this->accountInterfaceFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($accountMock);
        $this->resourceMock->expects($this->once())
            ->method('load')
            ->with($accountMock, self::DEFAULT_ID)
            ->willReturnSelf();

        $this->assertSame($accountMock, $this->accountRepository->getById(self::DEFAULT_ID));
    }

    /**
     * Test getById method with exception
     *
     * @throws NoSuchEntityException
     * @expectedException \Magento\Framework\Exception\NoSuchEntityException
     * @expectedExceptionMessage No such entity with account_id = 1
     */
    public function testGetByIdWithException()
    {
        $accountMock = $this->getAccountMock(null);

        $this->accountInterfaceFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($accountMock);
        $this->resourceMock->expects($this->once())
            ->method('load')
            ->with($accountMock, self::DEFAULT_ID)
            ->willReturnSelf();
        $this->expectException(NoSuchEntityException::class);
        $this->assertSame($accountMock, $this->accountRepository->getById(self::DEFAULT_ID));
    }

    /**
     * Test getByCustomerId method
     *
     * @throws NoSuchEntityException
     */
    public function testGetByCustomerId()
    {
        $customerId = self::DEFAULT_ID;
        $websiteId = 1;
        $accountMock = $this->getAccountMock();

        $this->resourceMock->expects($this->once())
            ->method('getAccountIdByCustomerId')
            ->with($customerId, $websiteId)
            ->willReturn(self::DEFAULT_ID);
        $this->accountInterfaceFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($accountMock);
        $this->resourceMock->expects($this->once())
            ->method('load')
            ->with($accountMock, self::DEFAULT_ID)
            ->willReturnSelf();

        $this->assertSame($accountMock, $this->accountRepository->getByCustomerId($customerId, $websiteId));
    }

    /**
     * Test getByCustomerId method with exception
     *
     * @throws NoSuchEntityException
     * @expectedException \Magento\Framework\Exception\NoSuchEntityException
     * @expectedExceptionMessage No such entity with customer_id = 1
     */
    public function testGetByCustomerIdWithException()
    {
        $customerId = self::DEFAULT_ID;
        $websiteId = 1;
        $accountMock = $this->getAccountMock(null);

        $this->resourceMock->expects($this->once())
            ->method('getAccountIdByCustomerId')
            ->with($customerId, $websiteId)
            ->willReturn(null);
        $this->accountInterfaceFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($accountMock);
        $this->resourceMock->expects($this->once())
            ->method('load')
            ->with($accountMock, null)
            ->willReturnSelf();
        $this->expectException(NoSuchEntityException::class);
        $this->assertSame($accountMock, $this->accountRepository->getByCustomerId($customerId, $websiteId));
    }

    /**
     * Test getList method
     *
     * @param array $collectionItems
     * @param array $searchResultItems
     * @param AccountModel|null|\PHPUnit_Framework_MockObject_MockObject $accountModelMock
     * @dataProvider testGetListProvider
     */
    public function testGetList($collectionItems, $searchResultItems, $accountModelMock = null)
    {
        /** @var SearchCriteriaInterface|\PHPUnit_Framework_MockObject_MockObject $searchCriteriaMock */
        $searchCriteriaMock = $this->createMock(SearchCriteriaInterface::class);
        $collectionSize = count($collectionItems);
        $accountCollectionMock = $this->createMock(AccountCollection::class);
        $searchResultsMock = $this->createMock(AccountSearchResultsInterface::class);
        $accountData = [AccountInterface::ID => self::DEFAULT_ID];

        $this->accountCollectionFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($accountCollectionMock);
        $this->extensionAttributesJoinProcessorMock->expects($this->once())
            ->method('process')
            ->with($accountCollectionMock, AccountInterface::class);
        $this->collectionProcessorMock->expects($this->once())
            ->method('process')
            ->with($searchCriteriaMock, $accountCollectionMock);
        $this->searchResultsFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($searchResultsMock);
        $searchResultsMock->expects($this->once())
            ->method('setSearchCriteria')
            ->with($searchCriteriaMock);
        $accountCollectionMock->expects($this->once())
            ->method('getSize')
            ->willReturn($collectionSize);
        $searchResultsMock->expects($this->once())
            ->method('setTotalCount')
            ->with($collectionSize);
        $accountCollectionMock->expects($this->once())
            ->method('getItems')
            ->willReturn($collectionItems);
        $this->accountInterfaceFactoryMock->expects($this->exactly($collectionSize))
            ->method('create')
            ->willReturn($accountModelMock);
        $this->dataObjectProcessorMock->expects($this->exactly($collectionSize))
            ->method('buildOutputDataArray')
            ->with($accountModelMock, AccountInterface::class)
            ->willReturn($accountData);
        $this->dataObjectHelperMock->expects($this->exactly($collectionSize))
            ->method('populateWithArray')
            ->with($accountModelMock, $accountData, AccountInterface::class);
        $searchResultsMock->expects($this->once())
            ->method('setItems')
            ->with($searchResultItems)
            ->willReturnSelf();

        $this->assertSame($searchResultsMock, $this->accountRepository->getList($searchCriteriaMock));
    }

    /**
     * Test getAffiliateIdsToPayout method
     *
     * @param array $result
     * @dataProvider testGetAffiliateIdsToPayoutProvider
     */
    public function testGetAffiliateIdsToPayout($result)
    {
        $this->resourceMock->expects($this->once())
            ->method('getAffiliateIdsToPayout')
            ->willReturn($result);

        $this->assertEquals($result, $this->accountRepository->getAffiliateIdsToPayout());
    }

    /**
     * Get account mock
     *
     * @param int|null $accountId
     * @return AccountModel|\PHPUnit_Framework_MockObject_MockObject
     */
    private function getAccountMock($accountId = self::DEFAULT_ID)
    {
        $accountMock = $this->createMock(AccountModel::class);

        $accountMock->expects($this->atMost(1))
            ->method('getAccountId')
            ->willReturn($accountId);

        return $accountMock;
    }

    /**
     * @return array
     */
    public function testGetListProvider()
    {
        $accountModelMock = $this->createMock(AccountModel::class);

        return [
            [[$accountModelMock], [$accountModelMock], $accountModelMock],
            [[],[]]
        ];
    }

    /**
     * @return array
     */
    public function testGetAffiliateIdsToPayoutProvider()
    {
        return [
            [[self::DEFAULT_ID]],
            [[]]
        ];
    }
}
