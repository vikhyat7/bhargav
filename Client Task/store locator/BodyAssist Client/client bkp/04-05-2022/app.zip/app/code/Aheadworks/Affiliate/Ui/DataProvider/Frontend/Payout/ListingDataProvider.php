<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Ui\DataProvider\Frontend\Payout;

use Aheadworks\Affiliate\Api\AccountRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\PayoutInterface;
use Aheadworks\Affiliate\Ui\DataProvider\Frontend\AbstractDataProvider;
use Aheadworks\Affiliate\Model\ResourceModel\Payout\Collection;
use Aheadworks\Affiliate\Model\ResourceModel\Payout\CollectionFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Customer\Model\Session as CustomerSession;

/**
 * Class ListingDataProvider
 * @package Aheadworks\Affiliate\Ui\DataProvider\Frontend\Payout
 */
class ListingDataProvider extends AbstractDataProvider
{
    /**
     * @var Collection
     */
    protected $collection;

    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param StoreManagerInterface $storeManager
     * @param CustomerSession $customerSession
     * @param AccountRepositoryInterface $accountRepository
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        StoreManagerInterface $storeManager,
        CustomerSession $customerSession,
        CollectionFactory $collectionFactory,
        AccountRepositoryInterface $accountRepository,
        array $meta = [],
        array $data = []
    ) {
        parent::__construct(
            $name,
            $primaryFieldName,
            $requestFieldName,
            $storeManager,
            $customerSession,
            $accountRepository,
            $meta,
            $data
        );
        $this->collection = $collectionFactory->create();
    }

    /**
     * {@inheritdoc}
     */
    protected function applyDefaultFilters()
    {
        $this->getCollection()
            ->addFieldToFilter(PayoutInterface::AFFILIATE_ID, $this->getAffiliateAccountId());
    }

    /**
     * {@inheritdoc}
     */
    protected function applyDefaultSorting()
    {
        $this->getCollection()->setOrder(PayoutInterface::CREATED_AT);
    }
}
