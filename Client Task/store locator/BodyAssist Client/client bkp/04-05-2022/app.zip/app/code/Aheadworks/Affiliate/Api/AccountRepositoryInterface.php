<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Api;

/**
 * Interface AccountRepositoryInterface
 *
 * @package Aheadworks\Affiliate\Api
 */
interface AccountRepositoryInterface
{
    /**
     * Save account
     *
     * @param \Aheadworks\Affiliate\Api\Data\AccountInterface $account
     * @return \Aheadworks\Affiliate\Api\Data\AccountInterface $account
     * @throws \Magento\Framework\Exception\CouldNotSaveException
     */
    public function save(\Aheadworks\Affiliate\Api\Data\AccountInterface $account);

    /**
     * Retrieve account by id
     *
     * @param int $accountId
     * @return \Aheadworks\Affiliate\Api\Data\AccountInterface
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getById($accountId);

    /**
     * Retrieve account by customer id
     *
     * @param int $customerId
     * @param int $websiteId
     * @return \Aheadworks\Affiliate\Api\Data\AccountInterface
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getByCustomerId($customerId, $websiteId);

    /**
     * Retrieve accounts matching the specified criteria
     *
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Aheadworks\Affiliate\Api\Data\AccountSearchResultsInterface
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria);

    /**
     * Retrieve affiliate ids to payout
     *
     * @return array
     */
    public function getAffiliateIdsToPayout();
}
