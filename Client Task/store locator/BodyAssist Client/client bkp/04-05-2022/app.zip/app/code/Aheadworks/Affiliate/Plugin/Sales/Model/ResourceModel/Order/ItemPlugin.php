<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Plugin\Sales\Model\ResourceModel\Order;

use Psr\Log\LoggerInterface;
use Magento\Sales\Model\ResourceModel\Order\Item as OrderItemResourceModel;
use Magento\Sales\Model\Order\Item as OrderItem;
use Aheadworks\Affiliate\Api\TransactionCreationManagementInterface;
use Aheadworks\Affiliate\Api\TransactionHoldingPeriodManagementInterface;
use Aheadworks\Affiliate\Api\BoundCustomerManagementInterface;

/**
 * Class ItemPlugin
 *
 * @package Aheadworks\Affiliate\Plugin\Sales\Model\ResourceModel\Order
 */
class ItemPlugin
{
    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var TransactionCreationManagementInterface
     */
    private $transactionCreationService;

    /**
     * @var TransactionHoldingPeriodManagementInterface
     */
    private $transactionHoldingPeriodService;

    /**
     * @var BoundCustomerManagementInterface
     */
    private $boundCustomerService;

    /**
     * @param LoggerInterface $logger
     * @param TransactionCreationManagementInterface $transactionCreationService
     * @param TransactionHoldingPeriodManagementInterface $transactionHoldingPeriodService
     * @param BoundCustomerManagementInterface $boundCustomerService
     */
    public function __construct(
        LoggerInterface $logger,
        TransactionCreationManagementInterface $transactionCreationService,
        TransactionHoldingPeriodManagementInterface $transactionHoldingPeriodService,
        BoundCustomerManagementInterface $boundCustomerService
    ) {
        $this->logger = $logger;
        $this->transactionCreationService = $transactionCreationService;
        $this->transactionHoldingPeriodService = $transactionHoldingPeriodService;
        $this->boundCustomerService = $boundCustomerService;
    }

    /**
     * @param OrderItemResourceModel $subject
     * @param OrderItemResourceModel $result
     * @param OrderItem $object
     * @return OrderItemResourceModel
     */
    public function afterSave(
        OrderItemResourceModel $subject,
        OrderItemResourceModel $result,
        OrderItem $object
    ) {
        try {
            $this->transactionCreationService->createTransactionByOrderItem($object);
        } catch (\Exception $e) {
            $this->logger->error($e);
        }
        try {
            $this->boundCustomerService->addBoundCustomer($object);
        } catch (\Exception $e) {
            $this->logger->error($e);
        }
        try {
            $this->transactionHoldingPeriodService->processUnexpiredTransactionsByOrderItem($object);
        } catch (\Exception $e) {
            $this->logger->error($e);
        }
        return $result;
    }
}
