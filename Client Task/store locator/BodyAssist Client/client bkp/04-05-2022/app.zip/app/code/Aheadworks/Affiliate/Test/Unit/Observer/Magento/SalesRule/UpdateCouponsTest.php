<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Observer\Magento\SalesRule;

use PHPUnit\Framework\TestCase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Aheadworks\Affiliate\Observer\Magento\SalesRule\UpdateCoupons;
use Magento\Framework\Event;
use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Magento\Framework\Event\Observer;
use Aheadworks\Affiliate\Model\CouponManager;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\InputException;

/**
 * Test for \Aheadworks\Affiliate\Observer\Magento\SalesRule\UpdateCoupons
 */
class UpdateCouponsTest extends TestCase
{
    /**
     * @var UpdateCoupons
     */
    private $model;

    /**
     * @var CouponManager|\PHPUnit_Framework_MockObject_MockObject
     */
    private $couponManagerMock;

    /**
     * Init mocks for tests
     *
     * @return void
     */
    public function setUp() : void
    {
        $objectManager = new ObjectManager($this);

        $this->couponManagerMock = $this->createMock(CouponManager::class);

        $this->model = $objectManager->getObject(
            UpdateCoupons::class,
            [
                'couponManager' => $this->couponManagerMock
            ]
        );
    }

    /**
     * Test for execute() with wrong entity
     */
    public function testExecuteWrongEntity()
    {
        $campaignMock = null;
        $eventMock = $this->createMock(Event::class);
        $eventMock->expects($this->once())
            ->method('__call')
            ->with('getEntity')
            ->willReturn($campaignMock);

        $observerMock = $this->createMock(Observer::class);
        $observerMock->expects($this->once())
            ->method('getEvent')
            ->willReturn($eventMock);

        $this->couponManagerMock->expects($this->never())
            ->method('updateCoupons');

        $this->model->execute($observerMock);
    }

    /**
     * Test for execute()
     */
    public function testExecute()
    {
        $campaignMock = $this->createMock(CampaignInterface::class);
        $eventMock = $this->createMock(Event::class);
        $eventMock->expects($this->once())
            ->method('__call')
            ->with('getEntity')
            ->willReturn($campaignMock);

        $observerMock = $this->createMock(Observer::class);
        $observerMock->expects($this->once())
            ->method('getEvent')
            ->willReturn($eventMock);

        $this->couponManagerMock->expects($this->once())
            ->method('updateCoupons')
            ->with($campaignMock);

        $this->model->execute($observerMock);
    }

    /**
     * Test for execute() with localized exception
     *
     * @expectedException \Magento\Framework\Exception\LocalizedException
     * @expectedExceptionMessage Error!
     */
    public function testExecuteLocalizedException()
    {
        $campaignMock = $this->createMock(CampaignInterface::class);
        $eventMock = $this->createMock(Event::class);
        $eventMock->expects($this->once())
            ->method('__call')
            ->with('getEntity')
            ->willReturn($campaignMock);

        $observerMock = $this->createMock(Observer::class);
        $observerMock->expects($this->once())
            ->method('getEvent')
            ->willReturn($eventMock);

        $this->couponManagerMock->expects($this->once())
            ->method('updateCoupons')
            ->with($campaignMock)
            ->willThrowException(new LocalizedException(__('Error!')));
        $this->expectException(LocalizedException::class);
        $this->model->execute($observerMock);
    }

    /**
     * Test for execute() with localized exception
     *
     * @expectedException \Magento\Framework\Exception\NoSuchEntityException
     * @expectedExceptionMessage Error!
     */
    public function testExecuteNoSuchEntityException()
    {
        $campaignMock = $this->createMock(CampaignInterface::class);
        $eventMock = $this->createMock(Event::class);
        $eventMock->expects($this->once())
            ->method('__call')
            ->with('getEntity')
            ->willReturn($campaignMock);

        $observerMock = $this->createMock(Observer::class);
        $observerMock->expects($this->once())
            ->method('getEvent')
            ->willReturn($eventMock);

        $this->couponManagerMock->expects($this->once())
            ->method('updateCoupons')
            ->with($campaignMock)
            ->willThrowException(new NoSuchEntityException(__('Error!')));
        $this->expectException(NoSuchEntityException::class);
        $this->model->execute($observerMock);
    }

    /**
     * Test for execute() with input exception
     *
     * @expectedException \Magento\Framework\Exception\InputException
     * @expectedExceptionMessage Error!
     */
    public function testExecuteInputException()
    {
        $campaignMock = $this->createMock(CampaignInterface::class);
        $eventMock = $this->createMock(Event::class);
        $eventMock->expects($this->once())
            ->method('__call')
            ->with('getEntity')
            ->willReturn($campaignMock);

        $observerMock = $this->createMock(Observer::class);
        $observerMock->expects($this->once())
            ->method('getEvent')
            ->willReturn($eventMock);

        $this->couponManagerMock->expects($this->once())
            ->method('updateCoupons')
            ->with($campaignMock)
            ->willThrowException(new InputException(__('Error!')));
        $this->expectException(InputException::class);
        $this->model->execute($observerMock);
    }
}
