<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Signup;

use Magento\Backend\App\Action\Context;
use Aheadworks\Affiliate\Api\SignupRepositoryInterface;
use Aheadworks\Affiliate\Api\SignupManagementInterface;
use Aheadworks\Affiliate\Api\Data\SignupInterface;
use Aheadworks\Affiliate\Model\ResourceModel\Signup\CollectionFactory;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Ui\Component\MassAction\Filter;
use Magento\Framework\Exception\CouldNotSaveException;
use Aheadworks\Affiliate\Model\Signup\StatusResolver;

/**
 * Class AbstractMassChangeStatus
 *
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Signup
 */
abstract class AbstractMassChangeStatus extends AbstractMassAction
{
    /**
     * @var StatusResolver
     */
    protected $statusResolver;

    /**
     * @param Context $context
     * @param CollectionFactory $collectionFactory
     * @param SignupManagementInterface $signupManagement
     * @param SignupRepositoryInterface $signupRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param Filter $filter
     * @param StatusResolver $statusResolver
     */
    public function __construct(
        Context $context,
        CollectionFactory $collectionFactory,
        SignupManagementInterface $signupManagement,
        SignupRepositoryInterface $signupRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        Filter $filter,
        StatusResolver $statusResolver
    ) {
        $this->statusResolver = $statusResolver;
        parent::__construct(
            $context,
            $collectionFactory,
            $signupManagement,
            $signupRepository,
            $searchCriteriaBuilder,
            $filter
        );
    }

    /**
     * Change status for signups
     *
     * @param SignupInterface[] $signups
     */
    protected function massAction($signups)
    {
        $recordsCounter = 0;
        /** @var SignupInterface $item */
        foreach ($signups as $item) {
            try {
                if ($this->statusResolver->isStatusAllowedForSignup($this->getStatusToSet(), $item->getStatus())) {
                    $this->updateStatus($item->getSignupId());
                    $recordsCounter++;
                }
            } catch (CouldNotSaveException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            }
        }
        if ($recordsCounter) {
            $this->messageManager->addSuccessMessage($this->getSuccessMessage($recordsCounter));
        } else {
            $this->messageManager->addSuccessMessage($this->getMessageForNoChanges());
        }
    }

    /**
     * Update status
     *
     * @param int $signupId
     * @return int
     * @throws CouldNotSaveException
     */
    abstract protected function updateStatus($signupId);

    /**
     * Retrieve status id to set
     *
     * @return int
     */
    abstract protected function getStatusToSet();

    /**
     * Retrieve success message
     *
     * @param int $changedRecordsCounter
     * @return string
     */
    abstract protected function getSuccessMessage($changedRecordsCounter);

    /**
     * Retrieve error message
     *
     * @return string
     */
    abstract protected function getMessageForNoChanges();
}
