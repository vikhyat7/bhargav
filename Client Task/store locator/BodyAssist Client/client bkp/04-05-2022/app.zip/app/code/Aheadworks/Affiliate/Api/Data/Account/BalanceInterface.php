<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Api\Data\Account;

/**
 * Interface AccountBalanceInterface
 *
 * @package Aheadworks\Affiliate\Api\Data\Account
 */
interface BalanceInterface
{
    /**#@+
     * Constants defined for keys of the data array.
     * Identical to the name of the getter in snake case
     */
    const AFFILIATE_ID = 'affiliate_id';
    const PENDING_COMMISSIONS = 'pending_commissions';
    const AVAILABLE_COMMISSIONS = 'available_commissions';
    const PROCESSING_COMMISSIONS = 'processing_commissions';
    const PAID_COMMISSIONS = 'paid_commissions';
    /**#@-*/

    /**
     * Get affiliate id
     *
     * @return int
     */
    public function getAffiliateId();

    /**
     * Set affiliate id
     *
     * @param int $affiliateId
     * @return $this
     */
    public function setAffiliateId($affiliateId);

    /**
     * Get pending commissions
     *
     * @return float
     */
    public function getPendingCommissions();

    /**
     * Set pending commissions
     *
     * @param float $commissionsValue
     * @return $this
     */
    public function setPendingCommissions($commissionsValue);

    /**
     * Get available commissions
     *
     * @return float
     */
    public function getAvailableCommissions();

    /**
     * Set available commissions
     *
     * @param float $commissionsValue
     * @return $this
     */
    public function setAvailableCommissions($commissionsValue);

    /**
     * Get processing commissions
     *
     * @return float
     */
    public function getProcessingCommissions();

    /**
     * Set processing commissions
     *
     * @param float $commissionsValue
     * @return $this
     */
    public function setProcessingCommissions($commissionsValue);

    /**
     * Get paid commissions
     *
     * @return float
     */
    public function getPaidCommissions();

    /**
     * Set paid commissions
     *
     * @param float $commissionsValue
     * @return $this
     */
    public function setPaidCommissions($commissionsValue);
}
