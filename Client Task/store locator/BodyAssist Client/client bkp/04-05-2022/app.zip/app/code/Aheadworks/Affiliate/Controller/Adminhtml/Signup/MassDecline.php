<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Signup;

use Aheadworks\Affiliate\Model\Source\Signup\Status;

/**
 * Class MassDecline
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Signup
 */
class MassDecline extends AbstractMassChangeStatus
{
    /**
     * {@inheritdoc}
     */
    protected function updateStatus($signupId)
    {
        $this->signupManagement->declineSignup($signupId);
    }

    /**
     * {@inheritdoc}
     */
    protected function getStatusToSet()
    {
        return Status::DECLINED;
    }

    /**
     * {@inheritdoc}
     */
    protected function getSuccessMessage($changedRecordsCounter)
    {
        return __('A total of %1 signup request(s) were declined.', $changedRecordsCounter);
    }

    /**
     * {@inheritdoc}
     */
    protected function getMessageForNoChanges()
    {
        return __('No signup requests were declined.');
    }
}
