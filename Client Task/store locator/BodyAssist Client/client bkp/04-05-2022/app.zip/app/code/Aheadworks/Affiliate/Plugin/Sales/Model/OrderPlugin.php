<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Plugin\Sales\Model;

use Magento\Sales\Model\Order;
use Aheadworks\Affiliate\Model\LinkStatistic\Manager as LinkStatisticManager;

/**
 * Class OrderPlugin
 * @package Aheadworks\Affiliate\Plugin\Sales\Model
 */
class OrderPlugin
{
    /**
     * @var LinkStatisticManager
     */
    private $linkStatisticManager;

    /**
     * @param LinkStatisticManager $linkStatisticManager
     */
    public function __construct(
        LinkStatisticManager $linkStatisticManager
    ) {
        $this->linkStatisticManager = $linkStatisticManager;
    }

    /**
     * @param Order $subject
     * @param Order $result
     * @return Order
     */
    public function afterPlace(
        Order $subject,
        Order $result
    ) {
        $this->linkStatisticManager->registerOrderPlacement();
        return $result;
    }
}
