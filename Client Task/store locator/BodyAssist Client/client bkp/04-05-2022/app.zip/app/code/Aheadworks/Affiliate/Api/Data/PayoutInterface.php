<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Api\Data;

use Magento\Framework\Api\ExtensibleDataInterface;

/**
 * Interface PayoutInterface
 * @package Aheadworks\Affiliate\Api\Data
 */
interface PayoutInterface extends ExtensibleDataInterface
{
    /**#@+
     * Constants for keys of data array.
     * Identical to the name of the getter in snake case
     */
    const ID = 'payout_id';
    const AFFILIATE_ID = 'affiliate_id';
    const AMOUNT = 'amount';
    const TYPE = 'type';
    const STATUS = 'status';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
    const AFFILIATE_PAYMENT_TYPE = 'affiliate_payment_type';
    const AFFILIATE_PAYMENT_INFO = 'affiliate_payment_info';
    /**#@-*/

    /**
     * Get payout id
     *
     * @return int
     */
    public function getPayoutId();

    /**
     * Set payout id
     *
     * @param int $id
     * @return $this
     */
    public function setPayoutId($id);

    /**
     * Get affiliate id
     *
     * @return int
     */
    public function getAffiliateId();

    /**
     * Set affiliate id
     *
     * @param int $affiliateId
     * @return $this
     */
    public function setAffiliateId($affiliateId);

    /**
     * Get amount
     *
     * @return float
     */
    public function getAmount();

    /**
     * Set amount
     *
     * @param float $amount
     * @return $this
     */
    public function setAmount($amount);

    /**
     * Get type
     *
     * @return string
     */
    public function getType();

    /**
     * Set type
     *
     * @param string $type
     * @return $this
     */
    public function setType($type);

    /**
     * Get status
     *
     * @return string
     */
    public function getStatus();

    /**
     * Set status
     *
     * @param string $status
     * @return $this
     */
    public function setStatus($status);

    /**
     * Get created at
     *
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created at
     *
     * @param string $createdAt
     * @return $this
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated at
     *
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated at
     *
     * @param string $updatedAt
     * @return $this
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Get affiliate payment type
     *
     * @return int|null
     */
    public function getAffiliatePaymentType();

    /**
     * Set affiliate payment type
     *
     * @param int $affiliatePaymentType
     * @return $this
     */
    public function setAffiliatePaymentType($affiliatePaymentType);

    /**
     * Get affiliate payment info
     *
     * @return string|null
     */
    public function getAffiliatePaymentInfo();

    /**
     * Set affiliate payment info
     *
     * @param string $affiliatePaymentInfo
     * @return $this
     */
    public function setAffiliatePaymentInfo($affiliatePaymentInfo);

    /**
     * Retrieve existing extension attributes object or create a new one
     *
     * @return \Aheadworks\Affiliate\Api\Data\PayoutExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object
     *
     * @param \Aheadworks\Affiliate\Api\Data\PayoutExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aheadworks\Affiliate\Api\Data\PayoutExtensionInterface $extensionAttributes
    );
}
