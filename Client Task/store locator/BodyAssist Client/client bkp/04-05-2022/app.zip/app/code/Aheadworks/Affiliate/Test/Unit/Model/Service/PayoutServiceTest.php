<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Model\Service;

use Aheadworks\Affiliate\Model\Source\Payout\Type;
use Aheadworks\Affiliate\Model\Status\Actions\ActionsInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use PHPUnit\Framework\TestCase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Aheadworks\Affiliate\Model\Service\PayoutService;
use Aheadworks\Affiliate\Api\PayoutRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\PayoutInterface;
use Aheadworks\Affiliate\Model\Source\Payout\Status;
use Magento\Framework\Exception\CouldNotSaveException;
use Aheadworks\Affiliate\Model\Payout\StatusResolver;
use Aheadworks\Affiliate\Model\ResourceModel\Payout as PayoutResource;
use Magento\Framework\Exception\LocalizedException;
use Aheadworks\Affiliate\Model\Payout\NewPayoutPreparer;
use Aheadworks\Affiliate\Model\Status\ActionsPool as StatusActionsPool;

/**
 * Class PayoutServiceTest
 * @package Aheadworks\Affiliate\Test\Unit\Model\Service
 */
class PayoutServiceTest extends TestCase
{
    /**
     * @var PayoutRepositoryInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $payoutRepositoryMock;

    /**
     * @var StatusResolver|\PHPUnit_Framework_MockObject_MockObject
     */
    private $statusResolverMock;

    /**
     * @var NewPayoutPreparer|\PHPUnit_Framework_MockObject_MockObject
     */
    private $newPayoutPreparerMock;

    /**
     * @var PayoutResource|\PHPUnit_Framework_MockObject_MockObject
     */
    private $payoutResourceMock;

    /**
     * @var StatusActionsPool|\PHPUnit_Framework_MockObject_MockObject
     */
    private $statusActionsPoolMock;

    /**
     * @var PayoutService
     */
    private $testedClass;

    /**#@+
     * Constants used for tests
     */
    const DEFAULT_ID = 1;
    const DEFAULT_STATUS = Status::PENDING;
    const COULD_SAVE_PAYOUT_EXC_CODE = 1;
    const PREPARE_PAYOUT_EXC_CODE = 2;
    const NO_SUCH_PAYOUT_EXC_CODE = 3;
    const PAYOUT_STATUS_EXC_CODE = 4;
    /**#@-*/

    /**
     * Init mocks for tests
     *
     * @return void
     */
    public function setUp() : void
    {
        $objectManager = new ObjectManager($this);
        $this->payoutRepositoryMock = $this->createMock(PayoutRepositoryInterface::class);
        $this->statusResolverMock = $this->createMock(StatusResolver::class);
        $this->newPayoutPreparerMock = $this->createMock(NewPayoutPreparer::class);
        $this->payoutResourceMock = $this->createMock(PayoutResource::class);
        $this->statusActionsPoolMock = $this->createMock(StatusActionsPool::class);
        $this->testedClass = $objectManager->getObject(
            PayoutService::class,
            [
                'payoutRepository' => $this->payoutRepositoryMock,
                'statusResolver' => $this->statusResolverMock,
                'newPayoutPreparer' => $this->newPayoutPreparerMock,
                'payoutResource' => $this->payoutResourceMock,
                'statusActionsPool' => $this->statusActionsPoolMock
            ]
        );
    }

    /**
     * Test createPayoutForAffiliate method
     */
    public function testCreatePayoutForAffiliate()
    {
        $payoutMock = $this->getPayoutMock();

        $this->newPayoutPreparerMock->expects($this->once())
            ->method('prepareNewPayout')
            ->with(self::DEFAULT_ID, Type::MANUAL)
            ->willReturn($payoutMock);
        $this->mockObjectsPerformSaving($payoutMock);

        $this->assertSame($payoutMock, $this->testedClass->createPayoutForAffiliate(self::DEFAULT_ID));
    }

    /**
     * Test createPayoutForAffiliate method with exception
     *
     * @param CouldNotSaveException|LocalizedException $exception
     * @param string $exceptionMsg
     * @dataProvider testCreatePayoutForAffiliateWithExceptionProvider
     * @expectedException \Magento\Framework\Exception\LocalizedException
     */
    public function testCreatePayoutForAffiliateWithException($exception, $exceptionMsg)
    {
        $payoutMock = $this->getPayoutMock();

        if ($exception->getCode() == self::PREPARE_PAYOUT_EXC_CODE) {
            $this->newPayoutPreparerMock->expects($this->once())
                ->method('prepareNewPayout')
                ->with(self::DEFAULT_ID, Type::MANUAL)
                ->willThrowException($exception);
        } else {
            $this->newPayoutPreparerMock->expects($this->once())
                ->method('prepareNewPayout')
                ->with(self::DEFAULT_ID, Type::MANUAL)
                ->willReturn($payoutMock);
            $this->mockObjectsPerformSavingWithException($payoutMock, $exception);
        }
        $this->expectExceptionMessage($exceptionMsg);

        $this->testedClass->createPayoutForAffiliate(self::DEFAULT_ID);
    }

    /**
     * Test processPayout method
     *
     * @throws LocalizedException
     */
    public function testProcessPayout()
    {
        $currentStatus = Status::PENDING;
        $payoutMock = $this->getPayoutMock();

        $this->payoutRepositoryMock->expects($this->once())
            ->method('getById')
            ->willReturn($payoutMock);
        $this->statusResolverMock->expects($this->once())
            ->method('isStatusAllowedForPayout')
            ->with(Status::PROCESSING, $currentStatus)
            ->willReturn(true);
        $payoutMock->expects($this->once())
            ->method('setStatus')
            ->with(Status::PROCESSING)
            ->willReturnSelf();
        $this->mockObjectsPerformSaving($payoutMock);

        $this->assertSame($payoutMock, $this->testedClass->processPayout(self::DEFAULT_ID));
    }

    /**
     * Test processPayout method with exception
     *
     * @param CouldNotSaveException|LocalizedException $exception
     * @param string $exceptionMsg
     * @expectedException \Magento\Framework\Exception\LocalizedException
     * @dataProvider testProcessPayoutWithExceptionProvider
     * @throws LocalizedException
     */
    public function testProcessPayoutWithException($exception, $exceptionMsg)
    {
        $pendingPayoutMock = $this->getPayoutMock();
        $processingPayoutMock = $this->getPayoutMock(self::DEFAULT_ID, Status::PROCESSING);

        if ($exception->getCode() == self::NO_SUCH_PAYOUT_EXC_CODE) {
            $this->payoutRepositoryMock->expects($this->once())
                ->method('getById')
                ->willThrowException($exception);
        } elseif ($exception->getCode() == self::PAYOUT_STATUS_EXC_CODE) {
            $this->payoutRepositoryMock->expects($this->once())
                ->method('getById')
                ->with(self::DEFAULT_ID)
                ->willReturn($processingPayoutMock);
            $this->statusResolverMock->expects($this->once())
                ->method('isStatusAllowedForPayout')
                ->with(Status::PROCESSING, Status::PROCESSING)
                ->willReturn(false);
        } else {
            $this->payoutRepositoryMock->expects($this->once())
                ->method('getById')
                ->with(self::DEFAULT_ID)
                ->willReturn($pendingPayoutMock);
            $this->statusResolverMock->expects($this->once())
                ->method('isStatusAllowedForPayout')
                ->with(Status::PROCESSING, Status::PENDING)
                ->willReturn(true);
            $pendingPayoutMock->expects($this->once())
                ->method('setStatus')
                ->with(Status::PROCESSING)
                ->willReturnSelf();
            $this->mockObjectsPerformSavingWithException($pendingPayoutMock, $exception);
        }
        $this->expectExceptionMessage($exceptionMsg);

        $this->testedClass->processPayout(self::DEFAULT_ID);
    }

    /**
     * Test completePayout method
     *
     * @throws LocalizedException
     */
    public function testCompletePayout()
    {
        $currentStatus = Status::PROCESSING;
        $payoutMock = $this->getPayoutMock(self::DEFAULT_ID, $currentStatus);

        $this->payoutRepositoryMock->expects($this->once())
            ->method('getById')
            ->willReturn($payoutMock);
        $this->statusResolverMock->expects($this->once())
            ->method('isStatusAllowedForPayout')
            ->with(Status::COMPLETE, $currentStatus)
            ->willReturn(true);
        $payoutMock->expects($this->once())
            ->method('setStatus')
            ->with(Status::COMPLETE)
            ->willReturnSelf();
        $this->mockObjectsPerformSaving($payoutMock);

        $this->assertSame($payoutMock, $this->testedClass->completePayout(self::DEFAULT_ID));
    }

    /**
     * Test completePayout method with exception
     *
     * @param CouldNotSaveException|LocalizedException $exception
     * @param string $exceptionMsg
     * @expectedException \Magento\Framework\Exception\LocalizedException
     * @dataProvider testCompletePayoutWithExceptionProvider
     * @throws LocalizedException
     */
    public function testCompletePayoutWithException($exception, $exceptionMsg)
    {
        $processingPayoutMock = $this->getPayoutMock(self::DEFAULT_ID, Status::PROCESSING);
        $completePayoutMock = $this->getPayoutMock(self::DEFAULT_ID, Status::COMPLETE);

        if ($exception->getCode() == self::NO_SUCH_PAYOUT_EXC_CODE) {
            $this->payoutRepositoryMock->expects($this->once())
                ->method('getById')
                ->willThrowException($exception);
        } elseif ($exception->getCode() == self::PAYOUT_STATUS_EXC_CODE) {
            $this->payoutRepositoryMock->expects($this->once())
                ->method('getById')
                ->with(self::DEFAULT_ID)
                ->willReturn($completePayoutMock);
            $this->statusResolverMock->expects($this->once())
                ->method('isStatusAllowedForPayout')
                ->with(Status::COMPLETE, Status::COMPLETE)
                ->willReturn(false);
        } else {
            $this->payoutRepositoryMock->expects($this->once())
                ->method('getById')
                ->with(self::DEFAULT_ID)
                ->willReturn($processingPayoutMock);
            $this->statusResolverMock->expects($this->once())
                ->method('isStatusAllowedForPayout')
                ->with(Status::COMPLETE, Status::PROCESSING)
                ->willReturn(true);
            $processingPayoutMock->expects($this->once())
                ->method('setStatus')
                ->with(Status::COMPLETE)
                ->willReturnSelf();
            $this->mockObjectsPerformSavingWithException($processingPayoutMock, $exception);
        }
        $this->expectExceptionMessage($exceptionMsg);

        $this->testedClass->completePayout(self::DEFAULT_ID);
    }

    /**
     * Test cancelPayout method
     *
     * @throws LocalizedException
     */
    public function testCancelPayout()
    {
        $currentStatus = Status::PROCESSING;
        $payoutMock = $this->getPayoutMock(self::DEFAULT_ID, $currentStatus);

        $this->payoutRepositoryMock->expects($this->once())
            ->method('getById')
            ->willReturn($payoutMock);
        $this->statusResolverMock->expects($this->once())
            ->method('isStatusAllowedForPayout')
            ->with(Status::CANCELED, $currentStatus)
            ->willReturn(true);
        $payoutMock->expects($this->once())
            ->method('setStatus')
            ->with(Status::CANCELED)
            ->willReturnSelf();
        $this->mockObjectsPerformSaving($payoutMock);

        $this->assertSame($payoutMock, $this->testedClass->cancelPayout(self::DEFAULT_ID));
    }

    /**
     * Test cancelPayout method with exception
     *
     * @param CouldNotSaveException|LocalizedException $exception
     * @param string $exceptionMsg
     * @expectedException \Magento\Framework\Exception\LocalizedException
     * @dataProvider testCancelPayoutWithExceptionProvider
     * @throws LocalizedException
     */
    public function testCancelPayoutWithException($exception, $exceptionMsg)
    {
        $processingPayoutMock = $this->getPayoutMock(self::DEFAULT_ID, Status::PROCESSING);
        $canceledPayoutMock = $this->getPayoutMock(self::DEFAULT_ID, Status::CANCELED);

        if ($exception->getCode() == self::NO_SUCH_PAYOUT_EXC_CODE) {
            $this->payoutRepositoryMock->expects($this->once())
                ->method('getById')
                ->willThrowException($exception);
        } elseif ($exception->getCode() == self::PAYOUT_STATUS_EXC_CODE) {
            $this->payoutRepositoryMock->expects($this->once())
                ->method('getById')
                ->with(self::DEFAULT_ID)
                ->willReturn($canceledPayoutMock);
            $this->statusResolverMock->expects($this->once())
                ->method('isStatusAllowedForPayout')
                ->with(Status::CANCELED, Status::CANCELED)
                ->willReturn(false);
        } else {
            $this->payoutRepositoryMock->expects($this->once())
                ->method('getById')
                ->with(self::DEFAULT_ID)
                ->willReturn($processingPayoutMock);
            $this->statusResolverMock->expects($this->once())
                ->method('isStatusAllowedForPayout')
                ->with(Status::CANCELED, Status::PROCESSING)
                ->willReturn(true);
            $processingPayoutMock->expects($this->once())
                ->method('setStatus')
                ->with(Status::CANCELED)
                ->willReturnSelf();
            $this->mockObjectsPerformSavingWithException($processingPayoutMock, $exception);
        }
        $this->expectExceptionMessage($exceptionMsg);

        $this->testedClass->cancelPayout(self::DEFAULT_ID);
    }

    /**
     * Get payout mock
     *
     * @param int $payoutId
     * @param string $status
     * @return PayoutInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private function getPayoutMock($payoutId = self::DEFAULT_ID, $status = self::DEFAULT_STATUS)
    {
        $payoutMock = $this->createMock(PayoutInterface::class);

        $payoutMock->expects($this->atMost(1))
            ->method('getPayoutId')
            ->willReturn($payoutId);
        $payoutMock->expects($this->atMost(2))
            ->method('getStatus')
            ->willReturn($status);

        return $payoutMock;
    }

    /**
     * Mock objects for performPayoutSaving method
     *
     * @param PayoutInterface|\PHPUnit_Framework_MockObject_MockObject $payoutMock
     */
    private function mockObjectsPerformSaving($payoutMock)
    {
        $statusActionMock = $this->createMock(ActionsInterface::class);

        $this->payoutResourceMock->expects($this->once())
            ->method('beginTransaction')
            ->willReturnSelf();
        $this->payoutRepositoryMock->expects($this->once())
            ->method('save')
            ->with($payoutMock)
            ->willReturn($payoutMock);
        $this->statusActionsPoolMock->expects($this->once())
            ->method('getByStatus')
            ->willReturn($statusActionMock);
        $statusActionMock->expects($this->once())
            ->method('performActions')
            ->with($payoutMock);
        $this->payoutResourceMock->expects($this->once())
            ->method('commit')
            ->willReturnSelf();
    }

    /**
     * Mock objects for performPayoutSaving method with exception
     *
     * @param PayoutInterface|\PHPUnit_Framework_MockObject_MockObject $payoutMock
     * @param CouldNotSaveException|LocalizedException|NoSuchEntityException $exception
     */
    private function mockObjectsPerformSavingWithException($payoutMock, $exception)
    {
        $statusActionMock = $this->createMock(ActionsInterface::class);

        $this->payoutResourceMock->expects($this->once())
            ->method('beginTransaction')
            ->willReturnSelf();
        if ($exception->getCode() == self::COULD_SAVE_PAYOUT_EXC_CODE) {
            $this->payoutRepositoryMock->expects($this->once())
                ->method('save')
                ->with($payoutMock)
                ->willThrowException($exception);
        } else {
            $this->payoutRepositoryMock->expects($this->once())
                ->method('save')
                ->with($payoutMock)
                ->willReturn($payoutMock);
            $this->statusActionsPoolMock->expects($this->once())
                ->method('getByStatus')
                ->willReturn($statusActionMock);
            $statusActionMock->expects($this->once())
                ->method('performActions')
                ->with($payoutMock)
                ->willThrowException($exception);
        }
        $this->payoutResourceMock->expects($this->once())
            ->method('rollBack')
            ->willReturnSelf();
    }

    /**
     * @return array
     */
    public function testCreatePayoutForAffiliateWithExceptionProvider()
    {
        return array_merge(
            $this->getPerformSavingExceptions(),
            [
                [
                    new LocalizedException(
                        __('Error while preparing new payout.'),
                        null,
                        self::PREPARE_PAYOUT_EXC_CODE
                    ),
                    'Error while preparing new payout.'
                ]
            ]
        );
    }

    /**
     * @return array
     */
    public function testProcessPayoutWithExceptionProvider()
    {
        return array_merge(
            $this->getPerformSavingExceptions(),
            [
                [
                    new NoSuchEntityException(
                        __('Payout with ID = %1 does not exist.', self::DEFAULT_ID),
                        null,
                        self::NO_SUCH_PAYOUT_EXC_CODE
                    ),
                    'Payout with ID = 1 does not exist.'
                ],
                [
                    new LocalizedException(
                        __('Payout can\'t be processed.'),
                        null,
                        self::PAYOUT_STATUS_EXC_CODE
                    ),
                    'Payout can\'t be processed.'
                ]
            ]
        );
    }

    /**
     * @return array
     */
    public function testCompletePayoutWithExceptionProvider()
    {
        return array_merge(
            $this->getPerformSavingExceptions(),
            [
                [
                    new NoSuchEntityException(
                        __('Payout with ID = %1 does not exist.', self::DEFAULT_ID),
                        null,
                        self::NO_SUCH_PAYOUT_EXC_CODE
                    ),
                    'Payout with ID = 1 does not exist.'
                ],
                [
                    new LocalizedException(
                        __('Payout can\'t be completed.'),
                        null,
                        self::PAYOUT_STATUS_EXC_CODE
                    ),
                    'Payout can\'t be completed.'
                ]
            ]
        );
    }

    /**
     * @return array
     */
    public function testCancelPayoutWithExceptionProvider()
    {
        return array_merge(
            $this->getPerformSavingExceptions(),
            [
                [
                    new NoSuchEntityException(
                        __('Payout with ID = %1 does not exist.', self::DEFAULT_ID),
                        null,
                        self::NO_SUCH_PAYOUT_EXC_CODE
                    ),
                    'Payout with ID = 1 does not exist.'
                ],
                [
                    new LocalizedException(
                        __('Payout can\'t be canceled.'),
                        null,
                        self::PAYOUT_STATUS_EXC_CODE
                    ),
                    'Payout can\'t be canceled.'
                ]
            ]
        );
    }

    /**
     * Get performPayoutSaving method exceptions
     *
     * @return array
     */
    private function getPerformSavingExceptions()
    {
        return [
            [
                new CouldNotSaveException(
                    __('Error while payout saving.'),
                    null,
                    self::COULD_SAVE_PAYOUT_EXC_CODE
                ),
                'Error while payout saving.'
            ],
            [
                new CouldNotSaveException(__('Error while status actions performing.')),
                'Error while status actions performing.'
            ]
        ];
    }
}
