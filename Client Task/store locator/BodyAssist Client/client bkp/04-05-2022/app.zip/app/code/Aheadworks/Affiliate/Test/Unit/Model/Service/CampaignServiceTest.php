<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Model\Service;

use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\NoSuchEntityException;
use PHPUnit\Framework\TestCase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Aheadworks\Affiliate\Model\Service\CampaignService;
use Aheadworks\Affiliate\Api\CampaignRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Exception\CouldNotSaveException;

/**
 * Class CampaignServiceTest
 * @package Aheadworks\Affiliate\Test\Unit\Model\Service
 */
class CampaignServiceTest extends TestCase
{
    /**
     * @var CampaignRepositoryInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $campaignRepositoryMock;

    /**
     * @var DataObjectHelper|\PHPUnit_Framework_MockObject_MockObject
     */
    private $dataObjectHelperMock;

    /**
     * @var CampaignService
     */
    private $testedClass;

    const DEFAULT_CAMPAIGN_ID = 1;

    /**
     * Init mocks for tests
     *
     * @return void
     */
    public function setUp() : void
    {
        $objectManager = new ObjectManager($this);
        $this->campaignRepositoryMock = $this->createMock(CampaignRepositoryInterface::class);
        $this->dataObjectHelperMock = $this->createMock(DataObjectHelper::class);
        $this->testedClass = $objectManager->getObject(
            CampaignService::class,
            [
                'campaignRepository' => $this->campaignRepositoryMock,
                'dataObjectHelper' => $this->dataObjectHelperMock
            ]
        );
    }

    /**
     * Test createCampaign method
     */
    public function testCreateCampaign()
    {
        $campaignMock = $this->getCampaignMock();

        $this->campaignRepositoryMock->expects($this->once())
            ->method('save')
            ->with($campaignMock)
            ->willReturn($campaignMock);

        $this->assertSame($campaignMock, $this->testedClass->createCampaign($campaignMock));
    }

    /**
     * Test createCampaign method with exception
     *
     * @expectedException \Magento\Framework\Exception\CouldNotSaveException
     * @expectedExceptionMessage Test message.
     */
    public function testCreateCampaignWithException()
    {
        $campaignMock = $this->getCampaignMock();
        $exception = new CouldNotSaveException(__('Test message.'));

        $this->campaignRepositoryMock->expects($this->once())
            ->method('save')
            ->with($campaignMock)
            ->willThrowException($exception);
        $this->expectException(CouldNotSaveException::class);
        $this->testedClass->createCampaign($campaignMock);
    }

    /**
     * Test updateCampaign method
     */
    public function testUpdateCampaign()
    {
        $campaignMock = $this->getCampaignMock();
        $campaignToMergeMock = $this->getCampaignMock();

        $this->campaignRepositoryMock->expects($this->once())
            ->method('getById')
            ->with(self::DEFAULT_CAMPAIGN_ID)
            ->willReturn($campaignToMergeMock);
        $this->dataObjectHelperMock->expects($this->once())
            ->method('mergeDataObjects')
            ->with(CampaignInterface::class, $campaignMock, $campaignToMergeMock)
            ->willReturn($campaignToMergeMock);
        $this->campaignRepositoryMock->expects($this->once())
            ->method('save')
            ->with($campaignToMergeMock)
            ->willReturn($campaignToMergeMock);

        $this->assertSame($campaignToMergeMock, $this->testedClass->updateCampaign($campaignMock));
    }

    /**
     * Test updateCampaign method with exception
     *
     * @param CouldNotSaveException|NoSuchEntityException $exception
     * @param string $excClass
     * @param string $excMessage
     * @dataProvider testUpdateCampaignWithExceptionProvider
     */
    public function testUpdateCampaignWithException($exception, $excClass, $excMessage)
    {
        $campaignMock = $this->getCampaignMock();
        $campaignToMergeMock = $this->getCampaignMock();

        if ($exception instanceof NoSuchEntityException) {
            $this->campaignRepositoryMock->expects($this->once())
                ->method('getById')
                ->with(self::DEFAULT_CAMPAIGN_ID)
                ->willThrowException($exception);
        } else {
            $this->campaignRepositoryMock->expects($this->once())
                ->method('getById')
                ->with(self::DEFAULT_CAMPAIGN_ID)
                ->willReturn($campaignToMergeMock);
            $this->dataObjectHelperMock->expects($this->once())
                ->method('mergeDataObjects')
                ->with(CampaignInterface::class, $campaignMock, $campaignToMergeMock)
                ->willReturn($campaignToMergeMock);
            $this->campaignRepositoryMock->expects($this->once())
                ->method('save')
                ->with($campaignToMergeMock)
                ->willThrowException($exception);
        }
        $this->expectException($excClass);
        $this->expectExceptionMessage($excMessage);

        $this->testedClass->updateCampaign($campaignMock);
    }

    /**
     * Test deleteCampaign method
     */
    public function testDeleteCampaign()
    {
        $campaignMock = $this->getCampaignMock();

        $this->campaignRepositoryMock->expects($this->once())
            ->method('delete')
            ->with($campaignMock)
            ->willReturn(true);

        $this->assertTrue($this->testedClass->deleteCampaign($campaignMock));
    }

    /**
     * Test deleteCampaign method with exception
     *
     * @expectedException \Magento\Framework\Exception\CouldNotDeleteException
     * @expectedExceptionMessage Test message.
     */
    public function testDeleteCampaignWithException()
    {
        $campaignMock = $this->getCampaignMock();
        $exception = new CouldNotDeleteException(__('Test message.'));
        $this->expectException(CouldNotDeleteException::class);
        $this->campaignRepositoryMock->expects($this->once())
            ->method('delete')
            ->with($campaignMock)
            ->willThrowException($exception);

        $this->testedClass->deleteCampaign($campaignMock);
    }

    /**
     * Test deleteCampaignById method
     */
    public function testDeleteCampaignById()
    {
        $campaignMock = $this->getCampaignMock();

        $this->campaignRepositoryMock->expects($this->once())
            ->method('getById')
            ->with(self::DEFAULT_CAMPAIGN_ID)
            ->willReturn($campaignMock);
        $this->campaignRepositoryMock->expects($this->once())
            ->method('delete')
            ->with($campaignMock)
            ->willReturn(true);

        $this->assertTrue($this->testedClass->deleteCampaignById(self::DEFAULT_CAMPAIGN_ID));
    }

    /**
     * Test deleteCampaignById method with exception
     *
     * @param CouldNotDeleteException|NoSuchEntityException $exception
     * @param string $excClass
     * @param string $excMessage
     * @dataProvider testDeleteCampaignByIdWithExceptionProvider
     */
    public function testDeleteCampaignByIdWithException($exception, $excClass, $excMessage)
    {
        $campaignMock = $this->getCampaignMock();

        if ($exception instanceof NoSuchEntityException) {
            $this->campaignRepositoryMock->expects($this->once())
                ->method('getById')
                ->with(self::DEFAULT_CAMPAIGN_ID)
                ->willThrowException($exception);
        } else {
            $this->campaignRepositoryMock->expects($this->once())
                ->method('getById')
                ->with(self::DEFAULT_CAMPAIGN_ID)
                ->willReturn($campaignMock);
            $this->campaignRepositoryMock->expects($this->once())
                ->method('delete')
                ->with($campaignMock)
                ->willThrowException($exception);
        }
        $this->expectException($excClass);
        $this->expectExceptionMessage($excMessage);

        $this->testedClass->deleteCampaignById(self::DEFAULT_CAMPAIGN_ID);
    }

    /**
     * @return array
     */
    public function testUpdateCampaignWithExceptionProvider()
    {
        return [
            [
                new NoSuchEntityException(__('No such entity message.')),
                NoSuchEntityException::class,
                'No such entity message.'
            ],
            [
                new CouldNotSaveException(__('Can\'t save message.')),
                CouldNotSaveException::class,
                'Can\'t save message.'
            ]
        ];
    }

    /**
     * @return array
     */
    public function testDeleteCampaignByIdWithExceptionProvider()
    {
        return [
            [
                new NoSuchEntityException(__('No such entity message.')),
                NoSuchEntityException::class,
                'No such entity message.'
            ],
            [
                new CouldNotSaveException(__('Can\'t delete message.')),
                CouldNotSaveException::class,
                'Can\'t delete message.'
            ]
        ];
    }

    /**
     * @param int $campaignId
     * @return CampaignInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private function getCampaignMock($campaignId = self::DEFAULT_CAMPAIGN_ID)
    {
        $campaignMock = $this->createMock(CampaignInterface::class);

        $campaignMock->expects($this->atMost(1))
            ->method('getCampaignId')
            ->willReturn($campaignId);

        return $campaignMock;
    }
}
