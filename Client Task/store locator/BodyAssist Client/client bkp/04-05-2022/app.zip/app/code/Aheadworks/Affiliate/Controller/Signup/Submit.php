<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Signup;

use Aheadworks\Affiliate\Api\AccountRepositoryInterface;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Data\Form\FormKey\Validator as FormKeyValidator;
use Magento\Framework\Api\DataObjectHelper;
use Aheadworks\Affiliate\Model\PostData\ProcessorComposite as PostDataProcessorComposite;
use Aheadworks\Affiliate\Api\Data\SignupInterface;
use Aheadworks\Affiliate\Api\Data\SignupInterfaceFactory;
use Aheadworks\Affiliate\Api\SignupManagementInterface;
use Aheadworks\Affiliate\Controller\AbstractPostCustomerAction;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Class Submit
 *
 * @package Aheadworks\Affiliate\Controller\Signup
 */
class Submit extends AbstractPostCustomerAction
{
    /**
     * @var PostDataProcessorComposite
     */
    private $postDataProcessorComposite;

    /**
     * @var DataObjectHelper
     */
    private $dataObjectHelper;

    /**
     * @var SignupInterfaceFactory
     */
    private $signupInterfaceFactory;

    /**
     * @var SignupManagementInterface
     */
    private $signupManagement;

    /**
     * @param Context $context
     * @param CustomerSession $customerSession
     * @param FormKeyValidator $formKeyValidator
     * @param StoreManagerInterface $storeManager
     * @param AccountRepositoryInterface $accountRepository
     * @param PostDataProcessorComposite $postDataProcessorComposite
     * @param DataObjectHelper $dataObjectHelper
     * @param SignupInterfaceFactory $signupInterfaceFactory
     * @param SignupManagementInterface $signupManagement
     */
    public function __construct(
        Context $context,
        CustomerSession $customerSession,
        FormKeyValidator $formKeyValidator,
        StoreManagerInterface $storeManager,
        AccountRepositoryInterface $accountRepository,
        PostDataProcessorComposite $postDataProcessorComposite,
        DataObjectHelper $dataObjectHelper,
        SignupInterfaceFactory $signupInterfaceFactory,
        SignupManagementInterface $signupManagement
    ) {
        parent::__construct($context, $customerSession, $formKeyValidator, $storeManager, $accountRepository);
        $this->postDataProcessorComposite = $postDataProcessorComposite;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->signupInterfaceFactory = $signupInterfaceFactory;
        $this->signupManagement = $signupManagement;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        $postData = $this->getRequest()->getPostValue();
        if (!empty($postData)) {
            try {
                $this->validate();
                $preparedData = $this->postDataProcessorComposite->prepareData($postData);
                $this->performSubmit($preparedData);
                $this->messageManager->addSuccessMessage(__('You submitted your signup for moderation'));
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addExceptionMessage($e, __('Something went wrong while submitting the signup.'));
            }
        }
        return $this->getPreparedRedirect();
    }

    /**
     * Perform signup submit
     *
     * @param array $preparedData
     * @return SignupInterface
     * @throws LocalizedException
     */
    private function performSubmit($preparedData)
    {
        $signupObject = $this->signupInterfaceFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $signupObject,
            $preparedData,
            SignupInterface::class
        );
        return $this->signupManagement->createSignup($signupObject);
    }

    /**
     * Retrieve redirect to the current page
     *
     * @return Redirect
     */
    protected function getPreparedRedirect()
    {
        /** @var Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        return $resultRedirect->setRefererOrBaseUrl();
    }
}
