<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Ui\DataProvider\Campaign;

use Magento\Ui\DataProvider\AbstractDataProvider;
use Aheadworks\Affiliate\Model\ResourceModel\Campaign\CollectionFactory;
use Aheadworks\Affiliate\Model\ResourceModel\Campaign\Collection;
use Aheadworks\Affiliate\Model\Campaign;
use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Aheadworks\Affiliate\Ui\DataProvider\FormDataProcessor\Composite as FormDataProcessorComposite;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\App\RequestInterface;

/**
 * Class FormDataProvider
 *
 * @package Aheadworks\Affiliate\Ui\DataProvider\Campaign
 */
class FormDataProvider extends AbstractDataProvider
{
    /**
     * Key for saving and getting form data from data persistor
     */
    const DATA_PERSISTOR_FORM_DATA_KEY = 'aw_affiliate_campaign_form';

    /**
     * @var Collection
     */
    protected $collection;

    /**
     * @var RequestInterface
     */
    private $request;

    /**
     * @var DataPersistorInterface
     */
    private $dataPersistor;

    /**
     * @var FormDataProcessorComposite
     */
    private $campaignFormDataProcessorComposite;

    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param RequestInterface $request
     * @param DataPersistorInterface $dataPersistor
     * @param FormDataProcessorComposite $campaignFormDataProcessorComposite
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        RequestInterface $request,
        DataPersistorInterface $dataPersistor,
        FormDataProcessorComposite $campaignFormDataProcessorComposite,
        array $meta = [],
        array $data = []
    ) {
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
        $this->collection = $collectionFactory->create();
        $this->request = $request;
        $this->dataPersistor = $dataPersistor;
        $this->campaignFormDataProcessorComposite = $campaignFormDataProcessorComposite;
    }

    /**
     * Get data
     *
     * @return array
     */
    public function getData()
    {
        $data = [];
        $dataFromForm = $this->dataPersistor->get(self::DATA_PERSISTOR_FORM_DATA_KEY);
        $campaignId = $this->request->getParam($this->getRequestFieldName());
        if (!empty($dataFromForm)) {
            $data[$campaignId] = $dataFromForm;
            $this->dataPersistor->clear(self::DATA_PERSISTOR_FORM_DATA_KEY);
        } elseif (!empty($campaignId)) {
            $campaigns = $this->getCollection()
                ->addFieldToFilter(CampaignInterface::ID, $campaignId)
                ->getItems();
            /** @var Campaign $campaign */
            foreach ($campaigns as $campaign) {
                if ($campaignId == $campaign->getId()) {
                    $campaignData = $campaign->getData();
                    $data[$campaignId] = $this->campaignFormDataProcessorComposite->prepareData($campaignData);
                    break;
                }
            }
        }

        return $data;
    }
}
