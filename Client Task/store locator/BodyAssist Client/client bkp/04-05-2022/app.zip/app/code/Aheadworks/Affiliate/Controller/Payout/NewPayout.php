<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Payout;

use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Data\Form\FormKey\Validator as FormKeyValidator;
use Aheadworks\Affiliate\Api\PayoutManagementInterface;
use Aheadworks\Affiliate\Controller\AbstractPostCustomerAction;
use Magento\Customer\Model\Session as CustomerSession;
use Aheadworks\Affiliate\Api\AccountRepositoryInterface;
use Aheadworks\Affiliate\Model\Source\Payout\Type as PayoutType;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Class NewPayout
 * @package Aheadworks\Affiliate\Controller\Payout
 */
class NewPayout extends AbstractPostCustomerAction
{
    /**
     * @var PayoutManagementInterface
     */
    private $payoutManagement;

    /**
     * @param Context $context
     * @param CustomerSession $customerSession
     * @param FormKeyValidator $formKeyValidator
     * @param PayoutManagementInterface $payoutManagement
     * @param AccountRepositoryInterface $accountRepository
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        Context $context,
        CustomerSession $customerSession,
        FormKeyValidator $formKeyValidator,
        PayoutManagementInterface $payoutManagement,
        AccountRepositoryInterface $accountRepository,
        StoreManagerInterface $storeManager
    ) {
        parent::__construct($context, $customerSession, $formKeyValidator, $storeManager, $accountRepository);
        $this->payoutManagement = $payoutManagement;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        try {
            $account = $this->getAffiliateAccount();
            $this->validate();
            $this->registerNewPayout($account->getAccountId());
            $this->messageManager->addSuccessMessage(
                __('Your request has been registered. We\'ll process it in several business days.')
            );
        } catch (LocalizedException $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        } catch (\Exception $e) {
            $this->messageManager->addExceptionMessage(
                $e,
                __('Something went wrong while submitting the request.')
            );
        }
        return $this->getPreparedRedirect();
    }

    /**
     * Register new payout for affiliate
     *
     * @param int $accountId
     * @throws LocalizedException
     */
    private function registerNewPayout($accountId)
    {
        $this->payoutManagement->createPayoutForAffiliate(
            $accountId,
            PayoutType::MANUAL
        );
    }

    /**
     * Retrieve redirect to the current page
     *
     * @return Redirect
     */
    protected function getPreparedRedirect()
    {
        /** @var Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        return $resultRedirect->setRefererOrBaseUrl();
    }
}
