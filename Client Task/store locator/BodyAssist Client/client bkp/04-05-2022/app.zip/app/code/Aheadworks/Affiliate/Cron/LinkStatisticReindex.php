<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Cron;

use Aheadworks\Affiliate\Model\Config;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Aheadworks\Affiliate\Model\Indexer\LinkStatistic\Processor as IndexProcessor;

/**
 * Class LinkStatisticReindex
 * @package Aheadworks\Affiliate\Cron
 */
class LinkStatisticReindex extends CronAbstract
{
    /**
     * Cron run interval in seconds
     */
    const RUN_INTERVAL = 23 * 60 * 60;

    /**
     * @var IndexProcessor
     */
    private $indexProcessor;

    /**
     * @param Config $config
     * @param DateTime $dateTime
     * @param IndexProcessor $indexProcessor
     */
    public function __construct(
        Config $config,
        DateTime $dateTime,
        IndexProcessor $indexProcessor
    ) {
        parent::__construct($config, $dateTime);
        $this->indexProcessor = $indexProcessor;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        if ($this->isLocked($this->config->getCronIndexProcessorLastExecTime(), self::RUN_INTERVAL)) {
            return $this;
        }

        $this->indexProcessor->reindexAll();
        $this->config->setCronIndexProcessorLastExecTime($this->getCurrentTime());

        return $this;
    }
}
