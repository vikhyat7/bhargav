<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Block\Adminhtml\Account\Button\Form\Edit;

use Aheadworks\Affiliate\Api\AccountRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Aheadworks\Affiliate\Model\Source\Account\Status;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;
use Magento\Framework\App\Request\Http as HttpRequest;

/**
 * Class Save
 * @package Aheadworks\Affiliate\Block\Adminhtml\Account\Button\Form\Edit
 */
class Save implements ButtonProviderInterface
{
    /**
     * @var AccountRepositoryInterface
     */
    private $accountRepository;

    /**
     * @var HttpRequest
     */
    private $request;

    /**
     * @param HttpRequest $request
     * @param AccountRepositoryInterface $accountRepository
     */
    public function __construct(
        HttpRequest $request,
        AccountRepositoryInterface $accountRepository
    ) {
        $this->request = $request;
        $this->accountRepository = $accountRepository;
    }

    /**
     * {@inheritdoc}
     */
    public function getButtonData()
    {
        if ($this->isNeedToShow()) {
            $buttonData = [
                'label' => __('Save'),
                'class' => 'save primary',
                'data_attribute' => [
                    'mage-init' => ['button' => ['event' => 'save']],
                    'form-role' => 'save'
                ],
                'sort_order' => 50,
            ];
        } else {
            $buttonData = [];
        }

        return $buttonData;
    }

    /**
     * Check is need to show button
     *
     * @return bool
     */
    private function isNeedToShow()
    {
        $accountId = $this->request->getParam(AccountInterface::ID, null);

        try {
            $result = $this->accountRepository->getById($accountId)->getStatus() != Status::DELETED;
        } catch (NoSuchEntityException $e) {
            $result = false;
        }

        return $result;
    }
}
