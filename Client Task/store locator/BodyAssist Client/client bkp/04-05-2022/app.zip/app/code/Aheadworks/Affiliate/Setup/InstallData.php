<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Setup;

use Aheadworks\Affiliate\Api\Data\AffiliateGroupInterfaceFactory;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\SampleData\Executor as SampleDataExecutor;
use Aheadworks\Affiliate\Setup\SampleData\Installer as SampleDataInstaller;

/**
 * Class InstallData
 *
 * @package Aheadworks\Affiliate\Setup
 */
class InstallData implements InstallDataInterface
{
    /**
     * @var SampleDataExecutor
     */
    private $sampleDataExecutor;

    /**
     * @var SampleDataInstaller
     */
    private $sampleDataInstaller;

    /**
     * @var SalesSetupFactory
     */
    private $salesSetupFactory;

    /**
     * @param SampleDataExecutor $sampleDataExecutor
     * @param SampleDataInstaller $sampleDataInstaller
     * @param SalesSetupFactory $salesSetupFactory
     */
    public function __construct(
        SampleDataExecutor $sampleDataExecutor,
        SampleDataInstaller $sampleDataInstaller,
        SalesSetupFactory $salesSetupFactory
    ) {
        $this->sampleDataExecutor = $sampleDataExecutor;
        $this->sampleDataInstaller = $sampleDataInstaller;
        $this->salesSetupFactory = $salesSetupFactory;
    }

    /**
     * {@inheritdoc}
     */
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $this
            ->installSampleData()
            ->installSalesAttributes($setup)
        ;
    }

    /**
     * Install sample data
     *
     * @return $this
     */
    private function installSampleData()
    {
        $this->sampleDataExecutor->exec($this->sampleDataInstaller);

        return $this;
    }

    /**
     * Install sales attributes
     *
     * @param ModuleDataSetupInterface $setup
     * @return $this
     */
    private function installSalesAttributes(ModuleDataSetupInterface $setup)
    {
        /** @var SalesSetup $salesSetup */
        $salesSetup = $this->salesSetupFactory->create(['setup' => $setup]);
        $attributes = $salesSetup->getAttributesToInstall();
        foreach ($attributes as $attributeParams) {
            $salesSetup->addAttribute(
                $attributeParams['type'],
                $attributeParams['attribute'],
                $attributeParams['params']
            );
        }

        return $this;
    }
}
