<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Api\Data;

use Magento\Framework\Api\ExtensibleDataInterface;

/**
 * Interface AffiliateGroupInterface
 * @package Aheadworks\Affiliate\Api\Data
 */
interface AffiliateGroupInterface extends ExtensibleDataInterface
{
    /**#@+
     * Constants defined for keys of the data array.
     * Identical to the name of the getter in snake case
     */
    const ID = 'affiliate_group_id';
    const NAME = 'name';
    const COMMISSION_TYPE = 'commission_type';
    const COMMISSION_VALUE = 'commission_value';
    const COMMISSION_HOLDING_PERIOD = 'commission_holding_period';
    /**#@-*/

    /**#@+
     * Default values
     */
    const DEFAULT_GROUP_ID = 1;
    const DEFAULT_COMMISSION_HOLDING_PERIOD = 30;
    /**#@-*/

    /**
     * Get affiliate group id
     *
     * @return int
     */
    public function getAffiliateGroupId();

    /**
     * Set affiliate group id
     *
     * @param int $id
     * @return $this
     */
    public function setAffiliateGroupId($id);

    /**
     * Get affiliate group name
     *
     * @return string
     */
    public function getName();

    /**
     * Set affiliate group name
     *
     * @param string $name
     * @return $this
     */
    public function setName($name);

    /**
     * Get commission type
     *
     * @return int
     */
    public function getCommissionType();

    /**
     * Set commission type
     *
     * @param int $type
     * @return $this
     */
    public function setCommissionType($type);

    /**
     * Get commission value
     *
     * @return float
     */
    public function getCommissionValue();

    /**
     * Set commission value
     *
     * @param float $value
     * @return $this
     */
    public function setCommissionValue($value);

    /**
     * Get commission holding period
     *
     * @return int
     */
    public function getCommissionHoldingPeriod();

    /**
     * Set commission holding period
     *
     * @param int $period
     * @return $this
     */
    public function setCommissionHoldingPeriod($period);

    /**
     * Retrieve existing extension attributes object or create a new one
     *
     * @return \Aheadworks\Affiliate\Api\Data\AffiliateGroupExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object
     *
     * @param \Aheadworks\Affiliate\Api\Data\AffiliateGroupExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aheadworks\Affiliate\Api\Data\AffiliateGroupExtensionInterface $extensionAttributes
    );
}
