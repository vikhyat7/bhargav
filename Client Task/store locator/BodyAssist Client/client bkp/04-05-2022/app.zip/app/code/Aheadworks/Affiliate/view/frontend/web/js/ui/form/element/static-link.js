define([
    'Magento_Ui/js/form/element/abstract',
    'underscore',
    'mage/translate'
], function (AbstractField, _, $t) {
    'use strict';

    return AbstractField.extend({
        defaults: {
            staticLinkUrl: ''
        },

        /**
         * @inheritdoc
         */
        getInitialValue: function () {
            var initialValue = this._super();

            return this.prepareStaticLink(initialValue);
        },

        /**
         * Prepare static link
         */
        prepareStaticLink: function (value) {
            var translatedValue = $t(value);
            return translatedValue.replace('{static_link_url}', this.staticLinkUrl);
        }
    });
});