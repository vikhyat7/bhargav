<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Api;

/**
 * Interface BoundCustomersRepositoryInterface
 *
 * @package Aheadworks\Affiliate\Api
 */
interface BoundCustomerRepositoryInterface
{
    /**
     * Save bound customer
     *
     * @param \Aheadworks\Affiliate\Api\Data\BoundCustomerInterface $boundCustomer
     * @return \Aheadworks\Affiliate\Api\Data\BoundCustomerInterface $boundCustomer
     * @throws \Magento\Framework\Exception\CouldNotSaveException
     */
    public function save(\Aheadworks\Affiliate\Api\Data\BoundCustomerInterface $boundCustomer);

    /**
     * Retrieve bound customer by id
     *
     * @param int $boundId
     * @return \Aheadworks\Affiliate\Api\Data\BoundCustomerInterface
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getById($boundId);

    /**
     * Retrieve bound customers matching the specified criteria
     *
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Aheadworks\Affiliate\Api\Data\BoundCustomerSearchResultsInterface
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria);
}
