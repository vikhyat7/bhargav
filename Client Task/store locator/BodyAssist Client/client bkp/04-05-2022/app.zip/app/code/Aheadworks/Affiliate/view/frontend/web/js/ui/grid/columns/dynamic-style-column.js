define([
    'underscore',
    'Magento_Ui/js/grid/columns/column'
], function (_, Component) {
    'use strict';

    return Component.extend({
        defaults: {
            additionalClassFieldname: ''
        },

        /**
         * Returns list of classes that should be applied to a field.
         *
         * @param {Object} record
         * @returns {Object}
         */
        getFieldClass: function (record) {
            var currentFieldClass = {},
                additionalClassArray = {};
            if (!_.isUndefined(this.additionalClassFieldname)
                && !_.isUndefined(record[this.additionalClassFieldname])
            ) {
                var additionalClass = record[this.additionalClassFieldname];
                additionalClassArray[additionalClass] = true;
            }
            _.extend(currentFieldClass, this._super(), additionalClassArray);
            return currentFieldClass;
        }
    });
});
