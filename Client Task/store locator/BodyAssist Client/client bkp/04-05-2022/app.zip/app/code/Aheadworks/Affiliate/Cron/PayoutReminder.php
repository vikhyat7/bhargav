<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Cron;

use Aheadworks\Affiliate\Api\Data\PayoutInterface;
use Aheadworks\Affiliate\Api\PayoutRepositoryInterface;
use Aheadworks\Affiliate\Model\Config;
use Aheadworks\Affiliate\Model\Payout\Reminder\Sender as RemindersSender;
use Aheadworks\Affiliate\Model\Source\Payout\Status;
use Aheadworks\Affiliate\Model\Source\Payout\Type;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Stdlib\DateTime\DateTime;

/**
 * Class PayoutReminder
 * @package Aheadworks\Affiliate\Cron
 */
class PayoutReminder extends CronAbstract
{
    const SECONDS_IN_DAY = 86400;

    /**
     * @var PayoutRepositoryInterface
     */
    private $payoutRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    private $searchCriteriaBuilder;

    /**
     * @var RemindersSender
     */
    private $remindersSender;

    /**
     * @param Config $config
     * @param DateTime $dateTime
     * @param PayoutRepositoryInterface $payoutRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param RemindersSender $remindersSender
     */
    public function __construct(
        Config $config,
        DateTime $dateTime,
        PayoutRepositoryInterface $payoutRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        RemindersSender $remindersSender
    ) {
        parent::__construct($config, $dateTime);
        $this->payoutRepository = $payoutRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->remindersSender = $remindersSender;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        if (!$this->isNeedToSendReminders()) {
            return $this;
        }

        $this->remindersSender->remindAboutPendingPayouts();
        $this->config->setSendPayoutReminderLastExecTime($this->getCurrentTime());

        return $this;
    }

    /**
     * Check is need to send reminders
     *
     * @return bool
     */
    private function isNeedToSendReminders()
    {
        return $this->config->isAdminPayoutRemindersEnabled()
            && !$this->isLocked($this->config->getSendPayoutReminderLastExecTime(), $this->getRunInterval())
            && $this->getCountPayoutsToProcess() > 0;
    }

    /**
     * Get run interval
     *
     * @return int
     */
    private function getRunInterval()
    {
        $configIntervalDays = $this->config->getPayoutCreationPeriodInDays();

        return $configIntervalDays * self::SECONDS_IN_DAY - self::INTERVAL_BETWEEN_JOBS;
    }

    /**
     * Get count of payout to process
     *
     * @return int
     */
    private function getCountPayoutsToProcess()
    {
        $searchCriteria = $this->searchCriteriaBuilder
            ->addFilter(PayoutInterface::TYPE, Type::AUTO)
            ->addFilter(PayoutInterface::STATUS, Status::PENDING)
            ->create();

        return count($this->payoutRepository->getList($searchCriteria)->getItems());
    }
}
