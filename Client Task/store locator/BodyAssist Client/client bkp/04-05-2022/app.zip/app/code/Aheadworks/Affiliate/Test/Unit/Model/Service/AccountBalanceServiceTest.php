<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Model\Service;

use PHPUnit\Framework\TestCase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Aheadworks\Affiliate\Model\Service\AccountBalanceService;
use Aheadworks\Affiliate\Model\Account\Balance\UpdatersPool;
use Aheadworks\Affiliate\Model\Account\Balance\Repository as AccountBalanceRepository;
use Aheadworks\Affiliate\Model\Account\Balance\Factory as BalanceFactory;
use Aheadworks\Affiliate\Api\Data\Account\BalanceInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\CouldNotSaveException;
use Aheadworks\Affiliate\Api\Data\TransactionInterface;
use Aheadworks\Affiliate\Model\Account\Balance\UpdaterInterface;
use Aheadworks\Affiliate\Model\Source\Transaction\Type as TransactionType;
use Aheadworks\Affiliate\Model\Source\Transaction\Status as TransactionStatus;

/**
 * Test for \Aheadworks\Affiliate\Model\Service\AccountBalanceService
 */
class AccountBalanceServiceTest extends TestCase
{
    /**
     * @var AccountBalanceService
     */
    private $model;

    /**
     * @var UpdatersPool|\PHPUnit_Framework_MockObject_MockObject
     */
    private $updatersPoolMock;

    /**
     * @var AccountBalanceRepository|\PHPUnit_Framework_MockObject_MockObject
     */
    private $accountBalanceRepositoryMock;

    /**
     * @var BalanceFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $balanceFactoryMock;

    /**
     * Init mocks for tests
     *
     * @return void
     */
    public function setUp() : void
    {
        $objectManager = new ObjectManager($this);

        $this->updatersPoolMock = $this->createMock(UpdatersPool::class);
        $this->accountBalanceRepositoryMock = $this->createMock(AccountBalanceRepository::class);
        $this->balanceFactoryMock = $this->createMock(BalanceFactory::class);

        $this->model = $objectManager->getObject(
            AccountBalanceService::class,
            [
                'updatersPool' => $this->updatersPoolMock,
                'accountBalanceRepository' => $this->accountBalanceRepositoryMock,
                'balanceFactory' => $this->balanceFactoryMock,
            ]
        );
    }

    /**
     * Test initializeBalance
     */
    public function testInitializeBalanceSuccessfully()
    {
        $accountId = 1;
        $balanceObjectMock = $this->createMock(BalanceInterface::class);
        $balanceObjectMock->expects($this->once())
            ->method('setAffiliateId')
            ->with($accountId)
            ->willReturnSelf();
        $this->balanceFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($balanceObjectMock);
        $this->accountBalanceRepositoryMock->expects($this->once())
            ->method('save')
            ->with($balanceObjectMock)
            ->willReturn($balanceObjectMock);

        $this->model->initializeBalance($accountId);
    }

    /**
     * Test initializeBalance with throwing exception
     *
     * @param int $accountId
     * @param string $errorMessage
     * @dataProvider initializeBalanceWithExceptionProvider
     */
    public function testInitializeBalanceWithException($accountId, $errorMessage)
    {
        $balanceObjectMock = $this->createMock(BalanceInterface::class);
        $balanceObjectMock->expects($this->once())
            ->method('setAffiliateId')
            ->with($accountId)
            ->willReturnSelf();
        $this->balanceFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($balanceObjectMock);
        $this->accountBalanceRepositoryMock->expects($this->once())
            ->method('save')
            ->with($balanceObjectMock)
            ->willThrowException(new CouldNotSaveException(__($errorMessage)));

        try {
            $this->model->initializeBalance($accountId);
        } catch (CouldNotSaveException $exception) {
            $this->assertEquals($errorMessage, $exception->getMessage());
        }
    }

    /**
     * @return array
     */
    public function initializeBalanceWithExceptionProvider()
    {
        return [
            [
                'accountId' => null,
                'errorMessage' => 'Error!'
            ],
            [
                'accountId' => 0,
                'errorMessage' => 'Error!'
            ],
            [
                'accountId' => -1,
                'errorMessage' => 'Error!'
            ],
            [
                'accountId' => 100500,
                'errorMessage' => 'Error!'
            ],
        ];
    }

    /**
     * Test getBalance
     */
    public function testGetBalance()
    {
        $accountId = 1;
        $balanceObjectMock = $this->createMock(BalanceInterface::class);
        $balanceObjectMock->expects($this->never())
            ->method('setAffiliateId');
        $this->balanceFactoryMock->expects($this->never())
            ->method('create');
        $this->accountBalanceRepositoryMock->expects($this->once())
            ->method('getByAffiliateId')
            ->with($accountId)
            ->willReturn($balanceObjectMock);

        $this->assertSame($balanceObjectMock, $this->model->getBalance($accountId));
    }

    /**
     * Test getBalance for missing balance record
     *
     * @param int $accountId
     * @param BalanceInterface $balance
     * @dataProvider getBalanceWithExceptionProvider
     */
    public function testGetBalanceWithException($accountId, $balance)
    {
        $this->accountBalanceRepositoryMock->expects($this->once())
            ->method('getByAffiliateId')
            ->with($accountId)
            ->willThrowException(new NoSuchEntityException());
        $this->balanceFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($balance);
        $this->assertSame($balance, $this->model->getBalance($accountId));
    }

    /**
     * @return array
     */
    public function getBalanceWithExceptionProvider()
    {
        $balanceObjectMock = $this->createMock(BalanceInterface::class);
        $balanceObjectMock->expects($this->any())
            ->method('setAffiliateId')
            ->willReturnSelf();
        return [
            [
                'accountId' => null,
                'balance' => $balanceObjectMock
            ],
            [
                'accountId' => 0,
                'balance' => $balanceObjectMock
            ],
            [
                'accountId' => -1,
                'balance' => $balanceObjectMock
            ],
            [
                'accountId' => 100500,
                'balance' => $balanceObjectMock
            ],
        ];
    }

    /**
     * Test updateBalance
     *
     * @param int $accountId
     * @param string $transactionType
     * @param string $transactionStatus
     * @param float $transactionAmount
     * @param UpdaterInterface|\PHPUnit_Framework_MockObject_MockObject|null $updater
     * @param BalanceInterface|\PHPUnit_Framework_MockObject_MockObject $balance
     * @param int $repositorySaveCallCount
     * @param bool $isExceptionThrown
     * @dataProvider updateBalanceProvider
     * @throws CouldNotSaveException
     */
    public function testUpdateBalance(
        $accountId,
        $transactionType,
        $transactionStatus,
        $transactionAmount,
        $updater,
        $balance,
        $repositorySaveCallCount,
        $isExceptionThrown
    ) {
        $transactionMock = $this->createMock(TransactionInterface::class);
        $transactionMock->expects($this->any())
            ->method('getType')
            ->willReturn($transactionType);
        $transactionMock->expects($this->any())
            ->method('getStatus')
            ->willReturn($transactionStatus);
        $transactionMock->expects($this->any())
            ->method('getAmount')
            ->willReturn($transactionAmount);

        $this->accountBalanceRepositoryMock->expects($this->once())
            ->method('getByAffiliateId')
            ->with($accountId)
            ->willThrowException(new NoSuchEntityException());
        $this->balanceFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($balance);

        $this->updatersPoolMock->expects($this->once())
            ->method('getUpdater')
            ->with($transactionType, $transactionStatus)
            ->willReturn($updater);

        if ($isExceptionThrown) {
            $errorMessage = 'Error!';
            $this->accountBalanceRepositoryMock->expects($this->exactly($repositorySaveCallCount))
                ->method('save')
                ->with($balance)
                ->willThrowException(new CouldNotSaveException(__($errorMessage)));
            try {
                $this->model->updateBalance($accountId, $transactionMock);
            } catch (CouldNotSaveException $exception) {
                $this->assertEquals($errorMessage, $exception->getMessage());
            }
        } else {
            $this->accountBalanceRepositoryMock->expects($this->exactly($repositorySaveCallCount))
                ->method('save')
                ->with($balance)
                ->willReturn($balance);
            $this->assertTrue($this->model->updateBalance($accountId, $transactionMock));
        }
    }

    /**
     * @return array
     */
    public function updateBalanceProvider()
    {
        $balanceMock = $this->createMock(BalanceInterface::class);
        $balanceMock->expects($this->any())
            ->method('setAffiliateId')
            ->willReturnSelf();
        $updaterMock = $this->createMock(UpdaterInterface::class);
        $updaterMock->expects($this->any())
            ->method('update')
            ->willReturn($balanceMock);
        return [
            [
                'accountId' => 1,
                'transactionType' => TransactionType::ADMIN_CHANGES,
                'transactionStatus' => TransactionStatus::COMPLETE,
                'transactionAmount' => 100,
                'updater' => $updaterMock,
                'balance' => $balanceMock,
                'repositorySaveCallCount' => 1,
                'isExceptionThrown' => false
            ],
            [
                'accountId' => 1,
                'transactionType' => TransactionType::ADMIN_CHANGES,
                'transactionStatus' => TransactionStatus::PENDING,
                'transactionAmount' => 100,
                'updater' => null,
                'balance' => $balanceMock,
                'repositorySaveCallCount' => 0,
                'isExceptionThrown' => false
            ],
            [
                'accountId' => 1,
                'transactionType' => TransactionType::ADMIN_CHANGES,
                'transactionStatus' => TransactionStatus::CANCELED,
                'transactionAmount' => 100,
                'updater' => null,
                'balance' => $balanceMock,
                'repositorySaveCallCount' => 0,
                'isExceptionThrown' => false
            ],
            [
                'accountId' => 1,
                'transactionType' => TransactionType::COMMISSION,
                'transactionStatus' => TransactionStatus::PENDING,
                'transactionAmount' => 100,
                'updater' => $updaterMock,
                'balance' => $balanceMock,
                'repositorySaveCallCount' => 1,
                'isExceptionThrown' => false
            ],
            [
                'accountId' => 1,
                'transactionType' => TransactionType::COMMISSION,
                'transactionStatus' => TransactionStatus::COMPLETE,
                'transactionAmount' => 100,
                'updater' => $updaterMock,
                'balance' => $balanceMock,
                'repositorySaveCallCount' => 1,
                'isExceptionThrown' => false
            ],
            [
                'accountId' => 1,
                'transactionType' => TransactionType::COMMISSION,
                'transactionStatus' => TransactionStatus::CANCELED,
                'transactionAmount' => 100,
                'updater' => $updaterMock,
                'balance' => $balanceMock,
                'repositorySaveCallCount' => 1,
                'isExceptionThrown' => false
            ],
            [
                'accountId' => 1,
                'transactionType' => TransactionType::PAYOUT,
                'transactionStatus' => TransactionStatus::PENDING,
                'transactionAmount' => 100,
                'updater' => $updaterMock,
                'balance' => $balanceMock,
                'repositorySaveCallCount' => 1,
                'isExceptionThrown' => false
            ],
            [
                'accountId' => 1,
                'transactionType' => TransactionType::PAYOUT,
                'transactionStatus' => TransactionStatus::COMPLETE,
                'transactionAmount' => 100,
                'updater' => $updaterMock,
                'balance' => $balanceMock,
                'repositorySaveCallCount' => 1,
                'isExceptionThrown' => false
            ],
            [
                'accountId' => 1,
                'transactionType' => TransactionType::PAYOUT,
                'transactionStatus' => TransactionStatus::CANCELED,
                'transactionAmount' => 100,
                'updater' => $updaterMock,
                'balance' => $balanceMock,
                'repositorySaveCallCount' => 1,
                'isExceptionThrown' => false
            ],
            [
                'accountId' => 1,
                'transactionType' => 'some_wrong_type',
                'transactionStatus' => TransactionStatus::PENDING,
                'transactionAmount' => 100,
                'updater' => null,
                'balance' => $balanceMock,
                'repositorySaveCallCount' => 0,
                'isExceptionThrown' => false
            ],
            [
                'accountId' => 1,
                'transactionType' => TransactionType::PAYOUT,
                'transactionStatus' => 'some_wrong_status',
                'transactionAmount' => 100,
                'updater' => null,
                'balance' => $balanceMock,
                'repositorySaveCallCount' => 0,
                'isExceptionThrown' => false
            ],
            [
                'accountId' => null,
                'transactionType' => TransactionType::COMMISSION,
                'transactionStatus' => TransactionStatus::COMPLETE,
                'transactionAmount' => 100,
                'updater' => $updaterMock,
                'balance' => $balanceMock,
                'repositorySaveCallCount' => 1,
                'isExceptionThrown' => true
            ],
        ];
    }
}
