<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Signup;

use Aheadworks\Affiliate\Api\Data\SignupInterface;
use Aheadworks\Affiliate\Api\SignupManagementInterface;
use Aheadworks\Affiliate\Model\Source\Signup\Status;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Backend\App\Action;

/**
 * Class Save
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Signup
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Save extends Action
{
    /**
     * {@inheritdoc}
     */
    const ADMIN_RESOURCE = 'Aheadworks_Affiliate::signups';

    /**
     * New status request param
     */
    const NEW_STATUS_PARAM = 'new_status';

    /**
     * @var DataPersistorInterface
     */
    private $dataPersistor;

    /**
     * @var SignupManagementInterface
     */
    private $signupManagement;

    /**.
     * @param Context $context
     * @param DataPersistorInterface $dataPersistor
     * @param SignupManagementInterface $signupManagement
     */
    public function __construct(
        Context $context,
        DataPersistorInterface $dataPersistor,
        SignupManagementInterface $signupManagement
    ) {
        parent::__construct($context);
        $this->dataPersistor = $dataPersistor;
        $this->signupManagement = $signupManagement;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($postData = $this->getRequest()->getPostValue()) {
            try {
                $newStatus = $this->getRequest()->getParam(self::NEW_STATUS_PARAM);
                $this->performChangeStatus($postData, $newStatus);
                $message = $this->getSuccessMessage($newStatus);
                $this->dataPersistor->clear('aw_affiliate_signup_form');
                $this->messageManager->addSuccessMessage($message);
                return $resultRedirect->setPath('*/*/');
            } catch (CouldNotSaveException $exception) {
                $this->messageManager->addErrorMessage($exception->getMessage());
            } catch (\Exception $exception) {
                $this->messageManager->addExceptionMessage(
                    $exception,
                    __('Something went wrong while saving the signup request.')
                );
            }
            $this->dataPersistor->set('aw_affiliate_signup_form', $postData);
            if (isset($postData[SignupInterface::ID])) {
                return $resultRedirect->setPath(
                    '*/*/edit',
                    [SignupInterface::ID => $postData[SignupInterface::ID], '_current' => true]
                );
            }
        }
        return $resultRedirect->setPath('*/*/');
    }

    /**
     * Perform change signup status
     *
     * @param array $postData
     * @param int $newStatus
     * @throws CouldNotSaveException
     */
    private function performChangeStatus($postData, $newStatus)
    {
        $signupId = $this->getSignupId($postData);
        $declineReason = $this->getDeclineReason($postData);

        if ($newStatus == Status::APPROVED) {
            $this->signupManagement->approveSignup($signupId);
        } elseif ($newStatus == Status::DECLINED) {
            $this->signupManagement->declineSignup($signupId, $declineReason);
        }
    }

    /**
     * Retrieve signup id
     *
     * @param array $postData
     * @return int|null
     */
    private function getSignupId($postData)
    {
        return isset($postData[SignupInterface::ID])
            ? $postData[SignupInterface::ID]
            : null;
    }

    /**
     * Retrieve decline message
     *
     * @param array $postData
     * @return string
     */
    private function getDeclineReason($postData)
    {
        return isset($postData[SignupInterface::DECLINE_REASON])
            ? $postData[SignupInterface::DECLINE_REASON]
            : '';
    }

    /**
     * Get success message by new status
     *
     * @param int $newStatus
     * @return \Magento\Framework\Phrase|string
     */
    private function getSuccessMessage($newStatus)
    {
        $message = '';

        if ($newStatus == Status::APPROVED) {
            $message = __('The signup request was successfully approved.');
        } elseif ($newStatus == Status::DECLINED) {
            $message = __('The signup request was successfully declined.');
        }

        return $message;
    }
}
