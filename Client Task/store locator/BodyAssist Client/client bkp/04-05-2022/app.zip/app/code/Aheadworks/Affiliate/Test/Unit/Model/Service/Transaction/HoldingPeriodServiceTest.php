<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Model\Service\Transaction;

use Magento\Framework\Exception\CouldNotSaveException;
use PHPUnit\Framework\TestCase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Aheadworks\Affiliate\Model\Service\Transaction\HoldingPeriodService;
use Aheadworks\Affiliate\Api\Data\TransactionInterface;
use Aheadworks\Affiliate\Api\TransactionManagementInterface;
use Aheadworks\Affiliate\Model\Transaction\HoldingPeriod\DataProvider as TransactionHoldingPeriodDataProvider;
use Aheadworks\Affiliate\Model\Source\Transaction\Status as TransactionStatus;
use Aheadworks\Affiliate\Model\Order\Item\Checker as OrderItemChecker;
use Magento\Sales\Model\Order\Item as OrderItem;

/**
 * Test for \Aheadworks\Affiliate\Model\Service\Transaction\HoldingPeriodService
 */
class HoldingPeriodServiceTest extends TestCase
{
    /**
     * @var HoldingPeriodService
     */
    private $model;

    /**
     * @var OrderItemChecker|\PHPUnit_Framework_MockObject_MockObject
     */
    private $orderItemCheckerMock;

    /**
     * @var TransactionManagementInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $transactionServiceMock;

    /**
     * @var TransactionHoldingPeriodDataProvider|\PHPUnit_Framework_MockObject_MockObject
     */
    private $transactionHoldingPeriodDataProviderMock;

    /**
     * Init mocks for tests
     *
     * @return void
     */
    public function setUp() : void
    {
        $objectManager = new ObjectManager($this);

        $this->orderItemCheckerMock = $this->createMock(OrderItemChecker::class);
        $this->transactionServiceMock = $this->createMock(TransactionManagementInterface::class);
        $this->transactionHoldingPeriodDataProviderMock = $this->createMock(
            TransactionHoldingPeriodDataProvider::class
        );

        $this->model = $objectManager->getObject(
            HoldingPeriodService::class,
            [
                'orderItemChecker' => $this->orderItemCheckerMock,
                'transactionService' => $this->transactionServiceMock,
                'transactionHoldingPeriodDataProvider' => $this->transactionHoldingPeriodDataProviderMock
            ]
        );
    }

    /**
     *  Test processExpiredTransactions when no expired transactions detected
     */
    public function testProcessExpiredTransactionsNoExpiredTransactions()
    {
        $expiredTransactions = [];

        $this->transactionHoldingPeriodDataProviderMock->expects($this->once())
            ->method('getExpiredTransactionsToProcess')
            ->willReturn($expiredTransactions);

        $this->transactionServiceMock->expects($this->never())
            ->method('updateTransactionStatus');

        $this->model->processExpiredTransactions();
    }

    /**
     *  Test processExpiredTransactions
     */
    public function testProcessExpiredTransactions()
    {
        $firstTransactionId = 10;
        $secondTransactionId = 18;
        $firstExpiredTransaction = $this->createMock(TransactionInterface::class);
        $firstExpiredTransaction->expects($this->once())
            ->method('getTransactionId')
            ->willReturn($firstTransactionId);
        $secondExpiredTransaction = $this->createMock(TransactionInterface::class);
        $secondExpiredTransaction->expects($this->once())
            ->method('getTransactionId')
            ->willReturn($secondTransactionId);
        $expiredTransactions = [
            $firstExpiredTransaction,
            $secondExpiredTransaction
        ];

        $this->transactionHoldingPeriodDataProviderMock->expects($this->once())
            ->method('getExpiredTransactionsToProcess')
            ->willReturn($expiredTransactions);

        $this->transactionServiceMock->expects($this->exactly(2))
            ->method('updateTransactionStatus')
            ->willReturnMap(
                [
                    [
                        $firstTransactionId,
                        TransactionStatus::COMPLETE,
                        $firstExpiredTransaction
                    ],
                    [
                        $secondTransactionId,
                        TransactionStatus::COMPLETE,
                        $secondExpiredTransaction
                    ],
                ]
            );

        $this->model->processExpiredTransactions();
    }

    /**
     * Test processExpiredTransactions with throwing exception
     * @expectedException \Magento\Framework\Exception\CouldNotSaveException
     * @expectedExceptionMessage This status can't be set to transaction.
     */
    public function testProcessExpiredTransactionsWithExceptionOnWrongStatus()
    {
        $firstTransactionId = 10;
        $secondTransactionId = 18;
        $firstExpiredTransaction = $this->createMock(TransactionInterface::class);
        $firstExpiredTransaction->expects($this->once())
            ->method('getTransactionId')
            ->willReturn($firstTransactionId);
        $secondExpiredTransaction = $this->createMock(TransactionInterface::class);
        $secondExpiredTransaction->expects($this->never())
            ->method('getTransactionId')
            ->willReturn($secondTransactionId);
        $expiredTransactions = [
            $firstExpiredTransaction,
            $secondExpiredTransaction
        ];

        $this->transactionHoldingPeriodDataProviderMock->expects($this->once())
            ->method('getExpiredTransactionsToProcess')
            ->willReturn($expiredTransactions);

        $this->transactionServiceMock->expects($this->once())
            ->method('updateTransactionStatus')
            ->with($firstTransactionId, TransactionStatus::COMPLETE)
            ->willThrowException(new CouldNotSaveException(__('This status can\'t be set to transaction.')));
        $this->expectException(CouldNotSaveException::class);
        $this->model->processExpiredTransactions();
    }

    /**
     * Test processExpiredTransactions with throwing exception
     * @expectedException \Magento\Framework\Exception\CouldNotSaveException
     * @expectedExceptionMessage Error!
     */
    public function testProcessExpiredTransactionsWithExceptionOnSaving()
    {
        $firstTransactionId = 10;
        $secondTransactionId = 18;
        $firstExpiredTransaction = $this->createMock(TransactionInterface::class);
        $firstExpiredTransaction->expects($this->once())
            ->method('getTransactionId')
            ->willReturn($firstTransactionId);
        $secondExpiredTransaction = $this->createMock(TransactionInterface::class);
        $secondExpiredTransaction->expects($this->never())
            ->method('getTransactionId')
            ->willReturn($secondTransactionId);
        $expiredTransactions = [
            $firstExpiredTransaction,
            $secondExpiredTransaction
        ];

        $this->transactionHoldingPeriodDataProviderMock->expects($this->once())
            ->method('getExpiredTransactionsToProcess')
            ->willReturn($expiredTransactions);

        $this->transactionServiceMock->expects($this->once())
            ->method('updateTransactionStatus')
            ->with($firstTransactionId, TransactionStatus::COMPLETE)
            ->willThrowException(new CouldNotSaveException(__('Error!')));
        $this->expectException(CouldNotSaveException::class);
        $this->model->processExpiredTransactions();
    }

    /**
     * Test processUnexpiredTransactionsByOrderItem when no need to process order item
     *
     * @param OrderItem $orderItem
     * @param bool $isTransactionCreated
     * @param bool $isTransactionCancellationAllowed
     * @throws CouldNotSaveException
     * @dataProvider processUnexpiredTransactionsByOrderItemNoNeedToProcessProvider
     */
    public function testProcessUnexpiredTransactionsByOrderItemNoNeedToProcess(
        $orderItem,
        $isTransactionCreated,
        $isTransactionCancellationAllowed
    ) {
        $this->orderItemCheckerMock->expects($this->once())
            ->method('isTransactionCreated')
            ->with($orderItem)
            ->willReturn($isTransactionCreated);

        $this->orderItemCheckerMock->expects($this->any())
            ->method('isTransactionCancellationAllowed')
            ->with($orderItem)
            ->willReturn($isTransactionCancellationAllowed);

        $this->transactionHoldingPeriodDataProviderMock->expects($this->never())
            ->method('getUnexpiredTransactionsByOrderItem');

        $this->transactionServiceMock->expects($this->never())
            ->method('updateTransactionStatus');

        $this->model->processUnexpiredTransactionsByOrderItem($orderItem);
    }

    /**
     * @return array
     */
    public function processUnexpiredTransactionsByOrderItemNoNeedToProcessProvider()
    {
        $orderItemMock = $this->createMock(OrderItem::class);
        return [
            [
                'orderItem' => $orderItemMock,
                'isTransactionCreated' => false,
                'isTransactionCancellationAllowed' => false,
            ],
            [
                'orderItem' => $orderItemMock,
                'isTransactionCreated' => false,
                'isTransactionCancellationAllowed' => true,
            ],
            [
                'orderItem' => $orderItemMock,
                'isTransactionCreated' => true,
                'isTransactionCancellationAllowed' => false,
            ],
        ];
    }

    /**
     * Test processUnexpiredTransactionsByOrderItem when no unexpired transaction found
     *
     * @throws CouldNotSaveException
     */
    public function testProcessUnexpiredTransactionsNoUnexpiredTransaction()
    {
        $orderItemMock = $this->createMock(OrderItem::class);
        $isTransactionCreated = true;
        $isTransactionCancellationAllowed = true;
        $unexpiredTransactions = [];

        $this->orderItemCheckerMock->expects($this->once())
            ->method('isTransactionCreated')
            ->with($orderItemMock)
            ->willReturn($isTransactionCreated);

        $this->orderItemCheckerMock->expects($this->any())
            ->method('isTransactionCancellationAllowed')
            ->with($orderItemMock)
            ->willReturn($isTransactionCancellationAllowed);

        $this->transactionHoldingPeriodDataProviderMock->expects($this->once())
            ->method('getUnexpiredTransactionsByOrderItem')
            ->with($orderItemMock)
            ->willReturn($unexpiredTransactions);

        $this->transactionServiceMock->expects($this->never())
            ->method('updateTransactionStatus');

        $this->model->processUnexpiredTransactionsByOrderItem($orderItemMock);
    }

    /**
     * Test processUnexpiredTransactionsByOrderItem
     *
     * @throws CouldNotSaveException
     */
    public function testProcessUnexpiredTransactions()
    {
        $orderItemMock = $this->createMock(OrderItem::class);
        $isTransactionCreated = true;
        $isTransactionCancellationAllowed = true;
        $unexpiredTransactionId = 7;
        $unexpiredTransaction = $this->createMock(TransactionInterface::class);
        $unexpiredTransaction->expects($this->once())
            ->method('getTransactionId')
            ->willReturn($unexpiredTransactionId);
        $unexpiredTransactions = [$unexpiredTransaction];

        $this->orderItemCheckerMock->expects($this->once())
            ->method('isTransactionCreated')
            ->with($orderItemMock)
            ->willReturn($isTransactionCreated);

        $this->orderItemCheckerMock->expects($this->any())
            ->method('isTransactionCancellationAllowed')
            ->with($orderItemMock)
            ->willReturn($isTransactionCancellationAllowed);

        $this->transactionHoldingPeriodDataProviderMock->expects($this->once())
            ->method('getUnexpiredTransactionsByOrderItem')
            ->with($orderItemMock)
            ->willReturn($unexpiredTransactions);

        $this->transactionServiceMock->expects($this->once())
            ->method('updateTransactionStatus')
            ->with($unexpiredTransactionId, TransactionStatus::CANCELED)
            ->willReturn($unexpiredTransaction);

        $this->model->processUnexpiredTransactionsByOrderItem($orderItemMock);
    }

    /**
     * Test processUnexpiredTransactionsByOrderItem
     *
     * @expectedException \Magento\Framework\Exception\CouldNotSaveException
     * @expectedExceptionMessage This status can't be set to transaction.
     */
    public function testProcessUnexpiredTransactionsWithExceptionOnWrongStatus()
    {
        $orderItemMock = $this->createMock(OrderItem::class);
        $isTransactionCreated = true;
        $isTransactionCancellationAllowed = true;
        $unexpiredTransactionId = 7;
        $unexpiredTransaction = $this->createMock(TransactionInterface::class);
        $unexpiredTransaction->expects($this->once())
            ->method('getTransactionId')
            ->willReturn($unexpiredTransactionId);
        $unexpiredTransactions = [$unexpiredTransaction];

        $this->orderItemCheckerMock->expects($this->once())
            ->method('isTransactionCreated')
            ->with($orderItemMock)
            ->willReturn($isTransactionCreated);

        $this->orderItemCheckerMock->expects($this->any())
            ->method('isTransactionCancellationAllowed')
            ->with($orderItemMock)
            ->willReturn($isTransactionCancellationAllowed);

        $this->transactionHoldingPeriodDataProviderMock->expects($this->once())
            ->method('getUnexpiredTransactionsByOrderItem')
            ->with($orderItemMock)
            ->willReturn($unexpiredTransactions);

        $this->transactionServiceMock->expects($this->once())
            ->method('updateTransactionStatus')
            ->with($unexpiredTransactionId, TransactionStatus::CANCELED)
            ->willThrowException(new CouldNotSaveException(__('This status can\'t be set to transaction.')));
        $this->expectException(CouldNotSaveException::class);
        $this->model->processUnexpiredTransactionsByOrderItem($orderItemMock);
    }

    /**
     * Test processUnexpiredTransactionsByOrderItem
     *
     * @expectedException \Magento\Framework\Exception\CouldNotSaveException
     * @expectedExceptionMessage Error!
     */
    public function testProcessUnexpiredTransactionsWithExceptionOnSaving()
    {
        $orderItemMock = $this->createMock(OrderItem::class);
        $isTransactionCreated = true;
        $isTransactionCancellationAllowed = true;
        $unexpiredTransactionId = 7;
        $unexpiredTransaction = $this->createMock(TransactionInterface::class);
        $unexpiredTransaction->expects($this->once())
            ->method('getTransactionId')
            ->willReturn($unexpiredTransactionId);
        $unexpiredTransactions = [$unexpiredTransaction];

        $this->orderItemCheckerMock->expects($this->once())
            ->method('isTransactionCreated')
            ->with($orderItemMock)
            ->willReturn($isTransactionCreated);

        $this->orderItemCheckerMock->expects($this->any())
            ->method('isTransactionCancellationAllowed')
            ->with($orderItemMock)
            ->willReturn($isTransactionCancellationAllowed);

        $this->transactionHoldingPeriodDataProviderMock->expects($this->once())
            ->method('getUnexpiredTransactionsByOrderItem')
            ->with($orderItemMock)
            ->willReturn($unexpiredTransactions);

        $this->transactionServiceMock->expects($this->once())
            ->method('updateTransactionStatus')
            ->with($unexpiredTransactionId, TransactionStatus::CANCELED)
            ->willThrowException(new CouldNotSaveException(__('Error!')));
        $this->expectException(CouldNotSaveException::class);
        $this->model->processUnexpiredTransactionsByOrderItem($orderItemMock);
    }
}
