<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Model;

use Aheadworks\Affiliate\Api\CouponRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Aheadworks\Affiliate\Api\Data\CampaignInterface;
use Aheadworks\Affiliate\Api\Data\CouponInterface;
use Aheadworks\Affiliate\Model\Coupon\Generator;
use Aheadworks\Affiliate\Model\Coupon\SalesRuleManager;
use Aheadworks\Affiliate\Model\Coupon\Resolver as CouponResolver;
use Aheadworks\Affiliate\Model\CouponManager;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;

/**
 * Class CouponManagerTest
 * @package Aheadworks\Affiliate\Test\Unit\Model
 */
class CouponManagerTest extends TestCase
{
    /**
     * @var Generator|\PHPUnit_Framework_MockObject_MockObject
     */
    private $generatorMock;

    /**
     * @var SalesRuleManager|\PHPUnit_Framework_MockObject_MockObject
     */
    private $salesRuleManagerMock;

    /**
     * @var CouponResolver|\PHPUnit_Framework_MockObject_MockObject
     */
    private $couponResolverMock;

    /**
     * @var CouponRepositoryInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $couponRepositoryMock;

    /**
     * @var CouponManager
     */
    private $couponManager;

    /**#@+
     * Constants used for tests
     */
    const DEFAULT_ID = 1;
    /**#@-*/

    /**
     * Init mocks for tests
     *
     * @return void
     */
    protected function setUp() : void
    {
        $objectManager = new ObjectManager($this);
        $this->generatorMock = $this->createMock(Generator::class);
        $this->salesRuleManagerMock = $this->createMock(SalesRuleManager::class);
        $this->couponResolverMock = $this->createMock(CouponResolver::class);
        $this->couponRepositoryMock = $this->createMock(CouponRepositoryInterface::class);
        $this->couponManager = $objectManager->getObject(
            CouponManager::class,
            [
                'generator' => $this->generatorMock,
                'salesRuleManager' => $this->salesRuleManagerMock,
                'couponResolver' => $this->couponResolverMock,
                'couponRepository' => $this->couponRepositoryMock
            ]
        );
    }

    /**
     * Test updateCoupons method
     *
     * @param int|null $salesRuleId
     * @throws LocalizedException
     * @dataProvider salesRuleIdProvider
     */
    public function testUpdateCoupons($salesRuleId = null)
    {
        $callsCount = $salesRuleId ? 1 : 0;
        $campaignMock = $this->getCampaignMock();

        $this->couponResolverMock->expects($this->once())
            ->method('getSalesRuleIdByCampaignId')
            ->with(self::DEFAULT_ID)
            ->willReturn($salesRuleId);
        $this->salesRuleManagerMock->expects($this->exactly($callsCount))
            ->method('saveSalesRule')
            ->with($campaignMock, $salesRuleId);

        $this->couponManager->updateCoupons($campaignMock);
    }

    /**
     * Test updateCoupons method with exception
     *
     * @param InputException|LocalizedException|NoSuchEntityException $exception
     * @param string $exceptionClass
     * @param string $exceptionMsg
     * @throws LocalizedException
     * @dataProvider testUpdateCouponsWithExceptionProvider
     */
    public function testUpdateCouponsWithException($exception, $exceptionClass, $exceptionMsg)
    {
        $salesRuleId = self::DEFAULT_ID;
        $campaignMock = $this->getCampaignMock();

        $this->couponResolverMock->expects($this->once())
            ->method('getSalesRuleIdByCampaignId')
            ->with(self::DEFAULT_ID)
            ->willReturn($salesRuleId);
        $this->salesRuleManagerMock->expects($this->once())
            ->method('saveSalesRule')
            ->with($campaignMock, $salesRuleId)
            ->willThrowException($exception);

        $this->expectException($exceptionClass);
        $this->expectExceptionMessage($exceptionMsg);

        $this->couponManager->updateCoupons($campaignMock);
    }

    /**
     * Test deleteCouponsByCampaign method
     *
     * @param int|null $salesRuleId
     * @throws LocalizedException
     * @dataProvider salesRuleIdProvider
     */
    public function testDeleteCouponsByCampaign($salesRuleId = null)
    {
        $callsCount = $salesRuleId ? 1 : 0;
        $campaignMock = $this->getCampaignMock();

        $this->couponResolverMock->expects($this->once())
            ->method('getSalesRuleIdByCampaignId')
            ->with(self::DEFAULT_ID)
            ->willReturn($salesRuleId);
        $this->salesRuleManagerMock->expects($this->exactly($callsCount))
            ->method('deleteSalesRule')
            ->with($salesRuleId);

        $this->couponManager->deleteCouponsByCampaign($campaignMock);
    }

    /**
     * Test deleteCouponsByCampaign method with exception
     *
     * @param LocalizedException|NoSuchEntityException $exception
     * @param string $exceptionClass
     * @param string $exceptionMsg
     * @throws LocalizedException
     * @dataProvider testDeleteCouponsByCampaignWithExceptionProvider
     */
    public function testDeleteCouponsByCampaignWithException($exception, $exceptionClass, $exceptionMsg)
    {
        $salesRuleId = self::DEFAULT_ID;
        $campaignMock = $this->getCampaignMock();

        $this->couponResolverMock->expects($this->once())
            ->method('getSalesRuleIdByCampaignId')
            ->with(self::DEFAULT_ID)
            ->willReturn($salesRuleId);
        $this->salesRuleManagerMock->expects($this->once())
            ->method('deleteSalesRule')
            ->with($salesRuleId)
            ->willThrowException($exception);

        $this->expectException($exceptionClass);
        $this->expectExceptionMessage($exceptionMsg);

        $this->couponManager->deleteCouponsByCampaign($campaignMock);
    }

    /**
     * Test deleteCouponsByAccount method
     *
     * @param CouponInterface[]|\PHPUnit_Framework_MockObject_MockObject[] $coupons
     * @throws LocalizedException
     * @dataProvider testDeleteCouponsByAccountProvider
     */
    public function testDeleteCouponsByAccount($coupons = [])
    {
        $callsCount = count($coupons);
        $accountMock = $this->getAccountMock();
        $couponMock = $this->createMock(CouponInterface::class);

        $this->couponResolverMock->expects($this->once())
            ->method('getCouponsByAffiliateId')
            ->with(self::DEFAULT_ID)
            ->willReturn($coupons);
        $this->couponRepositoryMock->expects($this->exactly($callsCount))
            ->method('delete')
            ->with($couponMock);

        $this->couponManager->deleteCouponsByAccount($accountMock);
    }

    /**
     * Test deleteCouponsByAccount method with exception
     *
     * @param LocalizedException $exception
     * @param string $exceptionClass
     * @param string $exceptionMsg
     * @throws LocalizedException
     * @dataProvider testDeleteCouponsByAccountWithExceptionProvider
     */
    public function testDeleteCouponsByAccountWithException($exception, $exceptionClass, $exceptionMsg)
    {
        $accountMock = $this->getAccountMock();
        $couponMock = $this->createMock(CouponInterface::class);
        $coupons = [$couponMock];

        $this->couponResolverMock->expects($this->once())
            ->method('getCouponsByAffiliateId')
            ->with(self::DEFAULT_ID)
            ->willReturn($coupons);
        $this->couponRepositoryMock->expects($this->once())
            ->method('delete')
            ->with($couponMock)
            ->willThrowException($exception);

        $this->expectException($exceptionClass);
        $this->expectExceptionMessage($exceptionMsg);

        $this->couponManager->deleteCouponsByAccount($accountMock);
    }

    /**
     * Test generateCoupon method
     *
     * @param int|null
     * @throws LocalizedException
     * @dataProvider salesRuleIdProvider
     */
    public function testGenerateCoupon($salesRuleId = null)
    {
        $accountMock = $this->getAccountMock();
        $campaignMock = $this->getCampaignMock();
        $couponMock = $this->createMock(CouponInterface::class);

        $this->couponResolverMock->expects($this->once())
            ->method('getSalesRuleIdByCampaignId')
            ->with(self::DEFAULT_ID)
            ->willReturn($salesRuleId);
        $this->generatorMock->expects($this->once())
            ->method('generateCoupon')
            ->with($accountMock, $campaignMock, $salesRuleId)
            ->willReturn($couponMock);

        $this->assertSame($couponMock, $this->couponManager->generateCoupon($accountMock, $campaignMock));
    }

    /**
     * Test generateCoupon method with exception
     *
     * @param InputException|LocalizedException|NoSuchEntityException $exception
     * @param string $exceptionClass
     * @param string $exceptionMsg
     * @throws LocalizedException
     * @dataProvider testGenerateCouponWithExceptionProvider
     */
    public function testGenerateCouponWithException($exception, $exceptionClass, $exceptionMsg)
    {
        $accountMock = $this->getAccountMock();
        $campaignMock = $this->getCampaignMock();
        $salesRuleId = self::DEFAULT_ID;

        $this->couponResolverMock->expects($this->once())
            ->method('getSalesRuleIdByCampaignId')
            ->with(self::DEFAULT_ID)
            ->willReturn($salesRuleId);
        $this->generatorMock->expects($this->once())
            ->method('generateCoupon')
            ->with($accountMock, $campaignMock, $salesRuleId)
            ->willThrowException($exception);

        $this->expectException($exceptionClass);
        $this->expectExceptionMessage($exceptionMsg);

        $this->couponManager->generateCoupon($accountMock, $campaignMock);
    }

    /**
     * Get campaign mock
     *
     * @return CampaignInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private function getCampaignMock()
    {
        $campaignMock = $this->createMock(CampaignInterface::class);

        $campaignMock->expects($this->atMost(1))
            ->method('getCampaignId')
            ->willReturn(self::DEFAULT_ID);

        return $campaignMock;
    }

    /**
     * Get account mock
     *
     * @return AccountInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private function getAccountMock()
    {
        $campaignMock = $this->createMock(AccountInterface::class);

        $campaignMock->expects($this->atMost(1))
            ->method('getAccountId')
            ->willReturn(self::DEFAULT_ID);

        return $campaignMock;
    }

    /**
     * @return array
     */
    public function salesRuleIdProvider()
    {
        return [
            [self::DEFAULT_ID],
            []
        ];
    }

    /**
     * @return array
     */
    private function getInputExceptionProvider()
    {
        return [
            [
                new InputException(__('Input exception message.')),
                InputException::class,
                'Input exception message.'
            ]
        ];
    }

    /**
     * @return array
     */
    private function getLocalizedExceptionProvider()
    {
        return [
            [
                new LocalizedException(__('Localized exception message.')),
                LocalizedException::class,
                'Localized exception message.'
            ]
        ];
    }

    /**
     * @return array
     */
    private function getNoSuchExceptionProvider()
    {
        return [
            [
                new NoSuchEntityException(__('No such exception message.')),
                NoSuchEntityException::class,
                'No such exception message.'
            ]
        ];
    }

    /**
     * @return array
     */
    public function testUpdateCouponsWithExceptionProvider()
    {
        return array_merge(
            $this->getInputExceptionProvider(),
            $this->getLocalizedExceptionProvider(),
            $this->getNoSuchExceptionProvider()
        );
    }

    /**
     * @return array
     */
    public function testDeleteCouponsByCampaignWithExceptionProvider()
    {
        return array_merge(
            $this->getLocalizedExceptionProvider(),
            $this->getNoSuchExceptionProvider()
        );
    }

    /**
     * @return array
     */
    public function testDeleteCouponsByAccountProvider()
    {
        $couponMock = $this->createMock(CouponInterface::class);

        return [
            [],
            [[$couponMock]],
            [[$couponMock, $couponMock]]
        ];
    }

    /**
     * @return array
     */
    public function testDeleteCouponsByAccountWithExceptionProvider()
    {
        return $this->getLocalizedExceptionProvider();
    }

    /**
     * @return array
     */
    public function testGenerateCouponWithExceptionProvider()
    {
        return array_merge(
            $this->getInputExceptionProvider(),
            $this->getLocalizedExceptionProvider(),
            $this->getNoSuchExceptionProvider()
        );
    }
}
