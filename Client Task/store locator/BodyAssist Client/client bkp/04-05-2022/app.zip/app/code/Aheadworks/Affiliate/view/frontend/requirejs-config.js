var config = {
    map: {
        '*': {
            'tabs': 'mage/tabs'
        }
    }
};
