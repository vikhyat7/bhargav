<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Promo;

use Aheadworks\Affiliate\Api\PromoLinkManagementInterface;
use Aheadworks\Affiliate\Controller\AbstractPostCustomerAction;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Data\Form\FormKey\Validator as FormKeyValidator;
use Magento\Customer\Model\Session as CustomerSession;
use Aheadworks\Affiliate\Api\Data\PromoLinkDataInterface;
use Aheadworks\Affiliate\Api\Data\PromoLinkDataInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Aheadworks\Affiliate\Api\AccountRepositoryInterface;

/**
 * Class GenerateLink
 *
 * @package Aheadworks\Affiliate\Controller\Promo
 */
class GenerateLink extends AbstractPostCustomerAction
{
    /**
     * @var JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var PromoLinkManagementInterface
     */
    private $promoLinkManagement;

    /**
     * @var PromoLinkDataInterfaceFactory
     */
    private $promoLinkDataFactory;

    /**
     * @var DataObjectHelper
     */
    private $dataObjectHelper;

    /**
     * @param Context $context
     * @param CustomerSession $customerSession
     * @param JsonFactory $resultJsonFactory
     * @param FormKeyValidator $formKeyValidator
     * @param PromoLinkManagementInterface $promoLinkManagement
     * @param PromoLinkDataInterfaceFactory $promoLinkDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param StoreManagerInterface $storeManager
     * @param AccountRepositoryInterface $accountRepository
     */
    public function __construct(
        Context $context,
        CustomerSession $customerSession,
        JsonFactory $resultJsonFactory,
        FormKeyValidator $formKeyValidator,
        PromoLinkManagementInterface $promoLinkManagement,
        PromoLinkDataInterfaceFactory $promoLinkDataFactory,
        DataObjectHelper $dataObjectHelper,
        StoreManagerInterface $storeManager,
        AccountRepositoryInterface $accountRepository
    ) {
        parent::__construct($context, $customerSession, $formKeyValidator, $storeManager, $accountRepository);
        $this->resultJsonFactory = $resultJsonFactory;
        $this->promoLinkManagement = $promoLinkManagement;
        $this->promoLinkDataFactory = $promoLinkDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        $data = ['success' => false];
        $postData = $this->getRequest()->getPostValue();
        if (!empty($postData)) {
            try {
                $this->validate();
                $data = [
                    'success' => true,
                    'promo_link' => $this->generatePromoLink($postData),
                    'message' => __('Promo link was successfully generated.')
                ];
            } catch (LocalizedException $e) {
                $data['message'] = $e->getMessage();
            } catch (\Exception $e) {
                $data['message'] = __('Something went wrong while link generation.');
            }
        } else {
            $data['message'] = __('No data provided to link generation.');
        }

        return $this->resultJsonFactory->create()->setData($data);
    }

    /**
     * Generate promo link
     *
     * @param array $data
     * @return string
     * @throws LocalizedException
     */
    private function generatePromoLink($data)
    {
        $account = $this->getAffiliateAccount();
        $promoLinkData = $this->getPromoLinkData($data);
        $promoLinkData->setAccountId($account->getAccountId());

        return $this->promoLinkManagement->generateLink($promoLinkData);
    }

    /**
     * Get promo link data object
     *
     * @param array $data
     * @return PromoLinkDataInterface
     */
    private function getPromoLinkData($data)
    {
        /** @var PromoLinkDataInterface $promoDataObject */
        $promoLinkData = $this->promoLinkDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $promoLinkData,
            $data,
            PromoLinkDataInterface::class
        );
        return $promoLinkData;
    }
}
