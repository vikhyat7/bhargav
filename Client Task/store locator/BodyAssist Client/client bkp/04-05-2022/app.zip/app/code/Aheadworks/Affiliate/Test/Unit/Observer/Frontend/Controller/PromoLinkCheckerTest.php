<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Observer\Frontend\Controller;

use PHPUnit\Framework\TestCase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Aheadworks\Affiliate\Observer\Frontend\Controller\PromoLinkChecker;
use Magento\Framework\Event;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Event\Observer;
use Psr\Log\LoggerInterface;
use Aheadworks\Affiliate\Api\PromoLinkManagementInterface;
use Magento\Framework\Exception\LocalizedException;

/**
 * Test for \Aheadworks\Affiliate\Observer\Frontend\Controller\PromoLinkChecker
 */
class PromoLinkCheckerTest extends TestCase
{
    /**
     * @var PromoLinkChecker
     */
    private $model;

    /**
     * @var LoggerInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $loggerMock;

    /**
     * @var PromoLinkManagementInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $promoLinkServiceMock;

    /**
     * Init mocks for tests
     *
     * @return void
     */
    public function setUp() : void
    {
        $objectManager = new ObjectManager($this);

        $this->loggerMock = $this->createMock(LoggerInterface::class);
        $this->promoLinkServiceMock = $this->createMock(PromoLinkManagementInterface::class);

        $this->model = $objectManager->getObject(
            PromoLinkChecker::class,
            [
                'logger' => $this->loggerMock,
                'promoLinkService' => $this->promoLinkServiceMock
            ]
        );
    }

    /**
     * Test for execute()
     */
    public function testExecute()
    {
        $requestMock = $this->createMock(RequestInterface::class);
        $eventMock = $this->createMock(Event::class);
        $eventMock->expects($this->once())
            ->method('__call')
            ->with('getRequest')
            ->willReturn($requestMock);

        $observerMock = $this->createMock(Observer::class);
        $observerMock->expects($this->once())
            ->method('getEvent')
            ->willReturn($eventMock);

        $this->promoLinkServiceMock->expects($this->once())
            ->method('processRequest')
            ->with($requestMock);

        $this->loggerMock->expects($this->never())
            ->method('critical');

        $this->model->execute($observerMock);
    }

    /**
     * Test for execute() with exception
     */
    public function testExecuteException()
    {
        $requestMock = $this->createMock(RequestInterface::class);
        $eventMock = $this->createMock(Event::class);
        $eventMock->expects($this->once())
            ->method('__call')
            ->with('getRequest')
            ->willReturn($requestMock);

        $observerMock = $this->createMock(Observer::class);
        $observerMock->expects($this->once())
            ->method('getEvent')
            ->willReturn($eventMock);

        $exception = new LocalizedException(__('Error!'));
        $this->promoLinkServiceMock->expects($this->once())
            ->method('processRequest')
            ->with($requestMock)
            ->willThrowException($exception);

        $this->loggerMock->expects($this->once())
            ->method('critical')
            ->with($exception);

        $this->model->execute($observerMock);
    }
}
