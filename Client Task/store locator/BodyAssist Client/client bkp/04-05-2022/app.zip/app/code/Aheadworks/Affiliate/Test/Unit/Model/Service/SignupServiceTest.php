<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Model\Service;

use Aheadworks\Affiliate\Model\Exception\CouldNotCreateAccount;
use Aheadworks\Affiliate\Model\Status\Actions\ActionsInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\NoSuchEntityException;
use PHPUnit\Framework\TestCase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Aheadworks\Affiliate\Model\Service\SignupService;
use Aheadworks\Affiliate\Api\SignupRepositoryInterface;
use Aheadworks\Affiliate\Api\Data\SignupInterface;
use Aheadworks\Affiliate\Model\Source\Signup\Status;
use Magento\Framework\Exception\CouldNotSaveException;
use Aheadworks\Affiliate\Model\Signup\StatusResolver;
use Aheadworks\Affiliate\Model\ResourceModel\Signup as SignupResource;
use Magento\Framework\Exception\LocalizedException;
use Aheadworks\Affiliate\Model\Status\ActionsPool as StatusActionsPool;

/**
 * Class SignupServiceTest
 * @package Aheadworks\Affiliate\Test\Unit\Model\Service
 */
class SignupServiceTest extends TestCase
{
    /**
     * @var SignupRepositoryInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $signupRepositoryMock;

    /**
     * @var StatusResolver|\PHPUnit_Framework_MockObject_MockObject
     */
    private $statusResolverMock;

    /**
     * @var SignupResource|\PHPUnit_Framework_MockObject_MockObject
     */
    private $signupResourceMock;

    /**
     * @var StatusActionsPool|\PHPUnit_Framework_MockObject_MockObject
     */
    private $statusActionsPoolMock;

    /**
     * @var SignupService
     */
    private $testedClass;

    /**#@+
     * Constants used for tests
     */
    const DEFAULT_ID = 1;
    const DEFAULT_STATUS = Status::PENDING;
    const COULD_SAVE_SIGNUP_EXC_CODE = 1;
    const COULD_NOT_CREATE_ACCOUNT = 2;
    const NO_SUCH_SIGNUP_EXC_CODE = 3;
    const SIGNUP_STATUS_EXC_CODE = 4;
    /**#@-*/

    /**
     * Init mocks for tests
     *
     * @return void
     */
    public function setUp() : void
    {
        $objectManager = new ObjectManager($this);
        $this->signupRepositoryMock = $this->createMock(SignupRepositoryInterface::class);
        $this->statusResolverMock = $this->createMock(StatusResolver::class);
        $this->signupResourceMock = $this->createMock(SignupResource::class);
        $this->statusActionsPoolMock = $this->createMock(StatusActionsPool::class);
        $this->testedClass = $objectManager->getObject(
            SignupService::class,
            [
                'signupRepository' => $this->signupRepositoryMock,
                'statusResolver' => $this->statusResolverMock,
                'signupResource' => $this->signupResourceMock,
                'statusActionsPool' => $this->statusActionsPoolMock
            ]
        );
    }

    /**
     * Test createSignup method
     *
     * @param int $status
     * @dataProvider testCreateSignupProvider
     */
    public function testCreateSignup($status)
    {
        $signupMock = $this->getSignupMock($status);

        $signupMock->expects($this->once())
            ->method('setStatus')
            ->with($status)
            ->willReturnSelf();
        $this->statusResolverMock->expects($this->once())
            ->method('getStatusForNewSignup')
            ->with($signupMock)
            ->willReturn($status);
        $this->mockObjectsPerformSaving($signupMock);

        $this->assertSame($signupMock, $this->testedClass->createSignup($signupMock));
    }

    /**
     * Test createSignup method with exception
     *
     * @param CouldNotSaveException|CouldNotCreateAccount $exception
     * @param string $exceptionMsg
     * @param int $status
     * @dataProvider testCreateSignupWithExceptionProvider
     * @expectedException \Magento\Framework\Exception\CouldNotSaveException
     */
    public function testCreateSignupWithException($exception, $exceptionMsg, $status = Status::PENDING)
    {
        $signupMock = $this->getSignupMock(Status::APPROVED);

        $signupMock->expects($this->once())
            ->method('setStatus')
            ->with($status)
            ->willReturnSelf();
        $this->statusResolverMock->expects($this->once())
            ->method('getStatusForNewSignup')
            ->with($signupMock)
            ->willReturn($status);
        $this->mockObjectsPerformSavingWithException($signupMock, $exception);
        $this->expectExceptionMessage($exceptionMsg);

        $this->testedClass->createSignup($signupMock);
    }

    /**
     * Test approveSignup method
     *
     * @throws CouldNotSaveException
     */
    public function testApproveSignup()
    {
        $currentStatus = Status::PENDING;
        $signupMock = $this->getSignupMock();

        $this->signupRepositoryMock->expects($this->once())
            ->method('getById')
            ->willReturn($signupMock);
        $this->statusResolverMock->expects($this->once())
            ->method('isStatusAllowedForSignup')
            ->with(Status::APPROVED, $currentStatus)
            ->willReturn(true);
        $signupMock->expects($this->once())
            ->method('setStatus')
            ->with(Status::APPROVED)
            ->willReturnSelf();
        $this->mockObjectsPerformSaving($signupMock);

        $this->assertSame($signupMock, $this->testedClass->approveSignup(self::DEFAULT_ID));
    }

    /**
     * Test approveSignup method with exception
     *
     * @param CouldNotSaveException|LocalizedException $exception
     * @param string $exceptionMsg
     * @expectedException \Magento\Framework\Exception\LocalizedException
     * @dataProvider testApproveSignupWithExceptionProvider
     * @throws CouldNotSaveException
     */
    public function testApproveSignupWithException($exception, $exceptionMsg)
    {
        $pendingSignupMock = $this->getSignupMock();
        $approvedSignupMock = $this->getSignupMock(Status::APPROVED);

        if ($exception->getCode() == self::NO_SUCH_SIGNUP_EXC_CODE) {
            $this->signupRepositoryMock->expects($this->once())
                ->method('getById')
                ->willThrowException($exception);
        } elseif ($exception->getCode() == self::SIGNUP_STATUS_EXC_CODE) {
            $this->signupRepositoryMock->expects($this->once())
                ->method('getById')
                ->with(self::DEFAULT_ID)
                ->willReturn($approvedSignupMock);
            $this->statusResolverMock->expects($this->once())
                ->method('isStatusAllowedForSignup')
                ->with(Status::APPROVED, Status::APPROVED)
                ->willReturn(false);
        } else {
            $this->signupRepositoryMock->expects($this->once())
                ->method('getById')
                ->with(self::DEFAULT_ID)
                ->willReturn($pendingSignupMock);
            $this->statusResolverMock->expects($this->once())
                ->method('isStatusAllowedForSignup')
                ->with(Status::APPROVED, Status::PENDING)
                ->willReturn(true);
            $pendingSignupMock->expects($this->once())
                ->method('setStatus')
                ->with(Status::APPROVED)
                ->willReturnSelf();
            $this->mockObjectsPerformSavingWithException($pendingSignupMock, $exception);
        }
        $this->expectExceptionMessage($exceptionMsg);

        $this->testedClass->approveSignup(self::DEFAULT_ID);
    }

    /**
     * Test declineSignup method
     *
     * @throws CouldNotSaveException
     */
    public function testDeclineSignup()
    {
        $currentStatus = Status::DECLINED;
        $signupMock = $this->getSignupMock($currentStatus);

        $this->signupRepositoryMock->expects($this->once())
            ->method('getById')
            ->willReturn($signupMock);
        $this->statusResolverMock->expects($this->once())
            ->method('isStatusAllowedForSignup')
            ->with(Status::DECLINED, $currentStatus)
            ->willReturn(true);
        $signupMock->expects($this->once())
            ->method('setStatus')
            ->with(Status::DECLINED)
            ->willReturnSelf();
        $this->mockObjectsPerformSaving($signupMock);

        $this->assertSame($signupMock, $this->testedClass->declineSignup(self::DEFAULT_ID));
    }

    /**
     * Test declineSignup method with exception
     *
     * @param CouldNotSaveException|LocalizedException $exception
     * @param string $exceptionMsg
     * @expectedException \Magento\Framework\Exception\LocalizedException
     * @dataProvider testDeclineSignupWithExceptionProvider
     * @throws CouldNotSaveException
     */
    public function testDeclineSignupWithException($exception, $exceptionMsg)
    {
        $pendingSignupMock = $this->getSignupMock(Status::PENDING);
        $declinedSignupMock = $this->getSignupMock(Status::DECLINED);

        if ($exception->getCode() == self::NO_SUCH_SIGNUP_EXC_CODE) {
            $this->signupRepositoryMock->expects($this->once())
                ->method('getById')
                ->willThrowException($exception);
        } elseif ($exception->getCode() == self::SIGNUP_STATUS_EXC_CODE) {
            $this->signupRepositoryMock->expects($this->once())
                ->method('getById')
                ->with(self::DEFAULT_ID)
                ->willReturn($declinedSignupMock);
            $this->statusResolverMock->expects($this->once())
                ->method('isStatusAllowedForSignup')
                ->with(Status::DECLINED, Status::DECLINED)
                ->willReturn(false);
        } else {
            $this->signupRepositoryMock->expects($this->once())
                ->method('getById')
                ->with(self::DEFAULT_ID)
                ->willReturn($pendingSignupMock);
            $this->statusResolverMock->expects($this->once())
                ->method('isStatusAllowedForSignup')
                ->with(Status::DECLINED, Status::PENDING)
                ->willReturn(true);
            $pendingSignupMock->expects($this->once())
                ->method('setStatus')
                ->with(Status::DECLINED)
                ->willReturnSelf();
            $this->mockObjectsPerformSavingWithException($pendingSignupMock, $exception);
        }
        $this->expectExceptionMessage($exceptionMsg);

        $this->testedClass->declineSignup(self::DEFAULT_ID);
    }

    /**
     * Test deleteSignup method
     */
    public function testDeleteSignup()
    {
        $signupMock = $this->getSignupMock();

        $this->signupRepositoryMock->expects($this->once())
            ->method('delete')
            ->with($signupMock)
            ->willReturn(true);

        $this->assertTrue($this->testedClass->deleteSignup($signupMock));
    }

    /**
     * Test deleteSignup method with exception
     *
     * @expectedException \Magento\Framework\Exception\CouldNotDeleteException
     * @expectedExceptionMessage Test message.
     */
    public function testDeleteSignupWithException()
    {
        $signupMock = $this->getSignupMock();
        $exception = new CouldNotDeleteException(__('Test message.'));
        $this->expectException(CouldNotDeleteException::class);
        $this->signupRepositoryMock->expects($this->once())
            ->method('delete')
            ->with($signupMock)
            ->willThrowException($exception);

        $this->testedClass->deleteSignup($signupMock);
    }

    /**
     * Test deleteSignupById method
     */
    public function testDeleteSignupById()
    {
        $signupMock = $this->getSignupMock();

        $this->signupRepositoryMock->expects($this->once())
            ->method('getById')
            ->with(self::DEFAULT_ID)
            ->willReturn($signupMock);
        $this->signupRepositoryMock->expects($this->once())
            ->method('delete')
            ->with($signupMock)
            ->willReturn(true);

        $this->assertTrue($this->testedClass->deleteSignupById(self::DEFAULT_ID));
    }

    /**
     * Test deleteSignupById method with exception
     *
     * @param CouldNotDeleteException|NoSuchEntityException $exception
     * @param string $excClass
     * @param string $excMessage
     * @dataProvider testDeleteSignupByIdWithExceptionProvider
     */
    public function testDeleteSignupByIdWithException($exception, $excClass, $excMessage)
    {
        $signupMock = $this->getSignupMock();

        if ($exception instanceof NoSuchEntityException) {
            $this->signupRepositoryMock->expects($this->once())
                ->method('getById')
                ->with(self::DEFAULT_ID)
                ->willThrowException($exception);
        } else {
            $this->signupRepositoryMock->expects($this->once())
                ->method('getById')
                ->with(self::DEFAULT_ID)
                ->willReturn($signupMock);
            $this->signupRepositoryMock->expects($this->once())
                ->method('delete')
                ->with($signupMock)
                ->willThrowException($exception);
        }
        $this->expectException($excClass);
        $this->expectExceptionMessage($excMessage);

        $this->testedClass->deleteSignupById(self::DEFAULT_ID);
    }

    /**
     * Get signup mock
     *
     * @param int $status
     * @param int $signupId
     * @return SignupInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private function getSignupMock($status = self::DEFAULT_STATUS, $signupId = self::DEFAULT_ID)
    {
        $signupMock = $this->createMock(SignupInterface::class);

        $signupMock->expects($this->atMost(1))
            ->method('getSignupId')
            ->willReturn($signupId);
        $signupMock->expects($this->atMost(2))
            ->method('getStatus')
            ->willReturn($status);

        return $signupMock;
    }

    /**
     * Mock objects for performSignupSaving method
     *
     * @param SignupInterface|\PHPUnit_Framework_MockObject_MockObject $signupMock
     */
    private function mockObjectsPerformSaving($signupMock)
    {
        $statusActionMock = $this->createMock(ActionsInterface::class);

        $this->signupResourceMock->expects($this->once())
            ->method('beginTransaction')
            ->willReturnSelf();
        $this->signupRepositoryMock->expects($this->once())
            ->method('save')
            ->with($signupMock)
            ->willReturn($signupMock);
        $this->statusActionsPoolMock->expects($this->once())
            ->method('getByStatus')
            ->willReturn($statusActionMock);
        $statusActionMock->expects($this->once())
            ->method('performActions')
            ->with($signupMock);
        $this->signupResourceMock->expects($this->once())
            ->method('commit')
            ->willReturnSelf();
    }

    /**
     * Mock objects for performSignupSaving method with exception
     *
     * @param SignupInterface|\PHPUnit_Framework_MockObject_MockObject $signupMock
     * @param CouldNotSaveException|LocalizedException|NoSuchEntityException $exception
     */
    private function mockObjectsPerformSavingWithException($signupMock, $exception)
    {
        $statusActionMock = $this->createMock(ActionsInterface::class);

        $this->signupResourceMock->expects($this->once())
            ->method('beginTransaction')
            ->willReturnSelf();
        if ($exception->getCode() == self::COULD_SAVE_SIGNUP_EXC_CODE) {
            $this->signupRepositoryMock->expects($this->once())
                ->method('save')
                ->with($signupMock)
                ->willThrowException($exception);
        } else {
            if ($exception->getCode() == self::COULD_NOT_CREATE_ACCOUNT) {
                $this->signupResourceMock->expects($this->once())
                    ->method('rollBack')
                    ->willReturnSelf();
            }
            $this->signupRepositoryMock->expects($this->once())
                ->method('save')
                ->with($signupMock)
                ->willReturn($signupMock);
            $this->statusActionsPoolMock->expects($this->once())
                ->method('getByStatus')
                ->willReturn($statusActionMock);
            $statusActionMock->expects($this->once())
                ->method('performActions')
                ->with($signupMock)
                ->willThrowException($exception);
        }
    }

    /**
     * @return array
     */
    public function testCreateSignupProvider()
    {
        return [
            [Status::PENDING],
            [Status::APPROVED]
        ];
    }

    /**
     * @return array
     */
    public function testCreateSignupWithExceptionProvider()
    {
        return array_merge(
            $this->getPerformSavingExceptions(),
            [
                [
                    new CouldNotCreateAccount(
                        __('Error while creating new account.'),
                        null,
                        self::COULD_NOT_CREATE_ACCOUNT
                    ),
                    'Error while creating new account.',
                    Status::APPROVED
                ]
            ]
        );
    }

    /**
     * @return array
     */
    public function testApproveSignupWithExceptionProvider()
    {
        return array_merge(
            $this->getPerformSavingExceptions(),
            [
                [
                    new NoSuchEntityException(
                        __('Signup request does not exist.'),
                        null,
                        self::NO_SUCH_SIGNUP_EXC_CODE
                    ),
                    'Signup request does not exist.'
                ],
                [
                    new CouldNotSaveException(
                        __('Signup request can\'t be approved.'),
                        null,
                        self::SIGNUP_STATUS_EXC_CODE
                    ),
                    'Signup request can\'t be approved.'
                ]
            ]
        );
    }

    /**
     * @return array
     */
    public function testDeclineSignupWithExceptionProvider()
    {
        return array_merge(
            $this->getPerformSavingExceptions(),
            [
                [
                    new NoSuchEntityException(
                        __('Signup request does not exist.'),
                        null,
                        self::NO_SUCH_SIGNUP_EXC_CODE
                    ),
                    'Signup request does not exist.'
                ],
                [
                    new CouldNotSaveException(
                        __('Signup request can\'t be declined.'),
                        null,
                        self::SIGNUP_STATUS_EXC_CODE
                    ),
                    'Signup request can\'t be declined.'
                ]
            ]
        );
    }

    /**
     * @return array
     */
    public function testCancelSignupWithExceptionProvider()
    {
        return array_merge(
            $this->getPerformSavingExceptions(),
            [
                [
                    new NoSuchEntityException(
                        __('Signup with ID = %1 does not exist.', self::DEFAULT_ID),
                        null,
                        self::NO_SUCH_SIGNUP_EXC_CODE
                    ),
                    'Signup with ID = 1 does not exist.'
                ],
                [
                    new CouldNotSaveException(
                        __('Signup can\'t be canceled.'),
                        null,
                        self::SIGNUP_STATUS_EXC_CODE
                    ),
                    'Signup can\'t be canceled.'
                ]
            ]
        );
    }

    /**
     * @return array
     */
    public function testDeleteSignupByIdWithExceptionProvider()
    {
        return [
            [
                new NoSuchEntityException(__('No such entity message.')),
                NoSuchEntityException::class,
                'No such entity message.'
            ],
            [
                new CouldNotSaveException(__('Can\'t delete message.')),
                CouldNotSaveException::class,
                'Can\'t delete message.'
            ]
        ];
    }

    /**
     * Get performSignupSaving method exceptions
     *
     * @return array
     */
    private function getPerformSavingExceptions()
    {
        return [
            [
                new CouldNotSaveException(
                    __('Error while signup saving.'),
                    null,
                    self::COULD_SAVE_SIGNUP_EXC_CODE
                ),
                'Error while signup saving.'
            ],
            [
                new CouldNotSaveException(__('Error while status actions performing.')),
                'Error while status actions performing.'
            ]
        ];
    }
}
