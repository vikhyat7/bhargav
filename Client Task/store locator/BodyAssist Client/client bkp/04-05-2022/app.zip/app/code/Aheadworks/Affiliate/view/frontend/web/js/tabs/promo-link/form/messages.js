define([
    'Magento_Ui/js/view/messages',
    'Magento_Ui/js/model/messages'
], function (Component, Messages) {
    'use strict';

    return Component.extend({
        defaults: {
            template: 'Aheadworks_Affiliate/tabs/promo-link/form/messages'
        },

        /**
         * {@inheritdoc}
         */
        initialize: function (config, messageContainer) {
            this._super()
                .initObservable();

            this.messageContainer = new Messages();

            return this;
        }
    });
});
