<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Signup;

use Aheadworks\Affiliate\Api\Data\SignupInterface;
use Aheadworks\Affiliate\Api\SignupRepositoryInterface;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\View\Result\PageFactory;

/**
 * Class Edit
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Signup
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Edit extends Action
{
    /**
     * {@inheritdoc}
     */
    const ADMIN_RESOURCE = 'Aheadworks_Affiliate::signups';

    /**
     * {@inheritdoc}
     */
    protected $_publicActions = ['edit'];

    /**
     * @var PageFactory
     */
    private $resultPageFactory;

    /**
     * @var SignupRepositoryInterface
     */
    private $signupRepository;

    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     * @param SignupRepositoryInterface $signupRepository
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        SignupRepositoryInterface $signupRepository
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->signupRepository = $signupRepository;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        $signupId = (int)$this->getRequest()->getParam(SignupInterface::ID);
        if ($signupId) {
            try {
                /** @var SignupInterface $signup */
                $signup = $this->signupRepository->getById($signupId);
            } catch (NoSuchEntityException $exception) {
                $this->messageManager->addErrorMessage(
                    __('This signup request no longer exists.')
                );
                $resultRedirect = $this->resultRedirectFactory->create();
                $resultRedirect->setPath('*/*/');
                return $resultRedirect;
            }
        }

        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage
            ->setActiveMenu('Aheadworks_Affiliate::signups')
            ->getConfig()->getTitle()->prepend(__('Signup Request'));
        return $resultPage;
    }
}
