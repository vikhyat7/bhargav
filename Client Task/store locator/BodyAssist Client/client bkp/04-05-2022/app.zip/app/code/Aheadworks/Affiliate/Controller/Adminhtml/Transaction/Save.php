<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Adminhtml\Transaction;

use Aheadworks\Affiliate\Api\Data\TransactionInterface;
use Magento\Backend\App\Action;
use Aheadworks\Affiliate\Api\TransactionManagementInterface;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Request\DataPersistorInterface;
use Aheadworks\Affiliate\Ui\DataProvider\Transaction\FormDataProvider;
use Aheadworks\Affiliate\Model\Source\Transaction\Type as TransactionType;
use Aheadworks\Affiliate\Model\Source\Transaction\Status as TransactionStatus;
use Aheadworks\Affiliate\Model\Source\CommissionType;
use Magento\Framework\Exception\LocalizedException;

/**
 * Class Save
 *
 * @package Aheadworks\Affiliate\Controller\Adminhtml\Transaction
 */
class Save extends Action
{
    /**
     * {@inheritdoc}
     */
    const ADMIN_RESOURCE = 'Aheadworks_Affiliate::transactions';

    /**
     * @var TransactionManagementInterface
     */
    private $transactionService;

    /**
     * @var DataPersistorInterface
     */
    private $dataPersistor;

    /**
     * @param Context $context
     * @param TransactionManagementInterface $transactionService
     * @param DataPersistorInterface $dataPersistor
     */
    public function __construct(
        Context $context,
        TransactionManagementInterface $transactionService,
        DataPersistorInterface $dataPersistor
    ) {
        parent::__construct($context);
        $this->transactionService = $transactionService;
        $this->dataPersistor = $dataPersistor;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($postData = $this->getRequest()->getPostValue()) {
            try {
                $this->performSave($postData);
                $this->dataPersistor->clear(FormDataProvider::DATA_PERSISTOR_FORM_DATA_KEY);
                $this->messageManager->addSuccessMessage(__('The transaction was successfully saved.'));
                return $resultRedirect->setPath('*/*/');
            } catch (LocalizedException $exception) {
                $this->messageManager->addErrorMessage($exception->getMessage());
            } catch (\Exception $exception) {
                $this->messageManager->addExceptionMessage(
                    $exception,
                    __('Something went wrong while saving the transaction.')
                );
            }
            $this->dataPersistor->set(FormDataProvider::DATA_PERSISTOR_FORM_DATA_KEY, $postData);
            return $resultRedirect->setPath('*/*/new', ['_current' => true]);
        }
        return $resultRedirect->setPath('*/*/');
    }

    /**
     * Perform transaction saving
     *
     * @param array $postData
     * @throws LocalizedException
     */
    private function performSave($postData)
    {
        $this->transactionService->addTransaction(
            $postData[TransactionInterface::AFFILIATE_ID],
            TransactionType::ADMIN_CHANGES,
            TransactionStatus::COMPLETE,
            null,
            $postData[TransactionInterface::AMOUNT],
            $postData[TransactionInterface::COMMENT]
        );
    }
}
