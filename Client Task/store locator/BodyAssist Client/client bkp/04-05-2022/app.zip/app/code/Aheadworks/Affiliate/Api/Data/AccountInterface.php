<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Api\Data;

use Magento\Framework\Api\ExtensibleDataInterface;

/**
 * Interface AccountInterface
 * @package Aheadworks\Affiliate\Api\Data
 */
interface AccountInterface extends ExtensibleDataInterface
{
    /**#@+
     * Constants defined for keys of the data array.
     * Identical to the name of the getter in snake case
     */
    const ID = 'account_id';
    const CUSTOMER_ID = 'customer_id';
    const WEBSITE_ID = 'website_id';
    const STATUS = 'status';
    const PREFIX = 'prefix';
    const FIRSTNAME = 'firstname';
    const MIDDLENAME = 'middlename';
    const LASTNAME = 'lastname';
    const SUFFIX = 'suffix';
    const EMAIL = 'email';
    const SIGNUP_ID = 'signup_id';
    const SIGNUP_APPROVAL_DATE = 'signup_approval_date';
    const AFFILIATE_GROUP_ID = 'affiliate_group_id';
    const REFERRAL_WEBSITE = 'referral_website';
    const UNIQUE_COUPON_PREFIX = 'unique_coupon_prefix';
    const PAYMENT_TYPE = 'payment_type';
    const PAYMENT_INFO = 'payment_info';
    /**#@-*/

    /**
     * Get account id
     *
     * @return int
     */
    public function getAccountId();

    /**
     * Set account id
     *
     * @param int $id
     * @return $this
     */
    public function setAccountId($id);

    /**
     * Get customer id
     *
     * @return int
     */
    public function getCustomerId();

    /**
     * Set customer id
     *
     * @param int $customerId
     * @return $this
     */
    public function setCustomerId($customerId);

    /**
     * Get website id
     *
     * @return int
     */
    public function getWebsiteId();

    /**
     * Set website id
     *
     * @param int $websiteId
     * @return $this
     */
    public function setWebsiteId($websiteId);

    /**
     * Get status
     *
     * @return int
     */
    public function getStatus();

    /**
     * Set status
     *
     * @param int $status
     * @return $this
     */
    public function setStatus($status);

    /**
     * Get prefix
     *
     * @return string|null
     */
    public function getPrefix();

    /**
     * Set prefix
     *
     * @param string $prefix
     * @return $this
     */
    public function setPrefix($prefix);

    /**
     * Get first name
     *
     * @return string
     */
    public function getFirstname();

    /**
     * Set first name
     *
     * @param string $firstName
     * @return $this
     */
    public function setFirstname($firstName);

    /**
     * Get middle name
     *
     * @return string|null
     */
    public function getMiddlename();

    /**
     * Set middle name
     *
     * @param string $middleName
     * @return $this
     */
    public function setMiddlename($middleName);

    /**
     * Get last name
     *
     * @return string
     */
    public function getLastname();

    /**
     * Set last name
     *
     * @param string $lastName
     * @return $this
     */
    public function setLastname($lastName);

    /**
     * Get suffix
     *
     * @return string|null
     */
    public function getSuffix();

    /**
     * Set suffix
     *
     * @param string $suffix
     * @return $this
     */
    public function setSuffix($suffix);

    /**
     * Get email
     *
     * @return string
     */
    public function getEmail();

    /**
     * Set email
     *
     * @param string $email
     * @return $this
     */
    public function setEmail($email);

    /**
     * Get signup id
     *
     * @return int
     */
    public function getSignupId();

    /**
     * Set signup id
     *
     * @param int $signupId
     * @return $this
     */
    public function setSignupId($signupId);

    /**
     * Get signup approval date
     *
     * @return string
     */
    public function getSignupApprovalDate();

    /**
     * Set signup approval date
     *
     * @param string $date
     * @return $this
     */
    public function setSignupApprovalDate($date);

    /**
     * Get affiliate group id
     *
     * @return int
     */
    public function getAffiliateGroupId();

    /**
     * Set affiliate group id
     *
     * @param int $groupId
     * @return $this
     */
    public function setAffiliateGroupId($groupId);

    /**
     * Get referral website
     *
     * @return string|null
     */
    public function getReferralWebsite();

    /**
     * Set referral website
     *
     * @param string $website
     * @return $this
     */
    public function setReferralWebsite($website);

    /**
     * Get unique coupon prefix
     *
     * @return string|null
     */
    public function getUniqueCouponPrefix();

    /**
     * Set unique coupon prefix
     *
     * @param string $prefix
     * @return $this
     */
    public function setUniqueCouponPrefix($prefix);

    /**
     * Get payment type
     *
     * @return int|null
     */
    public function getPaymentType();

    /**
     * Set payment type
     *
     * @param int $type
     * @return $this
     */
    public function setPaymentType($type);

    /**
     * Get payment info
     *
     * @return string|null
     */
    public function getPaymentInfo();

    /**
     * Set payment info
     *
     * @param string $info
     * @return $this
     */
    public function setPaymentInfo($info);
    
    /**
     * Retrieve existing extension attributes object or create a new one
     *
     * @return \Aheadworks\Affiliate\Api\Data\AccountExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object
     *
     * @param \Aheadworks\Affiliate\Api\Data\AccountExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aheadworks\Affiliate\Api\Data\AccountExtensionInterface $extensionAttributes
    );
}
