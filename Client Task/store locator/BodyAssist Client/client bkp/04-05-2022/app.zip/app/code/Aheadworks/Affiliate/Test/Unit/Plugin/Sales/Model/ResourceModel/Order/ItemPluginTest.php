<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Plugin\Sales\Model\ResourceModel\Order;

use PHPUnit\Framework\TestCase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Aheadworks\Affiliate\Plugin\Sales\Model\ResourceModel\Order\ItemPlugin;
use Psr\Log\LoggerInterface;
use Magento\Sales\Model\ResourceModel\Order\Item as OrderItemResourceModel;
use Magento\Sales\Model\Order\Item as OrderItem;
use Aheadworks\Affiliate\Api\TransactionCreationManagementInterface;
use Aheadworks\Affiliate\Api\TransactionHoldingPeriodManagementInterface;
use Magento\Framework\Exception\CouldNotSaveException;

/**
 * Test for \Aheadworks\Affiliate\Plugin\Sales\Model\ResourceModel\Order\ItemPlugin
 */
class ItemPluginTest extends TestCase
{
    /**
     * @var ItemPlugin
     */
    private $model;

    /**
     * @var LoggerInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $loggerMock;

    /**
     * @var TransactionCreationManagementInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $transactionCreationServiceMock;

    /**
     * @var TransactionHoldingPeriodManagementInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $transactionHoldingPeriodServiceMock;

    /**
     * Init mocks for tests
     *
     * @return void
     */
    public function setUp() : void
    {
        $objectManager = new ObjectManager($this);

        $this->loggerMock = $this->createMock(LoggerInterface::class);
        $this->transactionCreationServiceMock = $this->createMock(
            TransactionCreationManagementInterface::class
        );
        $this->transactionHoldingPeriodServiceMock = $this->createMock(
            TransactionHoldingPeriodManagementInterface::class
        );

        $this->model = $objectManager->getObject(
            ItemPlugin::class,
            [
                'logger' => $this->loggerMock,
                'transactionCreationService' => $this->transactionCreationServiceMock,
                'transactionHoldingPeriodService' => $this->transactionHoldingPeriodServiceMock
            ]
        );
    }

    /**
     * Test for afterSave
     */
    public function testAfterSave()
    {
        $subjectMock = $this->createMock(OrderItemResourceModel::class);
        $resultMock = $this->createMock(OrderItemResourceModel::class);
        $objectMock = $this->createMock(OrderItem::class);

        $this->transactionCreationServiceMock->expects($this->once())
            ->method('createTransactionByOrderItem')
            ->with($objectMock);

        $this->transactionHoldingPeriodServiceMock->expects($this->once())
            ->method('processUnexpiredTransactionsByOrderItem')
            ->with($objectMock);

        $this->loggerMock->expects($this->never())
            ->method('error');

        $this->assertSame(
            $resultMock,
            $this->model->afterSave($subjectMock, $resultMock, $objectMock)
        );
    }

    /**
     * Test for afterSave with exception on creation
     */
    public function testAfterSaveExceptionOnCreation()
    {
        $subjectMock = $this->createMock(OrderItemResourceModel::class);
        $resultMock = $this->createMock(OrderItemResourceModel::class);
        $objectMock = $this->createMock(OrderItem::class);
        $creationException = new CouldNotSaveException(__('Error!'));

        $this->transactionCreationServiceMock->expects($this->once())
            ->method('createTransactionByOrderItem')
            ->with($objectMock)
            ->willThrowException($creationException);

        $this->transactionHoldingPeriodServiceMock->expects($this->once())
            ->method('processUnexpiredTransactionsByOrderItem')
            ->with($objectMock);

        $this->loggerMock->expects($this->once())
            ->method('error')
            ->with($creationException);

        $this->assertSame(
            $resultMock,
            $this->model->afterSave($subjectMock, $resultMock, $objectMock)
        );
    }

    /**
     * Test for afterSave with exception in holding period service
     */
    public function testAfterSaveExceptionInHoldingPeriodService()
    {
        $subjectMock = $this->createMock(OrderItemResourceModel::class);
        $resultMock = $this->createMock(OrderItemResourceModel::class);
        $objectMock = $this->createMock(OrderItem::class);
        $holdingPeriodServiceException = new CouldNotSaveException(__('Error!'));

        $this->transactionCreationServiceMock->expects($this->once())
            ->method('createTransactionByOrderItem')
            ->with($objectMock);

        $this->transactionHoldingPeriodServiceMock->expects($this->once())
            ->method('processUnexpiredTransactionsByOrderItem')
            ->with($objectMock)
            ->willThrowException($holdingPeriodServiceException);

        $this->loggerMock->expects($this->once())
            ->method('error')
            ->with($holdingPeriodServiceException);

        $this->assertSame(
            $resultMock,
            $this->model->afterSave($subjectMock, $resultMock, $objectMock)
        );
    }

    /**
     * Test for afterSave with two exceptions
     */
    public function testAfterSaveWithTwoExceptions()
    {
        $subjectMock = $this->createMock(OrderItemResourceModel::class);
        $resultMock = $this->createMock(OrderItemResourceModel::class);
        $objectMock = $this->createMock(OrderItem::class);
        $creationException = new CouldNotSaveException(__('Error!'));
        $holdingPeriodServiceException = new CouldNotSaveException(__('Error!'));

        $this->transactionCreationServiceMock->expects($this->once())
            ->method('createTransactionByOrderItem')
            ->with($objectMock)
            ->willThrowException($creationException);

        $this->transactionHoldingPeriodServiceMock->expects($this->once())
            ->method('processUnexpiredTransactionsByOrderItem')
            ->with($objectMock)
            ->willThrowException($holdingPeriodServiceException);

        $this->loggerMock->expects($this->exactly(2))
            ->method('error')
            ->withConsecutive([$creationException], [$holdingPeriodServiceException]);

        $this->assertSame(
            $resultMock,
            $this->model->afterSave($subjectMock, $resultMock, $objectMock)
        );
    }
}
