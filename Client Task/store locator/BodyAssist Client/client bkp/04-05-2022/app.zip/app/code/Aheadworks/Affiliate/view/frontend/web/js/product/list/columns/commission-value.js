define([
    'Magento_Ui/js/grid/columns/column'
], function (Column) {
    'use strict';

    return Column.extend({
        defaults: {
            labelKey: 'aw_aff_formatted_commission_value'
        },

        /**
         * @inheritdoc
         */
        getLabel: function (record) {
            return record['extension_attributes'][this.labelKey];
        }
    });
});
