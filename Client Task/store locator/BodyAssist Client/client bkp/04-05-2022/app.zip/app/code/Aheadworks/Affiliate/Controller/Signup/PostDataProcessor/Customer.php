<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Signup\PostDataProcessor;

use Aheadworks\Affiliate\Model\PostData\ProcessorInterface as PostDataProcessorInterface;
use Magento\Customer\Model\Session as CustomerSession;
use Aheadworks\Affiliate\Api\Data\SignupInterface;

/**
 * Class Customer
 *
 * @package Aheadworks\Affiliate\Controller\Signup\PostDataProcessor
 */
class Customer implements PostDataProcessorInterface
{
    /**
     * @var CustomerSession
     */
    private $customerSession;

    /**
     * @param CustomerSession $customerSession
     */
    public function __construct(
        CustomerSession $customerSession
    ) {
        $this->customerSession = $customerSession;
    }

    /**
     * {@inheritdoc}
     */
    public function process($data)
    {
        if (!isset($data[SignupInterface::CUSTOMER_ID])) {
            $data[SignupInterface::CUSTOMER_ID] = $this->customerSession->getCustomerId();
        }
        return $data;
    }
}
