<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Api;

/**
 * Interface TransactionManagementInterface
 * @package Aheadworks\Affiliate\Api
 */
interface TransactionManagementInterface
{
    /**
     * Add transaction
     *
     * @param int $affiliateId
     * @param string $type
     * @param int $status
     * @param \Aheadworks\Affiliate\Api\Data\PayoutInterface|\Magento\Sales\Api\Data\OrderItemInterface|null $entity
     * @param float
     * @param string $comment
     * @throws \Magento\Framework\Exception\CouldNotSaveException
     * @return \Aheadworks\Affiliate\Api\Data\TransactionInterface
     */
    public function addTransaction(
        $affiliateId,
        $type,
        $status,
        $entity = null,
        $amount = 0.00,
        $comment = ''
    );

    /**
     * Update transaction status
     *
     * @param int $transactionId
     * @param int $statusToSet
     * @throws \Magento\Framework\Exception\CouldNotSaveException
     * @return \Aheadworks\Affiliate\Api\Data\TransactionInterface
     */
    public function updateTransactionStatus($transactionId, $statusToSet);
}
