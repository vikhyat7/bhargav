<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Ui\Component\DataProvider;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\View\Element\UiComponent\DataProvider\Document as DataProviderDocument;
use Magento\Framework\Api\AttributeValueFactory;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Class Document
 * @package Aheadworks\Affiliate\Ui\Component\DataProvider
 */
class Document extends DataProviderDocument
{
    /**#@+
     * Custom attribute codes
     */
    const WEBSITE_ATTRIBUTE_CODE = 'website_id';
    const CURRENCY_ATTRIBUTE_CODE = 'currency_code';
    /**#@-*/

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * @param AttributeValueFactory $attributeValueFactory
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        AttributeValueFactory $attributeValueFactory,
        StoreManagerInterface $storeManager
    ) {
        parent::__construct($attributeValueFactory);
        $this->storeManager = $storeManager;
    }

    /**
     * {@inheritdoc}
     */
    public function getCustomAttribute($attributeCode)
    {
        switch ($attributeCode) {
            case self::WEBSITE_ATTRIBUTE_CODE:
                $this->setWebsiteValue();
                break;
            case self::CURRENCY_ATTRIBUTE_CODE:
                $this->setCurrencyCodeValue();
                break;
        }
        return parent::getCustomAttribute($attributeCode);
    }
    
    /**
     * Update website value
     *
     * @return void
     */
    private function setWebsiteValue()
    {
        $websiteId = $this->getData(self::WEBSITE_ATTRIBUTE_CODE);

        try {
            $websiteName = $this->storeManager->getWebsite($websiteId)->getName();
        } catch (LocalizedException $e) {
            $websiteName = '';
        }

        $this->setCustomAttribute(self::WEBSITE_ATTRIBUTE_CODE, $websiteName);
    }

    /**
     * Update currency code
     *
     * @return void
     */
    private function setCurrencyCodeValue()
    {
        $websiteId = $this->getData(self::WEBSITE_ATTRIBUTE_CODE);

        try {
            $currencyCode = $this->storeManager->getWebsite($websiteId)->getBaseCurrencyCode();
        } catch (LocalizedException $e) {
            $currencyCode = '';
        }

        $this->setCustomAttribute(self::CURRENCY_ATTRIBUTE_CODE, $currencyCode);
    }
}
