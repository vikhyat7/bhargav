define([
    './adapter',
    'Magento_Ui/js/form/form'
], function (adapter, Form) {
    'use strict';

    return Form.extend({

        /**
         * {@inheritDoc}
         */
        initAdapter: function () {
            adapter.on({
                'approve': this.save.bind(this, true, {new_status: 2}),
                'decline': this.save.bind(this, true, {new_status: 3})
            });

            return this;
        }
    });
});
