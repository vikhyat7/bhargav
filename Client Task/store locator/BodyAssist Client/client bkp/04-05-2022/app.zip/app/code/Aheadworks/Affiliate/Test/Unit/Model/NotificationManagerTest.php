<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Test\Unit\Model;

use Aheadworks\Affiliate\Api\Data\PayoutInterface;
use Aheadworks\Affiliate\Api\Data\PayoutReminderInterface;
use Aheadworks\Affiliate\Api\Data\SignupInterface;
use Aheadworks\Affiliate\Model\Email\EmailMetadataInterface;
use Aheadworks\Affiliate\Model\Email\Processor\MetadataProcessorInterface;
use Aheadworks\Affiliate\Model\Email\ProcessorFactory;
use Aheadworks\Affiliate\Model\Email\Sender;
use Aheadworks\Affiliate\Model\Source\Email\Type;
use Psr\Log\LoggerInterface;
use Magento\Framework\Exception\MailException;
use Magento\Framework\Api\ExtensibleDataInterface;
use Aheadworks\Affiliate\Model\NotificationManager;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;

/**
 * Class NotificationManagerTest
 * @package Aheadworks\Affiliate\Test\Unit\Model
 */
class NotificationManagerTest extends TestCase
{
    /**
     * @var Sender|\PHPUnit_Framework_MockObject_MockObject
     */
    private $senderMock;

    /**
     * @var ProcessorFactory|\PHPUnit_Framework_MockObject_MockObject
     */
    private $processorFactoryMock;

    /**
     * @var LoggerInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $loggerMock;

    /**
     * @var NotificationManager
     */
    private $notificationManager;

    /**#@+
     * Constants used for tests
     */
    const NO_SUCH_PROCESSOR_EXC_CODE = 1;
    const PROCESSOR_EXECUTION_EXC_CODE = 2;
    const SENDER_EXC_CODE = 3;
    /**#@-*/

    /**
     * Init mocks for tests
     *
     * @return void
     */
    protected function setUp() : void
    {
        $objectManager = new ObjectManager($this);
        $this->processorFactoryMock = $this->createMock(ProcessorFactory::class);
        $this->senderMock = $this->createMock(Sender::class);
        $this->loggerMock = $this->createMock(LoggerInterface::class);
        $this->notificationManager = $objectManager->getObject(
            NotificationManager::class,
            [
                'processorFactory' => $this->processorFactoryMock,
                'sender' => $this->senderMock,
                'logger' => $this->loggerMock
            ]
        );
    }

    /**
     * Test notify method
     *
     * @param string $type
     * @param ExtensibleDataInterface|\PHPUnit_Framework_MockObject_MockObject $objectMock
     * @dataProvider testNotifyProvider
     */
    public function testNotify($type, $objectMock)
    {
        $processorMock = $this->createMock(MetadataProcessorInterface::class);
        $emailMetadataMock = $this->createMock(EmailMetadataInterface::class);

        $this->processorFactoryMock->expects($this->once())
            ->method('create')
            ->with($type)
            ->willReturn($processorMock);
        $processorMock->expects($this->once())
            ->method('process')
            ->with($objectMock)
            ->willReturn($emailMetadataMock);
        $this->senderMock->expects($this->once())
            ->method('send')
            ->with($emailMetadataMock);

        $this->assertTrue($this->notificationManager->notify($type, $objectMock));
    }

    /**
     * Test notify method with exception
     *
     * @param MailException|\Exception $exception
     * @param string $exceptionMsg
     * @dataProvider testNotifyWithExceptionProvider
     */
    public function testNotifyWithException($exception, $exceptionMsg)
    {
        /** @var ExtensibleDataInterface|\PHPUnit_Framework_MockObject_MockObject $objectMock */
        $objectMock = $this->createMock(ExtensibleDataInterface::class);
        $processorMock = $this->createMock(MetadataProcessorInterface::class);
        $emailMetadataMock = $this->createMock(EmailMetadataInterface::class);
        $type = 'some_type';

        if ($exception->getCode() == self::NO_SUCH_PROCESSOR_EXC_CODE) {
            $this->processorFactoryMock->expects($this->once())
                ->method('create')
                ->with($type)
                ->willThrowException($exception);
        } elseif ($exception->getCode() == self::PROCESSOR_EXECUTION_EXC_CODE) {
            $this->processorFactoryMock->expects($this->once())
                ->method('create')
                ->with($type)
                ->willReturn($processorMock);
            $processorMock->expects($this->once())
                ->method('process')
                ->with($objectMock)
                ->willThrowException($exception);
        } else {
            $this->processorFactoryMock->expects($this->once())
                ->method('create')
                ->with($type)
                ->willReturn($processorMock);
            $processorMock->expects($this->once())
                ->method('process')
                ->with($objectMock)
                ->willReturn($emailMetadataMock);
            $this->senderMock->expects($this->once())
                ->method('send')
                ->willThrowException($exception);
        }
        $this->loggerMock->expects($this->once())
            ->method('critical')
            ->with($exceptionMsg);

        $this->assertEquals(false, $this->notificationManager->notify($type, $objectMock));
    }

    /**
     * @return array
     */
    public function testNotifyProvider()
    {
        $signupMock = $this->createMock(SignupInterface::class);
        $payoutMock = $this->createMock(PayoutInterface::class);
        $payoutReminderMock = $this->createMock(PayoutReminderInterface::class);

        return [
            [Type::ADMIN_NEW_SIGNUP, $signupMock],
            [Type::AFFILIATE_SIGNUP_APPROVED, $signupMock],
            [Type::AFFILIATE_SIGNUP_DECLINED, $signupMock],
            [Type::ADMIN_NEW_MANUAL_PAYOUT, $payoutMock],
            [Type::AFFILIATE_PAYOUT_COMPLETE, $payoutMock],
            [Type::AFFILIATE_PAYOUT_CANCELED, $payoutMock],
            [Type::ADMIN_PAYOUT_REMINDER, $payoutReminderMock]
        ];
    }

    /**
     * @return array
     */
    public function testNotifyWithExceptionProvider()
    {
        return [
            [
                new \Exception(
                    __('Notification type "some_type" not supported!'),
                    self::NO_SUCH_PROCESSOR_EXC_CODE
                ),
                'Notification type "some_type" not supported!'
            ],
            [
                new MailException(
                    __('Processor execution exception message.'),
                    null,
                    self::PROCESSOR_EXECUTION_EXC_CODE
                ),
                'Processor execution exception message.'
            ],
            [
                new MailException(
                    __('Send mail exception message.'),
                    null,
                    self::SENDER_EXC_CODE
                ),
                'Send mail exception message.'
            ]
        ];
    }
}
