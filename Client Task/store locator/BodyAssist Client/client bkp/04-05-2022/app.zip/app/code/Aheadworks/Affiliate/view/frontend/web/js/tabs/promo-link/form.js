define([
    'Aheadworks_Affiliate/js/ui/form/form',
    'uiRegistry',
    'uiLayout'
], function (Component, registry, layout) {
    'use strict';

    return Component.extend({
        defaults: {
            template: 'Aheadworks_Affiliate/tabs/promo-link/form',
            listens: {
                responseData: 'onResponseData'
            },
            generatedLinkComponentName: '${ $.name }.generated_link',
            messagesConfig: {
                component: 'Aheadworks_Affiliate/js/tabs/promo-link/form/messages',
                template: 'Aheadworks_Affiliate/tabs/promo-link/form/messages',
                name: 'aw_affiliate_link_generation_messages',
                cssclass: 'link-generation-messages',
                selector: '.link-generation-messages'
            }
        },

        /**
         * {@inheritDoc}
         */
        onResponseData: function (response) {
            var linkComponent = this.getGeneratedLinkComponent();

            if (response.success && linkComponent) {
                linkComponent.value(response.promo_link);
                this.getMessagesContainer().addSuccessMessage(response);
            } else {
                this.getMessagesContainer().addErrorMessage(response);
            }

            return this;
        },

        /**
         * @return {Object}|null
         */
        getGeneratedLinkComponent: function () {
            return registry.get(this.generatedLinkComponentName);
        },

        /**
         * Initialize messages component
         *
         * @returns {String}
         */
        initMessages: function () {
            layout([this.messagesConfig]);

            return this.messagesConfig.name;
        },

        /**
         * Get messages container class
         *
         * @returns {Object}
         */
        getMessagesContainer: function () {
            return registry.get(this.messagesConfig.name).messageContainer;
        }
    });
});
