<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Api\Data;

use Magento\Framework\Api\ExtensibleDataInterface;

/**
 * Interface SignupInterface
 * @package Aheadworks\Affiliate\Api\Data
 */
interface SignupInterface extends ExtensibleDataInterface
{
    /**#@+
     * Constants defined for keys of the data array.
     * Identical to the name of the getter in snake case
     */
    const ID = 'signup_id';
    const CUSTOMER_ID = 'customer_id';
    const STORE_ID = 'store_id';
    const STATUS = 'status';
    const SIGNUP_DATE = 'signup_date';
    const REFERRAL_WEBSITE = 'referral_website';
    const SINGUP_MESSAGE = 'signup_message';
    const DECLINE_REASON = 'decline_reason';
    /**#@-*/

    /**
     * Get signup id
     *
     * @return int
     */
    public function getSignupId();

    /**
     * Set signup id
     *
     * @param int $id
     * @return $this
     */
    public function setSignupId($id);

    /**
     * Get customer id
     *
     * @return int
     */
    public function getCustomerId();

    /**
     * Set customer id
     *
     * @param int $customerId
     * @return $this
     */
    public function setCustomerId($customerId);

    /**
     * Get signup store id
     *
     * @return int
     */
    public function getStoreId();

    /**
     * Set signup store id
     *
     * @param int $storeId
     * @return $this
     */
    public function setStoreId($storeId);

    /**
     * Get status
     *
     * @return int
     */
    public function getStatus();

    /**
     * Set status
     *
     * @param int $status
     * @return $this
     */
    public function setStatus($status);

    /**
     * Get signup date
     *
     * @return string|null
     */
    public function getSignupDate();

    /**
     * Set signup date
     *
     * @param string $date
     * @return $this
     */
    public function setSignupDate($date);

    /**
     * Get referral website
     *
     * @return string|null
     */
    public function getReferralWebsite();

    /**
     * Get referral website
     *
     * @param string $website
     * @return $this
     */
    public function setReferralWebsite($website);

    /**
     * Get signup message
     *
     * @return string
     */
    public function getSignupMessage();

    /**
     * Set signup message
     *
     * @param string $message
     * @return $this
     */
    public function setSignupMessage($message);

    /**
     * Get decline reason
     *
     * @return string
     */
    public function getDeclineReason();

    /**
     * Set decline reason
     *
     * @param string $reason
     * @return $this
     */
    public function setDeclineReason($reason);

    /**
     * Retrieve existing extension attributes object or create a new one
     *
     * @return \Aheadworks\Affiliate\Api\Data\SignupExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object
     *
     * @param \Aheadworks\Affiliate\Api\Data\SignupExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aheadworks\Affiliate\Api\Data\SignupExtensionInterface $extensionAttributes
    );
}
