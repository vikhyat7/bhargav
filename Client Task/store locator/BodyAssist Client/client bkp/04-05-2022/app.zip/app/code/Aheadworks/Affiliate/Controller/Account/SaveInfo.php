<?php
/**
 * Aheadworks Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://ecommerce.aheadworks.com/end-user-license-agreement/
 *
 * @package    Affiliate
 * @version    1.2.0
 * @copyright  Copyright (c) 2020 Aheadworks Inc. (http://www.aheadworks.com)
 * @license    https://ecommerce.aheadworks.com/end-user-license-agreement/
 */
namespace Aheadworks\Affiliate\Controller\Account;

use Aheadworks\Affiliate\Api\AccountRepositoryInterface;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Data\Form\FormKey\Validator as FormKeyValidator;
use Magento\Framework\Api\DataObjectHelper;
use Aheadworks\Affiliate\Api\Data\AccountInterface;
use Aheadworks\Affiliate\Api\AccountManagementInterface;
use Aheadworks\Affiliate\Controller\AbstractPostCustomerAction;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Store\Model\StoreManagerInterface;
use Aheadworks\Affiliate\Model\Account\Data\Extractor as AccountDataExtractor;

/**
 * Class SaveInfo
 *
 * @package Aheadworks\Affiliate\Controller\Account
 */
class SaveInfo extends AbstractPostCustomerAction
{
    /**
     * @var DataObjectHelper
     */
    private $dataObjectHelper;

    /**
     * @var AccountManagementInterface
     */
    private $accountService;

    /**
     * @var AccountDataExtractor
     */
    private $accountDataExtractor;

    /**
     * @param Context $context
     * @param CustomerSession $customerSession
     * @param FormKeyValidator $formKeyValidator
     * @param StoreManagerInterface $storeManager
     * @param AccountRepositoryInterface $accountRepository
     * @param DataObjectHelper $dataObjectHelper
     * @param AccountManagementInterface $accountService
     * @param AccountDataExtractor $accountDataExtractor
     */
    public function __construct(
        Context $context,
        CustomerSession $customerSession,
        FormKeyValidator $formKeyValidator,
        StoreManagerInterface $storeManager,
        AccountRepositoryInterface $accountRepository,
        DataObjectHelper $dataObjectHelper,
        AccountManagementInterface $accountService,
        AccountDataExtractor $accountDataExtractor
    ) {
        parent::__construct($context, $customerSession, $formKeyValidator, $storeManager, $accountRepository);
        $this->dataObjectHelper = $dataObjectHelper;
        $this->accountService = $accountService;
        $this->accountDataExtractor = $accountDataExtractor;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        $postData = $this->getRequest()->getPostValue();
        if (!empty($postData)) {
            try {
                $this->validate();
                $account = $this->getAffiliateAccount();
                $accountInfo = $this->accountDataExtractor->extractInfoFields($postData);
                $this->dataObjectHelper->populateWithArray(
                    $account,
                    $accountInfo,
                    AccountInterface::class
                );
                $this->accountService->updateAccount($account);
                $this->messageManager->addSuccessMessage(__('You saved your account data.'));
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addExceptionMessage($e, __('Something went wrong while saving account data.'));
            }
        }
        return $this->getPreparedRedirect();
    }

    /**
     * Retrieve redirect to the current page
     *
     * @return Redirect
     */
    protected function getPreparedRedirect()
    {
        /** @var Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        return $resultRedirect->setRefererOrBaseUrl();
    }
}
