/**
 * Mageants ConfigurableProductWholesale Magento2 Extension 
 */ 
var config = {
    map: {
        '*': {
            'Magento_SalesRule/js/action/cancel-coupon': 'Mageants_FreeGift/js/cancel-coupon',
            'Magento_SalesRule/js/action/set-coupon-code': 'Mageants_FreeGift/js/set-coupon-code',
        },
    }
};
