<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Mageants\FreeGift\Observer;

class CheckQtyBeforeAddtoCart implements \Magento\Framework\Event\ObserverInterface
{
    protected $_request;
    /**
     * RestrictWebsite constructor.
     */
    public function __construct(
        \Magento\Framework\App\RequestInterface $request
    )
    {
        $this->_request = $request;        
    }

    /**
     * Execute observer
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(
        \Magento\Framework\Event\Observer $observer
    ) {
        // $buyRequest = $observer->getEvent()->getBuyRequest();
        // $qty = $buyRequest->getQty();

        // $postValues = $this->_request->getPostValue();
        // $qty = $postValues['qty'];

        // echo"hello";
        // echo($qty);
        // exit();
        // return $qty;
    }
}