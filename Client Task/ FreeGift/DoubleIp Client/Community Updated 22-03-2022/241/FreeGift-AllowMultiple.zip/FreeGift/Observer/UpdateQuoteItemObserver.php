<?php
/**
 * @category Mageants FreeGift
 * @package Mageants_FreeGift
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */
 
namespace Mageants\FreeGift\Observer;

use Magento\Framework\Event\ObserverInterface;

class UpdateQuoteItemObserver implements ObserverInterface
{
	/**
     * @var \Magento\Framework\App\ResponseFactory
     */
    protected $_responseFactory;

	/**
     * @var \Magento\Framework\UrlInterface
     */    
    protected $_url;

	/**
     * @var \Magento\Framework\Message\ManagerInterface
     */
    protected $_messageManager;
    
    /**
     * @param \Magento\Framework\App\ResponseFactory $responseFactory
     * @param \Magento\Framework\UrlInterface $url
     * @param \Magento\Framework\Message\ManagerInterface $messageManager
     */    
    public function __construct(
        \Magento\Framework\App\ResponseFactory $responseFactory,
        \Magento\Framework\UrlInterface $url,
        \Magento\Framework\Message\ManagerInterface $messageManager
    ) {
        $this->_responseFactory = $responseFactory;
        $this->_url = $url;
        $this->_messageManager = $messageManager;
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/test1.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info('UpdateQuoteItemObserver');
        
        $cart = $observer->getEvent()->getCart();
        $data = $observer->getEvent()->getInfo()->toArray(); 

    // echo "bhargav";       
        $logger->info('-----');
        // $logger->info(print_r($data));
    
    // echo "end data";
        
		foreach ($data as $itemId => $itemInfo) {

			$item = $cart->getQuote()->getItemById($itemId);
                // $logger->info('-----');
                // $logger->info(print_r($data));
			
            if($item->getIsFreeItem() == 1 && $itemInfo['qty'] != $item->getQty()) 
            {
				$CustomRedirectionUrl = $this->_url->getUrl('checkout/cart');
				$this->_messageManager->addNotice( __('You can not update Free Gift Qty Please update only main product Qty.') );
				$this->_responseFactory->create()->setRedirect($CustomRedirectionUrl)->sendResponse();
				/* die use for stop excaution */
				 // exit();
             die();

			}
            // if($item->getIsFreeItem() == 0)
            // {
            //     $logger->info('-----');
            //     $logger->info('called in');
            //     $logger->info($item->getQty());

            // }
		}
        return $this;
	}
}
