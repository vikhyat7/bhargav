<?php

namespace Mageants\FreeGift\Plugin;

use Magento\Checkout\Model\Cart;

class Beforeaddtocart
{

    public function beforeAddProduct(Cart $subject, $productInfo, $requestInfo = null)
    {
        // Code that you want to perform before addto cart
        $qty = $requestInfo['qty'];
        
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/test.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info('---');
        $logger->info(print_r("qty". $qty,true));

        // echo "bhargav";
        // echo($qty);
        // exit();
        // return [$productInfo,$requestInfo];
    }
}