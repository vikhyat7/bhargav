# Shipping per product
*********************************************************************

Current version no - 2.0.3
Date - 12/11/2019
*************************************************************************
New Feature
*************************************************************************
	==> Mageants enhancement in shipping per product extension now admin can also add shipping per product price using csv file, extension working fine in all magento version.


*************************************************************************
File changes
*************************************************************************
--> Mageants/ShippingPerProduct/etc/module.xml
--> Mageants/ShippingPerProduct/composer.json

************************************************************************************************************************************************************************************************

Current version no - 2.0.2
Date - 05/04/2019
*************************************************************************
Bug Fixed
*************************************************************************
	==> When user add two product to cart, for one product admin set some Shipping price from backend, but shipping price takes for both product. Now it's working fine in all magento version.

	==> Highest shipping amount was not working properly. Issue fixed in all magento version.
	
*************************************************************************
Bug Fixed
*************************************************************************
Mageants/ShippingPerProduct/Model/Carrier/RockShippingModel.php

************************************************************************************************************************************************************************************************

Current version no - 2.0.1
Date - 11/03/2019
*************************************************************************
Bug Fixed
*************************************************************************
	==> MageAnts update Shipping per product extension in latest magento2.3 version, Now extension working with all magento version.

************************************************************************************************************************************************************************************************

Current version no - 2.0.1
Date - 25/10/2018
*************************************************************************
Bug Fixed
*************************************************************************
	==> Update module version name in composer.json file same as module.xml file.

************************************************************************************************************************************************************************************************

Current version no - 2.0.1
Date - 25/10/2018
*************************************************************************
Bug Fixed
*************************************************************************
	==> When user set Shipping per product price in shipping method then frontend side shipping price display same but backend side it's display different. now issue fixed and working fine in all magento version.

*************************************************************************
File Changes
*************************************************************************
Mageants/ShippingPerProduct/Model/Carrier/RockShippingModel.php

************************************************************************************************************************************************************************************************

Current version no - 2.0.0
Date - 29/6/2018
*************************************************************************
Bug Fixed
*************************************************************************
	==> In Shipping per product module there was issue while add and edit of shipping per product amount value field with decimal /float value was not working on backend as well frontend .
	So this is fixed in current version so now decimal/float value can add in amount field while add/edit Shipping per product and same reflecting on frontend as well.
		
*************************************************************************

