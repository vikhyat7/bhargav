<?php

namespace Mageants\CustomStockStatus\Block\Product;

class Customstatus extends \Magento\Framework\View\Element\Template
{
}
