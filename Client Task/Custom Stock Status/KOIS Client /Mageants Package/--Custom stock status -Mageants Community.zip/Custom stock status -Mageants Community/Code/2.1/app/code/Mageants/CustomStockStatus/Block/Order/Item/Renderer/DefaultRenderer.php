<?php
/**
 * @category Mageants CustomStockStatus
 * @package Mageants_CustomStockStatus
 * @copyright Copyright (c) 2019 Mageants
 * @author Mageants Team <info@mageants.com>
 */

// @codingStandardsIgnoreFile

namespace Mageants\CustomStockStatus\Block\Order\Item\Renderer;


/**
 * Order item render block
 */
class DefaultRenderer extends \Magento\Sales\Block\Order\Item\Renderer\DefaultRenderer
{

}
