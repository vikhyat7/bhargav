var config = {
    map: {
        '*': {
            'mageants_stockstatus': "Mageants_CustomStockStatus/js/mageantsstockstatus"
        }
    }
};
