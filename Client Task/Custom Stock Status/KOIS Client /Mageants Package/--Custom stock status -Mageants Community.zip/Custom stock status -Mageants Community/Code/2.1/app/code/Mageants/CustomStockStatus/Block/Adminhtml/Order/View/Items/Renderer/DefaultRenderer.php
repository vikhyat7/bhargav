<?php
/**
 * @category Mageants CustomStockStatus
 * @package Mageants_CustomStockStatus
 * @copyright Copyright (c) 2019 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\CustomStockStatus\Block\Adminhtml\Order\View\Items\Renderer;


/**
 * Adminhtml sales order item renderer
 */
class DefaultRenderer extends \Magento\Sales\Block\Adminhtml\Order\View\Items\Renderer\DefaultRenderer
{
    
}
