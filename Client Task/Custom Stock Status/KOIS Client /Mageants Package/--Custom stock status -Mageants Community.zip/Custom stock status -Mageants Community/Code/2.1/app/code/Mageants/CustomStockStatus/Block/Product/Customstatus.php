<?php

namespace Mageants\CustomStockStatus\Block\Product;

class Customstatus extends \Magento\Framework\View\Element\Template
{
    /*protected $product;

    public function setProduct(){
    	echo "fsd"; die;
        $this->product = $this->getData('product');
    }

    public function getProduct(){
        return $this->product;
    }*/

}