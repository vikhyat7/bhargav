var config = {
    map: {
        '*': {
            'mageants_stockstatus': "Mageants_CustomStockStatus/js/mageantsstockstatus",
            'mage/SwatchRenderer': 'Magento_Swatches/js/swatch-renderer',
            'Magento_Swatches/js/swatch-renderer': 'Mageants_CustomStockStatus/js/swatch-renderer'
        }
    }
};
