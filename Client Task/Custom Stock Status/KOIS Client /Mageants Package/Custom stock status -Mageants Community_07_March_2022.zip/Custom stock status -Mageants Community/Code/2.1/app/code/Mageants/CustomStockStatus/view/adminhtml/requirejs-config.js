/**
 * Mageants CustomStockStatus Magento2 Extension 
 */ 
var config = {
    "map": {
        "*": {
            'Mageants_CustomStockStatus': 'Mageants_CustomStockStatus/js/custom_option_qty_range'
        }
    }
};
