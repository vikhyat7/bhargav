# Custom stock status

	Current version number: 2.0.9
	Date :- 27/01/2022
	************************************************************
    Bug fixed
	************************************************************
	--> Frontend side in configurable product option is not visible on product page in Magento2.4.3.
	--> Pagination not display in product list page in Magento2.4.3 version, MageAnts team resolved issue and make compatible with All version.

	************************************************************
    File Changes
	************************************************************
	Mageants/CustomStockStatus/Helper/Data.php
	Mageants/CustomStockStatus/view/frontend/templates/order/items/renderer/default.phtml
	Mageants/CustomStockStatus/view/frontend/templates/product/list.phtml
	Mageants/CustomStockStatus/etc/module.xml
	Mageants/CustomStockStatus/composer.json

***********************************************************************************************************************************************************************************

	Current version number: 2.0.8
	Date :- 25/05/2021
	************************************************************
    Bug fixed
	************************************************************
	--> Custom stock status extension not working for configurable product in magento version2.4.2, MageAnts team resolved issue and make compatible with all magento version.

	************************************************************
    File Changes
	************************************************************
	Mageants/CustomStockStatus/Plugin/DefaultRendererPlugin.php
	Mageants/CustomStockStatus/Helper/Data.php
	Mageants/CustomStockStatus/etc/adminhtml/system.xml
	Mageants/CustomStockStatus/view/frontend/web/js/swatch-renderer.js
	Mageants/CustomStockStatus/etc/module.xml
	Mageants/CustomStockStatus/composer.json

***********************************************************************************************************************************************************************************

	Current version number: 2.0.7
	Date :- 05/10/2020
	************************************************************
    Bug fixed
	************************************************************
	--> Mageants team make Custom stock status extension compatible in Magento2.4 latest version.
	--> Custom stock status not changing in configurable products when customer change product attributes at product page, MageAnts team resolved issue in all magento version.

	************************************************************
    File Changes
	************************************************************
	Mageants/CustomStockStatus/view/frontend/templates/product/view/renderer.phtml
	Mageants/CustomStockStatus/view/frontend/web/js/swatch-renderer.js
	Mageants/CustomStockStatus/Plugin/ConfigurableProduct/Product/View/Type/Configurable.php
	Mageants/CustomStockStatus/etc/module.xml
	Mageants/CustomStockStatus/composer.json

***********************************************************************************************************************************************************************************

	Current version number: 2.0.6
	Date :- 02/06/2020
	************************************************************
    Bug fixed
	************************************************************
	--> When admin not upload custom stock status icon then img src tag display in console element. Mageants remove img src tag when icon not uploaded.(Product page, Cart page, Backend frontend order grid).

	--> Resolved issue of custom stock status update automatically based on quantity of product. MageAnts resolved issue in all magento version now extension working fine in all version.

	************************************************************
    File Changes
	************************************************************
	--> Mageants/CustomStockStatus/view/adminhtml/templates/QuantityRange.phtml
	--> Mageants/CustomStockStatus/view/frontend/templates/product/view/type/default.phtml
	--> Mageants/CustomStockStatus/Plugin/AttributePlugin.php
	--> Mageants/CustomStockStatus/view/frontend/templates/order/items/renderer/default.phtml
	--> Mageants/CustomStockStatus/view/frontend/templates/customstock/list.phtml
	--> Mageants/CustomStockStatus/Plugin/DefaultRendererPlugin.php
	--> Mageants/CustomStockStatus/Helper/Data.php
	--> Mageants/CustomStockStatus/Plugin/BeforeAllowProducts.php
	--> Mageants/CustomStockStatus/view/frontend/templates/product/view/type/default.phtml
	--> Mageants/CustomStockStatus/etc/di.xml
	--> Mageants/CustomStockStatus/etc/module.xml
	--> Mageants/CustomStockStatus/composer.json

***********************************************************************************************************************************************************************************

	Current version number: 2.0.5
	Date :- 10/06/2019
	************************************************************
    New feature
	************************************************************
	--> MageAnts enhancement in Custom stock status extension now custom stock status icon also display in frontend backend order grid.

	************************************************************
    File Changes
	************************************************************
	Mageants/CustomStockStatus/etc/adminhtml/system.xml
	Mageants/CustomStockStatus/etc/module.xml
	Mageants/CustomStockStatus/Helper/Data.php
	Mageants/CustomStockStatus/etc/di.xml
	Mageants/CustomStockStatus/etc/adminhtml/system.xml

	************************************************************
    New Added
	************************************************************
	Mageants/CustomStockStatus/view/frontend/layout/sales_order_view.xml
	Mageants/CustomStockStatus/view/frontend/layout/sales_order_item_renderers.xml
	Mageants/CustomStockStatus/view/frontend/templates/order/items.phtml
	Mageants/CustomStockStatus/view/frontend/templates/order/items/renderer/default.phtml
	Mageants/CustomStockStatus/view/frontend/templates/order/items/renderer/renderer.phtml
	Mageants/CustomStockStatus/view/adminhtml/layout/sales_order_view.xml
	Mageants/CustomStockStatus/view/adminhtml/templates/order/view/items/renderer/default.phtml
	Mageants/CustomStockStatus/Block/Order/Item/Renderer/DefaultRenderer.php
	Mageants/CustomStockStatus/Block/Adminhtml/Order/View/Items/Renderer/DefaultRenderer.php

***********************************************************************************************************************************************************************************

	Current version number: 2.0.4
	Date :- 11/03/2019
	************************************************************
    Bug fixed
	************************************************************
	--> MageAnts update Custom stock status extension in latest magento2.3 version, Now extension working with all magento version.

***********************************************************************************************************************************************************************************

	Current version number: 2.0.4
	Date :- 16/01/2019
	************************************************************
    Bug fixed
	************************************************************
	--> Update module version name in composer.json file same as module.xml file.

***********************************************************************************************************************************************************************************

	Current version number: 2.0.4
	Date :- 30/11/2018
	************************************************************
    Bug fixed
	************************************************************
	--> When user open configurable product in frontend then product attributes not display in product view page, now issue solve and working fine in all magento version.

	************************************************************
    File list
	************************************************************
	Mageants/CustomStockStatus/Helper/Data.php


	Current version number: 2.0.3
	Date :- 1/10/2018
	************************************************************
    Bug fixed
	************************************************************
	==> When user click on view and edit cart page then cart page not loading, now issue solve and working fine for all version.

	************************************************************
    File list
	************************************************************
	Mageants/CustomStockStatus/view/frontend/layout/checkout_cart_item_renderers.xml
	Mageants/CustomStockStatus/etc/module.xml

***********************************************************************************************************************************************

	Current version number: 2.0.2
	Date :- 21/09/2018
	************************************************************
    Bug fixed
	************************************************************
	Extension working fine in all magento version.