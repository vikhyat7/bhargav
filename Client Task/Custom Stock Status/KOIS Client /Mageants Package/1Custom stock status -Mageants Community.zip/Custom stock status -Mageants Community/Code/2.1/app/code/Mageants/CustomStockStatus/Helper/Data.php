<?php
/**
 * @category Mageants CustomStockStatus
 * @package Mageants_CustomStockStatus
 * @copyright Copyright (c) 2018 Mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\CustomStockStatus\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{

    protected $_adapterFactory;

    protected $_uploader;

    protected $_filesystem;

    protected $_messageManager;

    protected $_scopeConfig;

    protected $_customIconManage;

    protected $_customRuleManage;

    protected $_stockItemRepository; 

    protected $_eavConfig;

    protected $_objectManager;

    protected $_productloader;

    protected $_date;

    protected $_productRepository;

    protected $_postHelper;

    protected $_jsonHelper;

    CONST ICON_PATH = 'mageants/customStatusIcon/images/';

    CONST CUSTOM_STOCK_STATUS_ATTRIBUTE = 'mageants_custom_stock_status';
    
    public function __construct(
        \Magento\Framework\Image\AdapterFactory $adapterFactory,
        \Magento\MediaStorage\Model\File\UploaderFactory $uploader,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Framework\Message\Manager $messageManager,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Mageants\CustomStockStatus\Model\CustomStockStFactory $CustomIconManage,
        \Mageants\CustomStockStatus\Model\CustomStockRuleFactory $CustomRuleManage,
        \Magento\CatalogInventory\Model\Stock\StockItemRepository $stockItemRepository,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Catalog\Model\ProductFactory $_productloader,
        \Magento\Framework\Stdlib\DateTime\DateTime $date,
        \Magento\Catalog\Model\ProductRepository $productRepository,
        \Magento\Eav\Model\Config $eavConfig,
        \Magento\Framework\Data\Helper\PostHelper $postHelper,
        \Magento\Framework\Json\Helper\Data $jsonHelper
    ) { 
       $this->_adapterFactory = $adapterFactory;
       $this->_uploader = $uploader;
       $this->_filesystem = $filesystem; 
       $this->_messageManager   = $messageManager;  
       $this->_scopeConfig = $scopeConfig; 
       $this->_customIconManage = $CustomIconManage; 
       $this->_customRuleManage = $CustomRuleManage;
       $this->_stockItemRepository = $stockItemRepository;
       $this->_eavConfig = $eavConfig;
       $this->_objectManager = $objectManager;
       $this->_productloader = $_productloader;
       $this->_date = $date;
       $this->_productRepository = $productRepository;
       $this->_postHelper = $postHelper;
       $this->_jsonHelper = $jsonHelper;

    }

    public function getVisibleBothStatus()
    {
        $visibleStatus = $this->_scopeConfig->getValue('CustomStockSt/general/outofstockitem',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);

        return $visibleStatus;
    }

    public function getHideStockStatus()
    {
        $hideStatus =$this->_scopeConfig->getValue('CustomStockSt/general/hidestockst',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);

        return $hideStatus;
    }

    public function getUseQtyRange()
    {
        $useQtyRange = $this->_scopeConfig->getValue('CustomStockSt/general/useqtyrange', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

        return $useQtyRange;
    }

    public function getRuleQtyRange()
    {
        $ruleQtyRange = $this->_scopeConfig->getValue('CustomStockSt/general/ruleqtyrange', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

        return $ruleQtyRange;
    }

    public function getDisplayIcon()
    {
        $displayIcon = $this->_scopeConfig->getValue('CustomStockSt/general/displayicon', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

        return $displayIcon;
    }

    public function getBackInStockAlert()
    {
        $stockAlert = $this->_scopeConfig->getValue('CustomStockSt/general/backinstockconfig', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

        return $stockAlert;
    }


    public function getOutOfStockAttribute()
    {
        $configAttribute = $this->_scopeConfig->getValue('CustomStockSt/general/outofstockconfigattribute', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

        return $configAttribute;
    }

    public function getChangeConfigProduct()
    {
        $changeConfigPro = $this->_scopeConfig->getValue('CustomStockSt/general/changeconfigproductst', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

        return $changeConfigPro;
    }

    public function getLoadProduct($id)
    {
        return $this->_productloader->create()->load($id);
    }

    public function getCustomStockLabel($productOptionId,$productOptionRule,$productOptionQtyRule,$productId)
    {
     
      
      $useQtyRange = $this->getUseQtyRange();
      $ruleQtyRange = $this->getRuleQtyRange();

      $customRule = $this->_customRuleManage->create();

        $productLoad = $this->_stockItemRepository->get($productId);
        $productQty = $productLoad->getQty(); 
        $backorderRule = $productLoad->getBackorders(); 
        
        $customStockSt = array(); 
        $foundRule = 0;

        $customStatus = $customRule->getCollection()->addFieldToFilter('option_id',$productOptionId);

        if($productOptionId && !$productOptionQtyRule && !$productOptionRule):
            
            $customStockSt = $this->getAttributeOption($productOptionId,$productId,$productQty);
          
            return $customStockSt;
      
        endif;  

        if($useQtyRange && $productOptionQtyRule && $ruleQtyRange && $productOptionRule):
            $foundRule = 1;
            
            $customStatus = $customStatus->addFieldToFilter('rule_id',$productOptionRule);

        elseif($backorderRule && $ruleQtyRange && $useQtyRange):
            $foundRule = 1;
            $customStatus = $customStatus->addFieldToFilter('rule_id',$backorderRule);

        endif;    

        if(count($customStatus)>=1):

            foreach ($customStatus as $statusData):
                    
                    if(!$ruleQtyRange && $productOptionRule && $foundRule == 0):

                      continue;

                    endif;

                    if($productQty >= $statusData['from'] && $productQty  <= $statusData['to'] && $useQtyRange && $productOptionQtyRule)
                    {  
                      if($productOptionQtyRule && $useQtyRange):

                        $customStockSt = $this->getAttributeOption($statusData['option_id'],$productId,$productQty);

                       return $customStockSt;

                      else:
                          
                         continue;

                      endif; 

                    }elseif ($productOptionId && !$productOptionQtyRule && !$productOptionRule) {   
                        $customStockSt = $this->getAttributeOption($statusData['option_id'],$productId,$productQty);

                       return $customStockSt;
                    }
                     
            endforeach;  

        else:
            
            $customStockSt = array();   

            return $customStockSt;

        endif;
        
      return $customStockSt; 

    }

    public function getAttributeOption($optionId,$productId,$productQty)
    { 
        $attributeDetails = $this->_eavConfig->getAttribute("catalog_product", self::CUSTOM_STOCK_STATUS_ATTRIBUTE);
        $allOptions = $attributeDetails->getSource()->getAllOptions();

        $customStockSt = array();
        if(count($allOptions) >= 1):

            foreach ($allOptions as $options):

                if($options['value'] == $optionId):
                     
                    $customIcon = $this->_customIconManage->create();

                    $optionIconCollection = $customIcon->getCollection()->addFieldToFilter('option_id',$optionId)->getFirstItem();

                    $mediaPath= $this->getMediaImagePath();
                    if($optionIconCollection->getData('icon')){

                        $customStockSt['icon'] = $mediaPath.$optionIconCollection->getData('icon');
                    }else{
                        $customStockSt['icon'] = '';
                    }
                   
                    $customStockSt['label'] = $this->getOptionVariable($options['label'],$productId,$productQty);

                    return $customStockSt;

                endif;    

            endforeach;

        endif;   
        
      return $customStockSt;

    }

   public function getOptionVariable($option,$productId,$productQty)
   {

       if (strpos($option, '{qty}') !== false) 
       {
            $option = str_replace('{qty}',$productQty,$option);

       }elseif(strpos($option, '{special_price}') !== false)
       {
            $product = $this->_productRepository->getById($productId);
            $productSpacialPrice = number_format($product->getSpecialPrice(),2);

            $option = str_replace('{special_price}',$productSpacialPrice,$option);
 
       }elseif (strpos($option, '{day-after-tomorrow}') !== false) {

            $date = $this->_date->date();
            $newDate = date("M j, Y", strtotime($date.'+2 day'));
            $option = str_replace('{day-after-tomorrow}',$newDate,$option);

       }elseif(strpos($option, '{tomorrow}') !== false){

            $date = $this->_date->date();
            $newDate = date("M j, Y", strtotime($date.'+1 day'));
            $option = str_replace('{tomorrow}',$newDate,$option);

       }else{

            $option;
       }    

       return $option;

   }

   public function getConfigurableAttribute($attributesData)
   {     
       $i=1;
       foreach($attributesData['attributes'] as $productAttribute) {

            foreach($productAttribute['options'] as $key => $attribute) {

                $optionId[$i][$attribute['id']]= $attribute['products'];
            } 
         $i++;
        } 

        $optionIdArray = array_shift($optionId);

        $mergeOptionIdArray = $optionId;

        $configAttributeData = array();
        $removeKey =array();
        foreach($optionIdArray as $key=>$mainOptVal){
            
            $mainOptKey = $key;

            foreach ($mergeOptionIdArray as $mergeOptionId) {
                $j=0;  
                foreach ($mergeOptionId as $childKey => $optionValue) {
                    
                    $product = $this->getLoadProduct($mainOptVal[$j]);
                    
                    $productOptionId = $product->getMageantsCustomStockStatus(); 
                    
                    $productOptionRule = $product->getMageantsCustomStockRule();
                    $productOptionQtyRule = $product->getMageantsQtyBaseRuleStatus();
                    $productId = $product->getId();

                    $customLable = $this->getCustomStockLabel($productOptionId,$productOptionRule,$productOptionQtyRule,$productId);
        
                    $productLoad = $this->_stockItemRepository->get($productId);
                    $productInStock = $productLoad->getIsInStock();

                    $hideDefaultSt = $this->getHideStockStatus();
                    $productStockAlert = ' ';
                    $productStockLb = ' ';
                    if($productInStock)
                    {
                        $productInStock = 1;

                        if(!$hideDefaultSt):
                          $productStockLb = "In stock";
                        endif;
                    }else{

                        $productInStock = 0;

                        if(!$hideDefaultSt):
                          $productStockLb = "Out of stock";
                        endif;

                        $StockAlertEnable = $this->getBackInStockAlert();

                        if($StockAlertEnable):

                         $baseUrl = $this->_objectManager->get('Magento\Store\Model\StoreManagerInterface')
                            ->getStore()
                            ->getBaseUrl();

                         $productAlert = $baseUrl."productalert/add/stock/product_id/".$productId;
                            
                         $productAlertData = $this->_postHelper->getPostData($productAlert);

                         $productAlertArray = $this->_jsonHelper->jsonDecode($productAlertData);

                         $productAlertEncodeUrl = $productAlert."/uenc/".$productAlertArray['data']['uenc'];

                         $productAlertUrl = $this->_postHelper->getPostData($productAlertEncodeUrl);

                         $stockAlertLabel = 'Sign up to get notified when this configuration is back in stock';

                         $productStockAlert = '<div class="product alert alert stock link-stock-alert">
                                    <a href="#" data-post='.$productAlertUrl.'
                                       title='.$stockAlertLabel.' class="action alert">'.$stockAlertLabel.'
                                    </a>
                                </div>';
                        endif;      
                    }

                    $customStatusText = '';
                    if(is_array($customLable)):
                      
                      if(array_key_exists("label",$customLable))
                      {
                        $customStatusText = $customLable['label'];
                        $removeKey[$mainOptKey] = "yes";
                      }
                    endif;

                    $customStatus = '';
                    $customStatusOptionClass= 'customstockstatus status_'.$mainOptKey;

                    if(is_array($customLable)):
                      if(array_key_exists("label",$customLable) && array_key_exists("icon",$customLable))
                      {
                        $customStatus = $productStockLb.'<img class="custom_stock_status_icon" src='.$customLable['icon'].' alt="" title=""/><span class="'.$customStatusOptionClass.'">'.$customLable['label'].'</span>';
                      }elseif($customStatusText != null){
                          $customStatus = $productStockLb.'<span class="'.$customStatusOptionClass.'">'.$customLable['label'].'</span>';
                      }
                    endif;
                   
                    $customStatusIcon= '';
                    if(is_array($customLable)):
                      if(array_key_exists("icon",$customLable))
                      {
                        $customStatusIcon ='<img src='.$customLable['icon'].' class="custom_stock_status_icon" alt="" title="">';
                      }
                    endif;

                    $customStatusIconOnly = $this->getDisplayIcon();
 
                    $changeConfigurableStatus = $this->getChangeConfigProduct();
                    
                    if($j==1)
                    {  
                               
                          $configAttributeData[$mainOptKey] = [

                            'is_in_stock' => $productInStock,
                            'custom_stock_status_text' => $customStatusText,
                            'custom_stock_status' => $customStatus,
                            'custom_stock_status_icon' => $customStatusIcon,
                            'custom_stock_status_icon_only' => $customStatusIconOnly,
                            'product_id' => $productId,
                          ];

                    }

                    if($productStockAlert != null):

                    $configAttributeData[$mainOptKey.",".$childKey] = [

                        'is_in_stock' => $productInStock,
                        'custom_stock_status_text' => $customStatusText,
                        'custom_stock_status' => $customStatus,
                        'custom_stock_status_icon' => $customStatusIcon,
                        'custom_stock_status_icon_only' => $customStatusIconOnly,
                        'product_id' => $productId,
                        'stockalertmessage' => $productStockAlert,

                      ];
                    else:
                    $configAttributeData[$mainOptKey.",".$childKey] = [

                        'is_in_stock' => $productInStock,
                        'custom_stock_status_text' => $customStatusText,
                        'custom_stock_status' => $customStatus,
                        'custom_stock_status_icon' => $customStatusIcon,
                        'custom_stock_status_icon_only' => $customStatusIconOnly,
                        'product_id' => $productId,

                      ];   

                    endif; 
                     
                  
                    $j++;
                }
            }
        }
       
        
            foreach ($configAttributeData as $key => $value) {
                    
                 if(array_key_exists($key,$removeKey))
                 { 
                    $configAttributeData[$key] = NULL;
                 }
            }
       
            $configAttributeData['changeConfigurableProductStatus'] = $changeConfigurableStatus;
            $configAttributeData['type'] = "product.info.options.swatches";

        return $configAttributeData;
   }

   public function getConfigurableAttributeDropdown($simpleProductId,$attributeData)
   {  
        
      foreach ($attributeData as $attribute) {
           
        foreach ($attribute->getData('options') as $key => $optioId) {
      
           $productId = $simpleProductId[$key];

           $product = $this->getLoadProduct($productId);

           $productOptionId = $product->getMageantsCustomStockStatus(); 
           $productOptionRule = $product->getMageantsCustomStockRule();
           $productOptionQtyRule = $product->getMageantsQtyBaseRuleStatus();

           $customLable = $this->getCustomStockLabel($productOptionId,$productOptionRule,$productOptionQtyRule,$productId);

           $productLoad = $this->_stockItemRepository->get($productId);
           $productInStock = $productLoad->getIsInStock();
           $hideDefaultSt = $this->getHideStockStatus();

            $productStockAlert = ' '; 
            $productStockLb = ' ';    
            if($productInStock)
            {
                $productInStock = 1;

                if(!$hideDefaultSt):
                    $productStockLb = "In stock";
                endif;

            }else{
                 $productInStock = 0;

                  if(!$hideDefaultSt):
                    $productStockLb = "Out of stock";
                  endif;

                 $StockAlertEnable = $this->getBackInStockAlert();

                    if($StockAlertEnable):

                     $baseUrl = $this->_objectManager->get('Magento\Store\Model\StoreManagerInterface')
                        ->getStore()
                        ->getBaseUrl();

                     $productAlert = $baseUrl."productalert/add/stock/product_id/".$productId;
                        
                     $productAlertData = $this->_postHelper->getPostData($productAlert);

                     $productAlertArray = $this->_jsonHelper->jsonDecode($productAlertData);

                     $productAlertEncodeUrl = $productAlert."/uenc/".$productAlertArray['data']['uenc'];

                     $productAlertUrl = $this->_postHelper->getPostData($productAlertEncodeUrl);

                     $stockAlertLabel = 'Sign up to get notified when this configuration is back in stock';

                     $productStockAlert = '<div class="product alert alert stock link-stock-alert">
                                <a href="#" data-post='.$productAlertUrl.'
                                   title='.$stockAlertLabel.' class="action alert">'.$stockAlertLabel.'
                                </a>
                            </div>';
                    endif;      
            }

            $customStatusText = '';
            if(isset($customLable['label']) &&  $customLable['label'] != ' ')
            {
              $customStatusText = $customLable['label'];
            }

            $customStatus = '';
            $customStatusOptionClass= 'customstockstatus status_'.$optioId['value_index'];
            if($customLable['label'] && $customLable['icon'])
            {
              $customStatus = $productStockLb.'<img class="custom_stock_status_icon" src='.$customLable['icon'].' alt="" title=""/><span class="'.$customStatusOptionClass.'">'.$customLable['label'].'</span>';
            }elseif($customStatusText != null){
                $customStatus = $productStockLb.'<span class="'.$customStatusOptionClass.'">'.$customLable['label'].'</span>';
            }
            
            $customStatusIcon= '';
            if($customLable['icon'])
            {
              $customStatusIcon ='<img src='.$customLable['icon'].' class="custom_stock_status_icon" alt="" title="">';
            }
            
            $customStatusIconOnly = $this->getDisplayIcon();

            $changeConfigurableStatus = $this->getChangeConfigProduct();

            if($productStockAlert != null):

                    $configAttributeData[$optioId['value_index']] = [

                        'is_in_stock' => $productInStock,
                        'custom_stock_status_text' => $customStatusText,
                        'custom_stock_status' => $customStatus,
                        'custom_stock_status_icon' => $customStatusIcon,
                        'custom_stock_status_icon_only' => $customStatusIconOnly,
                        'product_id' => $productId,
                        'stockalertmessage' => $productStockAlert,

                      ];
            else:
                    $configAttributeData[$optioId['value_index']] = [

                        'is_in_stock' => $productInStock,
                        'custom_stock_status_text' => $customStatusText,
                        'custom_stock_status' => $customStatus,
                        'custom_stock_status_icon' => $customStatusIcon,
                        'custom_stock_status_icon_only' => $customStatusIconOnly,
                        'product_id' => $productId,

                      ];
            endif;  
              
        }

            $configAttributeData['changeConfigurableProductStatus'] = $changeConfigurableStatus;
            $configAttributeData['type'] = "product.info.options.swatches";

      }

      return $configAttributeData;

   }

   public function getMediaImagePath()
   {

       $mediapath = $this->_objectManager->get('Magento\Store\Model\StoreManagerInterface')
                ->getStore()
                ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);

       return $mediapath;

   }

    public function iconUpload($icon,$optionId)
    {
        /*  Save image upload */
        $optionIcon = '';
      
        try {              
                $imageName = 'manage_icon['.$optionId.']';

                $mediaDirectory = $this->_filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);

                if(file_exists($mediaDirectory->getAbsolutePath(self::ICON_PATH.$icon)))
                {
                    unlink($mediaDirectory->getAbsolutePath(self::ICON_PATH.$icon));  
                }

                $uploader = $this->_uploader->create(['fileId' => $imageName]);
          
                $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);

                $imageAdapter = $this->_adapterFactory->create();

                $uploader->addValidateCallback('image', $imageAdapter, 'validateUploadFile');

                $uploader->setAllowRenameFiles(true);

                $uploader->setFilesDispersion(false);

               

                $result = $uploader->save($mediaDirectory->getAbsolutePath(self::ICON_PATH));

                $optionIcon = self::ICON_PATH.$icon;


            } catch (\Exception $e) {
                
                $this->_messageManager->addError($e->getMessage());
           
           }
       
        return $optionIcon;
    }

    public function getStockItem($productId){
       return $this->_stockItemRepository->get($productId);
    }

    public function getProductBySku($sku){
       return $this->_productRepository->get($sku);
    }

}
