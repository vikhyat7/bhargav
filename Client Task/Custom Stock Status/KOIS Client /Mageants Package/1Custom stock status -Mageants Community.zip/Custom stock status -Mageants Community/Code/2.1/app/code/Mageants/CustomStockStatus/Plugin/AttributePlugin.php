<?php
/**
 * @category Mageants CustomStockStatus
 * @package Mageants_CustomStockStatus
 * @copyright Copyright (c) 2018 Mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\CustomStockStatus\Plugin;

use Magento\Catalog\Model\ResourceModel\Eav\Attribute;

class AttributePlugin
{
   
    protected $_request;

    protected $_customIconManage;

    protected $_iconHelper;

    protected $_filesystem;

    protected $_customRuleManage;

    public function __construct(
        \Magento\Framework\App\Request\Http $request,
        \Mageants\CustomStockStatus\Model\CustomStockStFactory $customIconManage,
        \Mageants\CustomStockStatus\Model\CustomStockRuleFactory $customRuleManage,
        \Mageants\CustomStockStatus\Helper\Data $iconHelper,
        \Magento\Framework\Filesystem $filesystem
    ) {
       $this->_request = $request;
       $this->_customIconManage = $customIconManage;  
       $this->_customRuleManage = $customRuleManage; 
       $this->_iconHelper = $iconHelper; 
       $this->_filesystem = $filesystem;   
    }

    public function aroundSave(Attribute $subject, \Closure $proceed)
    {       
        $postData = $this->_request->getPostValue();
        $imageFiles = $this->_request->getFiles('manage_icon');
        

        if(isset($postData['manage_icon_delete'])):
          
            $mediaDirectory = $this->_filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);

            foreach ($postData['manage_icon_delete'] as $optionId => $deleteImage):

                 if($deleteImage == 1):

                    $customIconDelete = $this->_customIconManage->create();
                    $optionIconDeleteCollection = $customIconDelete->getCollection()->addFieldToFilter('option_id',$optionId)->getFirstItem();

                    if(count($optionIconDeleteCollection->getData()) >= 1):
        
                        unlink($mediaDirectory->getAbsolutePath($optionIconDeleteCollection->getData('icon')));  
            
                        $customIconDelete->load($optionIconDeleteCollection->getData('id'));
                        $customIconDelete->delete();

                    endif;

                endif;

            endforeach;

        endif;

        if(isset($imageFiles)):
        
            foreach ($imageFiles as $optionId => $icon):

                if($icon['name']):

                        $optionIcon = $this->_iconHelper->iconUpload($icon['name'],$optionId);
                        $customIcon = $this->_customIconManage->create();
                        $optionIconCollection = $customIcon->getCollection()->addFieldToFilter('option_id',$optionId)->getFirstItem();
                 
                        if(count($optionIconCollection->getData()) >= 1):
                
                            $customIcon->load($optionIconCollection->getData('id'));
                        
                        endif;
                        $customIcon->setOptionId($optionId);
                        $customIcon->setIcon($optionIcon);
                        $customIcon->save();                        
                 endif;
            endforeach;
            
       endif;

        if(isset($postData['custom_status_rule_range'])):

            foreach ($postData['custom_status_rule_range'] as $key => $rangeRule):

                        $customRule = $this->_customRuleManage->create();
                        
                         if($rangeRule['delete'])
                        {
                            $customRule->load($rangeRule['delete']);
                            $customRule->delete();
                            continue;

                        } elseif($rangeRule['id'])
                        { 
                            $customRule->load($rangeRule['id']);
                        }
                        $customRule->setFrom($rangeRule['from']);
                        $customRule->setTo($rangeRule['to']);
                        $customRule->setOptionId($rangeRule['option_id']);
                        $customRule->setRuleId($rangeRule['rule_id']);
                        $customRule->save();

                         
            endforeach;
            
        endif;
       return $proceed();       
    }
}
