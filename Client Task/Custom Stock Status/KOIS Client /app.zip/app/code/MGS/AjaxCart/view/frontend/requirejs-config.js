var config = {
    map: {
        '*': {
            catalogAddToCart:       'MGS_AjaxCart/js/action/catalog-add-to-cart',
            productAddToCart:       'MGS_AjaxCart/js/action/product-add-to-cart',
            mgsAjaxCartFooter:      'MGS_AjaxCart/js/footer',
            mgsAjaxCartStockOption: 'MGS_AjaxCart/js/stock-option',
        }
    }
};
