<?php
/**
 * Copyright © 2016 MGS. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace MGS\AjaxCart\Block;
class AjaxCart extends \Magento\Framework\View\Element\Template
{
	public function __construct(
		\Magento\Framework\View\Element\Template\Context $context,
		array $data = []
	){	
		 parent::__construct($context, $data);
	}
	
	
	
}