define([
    'jquery'
], function($) {
    "use strict";

    var mgsConfig = {
        requestParamName: 'ajax',
    };
    mgsConfig.setOptions = function(options) {
        for (var optionName in options) {
            this[optionName] = options[optionName];
        }
    };

    return mgsConfig;
});
