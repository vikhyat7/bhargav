var config = {
    map: {
        '*': {
               
            aQuickView: 'MGS_Aquickview/js/quickview'
        
        }
    },
    paths: {
    },
};
 
