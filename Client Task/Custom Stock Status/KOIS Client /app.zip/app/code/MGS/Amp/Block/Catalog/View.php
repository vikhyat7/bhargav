<?php

namespace MGS\Amp\Block\Catalog;

/**
 * Class View
 * @package MGS\Amp\Block\Catalog
 */
class View extends  \Magento\Catalog\Block\Category\View
{
	
}
