<?php

namespace Bss\OptionTemplateFix\Plugin\Condition;

use Magento\Framework\Module\Manager;

class ProductVariant
{
    const OPTION_TEMPLATE_MODULE = 'Bss_CustomOptionTemplate';

    /**
     * @var Manager
     */
    protected $moduleManager;

    /**
     * ProductVariant constructor.
     * @param Manager $moduleManager
     */
    public function __construct(
        Manager $moduleManager
    ) {
        $this->moduleManager = $moduleManager;
    }

    /**
     * @param \Magento\CatalogRule\Model\Rule\Condition\Product $productCondition
     * @param $result
     * @param \Magento\Framework\Model\AbstractModel $model
     * @return bool
     */
    public function afterValidate(
        \Magento\CatalogRule\Model\Rule\Condition\Product $productCondition,
        $result,
        \Magento\Framework\Model\AbstractModel $model
    ) {
        $priceInvalidTypes = [
            'grouped',
            'bundle',
            'configurable'
        ];
        $attrCode = $productCondition->getAttribute();
        if ($this->moduleManager->isEnabled(self::OPTION_TEMPLATE_MODULE) && $attrCode === 'price') {
            $oldAttrValue = $model->getData($attrCode);
            if ($oldAttrValue === null) {
                if ($productCondition->getOperator() === '<=>') {
                    return $result;
                }
                if (in_array($model->getTypeId(), $priceInvalidTypes)) {
                    $priceInit = (float) 0;
                    return $productCondition->validateAttribute($priceInit);
                }
                return $result;
            }
        }
        return $result;
    }
}