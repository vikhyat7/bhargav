 /**
 * Mageants GiftCertificate Magento2 Extension                           
 */
var config = {
    map: {
        '*': {
            giftcertificate: 'Mageants_GiftCertificate/js/giftcertificate',
        }
    }
}