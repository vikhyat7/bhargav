<?php
/**
 * Copyright © MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\ShippingRules\Controller\Adminhtml\Shippingrules\Carrier;

use MageWorx\ShippingRules\Controller\Adminhtml\Shippingrules\Base\MassChangeStatusAbstract;

/**
 * Class MassChangeStatus
 */
class MassChangeStatus extends MassChangeStatusAbstract
{

}
