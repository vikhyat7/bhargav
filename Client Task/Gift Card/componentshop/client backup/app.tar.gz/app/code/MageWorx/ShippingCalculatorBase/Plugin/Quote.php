<?php
/**
 * Copyright © MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\ShippingCalculatorBase\Plugin;

use MageWorx\ShippingCalculatorBase\Api\EstimateShippingMethodsInterface;

/**
 * Class Quote
 */
class Quote
{
    /**
     * @param \Magento\Quote\Model\Quote $subject
     * @param $result
     * @return bool
     */
    public function afterIsSaveAllowed($subject, $result)
    {
        if ($subject->getData(EstimateShippingMethodsInterface::QUOTE_SAVE_DISABLED_FLAG)) {
            $result = false;
        }

        return $result;
    }
}
