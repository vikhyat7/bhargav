<?php
return [
    'backend' => [
        'frontName' => 'csadmin'
    ],
    'crypt' => [
        'key' => 'a9cewumx2gsh2nui9ai2uybohm2azxqy'
    ],
    'db' => [
        'table_prefix' => 'mgye_',
        'connection' => [
            'default' => [
                'host' => 'localhost',
                'dbname' => 'lnepower_ma',
                'username' => 'lnepower_ma',
                'password' => 'hghkKL5GL6Td',
                'active' => '1',
                'driver_options' => [

                ]
            ]
        ]
    ],
    'resource' => [
        'default_setup' => [
            'connection' => 'default'
        ]
    ],
    'x-frame-options' => 'SAMEORIGIN',
    'MAGE_MODE' => 'production',
    'session' => [
        'save' => 'files'
    ],
    'cache' => [
        'frontend' => [
            'default' => [
                'id_prefix' => '0b3_'
            ],
            'page_cache' => [
                'id_prefix' => '0b3_'
            ]
        ]
    ],
    'lock' => [
        'provider' => 'db',
        'config' => [
            'prefix' => null
        ]
    ],
    'cache_types' => [
        'config' => 1,
        'layout' => 1,
        'block_html' => 1,
        'collections' => 1,
        'reflection' => 1,
        'db_ddl' => 1,
        'compiled_config' => 1,
        'eav' => 1,
        'customer_notification' => 1,
        'config_integration' => 1,
        'config_integration_api' => 1,
        'full_page' => 1,
        'config_webservice' => 1,
        'translate' => 1,
        'vertex' => 1
    ],
    'downloadable_domains' => [
        'componentshop.co.uk'
    ],
    'http_cache_hosts' => [
        [
            'host' => '127.0.0.1',
            'port' => '6081'
        ]
    ],
    'install' => [
        'date' => 'Thu, 24 Sep 2020 14:36:57 +0100'
    ]
];
