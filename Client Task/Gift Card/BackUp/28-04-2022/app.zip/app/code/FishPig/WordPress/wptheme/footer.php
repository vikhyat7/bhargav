<?php
/**
 *
 */
// phpcs:ignoreFile -- this file is a WordPress theme file and will not run in Magento
?>
    <!--/WP-BODY-->
	<!--WP-FOOTER--><?php wp_footer() ?><!--/WP-FOOTER-->
</body>
</html>