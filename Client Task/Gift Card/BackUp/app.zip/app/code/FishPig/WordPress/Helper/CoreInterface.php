<?php
/**
 *
 */
namespace FishPig\WordPress\Helper;

interface CoreInterface
{

}
