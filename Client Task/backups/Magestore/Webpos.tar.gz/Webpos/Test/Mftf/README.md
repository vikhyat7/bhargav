# Webpos Functional Tests

The Functional Test Module for **Magestore Webpos** module.
