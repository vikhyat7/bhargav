<?php

/**
 * stock simple Data
 */
namespace Magestore\Webpos\Test\Constant;

/**
 * Class Stock
 * @package Magestore\Webpos\Test\Constant
 */
class Stock
{
    const STOCK_ID  = 10;
    const STOCK_NAME = 'stock-name-1';
}
