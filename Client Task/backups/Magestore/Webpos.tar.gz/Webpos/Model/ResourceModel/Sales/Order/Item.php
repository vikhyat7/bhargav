<?php

/**
 * Copyright © 2018 Magestore. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magestore\Webpos\Model\ResourceModel\Sales\Order;

/**
 * Class Item
 * @package Magestore\Webpos\Model\ResourceModel\Sales\Order
 */
class Item extends \Magento\Sales\Model\ResourceModel\Order\Item
{

}