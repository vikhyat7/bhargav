<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magestore\Webpos\Model\ResourceModel\Sales\Order\Creditmemo;

/**
 * Class Collection
 * @package Magestore\Webpos\Model\ResourceModel\Sales\Order\Creditmemo\Item
 */
class Item
    extends \Magento\Sales\Model\ResourceModel\Order\Creditmemo\Item
{

}
