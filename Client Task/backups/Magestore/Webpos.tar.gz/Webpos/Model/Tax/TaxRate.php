<?php

/**
 * Copyright © 2018 Magestore. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magestore\Webpos\Model\Tax;

class TaxRate extends \Magento\Tax\Model\Calculation\Rate
    implements \Magestore\Webpos\Api\Data\Tax\TaxRateInterface
{

}
