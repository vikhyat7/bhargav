<?php

/**
 * Copyright © 2018 Magestore. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magestore\Webpos\Model\Tax;

class TaxRule extends \Magento\Tax\Model\Calculation\Rule
    implements \Magestore\Webpos\Api\Data\Tax\TaxRuleInterface
{
    
}
