<?php

/**
 * Copyright © 2018 Magestore. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magestore\Webpos\Api\Data\Shift;

/**
 * @api
 */
class ShiftSearchResults extends \Magento\Framework\Api\SearchResults
{
   
}
