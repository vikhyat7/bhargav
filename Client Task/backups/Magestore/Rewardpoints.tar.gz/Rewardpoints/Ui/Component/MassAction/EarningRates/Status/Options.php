<?php
/**
 * Copyright © 2019 Magestore. All rights reserved.
 * See COPYING.txt for license details.
 *
 */
namespace Magestore\Rewardpoints\Ui\Component\MassAction\EarningRates\Status;

/**
 * Class Options
 */
class Options extends \Magestore\Rewardpoints\Ui\Component\MassAction\Status\Options
{

}
