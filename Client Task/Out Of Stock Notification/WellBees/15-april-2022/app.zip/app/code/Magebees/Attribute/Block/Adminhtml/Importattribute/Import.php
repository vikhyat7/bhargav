<?php
namespace Magebees\Attribute\Block\Adminhtml\Importattribute;

class Import extends \Magento\Backend\Block\Template
{

    
}
