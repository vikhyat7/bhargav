var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/model/checkout-data-resolver': {
                'HS_DefaultShippingPayment/js/model/checkout-data-resolver': true
            }
        }
    }
};
