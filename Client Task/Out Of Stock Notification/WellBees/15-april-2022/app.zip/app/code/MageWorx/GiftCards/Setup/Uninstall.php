<?php
/**
 * Copyright © MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

declare(strict_types=1);

namespace MageWorx\GiftCards\Setup;

use Magento\Framework\Setup\UninstallInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Catalog\Setup\CategorySetupFactory;

class Uninstall implements UninstallInterface
{
    /**
     * @var CategorySetupFactory
     */
    protected $categorySetupFactory;

    /**
     * Uninstall constructor.
     *
     * @param CategorySetupFactory $categorySetupFactory
     */
    public function __construct(CategorySetupFactory $categorySetupFactory)
    {
        $this->categorySetupFactory = $categorySetupFactory;
    }

    /**
     * Module uninstall code
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     */
    public function uninstall(
        SchemaSetupInterface $setup,
        ModuleContextInterface $context
    ) {
        $setup->startSetup();

        $connection = $setup->getConnection();
        $connection->dropTable($setup->getTable('mageworx_giftcards_card'));
        $connection->dropTable($setup->getTable('mageworx_giftcard_order'));
        $connection->dropTable($setup->getTable('mageworx_giftcards_customer_group'));
        $connection->dropTable($setup->getTable('mageworx_giftcards_store'));

        $categorySetupManager = $this->categorySetupFactory->create();

        $categorySetupManager->removeAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'mageworx_gc_type'
        );
        $categorySetupManager->removeAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'mageworx_gc_additional_price'
        );
        $categorySetupManager->removeAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'mageworx_gc_customer_groups'
        );
        $categorySetupManager->removeAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'mageworx_gc_lifetime_value'
        );
        $categorySetupManager->removeAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'mageworx_gc_allow_open_amount'
        );
        $categorySetupManager->removeAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'mageworx_gc_open_amount_min'
        );
        $categorySetupManager->removeAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'mageworx_gc_open_amount_max'
        );
        $categorySetupManager->removeAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'wts_gc_type'
        );
        $categorySetupManager->removeAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'wts_gc_additional_price'
        );
        $categorySetupManager->removeAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'customer_group_id'
        );

        //delete from table sales_invoice
        $connection->dropColumn($setup->getTable('sales_invoice'), 'mageworx_giftcards_amount');
        $connection->dropColumn($setup->getTable('sales_invoice'), 'base_mageworx_giftcards_amount');
        $connection->dropColumn($setup->getTable('sales_invoice'), 'mageworx_giftcards_description');

        //delete from table sales_creditmemo
        $connection->dropColumn($setup->getTable('sales_creditmemo'), 'mageworx_giftcards_amount');
        $connection->dropColumn($setup->getTable('sales_creditmemo'), 'base_mageworx_giftcards_amount');
        $connection->dropColumn($setup->getTable('sales_creditmemo'), 'mageworx_giftcards_description');

        $setup->endSetup();
    }
}
