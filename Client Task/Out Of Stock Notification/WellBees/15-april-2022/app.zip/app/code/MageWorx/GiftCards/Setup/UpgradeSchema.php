<?php
/**
 * Copyright © MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\GiftCards\Setup;

use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\App\ProductMetadataInterface;
use MageWorx\GiftCards\Api\Data\GiftCardsOrderInterface;
use MageWorx\GiftCards\Api\Data\GiftCardsInterface;
use MageWorx\GiftCards\Model\GiftCards;

/**
 * @codeCoverageIgnore
 */
class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * @var ProductMetadataInterface $productMetadata
     */
    public $productMetadata;

    public function __construct(
        ProductMetadataInterface $productMetadata
    ) {
        $this->productMetadata = $productMetadata;
    }

    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;

        $installer->startSetup();

        // update ptoduct type
        $installer->run(
            "UPDATE IGNORE `{$installer->getTable('catalog_product_entity')}` SET `type_id` = 'mageworx_giftcards' WHERE `type_id` LIKE 'giftcards'"
        );

        // update config path
        $installer->run(
            "UPDATE IGNORE `{$installer->getTable('core_config_data')}` SET `path` = REPLACE(`path`,'mageworx_giftcards/main/','mageworx_giftcards/mageworx_default/') WHERE `path` LIKE 'mageworx_giftcards/main/%'"
        );
        $installer->run(
            "UPDATE IGNORE `{$installer->getTable('core_config_data')}` SET `path` = REPLACE(`path`,'mageworx_giftcards/email/','mageworx_giftcards/mageworx_email/') WHERE `path` LIKE 'mageworx_giftcards/email/%'"
        );

        $installer->getConnection()
                  ->addColumn(
                      $installer->getTable('quote'),
                      'mageworx_giftcards_description',
                      [
                          'type'    => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                          'length'  => 255,
                          'comment' => 'MageWorx Gift Card Description',
                      ]
                  );

        $installer->getConnection()
                  ->addColumn(
                      $installer->getTable('quote'),
                      'mageworx_giftcards_amount',
                      [
                          'type'    => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                          'length'  => "12,4",
                          'comment' => 'MageWorx Gift Card Discount Amount',
                      ]
                  );

        $installer->getConnection()
                  ->addColumn(
                      $installer->getTable('quote'),
                      'base_mageworx_giftcards_amount',
                      [
                          'type'    => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                          'length'  => "12,4",
                          'comment' => 'MageWorx Gift Card Base Discount Amount',
                      ]
                  );

        $installer->getConnection()
                  ->addColumn(
                      $installer->getTable('sales_order'),
                      'mageworx_giftcards_description',
                      [
                          'type'    => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                          'length'  => 255,
                          'comment' => 'MageWorx Gift Card Description',
                      ]
                  );

        $installer->getConnection()
                  ->addColumn(
                      $installer->getTable('sales_order'),
                      'mageworx_giftcards_amount',
                      [
                          'type'    => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                          'length'  => "12,4",
                          'comment' => 'MageWorx Gift Card Discount Amount',
                      ]
                  );

        $installer->getConnection()
                  ->addColumn(
                      $installer->getTable('sales_order'),
                      'base_mageworx_giftcards_amount',
                      [
                          'type'    => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                          'length'  => "12,4",
                          'comment' => 'MageWorx Gift Card Base Discount Amount',
                      ]
                  );

        if (version_compare($context->getVersion(), '2.1.1') < 0) {
            $installer->getConnection()
                      ->addColumn(
                          $installer->getTable('mageworx_giftcards_card'),
                          'storeview_ids',
                          [
                              'type'    => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                              'length'  => 255,
                              'comment' => 'Store views to allow using the gift card code on',
                          ]
                      );
        }

        if (version_compare($context->getVersion(), '2.1.3') < 0) {
            $installer->getConnection()
                      ->addColumn(
                          $installer->getTable('mageworx_giftcards_card'),
                          'lifetime_days',
                          [
                              'type'    => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                              'length'  => 5,
                              'comment' => 'Card lifetime in days',
                          ]
                      );
        }

        if (version_compare($context->getVersion(), '2.1.6') < 0) {
            $installer->getConnection()
                      ->addColumn(
                          $installer->getTable('mageworx_giftcards_card'),
                          'ignore_default_lifetime',
                          [
                              'type'    => \Magento\Framework\DB\Ddl\Table::TYPE_BOOLEAN,
                              'comment' => 'Ignore default card lifetime',
                          ]
                      );
        }

        if (version_compare($context->getVersion(), '2.1.7') < 0) {
            $installer->getConnection()
                      ->addColumn(
                          $installer->getTable('mageworx_giftcards_card'),
                          'mageworx_gc_customer_groups',
                          [
                              'type'    => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                              'comment' => 'Available for Customer Groups',
                          ]
                      );
        }

        if (version_compare($context->getVersion(), '2.1.8') < 0) {
            $installer->getConnection()
                      ->addColumn(
                          $installer->getTable('mageworx_giftcards_card'),
                          'lifetime_days',
                          [
                              'type'    => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                              'length'  => 5,
                              'comment' => 'Card lifetime in days',
                          ]
                      );

            $installer->getConnection()
                      ->dropColumn(
                          $installer->getTable('mageworx_giftcards_card'),
                          'ignore_default_lifetime'
                      );

            $installer->getConnection()
                      ->dropColumn(
                          $installer->getTable('mageworx_giftcards_card'),
                          'lifetime_days'
                      );

            $installer->getConnection()
                      ->addColumn(
                          $installer->getTable('mageworx_giftcards_card'),
                          'expire_date',
                          [
                              'type'    => \Magento\Framework\DB\Ddl\Table::TYPE_DATE,
                              'comment' => 'Expire Date',
                          ]
                      );

            $installer->getConnection()
                      ->addColumn(
                          $installer->getTable('mageworx_giftcards_card'),
                          'expired_email_send',
                          [
                              'type'    => \Magento\Framework\DB\Ddl\Table::TYPE_BOOLEAN,
                              'comment' => 'Is Expired Email Send',
                              'default' => '0'
                          ]
                      );

            $installer->getConnection()
                      ->addColumn(
                          $installer->getTable('mageworx_giftcards_card'),
                          'expiration_alert_email_send',
                          [
                              'type'    => \Magento\Framework\DB\Ddl\Table::TYPE_BOOLEAN,
                              'comment' => 'Is Expiration Alert Email Send',
                              'default' => '0'
                          ]
                      );

            $installer->getConnection()
                      ->dropColumn(
                          $installer->getTable('mageworx_giftcards_card'),
                          'storeview_ids'
                      );

            $installer->getConnection()
                      ->dropColumn(
                          $installer->getTable('mageworx_giftcards_card'),
                          'mageworx_gc_customer_groups'
                      );

            $storeTable                   = $installer->getTable('store');
            $customerGroupsTable          = $installer->getTable('customer_group');
            $giftcardsStoresTable         = $installer->getTable('mageworx_giftcards_store');
            $giftcardsCustomerGroupsTable = $installer->getTable('mageworx_giftcards_customer_group');

            /**
             * Create table 'mageworx_giftcards_store' if not exists. This table will be used instead of
             * column storeview_ids of main giftcards table
             */
            $table = $installer->getConnection()->newTable(
                $giftcardsStoresTable
            )->addColumn(
                'card_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                [
                    'identity' => true,
                    'unsigned' => true,
                    'nullable' => false,
                    'primary'  => true
                ],
                'Card ID'
            )->addColumn(
                'store_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
                null,
                [
                    'unsigned' => true,
                    'nullable' => false,
                    'primary'  => true,
                ],
                'Store ID'
            )->addForeignKey(
                $installer->getFkName(
                    'mageworx_giftcards_store',
                    'card_id',
                    'mageworx_giftcards_card',
                    'card_id'
                ),
                'card_id',
                $installer->getTable('mageworx_giftcards_card'),
                'card_id',
                \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
            )->addForeignKey(
                $installer->getFkName(
                    'mageworx_giftcards_store',
                    'store_id',
                    'store',
                    'store_id'
                ),
                'store_id',
                $storeTable,
                'store_id',
                \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
            )->setComment(
                'MageWorx Giftcards To Stores Relations'
            );

            $installer->getConnection()->createTable($table);

            /**
             * Create table 'mageworx_giftcards_customer_group' if not exists. This table will be used instead of
             * column mageworx_gc_customer_groups of main giftcards table
             */

            $type = version_compare($this->getMagentoVersion(), '2.2.0-dev') < 0 ?
                \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT : \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER;

            $table = $installer->getConnection()->newTable(
                $giftcardsCustomerGroupsTable
            )->addColumn(
                'card_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                [
                    'identity' => true,
                    'unsigned' => true,
                    'nullable' => false,
                    'primary'  => true
                ],
                'Card Id'
            )->addColumn(
                'customer_group_id',
                $type,
                null,
                ['unsigned' => true, 'nullable' => false, 'primary' => true],
                'Customer Group Id'
            )->addIndex(
                $installer->getIdxName('mageworx_giftcards_customer_group', ['customer_group_id']),
                ['customer_group_id']
            )->addForeignKey(
                $installer->getFkName(
                    'mageworx_giftcards_customer_group',
                    'card_id',
                    'mageworx_giftcards',
                    'card_id'
                ),
                'card_id',
                $installer->getTable('mageworx_giftcards_card'),
                'card_id',
                \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
            )->addForeignKey(
                $installer->getFkName(
                    'mageworx_giftcards_customer_group',
                    'customer_group_id',
                    'customer_group',
                    'customer_group_id'
                ),
                'customer_group_id',
                $customerGroupsTable,
                'customer_group_id',
                \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
            )->setComment(
                'MageWorx Giftcards To Customer Groups Relations'
            );

            $installer->getConnection()->createTable($table);
        }

        if (version_compare($context->getVersion(), '2.1.10', '<')) {
            $this->addGiftcardCodeToGiftcardOrder($installer);
            $this->addOrderIncrementIdToGiftcardOrder($installer);
        }

        if (version_compare($context->getVersion(), '2.1.12', '<')) {
            $this->extendSalesInvoiceTable($installer);
            $this->extendSalesCreditMemoTable($installer);
        }

        if (version_compare($context->getVersion(), '2.2.0', '<')) {
            $this->addDeliveryStatusColumnToMageworxGiftcardsCardTable($installer);
        }

        if (version_compare($context->getVersion(), '2.2.1', '<')) {
            $this->addIndexToMageworxGiftcardsCardTable($installer, 'card_code', AdapterInterface::INDEX_TYPE_UNIQUE);
        }

        if (version_compare($context->getVersion(), '2.2.2', '<')) {
            $this->addStoreIdForEmailColumnToMageworxGiftcardsCardTable($installer);
        }

        $installer->endSetup();
    }

    /**
     * @return string
     */
    public function getMagentoVersion()
    {
        return $this->productMetadata->getVersion();
    }

    /**
     * Add Giftcard Code column
     *
     * @param SchemaSetupInterface $installer
     */
    private function addGiftcardCodeToGiftcardOrder($installer)
    {
        $installer->getConnection()->addColumn(
            $installer->getTable('mageworx_giftcard_order'),
            GiftCardsOrderInterface::GIFTCARD_CODE,
            [
                'type'    => Table::TYPE_TEXT,
                'length'  => 255,
                'comment' => 'Used Gift Card Code'
            ]
        );
    }

    /**
     * Add Order Increment Id column
     *
     * @param SchemaSetupInterface $installer
     */
    private function addOrderIncrementIdToGiftcardOrder($installer)
    {
        $installer->getConnection()->addColumn(
            $installer->getTable('mageworx_giftcard_order'),
            GiftCardsOrderInterface::ORDER_INCREMENT_ID,
            [
                'type'    => Table::TYPE_TEXT,
                'length'  => 50,
                'comment' => 'Order Increment Id'
            ]
        );
    }

    /**
     * @param SchemaSetupInterface $installer
     */
    protected function extendSalesInvoiceTable($installer)
    {
        $this->extendTable($installer, 'sales_invoice');
    }

    /**
     * @param SchemaSetupInterface $installer
     */
    protected function extendSalesCreditMemoTable($installer)
    {
        $this->extendTable($installer, 'sales_creditmemo');
    }

    /**
     * @param SchemaSetupInterface $installer
     * @param null|string $tableName
     */
    protected function extendTable($installer, $tableName)
    {
        $installer->getConnection()->addColumn(
            $installer->getTable($tableName),
            'mageworx_giftcards_amount',
            [
                'type'     => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                'length'   => '12,4',
                'nullable' => true,
                'comment'  => 'MageWorx Gift Card Amount'
            ]
        );

        $installer->getConnection()->addColumn(
            $installer->getTable($tableName),
            'base_mageworx_giftcards_amount',
            [
                'type'     => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                'length'   => '12,4',
                'nullable' => true,
                'comment'  => 'Base MageWorx Gift Card Amount'
            ]
        );

        $installer->getConnection()->addColumn(
            $installer->getTable($tableName),
            'mageworx_giftcards_description',
            [
                'type'    => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                'length'  => 255,
                'comment' => 'MageWorx Gift Card Description'
            ]
        );
    }

    /**
     * Add Delivery Status column
     *
     * @param SchemaSetupInterface $installer
     */
    private function addDeliveryStatusColumnToMageworxGiftcardsCardTable($installer)
    {
        $installer->getConnection()->addColumn(
            $installer->getTable('mageworx_giftcards_card'),
            GiftCardsInterface::DELIVERY_STATUS,
            [
                'type'     => Table::TYPE_SMALLINT,
                'length'   => 1,
                'nullable' => false,
                'unsigned' => true,
                'default'  => GiftCards::STATUS_NOT_DELIVERED,
                'comment'  => 'Delivery Status'
            ]
        );
    }

    /**
     * Add index to mageworx_giftcards_card table
     *
     * @param SchemaSetupInterface $installer
     * @param string|array $fields the table column name or array of ones
     * @param string $indexType the index type
     */
    private function addIndexToMageworxGiftcardsCardTable($installer, $fields, $indexType)
    {
        $installer->getConnection()->addIndex(
            $installer->getTable('mageworx_giftcards_card'),
            $installer->getIdxName('mageworx_giftcards_card', $fields, $indexType),
            $fields,
            $indexType
        );
    }

    /**
     * Add Send From Store Id column
     *
     * @param SchemaSetupInterface $installer
     */
    private function addStoreIdForEmailColumnToMageworxGiftcardsCardTable($installer)
    {
        $connection = $installer->getConnection();
        $connection->addColumn(
            $installer->getTable('mageworx_giftcards_card'),
            GiftCardsInterface::STORE_ID_FOR_EMAIL,
            [
                'type'     => Table::TYPE_SMALLINT,
                'nullable' => true,
                'unsigned' => true,
                'comment'  => 'Send From Store Id'
            ]
        );
        $connection->addForeignKey(
            $installer->getFkName(
                'mageworx_giftcards_card',
                GiftCardsInterface::STORE_ID_FOR_EMAIL,
                'store',
                'store_id'
            ),
            $installer->getTable('mageworx_giftcards_card'),
            GiftCardsInterface::STORE_ID_FOR_EMAIL,
            $installer->getTable('store'),
            'store_id'
        );
    }
}
