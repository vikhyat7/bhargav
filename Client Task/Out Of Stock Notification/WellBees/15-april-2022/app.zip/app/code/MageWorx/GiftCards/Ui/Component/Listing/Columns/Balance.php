<?php
/**
 * Copyright © MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\GiftCards\Ui\Component\Listing\Columns;

class Balance extends Amount
{
    /**
     * Column name
     */
    const NAME = 'card_balance';
}
