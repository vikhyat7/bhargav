<?php
/**
 * Copyright © MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\GiftCards\Block\Adminhtml\Catalog\Product\Composite\Fieldset;

class GiftCards extends \MageWorx\GiftCards\Block\Product\View\Type\GiftCards
{
}
