<?php
/**
 * Copyright © MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\GiftCards\Block\Adminhtml\GiftCards;

class PrintCard extends \MageWorx\GiftCards\Block\PrintCard
{
    const AREA = '_adminhtml';
}
