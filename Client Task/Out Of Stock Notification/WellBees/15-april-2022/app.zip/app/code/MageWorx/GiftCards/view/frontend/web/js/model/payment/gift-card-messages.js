/**
 * Copyright © MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

define([
    'ko',
    'Magento_Ui/js/model/messages'
], function (ko, Messages) {
    'use strict';

    return new Messages();
});