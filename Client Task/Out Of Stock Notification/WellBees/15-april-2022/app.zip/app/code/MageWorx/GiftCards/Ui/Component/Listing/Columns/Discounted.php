<?php
/**
 * Copyright © MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\GiftCards\Ui\Component\Listing\Columns;

class Discounted extends Amount
{
    /**
     * Column name
     */
    const NAME = 'discounted';
}
