/**
 * Copyright © Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {
            ajaxGiftCardInfo: 'MageWorx_GiftCards/js/ajax-giftcard-info',
            remainingGiftCardInfo: 'MageWorx_GiftCards/js/remaining-giftcard-info'
        }
    }
};
