<?php
 /**
  * @category   Mageants Shippingtracker
  * @package    Mageants_Shippingtracker
  * @copyright  Copyright (c) 2017 Mageants
  * @author     Mageants Team <support@Mageants.com>
  */
 
namespace Mageants\Shippingtracker\Controller\Index;

use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Action\Context;
use Magento\Sales\Model\ResourceModel\Order\Shipment\Track\CollectionFactory as TrackCollectionFactory;
use Magento\Sales\Api\Data\ShipmentTrackInterface;

class TrackingDetails extends \Magento\Framework\App\Action\Action
{
    /** @var \Magento\Framework\View\Result\LayoutFactor */
    protected $_shippingTracker;

    /**
     *  @var   \Magento\Framework\App\Action\Context::url()
     */
    protected $_url;

    /**
     *  @var   \Magento\Framework\App\Action\Context::request()
     */
    protected $_request;

    const USPS_URL = 'http://production.shippingapis.com/ShippingAPI.dll?API=TrackV2&XML=';

    /**
     *  @var   \Magento\Shipping\Helper\Data
     */
    protected $_helper;
    /**
     *  @var   TrackCollectionFactory
     */
    protected $trackingCollection;

    /**
     *  @param    \Magento\Framework\App\Action\Context $context
     *  @param   \Mageants\Shippingtracker\Block\Shippingtracker $shippingtracker
     *  @param   \Magento\Shipping\Helper\Data $helper
     *  @param   TrackCollectionFactory $collectionFactory
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Mageants\Shippingtracker\Block\Shippingtracker $shippingtracker,
        \Mageants\Shippingtracker\Helper\Data $shippingTrackerHelper,
        \Magento\Shipping\Helper\Data $helper,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        TrackCollectionFactory $collectionFactory
    ) {
        $this->_url = $context->getUrl();
        $this->_shippingTracker = $shippingtracker;
        $this->shippingTrackerHelper = $shippingTrackerHelper;
        $this->_request = $context->getRequest();
        $this->_helper  = $helper;
        $this->scopeConfig = $scopeConfig;
        $this->trackingCollection = $collectionFactory->create();
        parent::__construct($context);
    }
    /**
     * Shippingtracker Page
     *
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {

        $disabledCarrier = $this->shippingTrackerHelper->getDisabledCarrier();
        $disabledCarrierMessage = $this->shippingTrackerHelper->getDisabledCarrierMessage();
        $carrierCode = "";
        if ($this->_request->getPost('trackingid') != null) {
            $this->trackingCollection
                ->addFieldToFilter(ShipmentTrackInterface::TRACK_NUMBER, $this->_request->getPost('trackingid'));
            $tracking = $this->trackingCollection;
            foreach ($tracking as $trackingData) {
                $trackingDetails = $this->_shippingTracker->getOrderdetails($trackingData->getOrderId());
            }
            $status = "";
            $orderId = "";
            if (isset($trackingDetails)) {
                $trackCollect = $trackingDetails->getTracksCollection();
                foreach ($trackCollect as $track) {
                    $status = $track->getShipment()->getOrder()->getStatusLabel();
                    $orderId = $track->getShipment()->getIncrementId();
                    $carrierTitle = $track->getTitle();
                    $carrierCode = $track->getCarrierCode();
                }
            }
            if ($carrierCode == "usps" && isset($trackingDetails) && !in_array($carrierCode, $disabledCarrier)) {
                $authData = array();
                $authData['user_id'] = $this->getUspsUserId();
                $inquiryNumber = $this->_request->getPost('trackingid');
                $response = file_get_contents(
                    self::USPS_URL . $this->prepareParams($authData, $inquiryNumber)
                );
                $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
                $result = @simplexml_load_string($response);
                $result = $this->parseTrackInfo($result, $orderId, $carrierTitle, $status, $inquiryNumber);
                $details = array('uspsResult'=> $result,'isUsps'=> true);
                return $resultJson->setData($details);
            }
            if (isset($trackingDetails) && !in_array($carrierCode, $disabledCarrier)) {
                $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
                $details = array('tracking_count'=>$trackingDetails->getTracksCollection()->count(),'shippingurl'=>$this->_helper->getTrackingPopupUrlBySalesModel($trackingDetails));
                return $resultJson->setData($details);
            } else {
                if (isset($carrierTitle)) {
                    $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
                    $shipping_code  = '{{shipping_method_title}}';
                    if (strpos($disabledCarrierMessage, $shipping_code) !== false) {
                        $message = str_replace($shipping_code, $carrierTitle, $disabledCarrierMessage);
                    } else {
                        $message = $disabledCarrierMessage;
                    }
                    $details = array('shipping_method_disabled'=>1,'carrier_message'=>$message);
                    return  $resultJson->setData($details);
                }
            }
        } else {
            $trackingDetails = $this->_shippingTracker->getOrderdetails($this->_request->getPost('orderid'), $this->_request->getPost('email'));
            $trackNumber = 0;
            if(isset($trackingDetails['tracking_error_message'])){

            }else{
                if (isset($trackingDetails)) {
                    $trackCollect = $trackingDetails->getTracksCollection();
                    foreach ($trackCollect as $track) {
                        $status = $track->getShipment()->getOrder()->getStatusLabel();
                        $orderId = $track->getShipment()->getIncrementId();
                        $trackNumber = $track->getNumber();
                        $carrierTitle = $track->getTitle();
                        $carrierCode = $track->getCarrierCode();
                    }
                }
                if ($carrierCode == "usps" && isset($trackingDetails) && !in_array($carrierCode, $disabledCarrier)) {
                    $authData = array();
                    $authData['user_id'] = $this->getUspsUserId();
                    $inquiryNumber = $trackNumber;
                    $response = file_get_contents(
                        self::USPS_URL . $this->prepareParams($authData, $inquiryNumber)
                    );
                    $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
                    $result = @simplexml_load_string($response);
                    $result = $this->parseTrackInfo($result, $orderId, $carrierTitle, $status, $inquiryNumber);
                    $details = array('uspsResult'=> $result,'isUsps'=> true);
                    return $resultJson->setData($details);
                }

                if (isset($trackingDetails) && !in_array($carrierCode, $disabledCarrier)) {
                    $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
                    if (property_exists($trackingDetails,'tracking_error_message')) {
                        return $resultJson->setData($trackingDetails);
                    }
                    $details = array('tracking_count'=>$trackingDetails->getTracksCollection()->count(),'shippingurl'=>$this->_helper->getTrackingPopupUrlBySalesModel($trackingDetails));
                    return  $resultJson->setData($details);
                } else {
                    if (isset($carrierTitle)) {
                        $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
                        $shipping_code  = '{{shipping_method_title}}';
                        if (strpos($disabledCarrierMessage, $shipping_code) !== false) {
                            $message = str_replace($shipping_code, $carrierTitle, $disabledCarrierMessage);
                        } else {
                            $message = $disabledCarrierMessage;
                        }
                        $details = array('shipping_method_disabled'=>1,'carrier_message'=>$message);
                        return  $resultJson->setData($details);
                    }
                }
            }
        }
    }

    /**
     * @param $inquiryNumber
     * @return string
     */
    private function prepareParams($authData, $inquiryNumber)
    {
        $params = '<TrackRequest USERID="' . urlencode($authData['user_id'])
            . '"> <TrackID ID="' . $inquiryNumber . '"></TrackID></TrackRequest>';

        return urlencode($params);
    }
    /**
     * @param $informations
     * @return array
     */
    public function parseTrackInfo($informations, $orderId, $carrierTitle, $status, $inquiryNumber)
    {
        $result = [];
        $key = 0;
        $resultHtml = "";
        $resultHtml .= '<h1 class="page-title"><span class="base" data-ui-id="page-title-wrapper">'.__("Tracking Information").'</span></h1>';
        $resultHtml .= "<div class='table-wrapper'>";
        $resultHtml .= "<table class='data table order tracking'>";
        $resultHtml .= "<tr>";
        $resultHtml .= "<th class='col label'>".__("USPS Tracking Number")."</th>";
        $resultHtml .= "<td class='col value'>".$inquiryNumber."</td>";
        $resultHtml .= "</tr>";
        $resultHtml .= "<tr>";
        $resultHtml .= "<th class='col label'>".__("Order")."</th>";
        $resultHtml .= "<td class='col value'>".$orderId."</td>";
        $resultHtml .= "</tr>";
        $resultHtml .= "<tr>";
        $resultHtml .= "<th class='col label'>".__("Status")."</th>";
        $resultHtml .= "<td class='col value'>".$status."</td>";
        $resultHtml .= "</tr>";
        $resultHtml .= "<tr>";
        $resultHtml .= "<th class='col label'>".__("Carrier")."</th>";
        $resultHtml .= "<td class='col value'>".$carrierTitle."</td>";
        $resultHtml .= "</tr>";
        $resultHtml .= "</table>";
        $resultHtml .= "<table class='data table order tracking-details'>";
        if (isset($informations->TrackInfo->TrackDetail)) {
            $resultHtml .= "<tr>";
            $resultHtml .= "<th>".__("Location")."</th>";
            $resultHtml .= "<th>".__("Date")."</th>";
            $resultHtml .= "<th>".__("Time")."</th>";
            $resultHtml .= "<th>".__("Status")."</th>";
            $resultHtml .= "</tr>";
            foreach ($informations->TrackInfo->TrackDetail as $info) {
                $data = explode(',', $info);
                $activity = isset($data[0]) ? $data[0] : '';
                $date = (isset($data[1]) ? $data[1] : '') . (isset($data[2]) ? ', ' . $data[2] : '');

                if (count($data) > 3) {
                    $time = isset($data[3]) ? $data[3] : '';
                    $address = (isset($data[4]) ? $data[4] : '') . ' ' . (isset($data[5]) ? $data[5] : '');
                } else {
                    $time = null;
                    $address = null;
                }

                $result['info'][$key]['location'] = $address;
                $result['info'][$key]['date'] = $date;
                $result['info'][$key]['time'] = $time;
                $result['info'][$key]['status'] = $activity;

                $resultHtml .= "<tr>";
                $resultHtml .= "<td>".$address."</td>";
                $resultHtml .= "<td>".$date."</td>";
                $resultHtml .= "<td>".$time."</td>";
                $resultHtml .= "<td>".$activity."</td>";
                $resultHtml .= "</tr>";
                $key++;
            }

            $result['columns'] = [
                __('Location'),
                __('Date'),
                __('Time'),
                __('Status')
            ];
        }
        $resultHtml .= "</table>";
        $resultHtml .= "</div>";

        return $resultHtml;
    }

    public function getUspsUserId()
    {
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        return $this->scopeConfig->getValue('carriers/usps/userid', $storeScope);
    }
}
