 /**
 * Mageants ShippingTracker Magento2 Extension                           
 */
var config = {
    map: {
        '*': {
            shippingtracker: 'Mageants_Shippingtracker/js/shippingracker',
        }
    }
};