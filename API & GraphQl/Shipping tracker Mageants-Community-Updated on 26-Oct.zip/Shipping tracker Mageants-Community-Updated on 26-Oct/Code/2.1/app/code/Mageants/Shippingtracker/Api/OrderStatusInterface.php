<?php
namespace Mageants\Shippingtracker\Api;
 
interface OrderStatusInterface
{


     /**
     * Get Order details 
     * 
     * @param  int $id
     * @return int
     */
    public function GetStatusOfOrder($id);


    // public function GetOrder();


}