<?php
namespace Mageants\Shippingtracker\Model;
use Mageants\Shippingtracker\Api\OrderStatusInterface;
use Exception;
// use Psr\Log\LoggerInterface;
use Magento\Framework\View\Element\Template;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Framework\View\Element\Template\Context;

class OrderApi extends Template
{
    /**
     * @var SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * @var OrderRepositoryInterface
     */
    private $orderRepository;

    // *
    //  * @var LoggerInterface
     
    // private $logger;

    /**
     * @var array
     */
    private $data;

    /**
     * @param Context $context
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param OrderRepositoryInterface $orderRepository
     * @param array $data
     */
    public function __construct(
        Context $context,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        OrderRepositoryInterface $orderRepository,
        // LoggerInterface $logger,
        array $data = []
    ) {
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->orderRepository = $orderRepository;
        // $this->logger = $logger;
        parent::__construct($context,$data);
    }

    public function GetStatusOfOrder($id)
    {
        $items = array();
        $orderId = null;
        
        try {
            // $id = '1000000010';
            $searchCriteria = $this->searchCriteriaBuilder
                ->addFilter('increment_id', $id)->create();
            $orderData = $this->orderRepository->getList($searchCriteria)->getItems();

            foreach ($orderData as $order) {

                $items[] =  $order->getId();
                $items[] =  $order->getCustomerFirstname();
                $items[] =  $order->getCustomerLastname();
                $items[] =  $order->getCustomerEmail();
                $items[] =  $order->getCustomerDob();
                $customer_gender =  $order->getCustomerGender();
                 if ($customer_gender) {
                  if ($customer_gender==1)
                   {

                        $customer_gender = "Male";
                   }
                   else
                   {
                    $customer_gender = "Female";
                   }
                }
                $items[] = $customer_gender;
                $items[] = $order->getStatus();
                $items[] =  $order->getTotalPaid();
                $items[] = $order->getWeight();
                $items[] = $order->getShippingDescription();
                $items[] = $order->getStoreName();
                $items[] =   $order->getShippingAddress()->getData('city');
                $items[] =   $order->getShippingAddress()->getData('postcode');
                $items[] =   $order->getShippingAddress()->getData('region');
                // $items[] =   $order->getShippingAddress()->getData('carriers');
                $items[] =  $order->get();
                // $items[] =  $order->getShippingAddress()->getData('firstname').' '.$order->getShippingAddress()->getData('lastname');

            }
        } catch (Exception $exception) {
            $this->error($exception->getMessage());
        }

        return $items;
        // return "Order Id -> ". $orderId .",Status ->". $status .",Total paid ->". $TotalPaid .",weight ->". $weight .",Customer DOB ->". $customer_dob .",Email ->".$customer_email.",Gender ->".$customer_gender.",shipping_method -> ".$shipping_method."";
    }
}