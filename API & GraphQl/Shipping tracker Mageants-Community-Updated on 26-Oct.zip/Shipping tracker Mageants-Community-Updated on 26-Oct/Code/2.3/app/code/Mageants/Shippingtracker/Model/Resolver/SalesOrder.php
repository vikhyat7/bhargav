<?php
declare (strict_types = 1);
namespace Mageants\Shippingtracker\Model\Resolver;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Exception\GraphQlInputException;
use Magento\Framework\GraphQl\Exception\GraphQlNoSuchEntityException;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
class SalesOrder implements ResolverInterface {
    protected $orderRepository;
    protected $searchCriteriaBuilder;
    protected $priceCurrency;
    public function __construct(
       \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
       \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder,
       \Magento\Framework\Pricing\PriceCurrencyInterface $priceCurrency
    ) {
       $this->orderRepository = $orderRepository;
       $this->searchCriteriaBuilder = $searchCriteriaBuilder;
       $this->priceCurrency = $priceCurrency;
    }
    /**
     * @inheritdoc
     */
    public function resolve(
       Field $field,
       $context,
       ResolveInfo $info,
       array $value = null,
       array $args = null
    ) {
       $IncrementId = $this->getIncrementId($args);
       $OrderId = $this->getData($IncrementId);
       $OrderDetails = $this->getOrderDetails($OrderId);
       return $OrderDetails;
    }
    /**
     * @param array $args
     * @return int
     * @throws GraphQlInputException
     */
    private function getIncrementId(array $args): string {
       if (!isset($args['increment_id'])) {
           throw new GraphQlInputException(__('Customer id should be specified'));
       }
       return (string) $args['increment_id'];
    }
    /**
     * @param int $IncrementId
     * @return string
     * @throws GraphQlNoSuchEntityException
     */
    private function getData(string $IncrementId): string
    {
       try {
           $searchCriteria = $this->searchCriteriaBuilder->addFilter('increment_id', $IncrementId, 'eq')->create();
           $orderList = $this->orderRepository->getList($searchCriteria);
           $customerOrder = [];
           foreach ($orderList as $order1) {
               $order_id = $order1->getId();
               $customerOrder['fetchRecords'][$order_id]['entity_id'] = $order1->getId();
               
               // $en_id = $customerOrder['fetchRecords'][$order_id]['entity_id'];
               // $en_id = 5;
           }
       } catch (NoSuchEntityException $e) {
           throw new GraphQlNoSuchEntityException(__($e->getMessage()), $e);
       }
       
        return $customerOrder['fetchRecords'][$order_id]['entity_id'];

       

    }

     /**
     * @param string $ordId
     * @return array
     * @throws GraphQlNoSuchEntityException
     */
    private function getOrderDetails(string $ordId): array
    {

         try {


            $order = $this->orderRepository->get($ordId);
           
            $shippingAddress = $order->getShippingAddress()->getData();
            
            $shippingAddressArray = [];
            $shippingAddressArray['shipping_name'] = $order->getShippingAddress()->getData('firstname').' '.$order->getShippingAddress()->getData('lastname');
            $shippingAddressArray['city'] = $order->getShippingAddress()->getData('city');
            $shippingAddressArray['postcode'] = $order->getShippingAddress()->getData('postcode');
            $shippingAddressArray['state'] = $order->getShippingAddress()->getData('region');
            

            


            foreach ($order->getAllVisibleItems() as $_item) {
                $itemsData[] = $_item->getData();

            

            }
           $customerOrder1 = [];
            

                $order_id1 = $order->getId();
                $customerOrder1['fetchRecords'][$order_id1]['entity_id'] = $order->getId();
                $customerOrder1['fetchRecords'][$order_id1]['customer_id'] = $order->getCustomerId();
                $customerOrder1['fetchRecords'][$order_id1]['customer_name'] = $order->getCustomerFirstname().' '.$order->getCustomerLastname();
                $customerOrder1['fetchRecords'][$order_id1]['customer_dob'] = $order->getCustomerDob();
                $customerOrder1['fetchRecords'][$order_id1]['customer_gender'] = $order->getCustomerGender();
                $customerOrder1['fetchRecords'][$order_id1]['store_name'] = $order->getStoreName();
                $customerOrder1['fetchRecords'][$order_id1]['total_qty_ordered'] = $order->getTotalQtyOrdered();
                $customerOrder1['fetchRecords'][$order_id1]['grand_total'] = $order->getGrandTotal();
                $customerOrder1['fetchRecords'][$order_id1]['weight'] = $order->getWeight();
                $customerOrder1['fetchRecords'][$order_id1]['discount_amount'] = $order->getDiscountAmount();
                $customerOrder1['fetchRecords'][$order_id1]['status'] = $order->getStatus();
                $customerOrder1['fetchRecords'][$order_id1]['is_guest_customer'] = !empty($order->getCustomerIsGuest()) ? 1 : 0;
                $customerOrder1['fetchRecords'][$order_id1]['created_at'] = $order->getCreatedAt();
                $customerOrder1['fetchRecords'][$order_id1]['shipping_description'] = $order->getShippingDescription();
                $customerOrder1['fetchRecords'][$order_id1]['shipping_address'] = $shippingAddress;
                $customerOrder1['fetchRecords'][$order_id1]['items'] = $itemsData;
                $customerOrder1['fetchRecords'][$order_id1]['address_array'] = $shippingAddressArray;
               

            
        } catch (NoSuchEntityException $e) {
            throw new GraphQlNoSuchEntityException(__($e->getMessage()), $e);
        }
        return $customerOrder1;
    }
}