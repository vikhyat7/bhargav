# Shippingtracker

	Current version number: 2.0.7
	Date :- 08/06/2021
	************************************************************
    Bug fixed
	************************************************************
	--> Create all language translate csv file in i18n folder to convert all string for specific language scope of module, Working fine in all magento version.

	************************************************************
    File changes
	************************************************************
	Mageants/Shippingtracker/i18n/
	Mageants/Shippingtracker/etc/module.xml
	Mageants/Shippingtracker/composer.json
	Mageants/Shippingtracker/view/frontend/templates/tracking/details.phtml
	Mageants/Shippingtracker/view/frontend/templates/link.phtml
	Mageants/Shippingtracker/view/frontend/templates/shippingtracker.phtml

*********************************************************************************************************************************************

	Current version number: 2.0.6
	Date :- 05/10/2020
	************************************************************
    Bug fixed
	************************************************************
	--> When we tracking order with wrong order id or wrong tracking id then page taking much loading, MageAnts resolved issue in all magento version.

	--> MageAnts team make Shipping tracker extension compatible with Magento2.4.

	************************************************************
    File changes
	************************************************************
	Mageants/Shippingtracker/Controller/Index/TrackingDetails.php
	Mageants/Shippingtracker/view/frontend/web/js/shippingracker.js
	Mageants/Shippingtracker/view/frontend/web/css/source/_module.less
	Mageants/Shippingtracker/etc/module.xml
	Mageants/Shippingtracker/composer.json

*********************************************************************************************************************************************

	Current version number: 2.0.5
	Date :- 20/08/2020
	************************************************************
    Bug fixed
	************************************************************
	--> When customer track order of Usps shipping method then full tracking information was not showing Mageants resolved issue in all magento version.

	************************************************************
    File changes
	************************************************************
	Mageants/Shippingtracker/Controller/Index/TrackingDetails.php
	Mageants/Shippingtracker/view/frontend/web/js/shippingracker.js
	Mageants/Shippingtracker/composer.json
	Mageants/Shippingtracker/etc/module.xml

*********************************************************************************************************************************************

	Current version number: 2.0.4
	Date :- 24/07/2020
	************************************************************
    Bug fixed
	************************************************************
	--> When admin click on sending tracking information in shipment then it's give error, Mageants team resolved issue and extension working fine in all magento version.

	************************************************************
    File changes
	************************************************************
	Mageants/Shippingtracker/composer.json
	Mageants/Shippingtracker/etc/module.xml
	Mageants/Shippingtracker/view/frontend/templates/email/items.phtml
	Mageants/Shippingtracker/Controller/Index/TrackingDetails.php

*********************************************************************************************************************************************

	Current version number: 2.0.3
	Date :- 25/05/2020
	************************************************************
    Bug fixed
	************************************************************
	--> MageAnts update Shipping tracker extension now admin can add custom shipping method from backend so customer can track the order easily. Shipping method like UPS, USPS, DHL, Federal express, Magento shipping, Canada post etc, extension working with all magento version.

	************************************************************
    File changes
	************************************************************
	Mageants/Shippingtracker/composer.json
	Mageants/Shippingtracker/etc/module.xml
	Mageants/Shippingtracker/etc/config.xml
	Mageants/Shippingtracker/Helper/Data.php
	Mageants/Shippingtracker/etc/adminhtml/system.xml
	Mageants/Shippingtracker/Controller/Index/TrackingDetails.php
	Mageants/Shippingtracker/view/frontend/web/js/shippingracker.js
	Mageants/Shippingtracker/view/frontend/templates/shippingtracker.phtml

	************************************************************
    New added file
	************************************************************
	Mageants/Shippingtracker/etc/adminhtml/di.xml
	Mageants/Shippingtracker/Model/ShippingCarrier/Methods.php
	Mageants/Shippingtracker/Plugin/Block/Adminhtml/Order/Tracking.php
	Mageants/Shippingtracker/view/frontend/templates/tracking/popup.phtml
	Mageants/Shippingtracker/view/frontend/templates/tracking/details.phtml
	Mageants/Shippingtracker/view/frontend/layout/shipping_tracking_popup.xml

*********************************************************************************************************************************************

	Current version number: 2.0.2
	Date :- 09/03/2019
	************************************************************
    Bug fixed
	************************************************************
	--> MageAnts update Shipping tracker extension in latest magento2.3 version, Now extension working with all magento version.

*********************************************************************************************************************************************

	Current version number: 2.0.2
	Date :- 16/01/2019
	************************************************************
    Bug fixed
	************************************************************
	--> Update module version name in composer.json file same as module.xml file.

*********************************************************************************************************************************************


	Current version number: 2.0.2
	Date :- 05/01/2019
	************************************************************
    Bug fixed
	************************************************************
	--> We added new functionality in our extension, Now user can track their order by tracking id also.
	--> Now in our tracking information content Tracking Number, Carrier, Status, Signed by, Service Type, Weight, Delivered on and progress information block on same page.


*********************************************************************************************************************************************

	Current version number: 2.0.1
	Date :- 22/08/2018
	************************************************************
    Bug fixed
	************************************************************
	--> When logging into frontend then login not working. ==>https://prnt.sc/kcqedk
	--> Image not loading in all magento version.
	--> if extension install then product not added into cart. (Always it's loading)

 	************************************************************
    File change
	************************************************************

	1. Mageants/Shippingtracker/view/frontend/web/js/shippingracker.js