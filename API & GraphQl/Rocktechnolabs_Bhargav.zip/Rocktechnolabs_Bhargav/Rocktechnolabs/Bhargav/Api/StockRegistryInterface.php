<?php
namespace Rocktechnolabs\Bhargav\Api;

interface StockRegistryInterface
{
    /**
     * Updates the specified products in item array.
     *
     * @api
     * @param mixed $data
     * @return boolean
     */
    public function updateProduct($products);
}