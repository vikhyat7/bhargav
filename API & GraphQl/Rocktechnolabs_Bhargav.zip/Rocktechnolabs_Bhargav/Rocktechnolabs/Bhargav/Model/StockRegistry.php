<?php
namespace Rocktechnolabs\Bhargav\Model;

use Rocktechnolabs\Bhargav\Api\StockRegistryInterface;

class StockRegistry implements StockRegistryInterface 
{

    /**
     * @param \Magento\Catalog\Api\ProductRepositoryInterface $productRepository
     */
    public function __construct(
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository
    ) {
        $this->productRepository = $productRepository;
    }

    /**
     * Updates the specified product from the request payload.
     *
     * @api
     * @param mixed $products
     * @return boolean
     */
    public function updateProduct($products) 
    {
        if (!empty($products)) 
        {
            foreach ($products as $product) 
            {
                    $sku = $product['sku'];
                    $productObject = $this->productRepository->get($sku);
                    $qty = $product['qty'];
                    // $price = $product['price'];
                    // $productObject->setPrice($price);
                    $productObject->setStockData(
                        [
                          'is_in_stock' => 1,
                          'qty' => $qty
                        ]
                    );
                    $this->productRepository->save($productObject);
            }
            return "Products Updated!!";
        }
        else
        {
            return "Enter Valid Details (Sku & Qty)";    
        }
    }
}