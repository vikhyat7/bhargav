<?php
namespace Mageants\Reorder\Model;

use Mageants\Reorder\Api\AllOrderInterface;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory;
use Magento\Sales\Model\OrderFactory;


class AllOrderRepository  implements AllOrderInterface
{
   
     /**
     * @var OrderFactory1
     */

    private $orderFactory1;
   
     /**
     * @var collectionFactory
     */
    private $collectionFactory;
     /**
     * @var \Mageants\Reorder\Model\Reorder\Reorder
     */
    private $reorder;

    /**
     * @param \Mageants\Reorder\Model\Reorder\Reorder $reorder
     * @param OrderFactory1 $orderFactory1
    */


    public function __construct(
        \Mageants\Reorder\Model\Reorder\Reorder $reorder,
        CollectionFactory $collectionFactory,
        OrderFactory $orderFactory1

    ){
        $this->reorder = $reorder;
        $this->collectionFactory = $collectionFactory;
        $this->orderFactory1 = $orderFactory1;

     
    }
    /**
     * Add order item for the customer
     * @param int $customerId
     * @return array|bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function reorderItem($customerId)
    {   
        $customerOrder = $this->collectionFactory->create()
            ->addFieldToFilter('customer_id', $customerId);
        // return $customerOrder->getData();
        // $customerId = $this->customerId;
        
        foreach($customerOrder as $user) 
            {
                $ids[] = $user['increment_id'];
            }
            
          $entity1 = $ids;
        // return $entity1;


    $data = $this->_jsonHelper->jsonDecode($this->getRequest()->getContent());
    $maskedQuoteId = $data['quoteId'];
    $quoteIdMask = $this->quoteIdMaskFactory->create()->load($maskedQuoteId, 'masked_id');
        return $quoteIdMask;

        foreach($entity1 as $order1)
        {
            $order = $this->orderFactory1->create()->loadByIncrementId($order1);
            $storeId = $order->getStoreId();
            $storeI = $order->getQuoteId();
            // return $storeI;
            $reorderOutput = $this->reorder->execute($order1,$storeId);
        }

        
        return "saved";


       
    }
}
 