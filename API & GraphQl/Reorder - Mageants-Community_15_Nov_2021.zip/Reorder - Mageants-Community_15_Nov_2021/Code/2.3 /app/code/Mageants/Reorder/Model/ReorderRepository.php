<?php
namespace Mageants\Reorder\Model;

use Mageants\Reorder\Api\ReorderRepositoryInterface;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Sales\Model\OrderFactory;
use Mageants\Reorder\Model\Reorder\Reorder;

class ReorderRepository  implements ReorderRepositoryInterface
{   

     /**
     * @var OrderFactory1
     */
    private $orderFactory1;
    /**
     * @var Reorder
     */
    private $reorder;
    protected $customerId;
    
     /**
     * @var collectionFactory
     */
    private $collectionFactory;
    /**
     * @param Reorder $reorder
     * @param OrderFactory1 $orderFactory1
    */


    public function __construct(
        Reorder $reorder,
        OrderFactory $orderFactory1,
        CollectionFactory $collectionFactory
    ){
        
        $this->reorder = $reorder;
        $this->orderFactory1 = $orderFactory1;
        $this->collectionFactory = $collectionFactory;

     
    }

    /**
     * Add order item for the customer
     * @param int $customerId
     * @param string $orderId
     * @return array|bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function reorderItem($customerId, $orderId)
    {   


        // $customerOrder = $this->collectionFactory->create()
        //     ->addFieldToFilter('customer_id', $customerId);
        // return $customerOrder->getData();


        $IncrementId=$orderId;
        $CustomerId=$customerId;

        $order = $this->orderFactory1->create()->loadByIncrementId($IncrementId);
        $storeId = $order->getStoreId();

    

        if ((string)$order->getCustomerId()==$CustomerId) 
        {
            $reorderOutput = $this->reorder->execute($IncrementId,$storeId);
            return "Order Added to Your Cart !!!";
        }
        else
        {
             throw new NoSuchEntityException(
                __('Order doesn\'t belong to the current customer')
            );
        }

    }
}

   