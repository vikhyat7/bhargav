<?php

namespace Mageants\Reorder\Model\Resolver;

use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Exception\GraphQlAuthorizationException;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Magento\GraphQl\Model\Query\ContextInterface;
use Magento\Sales\Model\Reorder\Data\Error;
use Magento\Sales\Model\OrderFactory;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory;
use Magento\Framework\GraphQl\Exception\GraphQlInputException;

/**
 * ReOrder customer order
 */
class AllReorder implements ResolverInterface
{
    /**
     * @var collectionFactory
     */
    private $collectionFactory;
    /**
     * customer id
     */
    private const ARGUMENT_CUSTOMER_ID = 'customerId';

    /**
     * @var OrderFactory
     */
    private $orderFactory;

    /**
     * @var \Magento\Sales\Model\Reorder\Reorder
     */
    private $reorder;

    /**
     * @param \Magento\Sales\Model\Reorder\Reorder $reorder
     * @param OrderFactory $orderFactory
     */
    public function __construct(
        CollectionFactory $collectionFactory,
        \Magento\Sales\Model\Reorder\Reorder $reorder,
        OrderFactory $orderFactory
    ) {
        $this->orderFactory = $orderFactory;
        $this->collectionFactory = $collectionFactory;
        $this->reorder = $reorder;
    }

    /**
     * @inheritDoc
     */
    public function resolve(
        Field $field,
        $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null
    ) {

        $customerId = $args['customerId'] ?? '';
        

        $customerOrder = $this->collectionFactory->create()
            ->addFieldToFilter('customer_id', $customerId);

        
        foreach($customerOrder as $user) 
            {
                $ids[] = $user['increment_id'];
            }
            
          $entity1 = $ids;
        // return $entity1;
        foreach($entity1 as $order1)
        {
            $order = $this->orderFactory->create()->loadByIncrementId($order1);
            $storeId = $order->getStoreId();
            $reorderOutput = $this->reorder->execute($order1,$storeId);
        }
        return [
                    'cart' => [
                        'model' => $reorderOutput->getCart(),
                    ],
                    'userInputErrors' => \array_map(
                        function (Error $error) {
                            return [
                                'path' => [self::ARGUMENT_CUSTOMER_ID],
                                'code' => $error->getCode(),
                                'message' => $error->getMessage(),
                            ];
                        },
                        $reorderOutput->getErrors()
                    )
                ];
        
        // return "saved";
    }
}
