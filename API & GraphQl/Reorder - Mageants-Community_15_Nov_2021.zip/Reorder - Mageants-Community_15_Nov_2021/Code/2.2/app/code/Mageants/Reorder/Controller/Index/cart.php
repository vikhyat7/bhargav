<?php
/**
  * @category   Mageants Reorder
  * @package    Mageants_Reorder
  * @copyright  Copyright (c) 2017 Mageants
  * @author     Mageants Team <support@Mageants.com>
  */

namespace Mageants\Reorder\Controller\Index;
 
use Magento\Framework\App\Action\Context;
 
/**
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Cart extends \Magento\Framework\App\Action\Action
{   
    /**@var ProductRepositoryInterface*/
    protected $_productRepository;
    /**@var Cart*/
    protected $_cart;
    /**@var FormKey*/
    protected $formKey;
    /**
    * @param \Magento\Catalog\Model\ProductRepository $productRepository,
    * @param \Magento\Checkout\Model\Cart $cart, 
    * @param \Magento\Framework\Data\Form\FormKey $formKey
    */
    public function __construct(Context $context,
        \Magento\Catalog\Model\ProductRepository $productRepository,
        \Magento\Checkout\Model\Cart $cart, 
        \Magento\Framework\Data\Form\FormKey $formKey,
        \Magento\Framework\Serialize\Serializer\Json $serializer,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Mageants\Reorder\Helper\Data $helper
      )
    {
        $this->_productRepository = $productRepository;
        $this->_cart = $cart;
        $this->formKey = $formKey;
        $this->_helper = $helper;
        $this->_storeManager = $storeManager;
        $this->serializer = $serializer;
        parent::__construct($context);
    }
     /**
     * Add product to shopping cart action
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
 
    public function execute()
    {
        
        if(!$this->getRequest()->getPost('product'))
            {
             $this->messageManager->addWarning(__('Please select any product.'));
             return $this->resultRedirectFactory->create()->setPath('reorder');
            }
            try
            {
                $superattribute=[];
                $_reqQty = $this->getRequest()->getPost('qty');
                $productPrevBuyInfo =$this->getRequest()->getPost('productPrevBuyInfo');
                if($this->getRequest()->getPost('superattribute')){
                        $superattribute = $this->getRequest()->getPost('superattribute');
                }
                $parentProduct = $this->getRequest()->getPost('parent_product');

                foreach ($this->getRequest()->getPost('product') as $key => $option) {
                    if($superattribute!=null){
                    $allattributes=null;$parentProducts=null;
                    if(array_key_exists($key, $superattribute)){
                        $allattributes = unserialize($superattribute[$key]);
                     }
                    }
                

                    if($option){
                    
                    $params=unserialize(base64_decode($productPrevBuyInfo[$key])); 
                    $product = $this->_productRepository->getById($key);
                    if($parentProduct!=null){
                    if(array_key_exists($key, $parentProduct)){
                        $parentProducts = $this->_productRepository->getById($parentProduct[$key]);    
                        $params =array('product'=>$parentProduct[$key],'super_attribute'=>$allattributes, 'qty'=>1);
                      }
                    }
                    $parentProducts = ($parentProducts != null) ? $parentProducts : $product;
                    if (!$product) {
                        return $this->goBack();
                    }
                    
                    $params['info_buyRequest']['qty']= $_reqQty[$key];
                    
                    $this->_cart->addProduct($parentProducts, $params);
                    }
                                
                }
                 $this->_cart->save();

                $this->messageManager->addSuccess(__('Add to cart successfully.'));

                 
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                 $this->messageManager->addException(
                     $e,
                     __('%1', $e->getMessage())
                 );
            } catch (\Exception $e) {
                 $this->messageManager->addException($e, $e->getMessage());
            }
             if($this->_helper->getAllowToCartPage()==1){
             $this->_redirect('checkout/cart/index');
             return;
         }else{
            return $this->resultRedirectFactory->create()->setPath('reorder');
            //$this->_redirect($this->_storeManager->getStore()->getBaseUrl().'reorder');
            
            
         }     

    }
}