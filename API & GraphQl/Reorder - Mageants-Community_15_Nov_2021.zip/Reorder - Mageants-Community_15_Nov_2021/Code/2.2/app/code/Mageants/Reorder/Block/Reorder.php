<?php
/**
  * @category   Mageants Reorder
  * @package    Mageants_Reorder
  * @copyright  Copyright (c) 2017 Mageants
  * @author     Mageants Team <support@Mageants.com>
  */

namespace Mageants\Reorder\Block;

 //use Magento\CatalogInventory\Model\Stock\StockItemRepository;
 
class Reorder extends \Magento\Framework\View\Element\Template
{
    /** @var \Magento\Sales\Model\ResourceModel\Order\CollectionFactory */
    protected $_orderCollectionFactory;
    /** @var \Magento\Sales\Model\ResourceModel\Order\Collection */
    protected $orders;
    /** @var \Magento\Customer\Model\Session */
    protected $customerSession;
    /** @var \Magento\Sales\Api\OrderRepositoryInterface */
    protected $orderRepository;
    /**
     * helper
     *
     * @var  \Mageants\Faq\Helper\Data
     */
    protected $_helper;
    /**
      * @param \Magento\Framework\View\Element\Template\Context $context
      * @param \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory
      * @param \Magento\Customer\Model\Session $customerSession
      * @param \Magento\Sales\Api\OrderRepositoryInterface $orderRepository
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context, 
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory,
        \Magento\Customer\Model\SessionFactory $customerSession,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        \Magento\ConfigurableProduct\Model\ResourceModel\Product\Type\Configurable $configurable,
        \Magento\Catalog\Model\Product $product,
        \Magento\Eav\Model\Config $eavConfig,
        \Magento\Framework\Serialize\Serializer\Json $serializer,
        \Magento\Framework\App\ProductMetadata $productMetadata,
        \Magento\Catalog\Helper\Image $imageHelper,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Magento\CatalogInventory\Api\StockStateInterface $stockState,
        \Mageants\Reorder\Helper\Data $helper,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productcollection,
        array $data = []
    ) {
          $this->_orderCollectionFactory = $orderCollectionFactory;   
          $this->customerSession = $customerSession; 
          $this->orderRepository = $orderRepository;
          $this->configurable = $configurable;
          $this->product = $product;
          $this->eavConfig = $eavConfig;
          $this->serializer = $serializer;
          $this->productMetadata = $productMetadata;
          $this->imageHelper = $imageHelper;
          $this->productRepository = $productRepository;
          $this->stockState = $stockState;
          $this->_helper = $helper;
          $this->_productCollection = $productcollection;
          parent::__construct($context, $data);        
    }

    /**
     * @return bool|\Magento\Sales\Model\ResourceModel\Order\Collection
    */
    protected function _prepareLayout()
    { 
         parent::_prepareLayout();
        if ($this->getAllOrders()) {
        $pager = $this->getLayout()->createBlock(
            'Magento\Theme\Block\Html\Pager',
            'reorder_pager'
        )->setAvailableLimit(array(10=>10,15=>15,20=>20))->setShowPerPage(true)->setCollection(
            $this->getAllOrders()
        );
        $this->setChild('pager', $pager);
         $this->getAllOrders()->load();
    }
    return $this;
    }
    public function getPagerHtml()
    {
        return $this->getChildHtml('pager');
    }

    public function getTotalQty()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customer = $objectManager->create('Magento\Customer\Model\SessionFactory')->create();
        $customreid = $customer->getCustomer()->getId(); 
        $orders = $this->_orderCollectionFactory->create()
        ->addFieldToFilter('customer_id',$customreid);

        $total_qty = array();
        foreach ($orders as $order) {
          $items = $order->getAllVisibleItems();
          foreach($items as $item):
                  $total_qty[] = $item->getProductId();
          endforeach;
      }
      return $total_qty; 
    }
    public function getAllOrders()
    {
      $page = ($this->getRequest()->getParam('p'))? $this->getRequest()->getParam('p') : 1;
      $pageSize = ($this->getRequest()->getParam('limit'))? $this->getRequest()->getParam('limit') : 10;
      $productsIds=$this->getTotalQty();
      $productCollection = $this->_productCollection->create()->addAttributeToSelect('*')
      ->addFieldToFilter('entity_id', array('in' => $productsIds));
      $productCollection->setCurPage($page);
      $productCollection->setPageSize($pageSize);
      
          
      return $productCollection;
    }
    public function getOrders() 
    {        
      $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
      $customer = $objectManager->create('Magento\Customer\Model\SessionFactory')->create();

      if (!$this->orders) {
          $this->orders = $this->_orderCollectionFactory->create()->addFieldToSelect(
              '*'
          )->addFieldToFilter(
              'customer_id',
              $customer->getCustomer()->getId()
          )->setOrder(
              'created_at',
              'desc'
          );
      }
      $proitems = [];
      $uniuqProductSkus= array();
      $version = str_replace(".", "", $this->getVersion());
      if((int)$version >= 222){
        foreach($this->orders as $order){
          $items = $order->getAllVisibleItems();
              foreach($items as $item):
                  if (in_array($item->getProduct()->getSku(), $uniuqProductSkus)) {
                  continue;
                  } else {
                    array_push($uniuqProductSkus, $item->getProduct()->getSku());
                    $proitems[]=$item;
                  }
              endforeach;
          }
          return $proitems;
      }

      
          foreach($this->orders as $order){

            $items = $order->getItems();

                foreach($items as $item):
                  $details = '';
                    $currentId = $item->getProduct()->getId();
                    $price = $item->getProduct()->getPrice();
                    $options = $item->getProductOptions();
                    if(isset($options['info_buyRequest'])){
                      $option =  $options['info_buyRequest'];
                     
                        $details= 'Qty: '.$option['qty'];
                        if(isset($option['super_attribute'])){
                            foreach ($option['super_attribute'] as $key => $attribute) {
                               $details.="<br/>".$item->getProduct()->getResource()->getAttribute($key)->getName().": ";
                               $attr = $item->getProduct()->getResource()->getAttribute($item->getProduct()->getResource()->getAttribute($key)->getName());
                                $optionText = $attr->getSource()->getOptionText($attribute);
                                $details.=$optionText;
                            }  
                        }
                        
                      }
                    
                    $product = $this->configurable->getParentIdsByChild($item->getProduct()->getId());
                    $sku = isset($product[0]) ? $this->product->load($product[0])->getSku() : $item->getProduct()->getSku();
                    $item = isset($product[0]) ? $this->product->load($product[0])->getId() : $item->getId();
                   // print_r($uniuqProductSkus);

                   
                      array_push($uniuqProductSkus, $sku);
                      $proitems[]=array('item'=>$item, 'detail'=>$details, 'current_product'=>$currentId, 'price'=>$price);
                   
                endforeach;
        }

      return $proitems;
    }
    

    public function getProduct($id=null){
       return $this->product->load($id);
    }

    public function getOptionId($attribute=''){
      $attribute = $this->eavConfig->getAttribute('catalog_product', $attribute);
      return  $attribute->getSource()->getAllOptions();
    }

    public function getCurrentProduct(){
      return $this->product;
    }

    public function getSerializer(){
      return $this->serializer;
    }

    public function getVersion(){
      return $this->productMetadata->getVersion();
    }

    public function getItemImage($productId)
    {
        try {
            $_product = $this->productRepository->getById($productId);
        } catch (NoSuchEntityException $e) {
            return 'product not found';
        }
        $image_url = $this->imageHelper->init($_product, 'product_base_image')->getUrl();

        return $image_url;
    }

    public function getStockItem($productId)
    {
        return $this->stockState->getStockQty($productId);
    }

    
    public function isEnable()
    {
      return $this->_helper->getisEnable();
    }
    public function getShowPagination()
    {
        
        return $this->_helper->getShowPagination();
    }
    public function getShowHideCollumn()
    {
      return $this->_helper->getShowHideCollumn();
    }
    public function getShowSearchBox()
    {
        
       return $this->_helper->getShowSearchBox();
    }
    public function getConfig()
    {
        return [
            'baseUrl' => $this->getBaseUrl()
        ];
    }

    /**
     * @return string
     */
    public function getBaseUrl()
    {
        return $this->_storeManager->getStore()->getBaseUrl();
    }
    public function getShowSku()
    {
        return $this->_helper->getShowSku();
    }
    public function getShowQuickviewButton()
    {
        return $this->_helper->getShowQuickviewButton();
    }
    public function getDisplayCollumn()
    {
        return $this->_helper->getDisplayCollumn();
    }
}