<?php

namespace Mageants\Reorder\Model;

use Mageants\Reorder\Api\SingleItemReorderRepositoryInterface;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;


class SingleItemReorderRepository implements SingleItemReorderRepositoryInterface

{
    /**
     * Quote repository.
     *
     * @var CartRepositoryInterface
     */
    protected $quoteRepository;
     
    /**
     *  Order repository.
     *
     * @var OrderRepositoryInterface
     */
    protected $orderRepository;
    
    /**
     * @var SearchCriteriaBuilder
     */
    protected $SearchCriteriaBuilder;
    
    /**
     * @param SearchCriteriaBuilder $SearchCriteriaBuilder
    */
  

    /**
     * @param CartRepositoryInterface $quoteRepository
     */
    public function __construct(
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        SearchCriteriaBuilder $SearchCriteriaBuilder,
        CartRepositoryInterface $quoteRepository
    ) {
        $this->orderRepository = $orderRepository;
        $this->SearchCriteriaBuilder = $SearchCriteriaBuilder;
        $this->quoteRepository = $quoteRepository;
        
    }

    

    /**
     * @inheritdoc
     * @param int $customerId
     * @param string $orderId
     */
    public function save(\Magento\Quote\Api\Data\CartItemInterface $OrderItem, $customerId, $orderId)
    {
        /** @var \Magento\Quote\Model\Quote $quote */
       

         $items1 = array();
        $this->customerId = $customerId;
        $searchCriteria1 = $this->SearchCriteriaBuilder
                ->addFilter('increment_id', $orderId )->create();
    
    

     $Oid = $this->orderRepository->getList($searchCriteria1);

            foreach($Oid as $orderData)
                {

                $items1['entity_id'] =  $orderData->getId();
                // $items1['increment_id'] =  $orderData->getIncrementId();
                $items1['quote_id'] =  $orderData->getQuoteId();
                
                }
            $order1 = $items1['entity_id'];
            $orderQuote = $items1['quote_id'];

            // return $order1;

            $order = $this->orderRepository->get($order1);
            
            $cus = $order->getCustomerId();
            
        $sku1 = $OrderItem->getSku();
        $qty1 = $OrderItem->getQty();
        $cartId = $orderQuote;
        // return $cartId;
        if (!$sku1) {
             return "Sku is required. Enter and try again.";
        }

    if($cus == $customerId)
    {

        
    $items = $order->getItemsCollection()->addFieldToFilter("sku",$sku1)->getData();
      if($items){
       foreach ($items as $item)
       {    
    
        $quote = $this->quoteRepository->getActiveForCustomer($customerId);
        $quoteItems = $quote->getItems();
        
        $quoteItems[] = $OrderItem;
        // return $quoteItems;
        $quote->setItems($quoteItems);
        $this->quoteRepository->save($quote);
        $quote->collectTotals();
        return $quote->getLastAddedItem();
       }
   }else
   {
        return "Requested product is not in your order!!!!!!";
   }

    }
    else
    {
        
        return "Requested Order-Id doesn't match with your previous Orders!!!!!!";   
    }
            
       
    }

   
}