<?php
/**
* @category Mageants EventManager
* @package Mageants_EventManager
* @copyright Copyright (c) 2019 Mageants
* @author Mageants Team <support@mageants.com>
*/
namespace Mageants\Reorder\Model\Config\Source;

/**
 * Stores Class return array
 */ 
class Selectcolumn extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{
    /**
     * @return Array
     */
    public function getAllOptions()
    {
       return [
            ['value' => 'image','label' => __('Image')],
            ['value' => 'productdetails','label' => __('Product Details')],
            ['value' => 'orderprice','label' => __('Ordered Price')],
            ['value' => 'qty','label' => __('Qty')],
            ['value' => 'orderedqty','label' => __('Ordered Qty')],
            ['value' => 'ordereddate','label' => __('Ordered Date')],
            ['value' => 'stockstatus','label' => __('Stock Status')],
            ['value' => 'addtocart','label' => __('Add to Cart')],
        ];
    }
}
