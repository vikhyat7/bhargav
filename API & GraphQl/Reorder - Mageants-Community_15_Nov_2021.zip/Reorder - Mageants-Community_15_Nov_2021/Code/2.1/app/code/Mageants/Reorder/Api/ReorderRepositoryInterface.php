<?php

namespace Mageants\Reorder\Api;

use Magento\Quote\Model\Quote;

interface ReorderRepositoryInterface
{
    /**
    * Return Create reorder.
    *
    * @param int $customerId
    * @param string $orderId
    * @return Mageants\Reorder\Api\ReorderRepositoryInterface
    */

   public function reorderItem($customerId, $orderId);
}