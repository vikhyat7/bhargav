var config = {
    'map': {
        '*': {
            'magnificPopup': 'Mageants_Reorder/js/jquery.magnific-popup.min',            
            'mageants_quickview': 'Mageants_Reorder/js/mageants_quickview',
            'datatables': 'Mageants_Reorder/js/datatables.min'
            /*'Magento_Swatches/js/swatch-renderer': 'Mageants_QuickView/js/swatch-renderer',*/
        }
    },
    shim: {
        'magnificPopup': {
            deps: ['jquery']
        }
    },
    shim: {
        'mageants_quickview': {
            deps: ['jquery']
        }
    },
    shim: {
        'datatables': {
            deps: ['jquery']
        }
    }
};