<?php

namespace Mageants\Reorder\Api;

use Magento\Quote\Model\Quote;

interface AllOrderInterface
{
    /**
    * Return Create reorder.
    *
    * @param int $customerId
    * @return Mageants\Reorder\Api\AllOrderInterface
    */

   public function reorderItem($customerId);

}