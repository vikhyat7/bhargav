<?php
 /**
  * @category   Mageants Reorder
  * @package    Mageants_Reorder
  * @copyright  Copyright (c) 2017 Mageants
  * @author     Mageants Team <support@Mageants.com>
  */
 
namespace Mageants\Reorder\Controller\Index;
 
use Magento\Framework\App\Action\Context;
 
class Index extends \Magento\Framework\App\Action\Action
{   
    /** @var \Magento\Framework\View\Result\PageFactory */
    protected $_resultPageFactory;
    /** @var \Magento\Framework\App\Config\ScopeConfigInterface */
    protected $scopeConfig;

    /**
    * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
    * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
    */
    public function __construct(
      Context $context, 
      \Magento\Framework\View\Result\PageFactory $resultPageFactory,
      \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
      \Magento\Customer\Model\Session $customerSession
      ) {
        $this->_resultPageFactory = $resultPageFactory;
        $this->scopeConfig = $scopeConfig;
        $this->customerSession = $customerSession;
        parent::__construct($context);
      }
    /**
     * Reorder Page
     *
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        if($this->scopeConfig->getValue('reorder_section/reorder_general/reorder_enable', \Magento\Store\Model\ScopeInterface::SCOPE_STORE) == 0){
          return $this->_forward('index', 'noroute', 'cms');

        }
        
        if(!$this->customerSession->isLoggedIn()) {
            $this->_redirect('customer/account/login');

        }
        $this->_view->loadLayout();
        $this->_view->getLayout()->initMessages();
        $this->_view->renderLayout();
    }
}