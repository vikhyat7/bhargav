<?php
/**
* @category Mageants EventManager
* @package Mageants_EventManager
* @copyright Copyright (c) 2019 Mageants
* @author Mageants Team <support@mageants.com>
*/
namespace Mageants\Reorder\Helper;
use Magento\Store\Model\ScopeInterface;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * scope config
     *
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $_scopeConfig;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * faq collection
     *
     * @var \Mageants\Faq\Model\Category
     */
    protected $_faqCollection;
    
    /**
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager,
     * @param \Mageants\Faq\Model\Category $faqCollection
     */
    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    ) {
        $this->_scopeConfig = $scopeConfig;
        $this->_storeManager = $storeManager;
    }
	

	public function isEnable()
	{
		$modulestates = $this->_scopeConfig->getValue('reorder_section/reorder_general/reorder_enable', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        return $modulestates;
    }
    public function getShowPagination()
    {
        
        $pagination = $this->_scopeConfig->getValue('reorder_section/reorder_general/reorder_pagination', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        return $pagination;
    }
    public function getShowHideCollumn()
    {
        
        $showhidecollumn = $this->_scopeConfig->getValue('reorder_section/reorder_general/reorder_showhidecollumn', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        return $showhidecollumn;
    }
    public function getShowSearchBox()
    {
        
        $showsearchbox = $this->_scopeConfig->getValue('reorder_section/reorder_general/reorder_searchbox', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        return $showsearchbox;
    }
    public function getShowSku()
    {
        
        $showstockstates = $this->_scopeConfig->getValue('reorder_section/reorder_general/reorder_product_sku', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        return $showstockstates;
    }
    public function getShowQuickviewButton()
    {
        
        $showstockstates = $this->_scopeConfig->getValue('reorder_section/reorder_general/reorder_quickview_button', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        return $showstockstates;
    }
    public function getAllowToCartPage()
    {
        
        $showstockstates = $this->_scopeConfig->getValue('reorder_section/reorder_general/allow_to_redirect_cart_page', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        return $showstockstates;
    }
    public function getDisplayCollumn()
    {
        
        $showstockstates = $this->_scopeConfig->getValue('reorder_section/reorder_general/reorder_multiselect', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        return $showstockstates;
    }

	
	
}