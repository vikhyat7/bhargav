<?php
/**
  * @category   Mageants Reorder
  * @package    Mageants_Reorder
  * @copyright  Copyright (c) 2017 Mageants
  * @author     Mageants Team <support@Mageants.com>
  */

namespace Mageants\Reorder\Controller\Index;
 
use Magento\Framework\App\Action\Context;
 
/**
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Addcart extends \Magento\Framework\App\Action\Action
{   
    /**@var ProductRepositoryInterface*/
    protected $_productRepository;
    /**@var Cart*/
    protected $_cart;
    /**@var FormKey*/
    protected $formKey;
    /**
    * @param \Magento\Catalog\Model\ProductRepository $productRepository,
    * @param \Magento\Checkout\Model\Cart $cart, 
    * @param \Magento\Framework\Data\Form\FormKey $formKey
    */
    public function __construct(Context $context,
        \Magento\Catalog\Model\ProductRepository $productRepository,
        \Magento\Checkout\Model\Cart $cart, 
        \Magento\Framework\Data\Form\FormKey $formKey,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Mageants\Reorder\Helper\Data $helper
      )
    {
        $this->_productRepository = $productRepository;
        $this->_cart = $cart;
        $this->formKey = $formKey;
        $this->_helper = $helper;
        $this->_storeManager = $storeManager;
        parent::__construct($context);
    }
     /**
     * Add product to shopping cart action
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
 
    public function execute()
    {
        if(!$this->getRequest()->getPost('product'))
            {
             $this->messageManager->addWarning(__('Please select any product.'));
             return $this->resultRedirectFactory->create()->setPath('reorder');
            }
            try
            {
                $_reqQty = $this->getRequest()->getPost('qty');
                
                $productPrevBuyInfo =$this->getRequest()->getPost('productPrevBuyInfo');
                foreach ($this->getRequest()->getPost('product') as $key => $option) {

                    if($option){
                    
                    $params = unserialize(base64_decode($productPrevBuyInfo[$key])); 
                    $product = $this->_productRepository->getById($key);

                    if (!$product) {
                        return $this->goBack();
                    }

                    $params['info_buyRequest']['qty']= $_reqQty[$key];
                   
                    $this->_cart->addProduct($product, $params['info_buyRequest']);
                    }
                                
                }
                 $this->_cart->save();

                $this->messageManager->addSuccess(__('Add to cart successfully.'));

                

                 
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                 $this->messageManager->addException(
                     $e,
                     __('%1', $e->getMessage())
                 );
            } catch (\Exception $e) {
                 $this->messageManager->addException($e->getMessage(), __('Sorry, Right now we can\'t add product to cart.'));
            }

            if($this->_helper->getAllowToCartPage()==1){
             $this->_redirect('checkout/cart/index');
             return;
         }else{
            return $this->resultRedirectFactory->create()->setPath('reorder');
            //$this->_redirect($this->_storeManager->getStore()->getBaseUrl().'reorder');
            
            
         }   

    }
}