/**
 * Mageants QuickView Magento2 Extension 
 */
define([
    'jquery',
    'magnificPopup'
    ], function ($, magnificPopup) {
    "use strict";

    return {
        displayContent: function(prodUrl) {
            if (!prodUrl.length) {

                return false;
            }

           var url = window.reorder.baseUrl + 'reorder/index/updatecart';

            window.reorder.showMiniCartFlag = false;

            $.magnificPopup.open({
                items: {
                  src: prodUrl
                },
                type: 'iframe',
                closeOnBgClick: true,
                preloader: true,
                tLoading: '',
                callbacks: {
                    open: function() {
                      $('.mfp-preloader').show();
					  setTimeout(function(){ $('.mfp-close').show() }, 4000);
                    },
                    beforeClose: function() {
                        $('[data-block="minicart"]').trigger('contentLoading');
                        $.ajax({
                        url: url,
                        method: "POST"
                      });
                    },
                    close: function() {
                      $('.mfp-preloader').hide();
                    },
                 }
            });
        }
    };
});
