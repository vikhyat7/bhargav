<?php
namespace Mageants\Reorder\Api;

interface SingleItemReorderRepositoryInterface
{

    /**
     * Add/update the specified cart item.
     *
     * @param \Magento\Quote\Api\Data\CartItemInterface $OrderItem The item.
     * @param int $customerId
     * @param string $orderId
     * @return \Magento\Quote\Api\Data\CartItemInterface Item.
     * @throws \Magento\Framework\Exception\NoSuchEntityException The specified cart does not exist.
     * @throws \Magento\Framework\Exception\CouldNotSaveException The specified item could not be saved to the cart.
     * @throws \Magento\Framework\Exception\InputException The specified item or cart is not valid.
     */
    public function save(\Magento\Quote\Api\Data\CartItemInterface $OrderItem, $customerId, $orderId);

}
