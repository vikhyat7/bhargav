<?php
/**
 * @category Mageants QuickView
 * @package Mageants_QuickView
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <support@mageants.com>
 */

namespace Mageants\Reorder\Controller\Index;

class Updatecart extends \Magento\Framework\App\Action\Action
{
    public function execute()
    {
        if (!$this->getRequest()->isAjax()) {
            $this->_redirect('/');
            return;
        }
        $jsonData = json_encode(array('result' => true));
        $this->getResponse()->setHeader('Content-type', 'application/json');
        $this->getResponse()->setBody($jsonData);
    }
}
