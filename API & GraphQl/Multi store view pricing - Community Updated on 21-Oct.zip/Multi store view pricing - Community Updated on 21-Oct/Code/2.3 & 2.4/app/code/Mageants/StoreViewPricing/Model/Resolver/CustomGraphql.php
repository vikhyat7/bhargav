<?php
namespace Mageants\StoreViewPricing\Model\Resolver;
 
use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Exception\GraphQlInputException;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\GraphQl\Exception\GraphQlNoSuchEntityException;
use Mageants\StoreViewPricing\Model\PricingFactory;


 

class CustomGraphql implements ResolverInterface
{
    private $PricingFactory;
    
     protected $productRepository;


     public function __construct(
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        PricingFactory $PricingFactory
        )
     {
        $this->PricingFactory = $PricingFactory;
        
        $this->productRepository = $productRepository;

     }
    /**
     * @param Field $field
     * @param \Magento\Framework\GraphQl\Query\Resolver\ContextInterface $context
     * @param ResolveInfo $info
     * @param array|null $value
     * @param array|null $args
     * @return array|\Magento\Framework\GraphQl\Query\Resolver\Value|mixed
     * @throws GraphQlInputException
     */
    public function resolve(
        Field $field,
        $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null)
    {
        

        $skuData = $this->getProductSku($args);
        $productSku = $this->MySku($skuData);
        
        $ProId = $productSku;

         $insertData = $this->PricingFactory->create();
         $insertData->setEntityId($ProId)->save();
         $insertData->setPrice($args['price'])->save(); 
         $insertData->setStoreId($args['store_id'])->save(); 
         $insertData->setSpecialPrice($args['special_price'])->save(); 
         $insertData->setCost($args['cost'])->save(); 
         $insertData->setSpecialFromDate($args['special_from_date'])->save(); 
         $insertData->setSpecialToDate($args['special_to_date'])->save(); 
         $insertData->setMsrpDisplayActualPriceType($args['msrp_display_actual_price_type'])->save(); 
         $insertData->setMsrp($args['msrp'])->save(); 

         // return " New Store View Price (".$args['price'].") created for Product (" . $skuname . ") at store id (".$args['store_id'].") !!!!!";

         $output = [];
         // $output['entity_id'] = $args['entity_id'];
         $output['price'] = $args['price'];
         $output['store_id'] = $args['store_id'];
         $output['special_price'] = $args['special_price'];
         $output['cost'] = $args['cost'];
         $output['special_from_date'] = $args['special_from_date'];
         $output['special_to_date'] = $args['special_to_date'];
         $output['msrp_display_actual_price_type'] = $args['msrp_display_actual_price_type'];
         $output['msrp'] = $args['msrp'];
         
         return $output;
            

    }
         
        // return $productSku;
     /**
     * @param array $args
     * @return string
     * @throws GraphQlInputException
     */
    private function getProductSku(array $args): string
    {
        if (!isset($args['sku'])) {
            throw new GraphQlInputException(__('"sku should be specified'));
        }
 
        return (string)$args['sku'];
    }
     /**
     * @param array $sku
     * @return array
     * @throws GraphQlNoSuchEntityException
     */
    public function MySku( string $sku): string
    {
        $product = $this->productRepository->get($sku);
        
        $pageData = [
                
                'product_id' => $product->getId()
            ];



        $id = $pageData['product_id'];

        return $id;

    }

     
}