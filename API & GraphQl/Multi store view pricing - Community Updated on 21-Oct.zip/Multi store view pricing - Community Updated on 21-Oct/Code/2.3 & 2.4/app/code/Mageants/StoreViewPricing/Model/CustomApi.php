<?php 

namespace Mageants\StoreViewPricing\Model;
use Mageants\StoreViewPricing\Api\CustomInterface;
use Mageants\StoreViewPricing\Model\PricingFactory;

 
class CustomApi implements CustomInterface
{
   
     private $PricingFactory;
     protected $productRepository;

 
     public function __construct(
      \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        
         PricingFactory $PricingFactory
     ) {
        
         $this->PricingFactory = $PricingFactory;
         $this->productRepository = $productRepository;

     }


     public function getList($sku,$data)
     {
     	$product = $this->productRepository->get($sku);
        $id = $product->getId();
        $skuname = $product->getSku();

        // return $id;

     	$insertData = $this->PricingFactory->create();
         $insertData->setEntityid($id)->save();
         $insertData->setPrice($data['price'])->save(); 
         $insertData->setStoreId($data['store_id'])->save(); 
         $insertData->setSpecialPrice($data['special_price'])->save(); 
         $insertData->setCost($data['cost'])->save(); 
         $insertData->setSpecialFromDate($data['special_from_date'])->save(); 
         $insertData->setSpecialToDate($data['special_to_date'])->save(); 
         $insertData->setMsrpDisplayActualPriceType($data['msrp_display_actual_price_type'])->save(); 
        $insertData->setMsrp($data['msrp'])->save(); 

         return " New Store View Price (".$data['price'].") created for Product (" . $skuname . ") at store id (".$data['store_id'].") !!!!!";

        
     }

     

     		
          



}

