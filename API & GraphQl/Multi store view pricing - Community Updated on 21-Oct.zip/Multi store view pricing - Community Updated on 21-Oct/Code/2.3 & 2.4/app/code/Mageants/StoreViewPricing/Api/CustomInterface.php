<?php
namespace Mageants\StoreViewPricing\Api;
 
interface CustomInterface
{
    //  *
    //  * Insert data for Multi Store View
    //  * @param string[] $data 
    //  * @return string
     
    // public function insert($data);

     /**
     * Get info about product by product SKU
     *
     * @param string $sku
     * @param string[] $data 
     * @return string
     * @return \Magento\Catalog\Api\Data\ProductInterface
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getList($sku,$data);


}