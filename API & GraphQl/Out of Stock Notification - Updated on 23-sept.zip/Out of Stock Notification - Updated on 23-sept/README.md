# Out of Stock Notification

Current version number: 2.0.5
Date:- 08/10/2020
****************************************************************
New added
****************************************************************
- Out of stock product subscription email customer not receive product url in email, MageAnts team add product url in email and customer click on product url in email then it's redirect to particular product, Working fine in all Magento version.

****************************************************************
File list
****************************************************************
Mageants/OutofStockNotification/composer.json
Mageants/OutofStockNotification/etc/module.xml
Mageants/OutofStockNotification/Block/Product/Subscription
Mageants/OutofStockNotification/Controller/Index/Save
Mageants/OutofStockNotification/Helper/Data
Mageants/OutofStockNotification/view/frontend/layout/customer_account.xml
Mageants/OutofStockNotification/view/frontend/templates/notify.phtml
Mageants/OutofStockNotification/view/frontend/templates/Product/list.phtml

*****************************************************************************************************************************************************************************************

Current version number: 2.0.4
Date:- 20/08/2020
****************************************************************
Bug fixed
****************************************************************
- Notify block not display in configurable product in Magento2.3.5 version.
- When admin update quantity using csv file in backend then email not send to customer, Mageants resolved issue in all magento version.
- When customer subscribe any product then email send with particular product name.

****************************************************************
File list
****************************************************************
Mageants\OutofStockNotification\composer.json
Mageants\OutofStockNotification\etc\module.xml
Mageants\OutofStockNotification\etc\di.xml
Mageants\OutofStockNotification\Helper\ConfigurableProduct\Data.php
Mageants\OutofStockNotification\view\frontend\templates\Product\customize.phtml
Mageants\OutofStockNotification\view\frontend\templates\Product\list.phtml
Mageants\OutofStockNotification\Helper\Data.php
Mageants\OutofStockNotification\etc\adminhtml\events.xml
Mageants\OutofStockNotification\Observer\Adminhtml\CatalogProductImportBunchSaveAfter.php
Mageants\OutofStockNotification\view\frontend\email\subscription_mail.html
Mageants\OutofStockNotification\Controller\Index\Save.php
Mageants\OutofStockNotification\Block\Product\Subscription.php
Mageants\OutofStockNotification\view\frontend\templates\subscription.phtml

*****************************************************************************************************************************************************************************************

Current version number: 2.0.3
Date:- 11/02/2020
****************************************************************
Bug fixed
****************************************************************
- Mageants out of stock notification extension not working store wise, Mageants make compatible and now it's working in multistore as well.
- In Backend default template given by mageants sometimes not loaded properly, Mageants solved issue now it's working fine in all magento version
****************************************************************
File list
****************************************************************
- OutofStockNotification/Helper/Data.php
- OutofStockNotification/Observer/Adminhtml/Notify.php
- Mageants/OutofStockNotification/view/frontend/email/mageants_notify_template.html
- Mageants/OutofStockNotification/view/frontend/email/mageants_qty_notify.html
- Mageants/OutofStockNotification/view/frontend/email/notifyadmin.html
- Mageants/OutofStockNotification/view/frontend/email/subscription_mail.html
- Mageants/OutofStockNotification/etc/module.xml
- Mageants/OutofStockNotification/composer.json

*****************************************************************************************************************************************************************************************

Current version number: 2.0.2
Date:- 22/01/2020
****************************************************************
Bug fixed
****************************************************************
- When admin create email template in back-end and created email template select in out of stock configuration than out of stock product email send to customer from default template not new created template, Now issue solve and working fine in all magento version.

****************************************************************
File list
****************************************************************
Mageants/OutofStockNotification/etc/module.xml
Mageants/OutofStockNotification/composer.json
Mageants/OutofStockNotification/Controller/Index/Save.php
Mageants/OutofStockNotification/Helper/Data.php
Mageants/OutofStockNotification/Observer/Adminhtml/Notify.php
Mageants/OutofStockNotification/Cron/Notification.php

*****************************************************************************************************************************************************************************************

Current version number: 2.0.1
Date:- 27/11/2019
****************************************************************
Bug fixed
****************************************************************
- When All simple products of configurable product are out of stock, then e-mail subscription textbox not display.
- When product back in stock then email notification send when cron run, Now when product back in stock then directly email notification send to customer.

****************************************************************
File list
****************************************************************

app/code/Mageants/OutofStockNotification/view/frontend/templates/notify.phtml
app/code/Mageants/OutofStockNotification/Cron/Notification.php
app/code/Mageants/OutofStockNotification/composer.json
app/code/Mageants/OutofStockNotification/etc/module.xml

*****************************************************************************************************************************************************************************************

Current version number: 2.0.0
Date:- 10/04/2019
****************************************************************
Bug fixes
****************************************************************
- Mageants release Out of Stock Notification extension, Extension working fine in all magento version.

*****************************************************************************************************************************************************************************************
