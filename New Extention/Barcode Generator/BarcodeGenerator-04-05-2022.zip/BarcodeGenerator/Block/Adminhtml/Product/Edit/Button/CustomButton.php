<?php 
namespace Mageants\BarcodeGenerator\Block\Adminhtml\Product\Edit\Button;

use Magento\Catalog\Block\Adminhtml\Product\Edit\Button\Generic;

class CustomButton extends Generic
{
    public function getButtonData()
    {
        return [
            'on_click' => "alert('it works')",
            'sort_order' => 100
        ];
    }
}