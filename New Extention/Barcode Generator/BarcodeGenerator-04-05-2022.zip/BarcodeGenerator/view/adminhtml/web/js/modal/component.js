define(['underscore', 
        'jquery', 
        'Magento_Ui/js/modal/modal-component',
        'Magento_Ui/js/form/element/abstract',
        'mage/url'
        ], function (_, $,Abstract, Modal, url) 
{
    'use strict';
  
    return Modal.extend(
    {
        saveData: function () 
        {
            this.applyData();
            var link = url.setBaseUrl('<?php /* @escapeNotVerified */ echo $block->getAdminBaseUrl();?>');
            // var link = url.build('barcodegenerator/index/custom');
            console.log('customUrl');
            console.log(link);

            var data = {
                'form_key': window.FORM_KEY,
                'data' : this.applied
            };

            $.ajax(
            {
                type: 'POST',
                url: ajaxUrl,
                data: data,
                showLoader: true
            }).done(function (xhr) 
            {
                if (xhr.error) 
                {
                    self.onError(xhr);
                }
            }).fail(this.onError);

            this.closeModal();
        },
    });
});