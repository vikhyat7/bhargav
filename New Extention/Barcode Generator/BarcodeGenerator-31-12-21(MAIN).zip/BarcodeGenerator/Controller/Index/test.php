<?php
namespace Mageants\BarcodeGenerator\Controller\Index;

class test extends \Magento\Framework\App\Action\Action
{
    
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $pageFactory
    ) {
        $this->pageFactory = $pageFactory;
        return parent::__construct($context);
    }
 
    public function execute()
    {
        // echo "called";exit;
        echo "<pre>";
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        // $collection = $objectManager->create(\Mageants\Practice\Model\ResourceModel\Post\CollectionFactory::class);
        $collection = $objectManager->create(\Mageants\BarcodeGenerator\Helper\Data::class);
        $Barcodecollection = $objectManager->create(\Mageants\BarcodeGenerator\Helper\BarcodeData::class);
        
        // var_dump(get_class_methods($collection));
        $ABC1 = $collection->isEnable();
        $ABC2 = $collection->barcodeType();
        $ABC3 = $collection->barcodePrefix();
        $ABC4 = $collection->barcodeAtrribute();
        $ABC5 = $collection->pdfPageWidth();
        $ABC6 = $collection->pdfPageHeight();
        $ABC7 = $collection->isLogoEnble();
        $ABC8 = $collection->logoImage();
        $ABC11 = $collection->descriptionAtrr();




        $ABC12 = $Barcodecollection->barcodeText(1);
        
        // $iparr = explode("," , $ABC11);

        

        var_dump($ABC1);
        var_dump($ABC2);
        var_dump($ABC3);
        var_dump($ABC4);
        var_dump($ABC5);
        var_dump($ABC6);
        var_dump($ABC7);
        var_dump($ABC8);
        var_dump($ABC11);
        var_dump($ABC12);
        
        
        // print_r($iparr);
        
        // return $this->pageFactory->create();
    }
}
