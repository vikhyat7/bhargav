<?php
/**
 * @category Mageants_Orderattachment
 * @package Mageants_Orderattachment
 * @copyright Copyright (c) 2022 Mageants
 * @author Mageants Team <support@mageants.com>
 */
namespace Mageants\Orderattachment\Controller\View;

use Magento\Sales\Controller\OrderInterface;

class Attachment extends \Magento\Sales\Controller\AbstractController\View implements OrderInterface
{
    
}
