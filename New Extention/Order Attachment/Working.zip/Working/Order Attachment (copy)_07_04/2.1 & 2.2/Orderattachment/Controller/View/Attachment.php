<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mageants\Orderattachment\Controller\View;

use Magento\Sales\Controller\OrderInterface;

class Attachment extends \Magento\Sales\Controller\AbstractController\View implements OrderInterface
{
    
}
