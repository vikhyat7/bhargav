var config = {
    map: {
        '*': {
            orderAttachment : 'Mageants_Orderattachment/js/order-attachment'
        }
    }
};
